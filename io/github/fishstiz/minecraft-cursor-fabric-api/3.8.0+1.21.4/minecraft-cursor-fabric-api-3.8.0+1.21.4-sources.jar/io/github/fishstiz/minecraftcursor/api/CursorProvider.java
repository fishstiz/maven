package io.github.fishstiz.minecraftcursor.api;

/**
 * An alternative to the {@link ElementRegistrar} approach to determine the cursor type directly from the implementing {@link net.minecraft.class_364}
 * <p>
 * Implement this directly to your element if Minecraft Cursor is a required dependency.
 * </p>
 *
 * <p>
 * <b>Note:</b> The {@link net.minecraft.class_364} must either be the current screen or be accessible from the current screen or
 * from its parent element through {@link net.minecraft.class_4069#method_25396()}.
 * </p>
 */
public interface CursorProvider {
    /**
     * Returns the cursor type to be applied when the mouse is over the element.
     * <p>
     * This method is invoked after screen render and when
     * {@link net.minecraft.class_364#method_25405(double mouseX, double mouseY)}
     * returns {@code true}
     * </p>
     *
     * @param mouseX the X coordinate of the mouse
     * @param mouseY the Y coordinate of the mouse
     * @return The {@link CursorType} to be applied.
     */
    CursorType getCursorType(double mouseX, double mouseY);
}
