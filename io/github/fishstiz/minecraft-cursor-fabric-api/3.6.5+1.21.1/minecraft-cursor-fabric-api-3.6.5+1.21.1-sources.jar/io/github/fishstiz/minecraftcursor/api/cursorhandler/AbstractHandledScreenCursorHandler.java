package io.github.fishstiz.minecraftcursor.api.cursorhandler;

import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.provider.HandledScreenCursorProvider;
import net.minecraft.class_1703;
import net.minecraft.class_465;


/**
 * An abstract class for handling cursor types in {@link class_465} elements.
 *
 * <p>Extend this class to help retain the behavior of the cursor type in the base {@link class_465}</p>
 *
 * @param <T> The type of {@link class_1703} associated with the {@link class_465} to be registered.
 * @param <U> The type of {@link class_465} itself.
 */
public abstract class AbstractHandledScreenCursorHandler<T extends class_1703, U extends class_465<? extends T>> implements CursorHandler<U> {
    /**
     * Returns the computed {@link CursorType} of the base {@link class_465}.
     *
     * <p>Override this method in a subclass to implement custom logic for calculating the cursor type of
     * the {@link class_465} element.</p>
     *
     * <p>After evaluating the cursor type in the subclass, you can invoke and return
     * {@code super.getCursorType(handledScreen, mouseX, mouseY} to return the cursor type of the base {@link class_465}</p>
     *
     * @param handledScreen The {@link class_465} element.
     * @param mouseX        The X-coordinate of the mouse cursor.
     * @param mouseY        The Y-coordinate of the mouse cursor.
     * @return The computed cursor type of the base {@link class_465}.
     */
    @Override
    public CursorType getCursorType(U handledScreen, double mouseX, double mouseY) {
        return HandledScreenCursorProvider.getCursorType();
    }
}
