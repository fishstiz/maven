package io.github.fishstiz.minecraftcursor.gui.widget;

import org.jetbrains.annotations.NotNull;

import static io.github.fishstiz.minecraftcursor.util.SettingsUtil.clamp;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4265;
import net.minecraft.class_8030;

public abstract class AbstractListWidget<E extends AbstractListWidget<E>.Entry> extends class_4265<E> {
    public static final int DEFAULT_HEADER_HEIGHT = -4; // removes offsets in AbstractSelectionList
    protected final int rowGap;

    protected AbstractListWidget(class_310 minecraft, int width, int y, int height, int itemHeight) {
        super(minecraft, width, y, height, itemHeight, DEFAULT_HEADER_HEIGHT);

        this.rowGap = 0;
    }

    protected AbstractListWidget(class_310 minecraft, int width, int y, int height, int itemHeight, int rowGap) {
        super(minecraft, width, y, height, itemHeight + rowGap, DEFAULT_HEADER_HEIGHT);

        this.rowGap = rowGap;
    }

    @Override
    protected void method_25311(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int left = this.method_25342();
        int width = this.method_25322();

        for (int i = 0; i < this.method_25340(); i++) {
            int top = this.method_25337(i);
            int bottom = this.method_25319(i);
            if (bottom >= this.method_46427() && top <= this.method_55443()) {
                this.method_44397(guiGraphics, mouseX, mouseY, partialTick, i, left, top, width, this.field_22741);
            }
        }
    }

    @Override
    public int method_44390() {
        return Math.max(0, super.method_44390() - this.rowGap);
    }

    public void setClampedScrollAmount(double scrollAmount) {
        this.method_44382(clamp(scrollAmount, 0d, this.method_44390()));
    }

    public void clampScrollAmount() {
        this.setClampedScrollAmount(this.method_44387());
    }

    @Override
    protected int method_65507() {
        return this.method_55442() - field_55258;
    }

    @Override
    public int method_25322() {
        return this.method_44392() ? this.method_25368() - field_55258 : this.method_25368();
    }

    @Override
    public int method_25342() {
        return this.method_46426();
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        this.clampScrollAmount();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        this.clampScrollAmount();
    }

    protected abstract class Entry extends class_4265.class_4266<E> implements ElementView {
        private final int index;

        protected Entry(int index) {
            this.index = index;
        }

        protected Entry() {
            this(AbstractListWidget.this.method_25396().size());
        }

        @Override
        public int getX() {
            return AbstractListWidget.this.method_25342();
        }

        @Override
        public int getY() {
            return AbstractListWidget.this.method_25337(this.index);
        }

        @Override
        public int getWidth() {
            return AbstractListWidget.this.method_25322();
        }

        @Override
        public int getHeight() {
            return AbstractListWidget.this.field_22741 - AbstractListWidget.this.rowGap;
        }

        @Override
        public @NotNull class_8030 method_48202() {
            return ElementView.super.method_48202();
        }
    }
}
