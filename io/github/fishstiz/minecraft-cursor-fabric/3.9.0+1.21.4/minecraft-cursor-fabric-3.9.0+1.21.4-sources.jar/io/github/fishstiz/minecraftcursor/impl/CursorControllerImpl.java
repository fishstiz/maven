package io.github.fishstiz.minecraftcursor.impl;

import io.github.fishstiz.minecraftcursor.cursor.CursorManager;
import net.minecraft.class_156;
import io.github.fishstiz.minecraftcursor.api.CursorController;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import org.jetbrains.annotations.Nullable;

public final class CursorControllerImpl implements CursorController {
    private static final long TRANSIENT_EXPIRE_MS = 100; // 5 ticks
    private CursorType singleCycleCursor;
    private long timestamp = 0;

    public boolean hasTransientCursor() {
        if (singleCycleCursor != null) {
            if (class_156.method_658() - timestamp < TRANSIENT_EXPIRE_MS) {
                return true;
            }
            singleCycleCursor = null;
        }
        return false;
    }

    public @Nullable CursorType consumeTransientCursor() {
        CursorType cursorType = singleCycleCursor;
        singleCycleCursor = null;
        return cursorType;
    }

    @Override
    public void setSingleCycleCursor(CursorType cursorType) {
        this.singleCycleCursor = cursorType;
        this.timestamp = class_156.method_658();
    }

    @Override
    public void overrideCursor(CursorType cursorType, int index) {
        CursorManager.INSTANCE.overrideCurrentCursor(cursorType, index);
    }

    @Override
    public void removeOverride(int index) {
        CursorManager.INSTANCE.removeOverride(index);
    }
}
