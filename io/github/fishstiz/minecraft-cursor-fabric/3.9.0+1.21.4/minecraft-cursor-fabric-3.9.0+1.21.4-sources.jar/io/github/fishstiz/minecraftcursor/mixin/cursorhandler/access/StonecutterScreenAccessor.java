package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_3971;
import net.minecraft.class_3979;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3979.class)
public interface StonecutterScreenAccessor extends HandledScreenAccessor<class_3971> {
    @Accessor("startIndex")
    int getScrollOffset();
}