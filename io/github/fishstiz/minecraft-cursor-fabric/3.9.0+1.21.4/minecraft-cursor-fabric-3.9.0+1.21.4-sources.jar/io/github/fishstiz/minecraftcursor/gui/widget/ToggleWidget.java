package io.github.fishstiz.minecraftcursor.gui.widget;

import org.jetbrains.annotations.NotNull;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

public class ToggleWidget extends class_4185 {
    private final BiConsumer<ToggleWidget, Boolean> listener;
    private final class_2561 prefix;
    private boolean value;

    public ToggleWidget(
            int x,
            int y,
            int width,
            int height,
            boolean value,
            @NotNull class_2561 prefix,
            @NotNull BiConsumer<ToggleWidget, Boolean> listener
    ) {
        super(x, y, width, height, prefix, class_4185::method_25306, field_40754);

        this.listener = listener;
        this.prefix = prefix;

        this.setValue(value);
    }

    public ToggleWidget(boolean value, @NotNull class_2561 prefix, @NotNull BiConsumer<ToggleWidget, Boolean> listener) {
        this(0, 0, field_39500, field_39501, value, prefix, listener);
    }

    public ToggleWidget(boolean value, @NotNull class_2561 prefix, @NotNull Consumer<Boolean> listener) {
        this(0, 0, field_39500, field_39501, value, prefix, (target, v) -> listener.accept(v));
    }

    @Override
    public void method_25306() {
        this.value = !this.value;
        this.listener.accept(this, this.value);
        this.updateMessage();
    }

    public void setValue(boolean value) {
        this.value = value;
        this.updateMessage();
    }

    private void updateMessage() {
        this.method_25355(this.prefix.method_27661().method_27693(": ").method_10852(value ? class_5244.field_24332 : class_5244.field_24333));
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        this.method_25365(false);
    }
}
