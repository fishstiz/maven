package io.github.fishstiz.minecraftcursor.cursor.handler.world;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_528;

public class WorldListWidgetCursorHandler implements CursorHandler<class_528> {
    @Override
    public CursorType getCursorType(class_528 worldListWidget, double mouseX, double mouseY) {
        if (!MinecraftCursor.CONFIG.isWorldIconEnabled()) return CursorType.DEFAULT;

        int x = (int) Math.floor((double) worldListWidget.method_25368() / 2 - (double) worldListWidget.method_25322() / 2);
        for (class_528.class_7414 entry : worldListWidget.method_25396()) {
            if (entry.method_25405(mouseX, mouseY) && mouseX >= x && mouseX <= x + 32 && ((class_528.class_4272) entry).method_54629()) {
                return CursorType.POINTER;
            }
        }
        return CursorType.DEFAULT;
    }
}
