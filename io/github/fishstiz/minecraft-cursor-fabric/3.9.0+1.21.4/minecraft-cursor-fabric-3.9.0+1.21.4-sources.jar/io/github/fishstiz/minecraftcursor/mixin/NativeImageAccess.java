package io.github.fishstiz.minecraftcursor.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.nio.channels.WritableByteChannel;
import net.minecraft.class_1011;

@Mixin(class_1011.class)
public interface NativeImageAccess {
    @Invoker("writeToChannel")
    boolean invokeWriteToChannel(WritableByteChannel channel);
}
