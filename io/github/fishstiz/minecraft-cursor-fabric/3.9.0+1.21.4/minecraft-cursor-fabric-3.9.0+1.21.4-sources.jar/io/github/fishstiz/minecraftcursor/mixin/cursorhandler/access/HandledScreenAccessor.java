package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_465.class)
public interface HandledScreenAccessor<T extends class_1703> {
    @Accessor("imageWidth")
    int getBackgroundWidth();

    @Accessor("imageHeight")
    int getBackgroundHeight();

    @Accessor("menu")
    T getHandler();

    @Accessor("hoveredSlot")
    class_1735 getFocusedSlot();

    @Accessor("leftPos")
    int getX();

    @Accessor("topPos")
    int getY();

    @Invoker("isHovering")
    boolean invokeIsPointWithinBounds(int x, int y, int width, int height, double pointX, double pointY);
}
