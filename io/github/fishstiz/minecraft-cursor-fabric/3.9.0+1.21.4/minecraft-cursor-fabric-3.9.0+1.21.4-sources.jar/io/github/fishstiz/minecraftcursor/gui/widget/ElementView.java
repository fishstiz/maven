package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_364;
import net.minecraft.class_8030;
import org.jetbrains.annotations.NotNull;

public interface ElementView extends class_364 {
    int getX();

    int getY();

    int getWidth();

    int getHeight();

    default int getRight() {
        return this.getX() + this.getWidth();
    }

    default int getBottom() {
        return this.getY() + this.getHeight();
    }

    @Override
    default @NotNull class_8030 method_48202() {
        return new class_8030(this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
}
