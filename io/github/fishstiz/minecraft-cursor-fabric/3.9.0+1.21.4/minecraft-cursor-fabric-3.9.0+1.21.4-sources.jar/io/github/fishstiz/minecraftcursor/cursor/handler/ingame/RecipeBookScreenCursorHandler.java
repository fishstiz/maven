package io.github.fishstiz.minecraftcursor.cursor.handler.ingame;

import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.RecipeAlternativesWidgetAccessor;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.RecipeBookResultsAccessor;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.RecipeBookScreenAccessor;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.RecipeBookWidgetAccessor;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_10260;
import net.minecraft.class_1729;
import net.minecraft.class_339;
import net.minecraft.class_361;
import net.minecraft.class_508;
import net.minecraft.class_512;

public class RecipeBookScreenCursorHandler implements CursorHandler<class_10260<?>> {
    @Override
    public CursorType getCursorType(class_10260<? extends class_1729> recipeBookScreen, double mouseX, double mouseY) {
        RecipeBookWidgetAccessor recipeBook = (RecipeBookWidgetAccessor) ((RecipeBookScreenAccessor<?>) recipeBookScreen).getRecipeBook();
        if (!recipeBook.invokeIsOpen()) return CursorType.DEFAULT;

        RecipeBookResultsAccessor recipesArea = (RecipeBookResultsAccessor) recipeBook.getRecipesArea();
        RecipeAlternativesWidgetAccessor alternatesWidget = (RecipeAlternativesWidgetAccessor) recipesArea.getAlternatesWidget();

        if (((class_508) alternatesWidget).method_2616()) {
            return getAlternatesWidgetCursor(alternatesWidget);
        }

        boolean isResultHovered = recipesArea.getHoveredResultButton() != null;
        if (isResultHovered && CursorTypeUtil.canShift()) {
            return CursorType.SHIFT;
        } else if (isButtonHovered(recipeBook, recipesArea) || isResultHovered) {
            return CursorType.POINTER;
        } else if (recipeBook.getSearchField().method_49606()) {
            return CursorType.TEXT;
        }
        return getTabCursor(recipeBook);
    }

    private CursorType getAlternatesWidgetCursor(RecipeAlternativesWidgetAccessor alternatesWidget) {
        for (class_339 alternativeButton : alternatesWidget.getAlternativeButtons()) {
            if (alternativeButton.method_37303() && alternativeButton.method_49606()) {
                return CursorTypeUtil.canShift() ? CursorType.SHIFT : CursorType.POINTER;
            }
        }
        return CursorType.DEFAULT_FORCE;
    }

    private boolean isButtonHovered(RecipeBookWidgetAccessor recipeBook, RecipeBookResultsAccessor recipesArea) {
        class_361 prevPageButton = recipesArea.getPrevPageButton();
        class_361 nextPageButton = recipesArea.getNextPageButton();
        return (prevPageButton.method_49606() && prevPageButton.field_22764) || (nextPageButton.method_49606() && nextPageButton.field_22764) || recipeBook.getToggleCraftableButton().method_49606();
    }

    private CursorType getTabCursor(RecipeBookWidgetAccessor recipeBook) {
        for (class_512 tabButton : recipeBook.getTabButtons()) {
            if (tabButton.method_49606() && tabButton.method_37303() && tabButton != recipeBook.getCurrentTab()) {
                return CursorType.POINTER;
            }
        }
        return CursorType.DEFAULT;
    }
}
