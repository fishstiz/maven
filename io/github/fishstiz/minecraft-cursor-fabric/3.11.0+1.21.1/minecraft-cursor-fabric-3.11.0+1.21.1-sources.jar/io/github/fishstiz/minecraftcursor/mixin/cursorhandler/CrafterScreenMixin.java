package io.github.fishstiz.minecraftcursor.mixin.cursorhandler;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_8881;
import net.minecraft.class_8882;
import net.minecraft.class_8898;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_8898.class)
public abstract class CrafterScreenMixin extends AbstractContainerScreenMixin<class_8881> {
    @Shadow
    @Final
    private class_1657 player;

    protected CrafterScreenMixin(class_2561 title) {
        super(title);
    }

    @Override
    public @NotNull CursorType minecraft_cursor$getCursorType(double mouseX, double mouseY) {
        if (this.hoveredSlot instanceof class_8882 crafterSlot
            && this.menu.method_34255().method_7960()
            && !crafterSlot.method_7681()
            && !player.method_7325()) {
            return CursorType.POINTER;
        }
        return super.minecraft_cursor$getCursorType(mouseX, mouseY);
    }
}
