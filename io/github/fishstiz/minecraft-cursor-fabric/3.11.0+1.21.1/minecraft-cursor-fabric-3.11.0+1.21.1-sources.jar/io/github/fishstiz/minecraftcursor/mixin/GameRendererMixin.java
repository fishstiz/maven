package io.github.fishstiz.minecraftcursor.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.fishstiz.minecraftcursor.cursor.CursorManager;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Shadow
    @Final
    class_310 minecraft;

    @Inject(method = "render", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;flush()V"
    ))
    private void renderCursor(
            class_9779 deltaTracker,
            boolean renderLevel,
            CallbackInfo ci,
            @Local(ordinal = 0) class_332 guiGraphics,
            @Local(ordinal = 0) int mouseX,
            @Local(ordinal = 1) int mouseY
    ) {
        CursorManager.INSTANCE.renderCursor(this.minecraft, guiGraphics, mouseX, mouseY);
    }
}
