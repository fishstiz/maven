package io.github.fishstiz.minecraftcursor.gui.widget;

import static net.minecraft.class_3675.field_32000;

import net.minecraft.class_4069;

public interface ContainerEventHandlerPatch extends class_4069 {
    // should propagate mouse release to focused child
    @Override
    default boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == field_32000 && this.method_25397()) {
            this.method_25398(false);
            if (this.method_25399() != null) {
                return this.method_25399().method_25406(mouseX, mouseY, button);
            }
        }

        return this.method_19355(mouseX, mouseY).filter(child -> child.method_25406(mouseX, mouseY, button)).isPresent();
    }
}
