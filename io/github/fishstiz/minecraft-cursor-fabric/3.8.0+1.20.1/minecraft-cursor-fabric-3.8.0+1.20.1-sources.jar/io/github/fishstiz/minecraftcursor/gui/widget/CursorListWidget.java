package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.api.CursorProvider;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import io.github.fishstiz.minecraftcursor.util.DrawUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4264;
import net.minecraft.class_4265;
import net.minecraft.class_6379;
import net.minecraft.class_6382;

public class CursorListWidget extends class_4265<CursorListWidget.CursorEntry> {
    private static final int ITEM_HEIGHT = 32;
    private static final int SCROLLBAR_OFFSET = 6;
    private static final int ROW_GAP = 1;
    private final CursorOptionsScreen optionsScreen;

    public CursorListWidget(class_310 client, int width, int height, int y, int bottom, CursorOptionsScreen optionsScreen) {
        super(client, width + SCROLLBAR_OFFSET, height, y, bottom, ITEM_HEIGHT + ROW_GAP);
        this.optionsScreen = optionsScreen;
        this.field_19085 = y;
        method_31322(false);
        method_25315(false, 0);
        method_31323(false);

        refreshEntries();
    }

    public void refreshEntries() {
        this.method_25339();

        CursorEntry selectedEntry = null;
        for (Cursor cursor : optionsScreen.getCursors()) {
            CursorEntry entry = new CursorEntry(
                    cursor,
                    field_19088,
                    field_19085 + field_22741 * method_25340(),
                    field_22742 - SCROLLBAR_OFFSET,
                    ITEM_HEIGHT
            );

            if (optionsScreen.getSelectedCursor() == cursor) {
                selectedEntry = entry;
            }

            this.method_25321(entry);
        }

        if (selectedEntry != null) {
            this.method_25328(selectedEntry);
        }
    }

    @Override
    public int method_25331() {
        return Math.max(0, this.method_25317() - (this.field_19086 - this.field_19085) + (ROW_GAP * method_25340()) - ROW_GAP);
    }

    @Override
    protected int method_25329() {
        return (field_19088 + field_22742) - SCROLLBAR_OFFSET;
    }

    @Override
    protected int method_25337(int index) {
        return field_19085 + (this.field_22741 + ROW_GAP) * index - (int) this.method_25341();
    }

    protected int getRowIndex(double y) {
        int index = ((int) Math.floor(y - this.field_19085) + (int) this.method_25341()) / (this.field_22741 + ROW_GAP);
        return index >= 0 && index < this.method_25340() ? index : -1;
    }

    @Override
    protected @Nullable CursorEntry getEntryAtPosition(double mouseX, double mouseY) {
        int index = this.getRowIndex(mouseY);
        return index >= 0 && this.method_25405(mouseX, mouseY) ? this.method_25326(index) : null;
    }

    @Override
    protected void method_25311(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int left = this.field_19088;
        int width = this.field_22742 - SCROLLBAR_OFFSET;

        for (int i = 0; i < this.method_25340(); i++) {
            int top = this.method_25337(i);
            int bottom = this.method_25319(i);
            if (bottom >= this.field_19085 && top <= this.field_19086) {
                this.method_44397(guiGraphics, mouseX, mouseY, partialTick, i, left, top, width, this.field_22741);
            }
        }
    }

    @Override
    public void method_25333(int leftPos) {
        this.field_19088 = leftPos;
        super.method_25333(leftPos);
        this.method_25324(this.method_25336() != null ? this.method_25336() : this.method_48200());
    }

    public void setHeight(int height) {
        this.field_22743 = height;
        this.field_19086 = this.field_19085 + this.field_22743;
    }

    public class CursorEntry extends Entry<CursorEntry> {
        public final CursorButtonWidget button;

        public CursorEntry(Cursor cursor, int x, int y, int width, int height) {
            button = new CursorButtonWidget(x, y, width, height, cursor);
        }

        @Override
        public void render(@NotNull class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
            button.method_48229(x, y);
            button.method_48579(context, mouseX, mouseY, delta);
        }

        @Override
        public @NotNull List<? extends class_6379> narratables() {
            return List.of(button);
        }

        @Override
        public @NotNull List<? extends class_364> children() {
            return List.of(button);
        }
    }

    public class CursorButtonWidget extends class_4264 implements CursorProvider {
        private static final int TEXTURE_SIZE = 16;
        private static final int PADDING_LEFT = 8;
        private static final int BACKGROUND_COLOR = 0x7F000000; // black 50%
        private static final int TEXT_COLOR = 0xFFFFFFFF; // white
        private static final int TEXT_DISABLED_COLOR = 0xFF555555; // dark gray
        private static final int TEXT_UNLOADED_COLOR = 0xFFAA5555; // red
        private static final int BORDER_COLOR = 0xFF000000;
        private static final int SELECTED_BORDER_COLOR = 0xFFFFFFFF; // white
        private static final int HOVERED_BORDER_COLOR = 0xFFCCCCCC; // dark gray

        private final Cursor cursor;

        CursorButtonWidget(int x, int y, int width, int height, Cursor cursor) {
            super(x, y, width, height, class_2561.method_43473());
            this.cursor = cursor;
        }

        @Override
        public void method_25306() {
            optionsScreen.selectCursor(cursor);
        }

        @Override
        public void method_48579(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
            renderBox(context);
            renderTexture(context);
            renderMessage(context);
            renderBorder(context, mouseX, mouseY);
        }

        private void renderBorder(class_332 context, int mouseX, int mouseY) {
            int borderColor = BORDER_COLOR;

            if (cursor == optionsScreen.getSelectedCursor()) {
                borderColor = SELECTED_BORDER_COLOR;
            } else if (method_25370() || method_25405(mouseX, mouseY)) {
                borderColor = HOVERED_BORDER_COLOR;
            }

            context.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), borderColor);
        }

        private void renderBox(class_332 context) {
            int x2 = method_46426() + method_25368();
            int y2 = method_46427() + method_25364();
            context.method_25294(method_46426(), method_46427(), x2, y2, BACKGROUND_COLOR);
        }

        private void renderTexture(class_332 context) {
            if (cursor.isLoaded()) {
                int x = method_46426() + PADDING_LEFT;
                int y = method_46427() + (method_25364() / 2) - (TEXTURE_SIZE / 2);
                optionsScreen.animationHelper.drawSprite(context, cursor, x, y, TEXTURE_SIZE);
            }
        }

        private void renderMessage(class_332 context) {
            int color;

            boolean loaded = cursor.isLoaded();
            if (loaded && cursor.isEnabled()) {
                color = TEXT_COLOR;
            } else if (loaded) {
                color = TEXT_DISABLED_COLOR;
            } else {
                color = TEXT_UNLOADED_COLOR;
            }

            int x = method_46426() + (loaded ? TEXTURE_SIZE : 0) + PADDING_LEFT * 2;
            int endX = (method_46426() + method_25368()) - SCROLLBAR_OFFSET;
            int endY = method_46427() + method_25364();

            DrawUtil.drawScrollableTextLeftAlign(context, field_22740.field_1772, cursor.getText(), x, method_46427(), endX, endY, color);
        }

        @Override
        protected void method_47399(@NotNull class_6382 builder) {
            this.method_37021(builder);
        }

        @Override
        public CursorType getCursorType(double mouseX, double mouseY) {
            return CursorType.POINTER;
        }
    }
}
