package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.config.Config;
import io.github.fishstiz.minecraftcursor.cursor.AnimatedCursor;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import io.github.fishstiz.minecraftcursor.util.SettingsUtil;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_6382;
import net.minecraft.class_7919;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;
import static io.github.fishstiz.minecraftcursor.util.SettingsUtil.*;

public class CursorOptionsWidget extends AbstractContainerWidget implements ContainerEventHandlerPatch {
    private static final int OPTIONS_HEIGHT = 24;
    private static final int GRID_PADDING = 4;
    private static final int BOX_WIDGET_TEXTURE_SIZE = 96;
    private static final int HELPER_BUTTON_SIZE = 16;
    private static final int HELPER_ICON_SIZE = 10;
    private static final class_2960 HELPER_ICON = new class_2960("minecraft", "textures/gui/unseen_notification.png");
    private static final String GLOBAL_TEXT_KEY = "minecraft-cursor.options.global.tooltip";
    private static final class_2561 ANIMATE_TEXT = class_2561.method_43471("minecraft-cursor.options.animate");
    private static final class_2561 RESET_ANIMATION_TEXT = class_2561.method_43471("minecraft-cursor.options.animate-reset");
    private static final String HOT_UNIT = "px";

    public static final class_2561 ENABLED_TEXT = class_2561.method_43471("minecraft-cursor.options.enabled");
    public static final class_2561 SCALE_TEXT = class_2561.method_43471("minecraft-cursor.options.scale");
    public static final class_2561 XHOT_TEXT = class_2561.method_43471("minecraft-cursor.options.xhot");
    public static final class_2561 YHOT_TEXT = class_2561.method_43471("minecraft-cursor.options.yhot");

    private final CursorOptionsHandler handler;
    private final CursorOptionsScreen parent;
    private final List<class_364> children = new ArrayList<>();
    SelectedCursorToggleWidget enableButton;
    SelectedCursorSliderWidget scaleSlider;
    SelectedCursorSliderWidget xhotSlider;
    SelectedCursorSliderWidget yhotSlider;
    SelectedCursorToggleWidget animateButton;
    SelectedCursorButtonWidget resetAnimation;
    SelectedCursorHotspotWidget cursorHotspot;
    SelectedCursorTestWidget cursorTest;

    public CursorOptionsWidget(int x, int width, int height, int y, CursorOptionsScreen optionsScreen) {
        super(x, y, width, height, class_2561.method_43473());

        this.parent = optionsScreen;
        this.handler = new CursorOptionsHandler(this);

        initWidgets();
    }

    @Override
    protected void method_44386(@NotNull class_332 context) {
        // override to remove box
    }

    @Override
    public void method_48588(@NotNull class_332 context, @NotNull class_2960 texture, int x, int y, int u, int v, int hoveredVOffset, int width, int height, int textureWidth, int textureHeight) {
        // override to remove texture
    }

    private void initWidgets() {
        Config.Settings settings = handler.getSettings();

        enableButton = this.addChild(new SelectedCursorToggleWidget(ENABLED_TEXT, settings.isEnabled(), handler::handleEnable));
        scaleSlider = this.addChild(new SelectedCursorSliderWidget(
                SCALE_TEXT, settings.getScale(),
                SCALE_MIN, SCALE_MAX, SCALE_STEP,
                handler::handleChangeScale, CursorOptionsHandler::removeScaleOverride
        ));
        scaleSlider.setTextMapper(SettingsUtil::getAutoText);
        bindHelperButton(scaleSlider);
        xhotSlider = this.addChild(createHotspotSlider(XHOT_TEXT, settings.getXHot(), handler::handleChangeXHot));
        yhotSlider = this.addChild(createHotspotSlider(YHOT_TEXT, settings.getYHot(), handler::handleChangeYHot));
        animateButton = this.addChild(new SelectedCursorToggleWidget(ANIMATE_TEXT, handler.isAnimated(), handler::handlePressAnimate));
        resetAnimation = this.addChild(new SelectedCursorButtonWidget(RESET_ANIMATION_TEXT, handler::handleResetAnimation));
        cursorHotspot = this.addChild(new SelectedCursorHotspotWidget(BOX_WIDGET_TEXTURE_SIZE, this));
        cursorHotspot.setChangeEventListener(handler::handleChangeHotspotWidget);
        cursorTest = this.addChild(new SelectedCursorTestWidget(BOX_WIDGET_TEXTURE_SIZE, this));

        refreshWidgets();
    }

    private SelectedCursorSliderWidget createHotspotSlider(class_2561 prefix, int value, DoubleConsumer onApply) {
        var slider = new SelectedCursorSliderWidget(
                prefix, value,
                HOT_MIN, GLOBAL_HOT_MAX, 1, HOT_UNIT,
                handler.handleChangeHotspots(onApply)
        );
        bindHelperButton(slider);

        return slider;
    }

    private void bindHelperButton(SelectedCursorSliderWidget sliderWidget) {
        var helperButton = this.addChild(new SelectedCursorButtonWidget(HELPER_ICON, HELPER_ICON_SIZE, HELPER_ICON_SIZE, parent::toMoreOptions));
        helperButton.method_47400(class_7919.method_47407(class_2561.method_43469(GLOBAL_TEXT_KEY, sliderWidget.getPrefix())));
        sliderWidget.setInactiveHelperButton(helperButton, HELPER_BUTTON_SIZE, HELPER_BUTTON_SIZE);
    }

    private void refreshWidgets() {
        Cursor cursor = handler.getCursor();
        Config.GlobalSettings global = CONFIG.getGlobal();
        Config.Settings settings = CONFIG.getOrCreateCursorSettings(cursor);

        enableButton.setValue(settings.isEnabled());

        if (cursor.isLoaded()) {
            scaleSlider.update(SCALE_MIN, SCALE_MAX, settings.getScale(), !global.isScaleActive());

            int maxHotspot = cursor.getTextureWidth() - 1;
            xhotSlider.update(0, maxHotspot, settings.getXHot(), !global.isXHotActive());
            yhotSlider.update(0, maxHotspot, settings.getYHot(), !global.isYHotActive());

            animateButton.field_22763 = cursor instanceof AnimatedCursor;
            boolean animationEnabled = animateButton.field_22763 && ((AnimatedCursor) cursor).isAnimated();
            resetAnimation.field_22763 = animationEnabled;
            animateButton.setValue(animationEnabled);

            cursorHotspot.setRulerRendered(true, true);
            cursorHotspot.field_22763 = !(global.isXHotActive() && global.isYHotActive());
        }

        method_25396().forEach(widget -> widget.method_25365(false));
    }

    @Override
    protected void method_44389(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
        placeWidgets();

        Cursor cursor = handler.getCursor();

        enableButton.method_25394(context, mouseX, mouseY, delta);

        if (cursor.isLoaded()) {
            scaleSlider.method_48579(context, mouseX, mouseY, delta);
            xhotSlider.method_48579(context, mouseX, mouseY, delta);
            yhotSlider.method_48579(context, mouseX, mouseY, delta);

            if (cursor instanceof AnimatedCursor) {
                animateButton.method_25394(context, mouseX, mouseY, delta);
                resetAnimation.method_25394(context, mouseX, mouseY, delta);
            }

            cursorHotspot.method_25394(context, mouseX, mouseY, delta);
            cursorTest.method_48579(context, mouseX, mouseY, delta);
        }
    }

    private void placeWidgets() {
        boolean isAnimatedCursor = handler.getCursorAsAnimatedCursor().isPresent();

        grid(enableButton, 0, 0);
        grid(scaleSlider, 1, 0);
        grid(xhotSlider, 0, 1);
        grid(yhotSlider, 1, 1);

        if (isAnimatedCursor) {
            grid(animateButton, 0, 2);
            grid(resetAnimation, 1, 2);
            grid(cursorHotspot, 0, 3, true);
            grid(cursorTest, 1, 3, true);
        } else {
            grid(cursorHotspot, 0, 2, true);
            grid(cursorTest, 1, 2, true);
        }
    }

    private void grid(class_339 widget, int gridX, int gridY) {
        grid(widget, gridX, gridY, false);
    }

    private void grid(class_339 widget, int gridX, int gridY, boolean absolute) {
        if (!absolute) {
            widget.method_25358((method_25368() / 2) - GRID_PADDING);
            widget.field_22759 = OPTIONS_HEIGHT - GRID_PADDING;
        }
        widget.method_46421((method_46426() + ((method_25368() / 2) * gridX)) + 1);
        widget.method_46419((method_46427() + (OPTIONS_HEIGHT * (gridY))) + 1);
    }

    public void save() {
        handler.updateSettings();
    }

    public void refresh() {
        refreshWidgets();
    }

    public CursorOptionsScreen parent() {
        return parent;
    }

    private <T extends class_364> T addChild(T child) {
        this.children.add(child);
        return child;
    }

    @Override
    public @NotNull List<? extends class_364> method_25396() {
        return this.handler.getCursor().isLoaded() ? this.children : List.of(enableButton);
    }

    public void setHeight(int height) {
        this.field_22759 = height;
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        placeWidgets();
    }

    @Override
    protected void method_47399(@NotNull class_6382 builder) {
        // not supported
    }

    @Override
    protected int method_44391() {
        return this.method_25364();
    }

    @Override
    protected double method_44393() {
        return 0;
    }
}
