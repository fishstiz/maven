package io.github.fishstiz.minecraftcursor.mixin.cursorprovider;

import io.github.fishstiz.minecraftcursor.api.CursorController;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_332;
import net.minecraft.class_7528;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7528.class)
public abstract class AbstractScrollWidgetMixin {
    @Shadow
    private boolean scrolling;

    @Shadow protected abstract boolean scrollbarVisible();

    @Inject(method = "renderScrollBar", at = @At(value = "TAIL"))
    public void forceDefaultCursor(class_332 guiGraphics, CallbackInfo ci) {
        if (this.scrolling && this.scrollbarVisible() && CursorTypeUtil.isLeftClickHeld()) {
            CursorController.getInstance().setSingleCycleCursor(CursorType.DEFAULT_FORCE);
        }
    }
}
