package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_8021;

public interface LayoutElementPatch extends class_8021 {
    default int getRight() {
        return this.method_46426() + this.method_25368();
    }

    default int getBottom() {
        return this.method_46427() + this.method_25364();
    }
}
