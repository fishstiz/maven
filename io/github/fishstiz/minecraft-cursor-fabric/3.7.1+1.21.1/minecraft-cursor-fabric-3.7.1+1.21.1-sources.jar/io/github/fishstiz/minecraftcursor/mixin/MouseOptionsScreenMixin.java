package io.github.fishstiz.minecraftcursor.mixin;

import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_4185;
import net.minecraft.class_4288;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4288.class)
public abstract class MouseOptionsScreenMixin extends class_4667 {
    protected MouseOptionsScreenMixin(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    @Inject(method = "addOptions", at = @At("TAIL"))
    protected void addOptions(CallbackInfo ci) {
        if (this.field_51824 == null) {
            return;
        }

        class_4185 settingsBtn = class_4185.method_46430(
                class_2561.method_43471("minecraft-cursor.options").method_27693("..."),
                btn -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new CursorOptionsScreen(this));
                    }
                }).method_46431();

        class_4185 fillerBtn = class_4185.method_46430(class_2561.method_43473(), button -> {
        }).method_46431();
        fillerBtn.field_22764 = false;
        fillerBtn.field_22763 = false;

        this.field_51824.method_20407(settingsBtn, fillerBtn);
    }
}
