package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_1720;
import net.minecraft.class_489;
import net.minecraft.class_517;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_489.class)
public interface AbstractFurnaceScreenAccessor extends HandledScreenAccessor<class_1720> {
    @Accessor("recipeBookComponent")
    class_517 getRecipeBook();
}
