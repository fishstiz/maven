package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_1723;
import net.minecraft.class_490;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_490.class)
public interface InventoryScreenAccessor extends HandledScreenAccessor<class_1723> {
    @Accessor("recipeBookComponent")
    class_507 getRecipeBook();
}
