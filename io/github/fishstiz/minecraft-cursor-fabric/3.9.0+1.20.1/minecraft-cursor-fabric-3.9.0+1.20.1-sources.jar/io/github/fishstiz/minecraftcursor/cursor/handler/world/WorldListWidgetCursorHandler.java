package io.github.fishstiz.minecraftcursor.cursor.handler.world;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_528;

public class WorldListWidgetCursorHandler implements CursorHandler<class_528> {
    public static final int ICON_SIZE = 32;

    @Override
    public CursorType getCursorType(class_528 worldListWidget, double mouseX, double mouseY) {
        if (!MinecraftCursor.CONFIG.isWorldIconEnabled()) return CursorType.DEFAULT;

        int x = worldListWidget.method_25342();
        for (class_528.class_7414 entry : worldListWidget.method_25396()) {
            if (entry instanceof class_528.class_4272 worldEntry
                    && entry.method_25405(mouseX, mouseY)
                    && mouseX >= x - 1
                    && mouseX <= x - 1 + ICON_SIZE
                    && worldEntry.method_43465()) {
                return CursorType.POINTER;
            }
        }
        return CursorType.DEFAULT;
    }
}
