package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_3675;
import net.minecraft.class_4069;

/**
 * Ensure mouse release is propagated to focused child
 * <p>
 * Copied from 1.21.1 version of {@link class_4069#method_25406(double, double, int)}
 */
public interface ContainerEventHandlerPatch extends class_4069 {
    @Override
    default boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == class_3675.field_32000 && this.method_25397()) {
            this.method_25398(false);
            if (this.method_25399() != null) {
                return this.method_25399().method_25406(mouseX, mouseY, button);
            }
        }

        return this.method_19355(mouseX, mouseY).filter(child -> child.method_25406(mouseX, mouseY, button)).isPresent();
    }
}
