package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_4267;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4267.class_4270.class)
public interface OnlineServerEntryAccessor {
    @Accessor("screen")
    class_500 getScreen();

    @Invoker("canJoin")
    boolean invokeCanJoin();
}
