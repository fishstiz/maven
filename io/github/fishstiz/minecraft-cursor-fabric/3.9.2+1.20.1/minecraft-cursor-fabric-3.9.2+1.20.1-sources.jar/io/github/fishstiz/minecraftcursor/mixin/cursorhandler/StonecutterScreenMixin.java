package io.github.fishstiz.minecraftcursor.mixin.cursorhandler;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorController;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3971;
import net.minecraft.class_3979;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_3979.class)
public abstract class StonecutterScreenMixin extends AbstractContainerScreenMixin<class_3971> {
    @Unique
    private static final int minecraft_cursor$HIGHLIGHTED_V_OFFSET = 36;

    @Shadow
    @Final
    private static class_2960 BG_LOCATION;

    protected StonecutterScreenMixin(class_2561 title) {
        super(title);
    }

    @ModifyArg(method = "renderButtons", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"
    ))
    private class_2960 setPointerOnHover(class_2960 resourceLocation, int x, int y, int uOffset, int vOffset, int uWidth, int vHeight) {
        if (MinecraftCursor.CONFIG.isStonecutterRecipesEnabled()
            && resourceLocation == BG_LOCATION
            && vOffset == this.imageHeight + minecraft_cursor$HIGHLIGHTED_V_OFFSET) {
            CursorController.getInstance().setSingleCycleFallbackCursor(CursorType.POINTER);
        }
        return resourceLocation;
    }
}
