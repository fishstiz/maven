package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_454;
import net.minecraft.class_457;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_457.class)
public interface AdvancementScreenAccess {
    @Accessor("selectedTab")
    class_454 getSelectedTab();
}
