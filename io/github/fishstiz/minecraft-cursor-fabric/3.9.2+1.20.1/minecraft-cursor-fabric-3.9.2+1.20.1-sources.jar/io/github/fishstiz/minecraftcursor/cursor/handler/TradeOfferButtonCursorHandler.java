package io.github.fishstiz.minecraftcursor.cursor.handler;

import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_364;
import org.jetbrains.annotations.NotNull;

public class TradeOfferButtonCursorHandler implements CursorHandler<class_364> {
    private final String className;

    public TradeOfferButtonCursorHandler(String className) {
        this.className = className;
    }

    @Override
    public @NotNull TargetElement<class_364> getTargetElement() {
        return TargetElement.fromClassName(this.className);
    }

    @Override
    public CursorType getCursorType(class_364 element, double mouseX, double mouseY) {
        return CursorTypeUtil.canShift() ? CursorType.SHIFT : CursorType.POINTER;
    }
}
