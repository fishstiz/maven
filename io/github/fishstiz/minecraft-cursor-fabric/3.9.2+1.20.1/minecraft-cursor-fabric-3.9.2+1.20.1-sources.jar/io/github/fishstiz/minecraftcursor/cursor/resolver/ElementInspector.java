package io.github.fishstiz.minecraftcursor.cursor.resolver;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public interface ElementInspector {
    ElementInspector NO_OP = new ElementInspector() {
    };

    static class_2960 getId() {
        return MinecraftCursor.loc("inspector");
    }

    default void destroy() {
    }

    default boolean setProcessed(class_364 processed, boolean cached) {
        return false;
    }

    default void render(class_310 minecraft, @NotNull class_437 screen, class_332 guiGraphics, double mouseX, double mouseY) {
    }

    default boolean isInspecting() {
        return false;
    }
}
