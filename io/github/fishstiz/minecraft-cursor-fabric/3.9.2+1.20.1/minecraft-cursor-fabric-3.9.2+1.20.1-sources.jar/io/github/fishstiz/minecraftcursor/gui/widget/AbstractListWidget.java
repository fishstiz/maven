package io.github.fishstiz.minecraftcursor.gui.widget;

import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4265;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

import static io.github.fishstiz.minecraftcursor.util.SettingsUtil.clamp;

public abstract class AbstractListWidget<E extends AbstractListWidget<E>.Entry> extends class_4265<E> implements class_8021 {
    public static final int DEFAULT_HEADER_HEIGHT = -4; // removes offsets in AbstractSelectionList
    public static final int SCROLLBAR_WIDTH = 6;
    protected final int rowGap;

    protected AbstractListWidget(class_310 minecraft, int width, int y, int height, int itemHeight) {
        super(minecraft, width, height, y, y + height, itemHeight);
        this.method_25315(true, DEFAULT_HEADER_HEIGHT);
        this.rowGap = 0;
    }

    protected AbstractListWidget(class_310 minecraft, int width, int y, int height, int itemHeight, int rowGap) {
        super(minecraft, width, height, y, y + height, itemHeight + rowGap);

        this.method_25315(true, DEFAULT_HEADER_HEIGHT);
        this.rowGap = rowGap;
    }

    @Override
    protected void method_25311(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int left = this.method_25342();
        int width = this.method_25322();

        for (int i = 0; i < this.method_25340(); i++) {
            int top = this.method_25337(i);
            int bottom = this.method_25319(i);
            if (bottom >= this.method_46427() && top <= this.getBottom()) {
                this.method_44397(guiGraphics, mouseX, mouseY, partialTick, i, left, top, width, this.field_22741);
            }
        }
    }

    public void setClampedScrollAmount(double scrollAmount) {
        this.method_25307(clamp(scrollAmount, 0d, this.method_25331()));
    }

    public void clampScrollAmount() {
        this.setClampedScrollAmount(this.method_25341());
    }

    public boolean scrollbarVisible() {
        return this.method_25331() > 0;
    }

    @Override
    public int method_25331() {
        return Math.max(0, (super.method_25331() - this.rowGap));
    }

    @Override
    protected int method_25329() {
        return this.scrollbarVisible() ? this.getRight() - SCROLLBAR_WIDTH : this.getRight();
    }

    @Override
    public int method_25322() {
        return this.scrollbarVisible() ? this.method_25368() - SCROLLBAR_WIDTH : this.method_25368();
    }

    @Override
    public int method_25342() {
        return this.method_46426();
    }

    public void setWidth(int width) {
        this.field_22742 = width;
        this.field_19087 = this.field_19088 + this.field_22742;
    }

    public void setHeight(int height) {
        this.field_22743 = height;
        this.field_19086 = this.field_19085 + this.field_22743;
        this.clampScrollAmount();
    }

    public void setSize(int width, int height) {
        this.setWidth(width);
        this.setHeight(height);
    }

    @Override
    public void method_46421(int x) {
        this.method_25333(x);
    }

    @Override
    public void method_46419(int y) {
        this.field_19085 = y;
        this.field_19086 = this.field_19085 + this.field_22743;
    }

    @Override
    public int method_46426() {
        return this.field_19088;
    }

    @Override
    public int method_46427() {
        return this.field_19085;
    }

    @Override
    public int method_25368() {
        return this.field_22742;
    }

    @Override
    public int method_25364() {
        return this.field_22743;
    }

    public int getRight() {
        return this.method_46426() + this.method_25368();
    }

    public int getBottom() {
        return this.method_46427() + this.method_25364();
    }

    @Override
    public @NotNull class_8030 method_48202() {
        return class_8021.super.method_48202();
    }

    @Override
    public void method_48206(@NotNull Consumer<class_339> visitor) {
    }

    protected abstract class Entry extends class_4265.class_4266<E> implements class_8021, ContainerEventHandlerPatch {
        private final int index;

        protected Entry(int index) {
            this.index = index;
        }

        protected Entry() {
            this(AbstractListWidget.this.method_25396().size());
        }

        @Override
        public void method_46421(int i) {
        }

        @Override
        public void method_46419(int i) {
        }

        @Override
        public int method_46426() {
            return AbstractListWidget.this.method_25342();
        }

        @Override
        public int method_46427() {
            return AbstractListWidget.this.method_25337(this.index);
        }

        @Override
        public int method_25368() {
            return AbstractListWidget.this.method_25322();
        }

        @Override
        public int method_25364() {
            return AbstractListWidget.this.field_22741 - AbstractListWidget.this.rowGap;
        }

        public int getRight() {
            return this.method_46426() + this.method_25368();
        }

        public int getBottom() {
            return this.method_46427() + this.method_25364();
        }

        @Override
        public @NotNull class_8030 method_48202() {
            return class_8021.super.method_48202();
        }

        @Override
        public void method_48206(@NotNull Consumer<class_339> visitor) {
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
        }
    }
}
