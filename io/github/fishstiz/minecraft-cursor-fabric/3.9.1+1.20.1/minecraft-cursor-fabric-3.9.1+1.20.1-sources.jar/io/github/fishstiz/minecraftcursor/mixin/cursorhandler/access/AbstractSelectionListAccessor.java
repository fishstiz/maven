package io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access;

import net.minecraft.class_350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_350.class)
public interface AbstractSelectionListAccessor {
    @Invoker("getRowTop")
    int invokeGetRowTop(int index);
}
