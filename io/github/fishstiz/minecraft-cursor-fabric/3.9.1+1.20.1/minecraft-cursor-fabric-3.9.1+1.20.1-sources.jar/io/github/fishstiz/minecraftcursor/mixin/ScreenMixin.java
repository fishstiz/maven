package io.github.fishstiz.minecraftcursor.mixin;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenMixin {
    @Shadow
    @Nullable
    protected class_310 minecraft;

    @Inject(method = "render", at = @At("RETURN"))
    public void afterRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (this.minecraft != null) {
            MinecraftCursor.afterScreenRender(this.minecraft, (class_437) (Object) this, guiGraphics, mouseX, mouseY);
        }
    }
}
