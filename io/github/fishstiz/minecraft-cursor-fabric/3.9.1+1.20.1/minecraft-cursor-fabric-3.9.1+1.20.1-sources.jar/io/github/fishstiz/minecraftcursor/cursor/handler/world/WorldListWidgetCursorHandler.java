package io.github.fishstiz.minecraftcursor.cursor.handler.world;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_528;

public class WorldListWidgetCursorHandler implements CursorHandler<class_528> {
    private static final int ICON_WIDTH = 32;

    @Override
    public CursorType getCursorType(class_528 worldListWidget, double mouseX, double mouseY) {
        if (!MinecraftCursor.CONFIG.isWorldIconEnabled()) return CursorType.DEFAULT;

        if (mouseX <= worldListWidget.method_25342() + ICON_WIDTH) {
            for (class_528.class_7414 entry : worldListWidget.method_25396()) {
                if (entry instanceof class_528.class_4272 worldListEntry
                    && worldListEntry.method_25405(mouseX, mouseY)
                    && worldListEntry.method_43465()) {
                    return CursorType.POINTER;
                }
            }
        }
        return CursorType.DEFAULT;
    }
}
