package io.github.fishstiz.minecraftcursor.cursor.handler.multiplayer;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.AbstractSelectionListAccessor;
import io.github.fishstiz.minecraftcursor.mixin.cursorhandler.access.OnlineServerEntryAccessor;
import java.util.List;
import net.minecraft.class_4267;

public class MultiplayerServerListWidgetCursorHandler implements CursorHandler<class_4267> {
    private static final int ICON_SIZE = 32;
    private static final int MOVE_ICON_SIZE = ICON_SIZE / 2;

    @Override
    public CursorType getCursorType(class_4267 serverList, double mouseX, double mouseY) {
        if (!MinecraftCursor.CONFIG.isServerIconEnabled()) return CursorType.DEFAULT;

        if (mouseX <= serverList.method_25342() + ICON_SIZE) {
            List<class_4267.class_504> entries = serverList.method_25396();
            for (int i = 0; i <= entries.size(); i++) {
                if (entries.get(i) instanceof class_4267.class_4270 entry && entry.method_25405(mouseX, mouseY)) {
                    OnlineServerEntryAccessor accessor = (OnlineServerEntryAccessor) entry;
                    double relativeX = mouseX - serverList.method_25342();
                    double relativeY = mouseY - ((AbstractSelectionListAccessor) serverList).invokeGetRowTop(i);

                    if (relativeX < ICON_SIZE && relativeX > MOVE_ICON_SIZE && accessor.invokeCanJoin()) {
                        return CursorType.POINTER;
                    }
                    if (relativeX < MOVE_ICON_SIZE && relativeY < MOVE_ICON_SIZE && i > 0) {
                        return CursorType.POINTER;
                    }
                    if (relativeX < MOVE_ICON_SIZE && relativeY > MOVE_ICON_SIZE && i < accessor.getScreen().method_2529().method_2984() - 1) {
                        return CursorType.POINTER;
                    }
                }
            }
        }

        return CursorType.DEFAULT;
    }
}
