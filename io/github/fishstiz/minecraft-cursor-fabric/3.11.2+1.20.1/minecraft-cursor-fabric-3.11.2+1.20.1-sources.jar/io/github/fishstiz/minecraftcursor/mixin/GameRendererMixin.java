package io.github.fishstiz.minecraftcursor.mixin;

import io.github.fishstiz.minecraftcursor.cursor.CursorManager;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Shadow
    @Final
    class_310 minecraft;

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;flush()V"
            ),
            locals = LocalCapture.CAPTURE_FAILSOFT
    )
    private void renderCursor(
            float partialTicks,
            long nanoTime,
            boolean renderLevel,
            CallbackInfo ci,
            int i,
            int j,
            class_1041 window,
            Matrix4f matrix4f,
            class_4587 posestack,
            class_332 guigraphics
    ) {
        CursorManager.INSTANCE.renderCursor(this.minecraft, guigraphics, i, j);
    }
}
