package io.github.fishstiz.minecraftcursor.gui.screen.panel;

import io.github.fishstiz.minecraftcursor.compat.ExternalCursorTracker;
import io.github.fishstiz.minecraftcursor.cursor.CursorManager;
import io.github.fishstiz.minecraftcursor.gui.widget.OptionsListWidget;
import io.github.fishstiz.minecraftcursor.config.Flag;
import io.github.fishstiz.minecraftcursor.platform.Services;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;

public class CompatibilityOptionsPanel extends AbstractOptionsPanel {
    private static final class_7919 RESTART_TO_APPLY_INFO = class_7919.method_47407(class_2561.method_43471("minecraft-cursor.options.restart_to_apply"));
    private static final class_2561 AGGRESSIVE_TEXT = class_2561.method_43471("minecraft-cursor.options.compat.aggressive_cursor");
    private static final class_7919 AGGRESSIVE_INFO = class_7919.method_47407(class_2561.method_43471("minecraft-cursor.options.compat.aggressive_cursor.info"));
    private static final class_2561 REMAP_TEXT = class_2561.method_43471("minecraft-cursor.options.compat.remap_cursors");
    private static final class_7919 REMAP_INFO = class_7919.method_47407(class_2561.method_43471(Flag.REMAP.getInfoKey()));
    private static final class_7919 REMAP_EMPTY_INFO = class_7919.method_47407(class_2561.method_43471("minecraft-cursor.options.compat.remap_cursors.empty"));
    private static final class_2561 VIRTUAL_TEXT = class_2561.method_43471("minecraft-cursor.options.compat.virtual_mode");
    private static final class_7919 VIRTUAL_INFO = class_7919.method_47407(class_2561.method_43471("minecraft-cursor.options.compat.virtual_mode.info"));
    private static final class_2561 IMGUI_DISABLE_CURSOR_CHANGES_TEXT = class_2561.method_43471("minecraft-cursor.options.compat.imgui.disable_cursor_changes");
    private static final boolean VEIL_LOADED = Services.PLATFORM.isModLoaded("veil");
    private static final class_2561 VEIL_TEXT = class_2561.method_43471("minecraft-cursor.options.compat.veil")
            .method_27692(class_124.field_1067)
            .method_27692(VEIL_LOADED ? class_124.field_1068 : class_124.field_1063);
    private OptionsListWidget optionsList;

    public CompatibilityOptionsPanel(class_2561 title) {
        super(title);
    }

    @Override
    protected void initContents() {
        this.optionsList = new OptionsListWidget(this.getMinecraft(), this.getFont(), this.getSpacing());

        this.optionsList.addToggle(
                CONFIG.isAggressiveCursor(),
                CONFIG::setAggressiveCursor,
                this.index(AGGRESSIVE_TEXT),
                AGGRESSIVE_INFO,
                true
        );
        this.optionsList.addToggle(
                CursorManager.INSTANCE.isVirtual(),
                value -> {
                    CursorManager.INSTANCE.toggleVirtual();
                    CONFIG.setVirtualMode(CursorManager.INSTANCE.isVirtual());
                },
                this.index(VIRTUAL_TEXT),
                VIRTUAL_INFO,
                true
        );
        this.optionsList.addToggle(
                Flag.REMAP.isEnabled() && CONFIG.isRemapCursorsEnabled(),
                CONFIG::setRemapCursorsEnabled,
                this.index(REMAP_TEXT),
                !Flag.REMAP.isEnabled() || ExternalCursorTracker.isTracking() ? REMAP_INFO : REMAP_EMPTY_INFO,
                Flag.REMAP.isEnabled()
        );

        this.optionsList.addWidget(this.createModSectionTitle(VEIL_TEXT, VEIL_LOADED));
        this.optionsList.addToggle(
                VEIL_LOADED && CONFIG.isVeilCursorChangesDisabled(),
                CONFIG::setVeilCursorChangesDisabled,
                class_2561.method_43470("└ ").method_10852(this.index(IMGUI_DISABLE_CURSOR_CHANGES_TEXT)),
                VEIL_LOADED ? RESTART_TO_APPLY_INFO : class_7919.method_47407(class_2561.method_43469("minecraft-cursor.options.compat.mod_not_loaded", VEIL_TEXT)),
                VEIL_LOADED
        );

        this.optionsList.search(this.getSearch());

        this.addRenderableWidget(this.optionsList);
    }

    private class_7842 createModSectionTitle(class_2561 modName, boolean loaded) {
        class_7842 title = new class_7842(this.index(modName), this.getFont()).method_48596();
        title.method_47400(class_7919.method_47407(class_2561.method_43469(
                loaded ? "minecraft-cursor.options.compat.mod_loaded" : "minecraft-cursor.options.compat.mod_not_loaded",
                modName
        )));
        return title;
    }

    @Override
    protected void repositionContents(int x, int y) {
        if (this.optionsList != null) {
            this.optionsList.method_55445(this.getWidth(), this.computeMaxHeight(y));
            this.optionsList.method_48229(x, y);
        }
    }

    @Override
    protected void searched(@NotNull String search, @Nullable class_2561 matched) {
        if (this.optionsList != null) {
            this.optionsList.search(search);
        }
    }
}
