package io.github.fishstiz.minecraftcursor.gui.screen;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.widget.CursorListWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.CursorOptionsHandler;
import io.github.fishstiz.minecraftcursor.gui.widget.CursorOptionsWidget;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8132;
import net.minecraft.class_9017;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;

public class CursorOptionsScreen extends class_437 {
    private static final class_2561 TITLE_TEXT = class_2561.method_43471("minecraft-cursor.options");
    private static final int CURSORS_COLUMN_WIDTH = 96;
    private static final int SELECTED_CURSOR_COLUMN_WIDTH = 200;
    private static final int COLUMN_GAP = 8;

    private final class_8132 layout = new class_8132(this);
    private final class_4185 moreButton = class_4185.method_46430(
            class_2561.method_43471("minecraft-cursor.options.more").method_27693("..."),
            btn -> toMoreOptions()).method_46431();
    private final class_4185 doneButton = class_4185.method_46430(
            class_5244.field_24334, btn -> this.method_25419()).method_46431();

    public final CursorAnimationHelper animationHelper = new CursorAnimationHelper();
    private final CursorManager cursorManager;
    private final List<Cursor> cursors;
    private final class_437 previousScreen;
    private Cursor selectedCursor;
    CursorOptionsBody body;

    public CursorOptionsScreen(class_437 previousScreen, CursorManager cursorManager) {
        super(TITLE_TEXT);

        this.previousScreen = previousScreen;
        this.cursorManager = cursorManager;

        cursors = this.cursorManager.getLoadedCursors();
    }

    @Override
    protected void method_25426() {
        selectedCursor = cursorManager.getLoadedCursors().getFirst();

        this.layout.method_57726(this.field_22785, this.field_22793);
        this.body = this.layout.method_48999(new CursorOptionsBody());

        this.layout.method_48996(moreButton);
        this.layout.method_48996(doneButton);

        this.layout.method_48206(this::method_37063);

        if (this.body != null) {
            this.method_48640();
        }
    }

    @Override
    protected void method_48640() {
        this.layout.method_48222();

        int bodyWidth = CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH + COLUMN_GAP;
        int buttonWidth = bodyWidth / 2 - COLUMN_GAP / 2;
        int centerX = field_22789 / 2;
        int gapHalf = COLUMN_GAP / 2;

        moreButton.method_25358(buttonWidth);
        doneButton.method_25358(buttonWidth - 2);

        moreButton.method_46421(centerX - buttonWidth - gapHalf);
        doneButton.method_46421(centerX + gapHalf);

        body.position();
    }

    public void selectCursor(Cursor cursor) {
        updateSelectedCursorConfig();
        selectedCursor = cursor;

        if (body != null) {
            body.selectedCursorColumn.refresh();
        }
    }

    private void updateSelectedCursorConfig() {
        if (body != null) {
            body.selectedCursorColumn.save();
        }
    }

    public Cursor getSelectedCursor() {
        return selectedCursor;
    }

    public List<Cursor> getCursors() {
        return cursors;
    }

    public void toMoreOptions() {
        if (field_22787 != null) {
            field_22787.method_1507(new MoreOptionsScreen(this, cursorManager));
        }
    }

    @Override
    public void method_25419() {
        CursorOptionsHandler.removeScaleOverride();
        CONFIG.save();

        if (this.field_22787 != null) {
            this.field_22787.method_1507(previousScreen);
        }
    }

    public class CursorOptionsBody extends class_9017 {
        public final CursorListWidget cursorsColumn;
        public final CursorOptionsWidget selectedCursorColumn;

        public CursorOptionsBody() {
            super(layout.method_46426(), layout.method_48998(), CursorOptionsScreen.this.field_22789, layout.method_57727(), class_2561.method_43473());

            int y = layout.method_48998();
            int height = layout.method_57727();
            var screen = CursorOptionsScreen.this;

            cursorsColumn = new CursorListWidget(field_22787, CURSORS_COLUMN_WIDTH, height, y, screen);
            selectedCursorColumn = new CursorOptionsWidget(computedX2(), SELECTED_CURSOR_COLUMN_WIDTH, height, y, screen);

            position();
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
            if (cursorsColumn.method_25405(mouseX, mouseY)) {
                return cursorsColumn.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
            }
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return List.of(cursorsColumn, selectedCursorColumn);
        }

        @Override
        protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            cursorsColumn.method_48579(context, mouseX, mouseY, delta);
            selectedCursorColumn.method_48579(context, mouseX, mouseY, delta);
        }

        public void position() {
            int width = CursorOptionsScreen.this.field_22789;
            int height = layout.method_57727();
            int y = layout.method_48998();

            this.method_55445(width, height);
            this.method_48229(0, y);

            cursorsColumn.method_53533(height);
            selectedCursorColumn.method_53533(height);

            cursorsColumn.method_48229(computedX(), y);
            selectedCursorColumn.method_48229(computedX2(), y);
        }

        private int computedX() {
            return CursorOptionsScreen.this.field_22789 / 2 - (CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH + COLUMN_GAP) / 2;
        }

        private int computedX2() {
            return computedX() + CURSORS_COLUMN_WIDTH + COLUMN_GAP;
        }

        @Override
        protected void method_47399(class_6382 builder) {
            // not supported
        }
    }
}
