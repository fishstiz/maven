package io.github.fishstiz.minecraftcursor.mixin.access;

import net.minecraft.class_1735;
import net.minecraft.class_1761;
import net.minecraft.class_481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_481.class)
public interface CreativeInventoryScreenAccessor extends HandledScreenAccessor<class_481.class_483> {
    @Accessor("selectedTab")
    static class_1761 getSelectedTab() {
        throw new AssertionError();
    }

    @Accessor("destroyItemSlot")
    class_1735 getDeleteItemSlot();

    @Invoker("getTabX")
    int invokeGetTabX(class_1761 group);

    @Invoker("getTabY")
    int invokeGetTabY(class_1761 group);
}
