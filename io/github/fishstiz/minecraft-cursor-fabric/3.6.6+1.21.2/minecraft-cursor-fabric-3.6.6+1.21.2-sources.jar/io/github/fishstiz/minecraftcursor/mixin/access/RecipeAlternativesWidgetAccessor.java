package io.github.fishstiz.minecraftcursor.mixin.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_508;

@Mixin(class_508.class)
public interface RecipeAlternativesWidgetAccessor {
    @Accessor("recipeButtons")
    List<? extends class_339> getAlternativeButtons();
}
