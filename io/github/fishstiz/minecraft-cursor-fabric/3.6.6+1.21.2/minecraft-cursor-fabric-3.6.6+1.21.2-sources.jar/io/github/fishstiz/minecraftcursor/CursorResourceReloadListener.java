package io.github.fishstiz.minecraftcursor;

import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

class CursorResourceReloadListener extends AbstractCursorResourceReloadListener implements SimpleSynchronousResourceReloadListener {
    @Override
    public class_2960 getFabricId() {
        return getId();
    }

    @Override
    public void method_14491(class_3300 manager) {
        reloadMinecraftCursor(manager);
    }
}
