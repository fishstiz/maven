package io.github.fishstiz.minecraftcursor.mixin.access;

import net.minecraft.class_4185;
import net.minecraft.class_473;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_473.class)
public interface BookEditScreenAccessor {
    @Accessor("finalizeButton")
    class_4185 getFinalizeButton();

    @Invoker("convertScreenToLocal")
    class_473.class_5234 invokeScreenPosToAbsPos(class_473.class_5234 position);
}
