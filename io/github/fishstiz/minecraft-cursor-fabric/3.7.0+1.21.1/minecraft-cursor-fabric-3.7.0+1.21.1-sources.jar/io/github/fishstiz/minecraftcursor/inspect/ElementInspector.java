package io.github.fishstiz.minecraftcursor.inspect;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;

public interface ElementInspector {
    default void destroy() {
        // no-op
    }

    default boolean isEnabled() {
        return false;
    }

    default boolean setHovered(class_364 hovered, boolean cached) {
        return false;
    }

    default void renderDeepest(class_310 minecraft, class_332 guiGraphics, class_437 screen, double mouseX, double mouseY) {
        // no-op
    }

    default void renderHovered(class_310 minecraft, class_332 guiGraphics) {
        // no-op
    }

    default void renderCacheSize(class_310 minecraft, class_332 guiGraphics) {
        // no-op
    }

    static ElementInspector toggle(ElementInspector elementInspector) {
        elementInspector.destroy();

        return elementInspector instanceof ElementInspectorImpl
                ? new ElementInspector() {} // no-op inspector
                : new ElementInspectorImpl();
    }
}
