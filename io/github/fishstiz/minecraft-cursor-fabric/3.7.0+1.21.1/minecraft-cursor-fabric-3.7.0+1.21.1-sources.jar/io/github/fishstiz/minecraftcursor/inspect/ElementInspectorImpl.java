package io.github.fishstiz.minecraftcursor.inspect;

import io.github.fishstiz.minecraftcursor.platform.Services;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

public class ElementInspectorImpl implements ElementInspector {
    private static final int DEEPEST_COLOR = 0xFF00FF00; // green
    private static final int HOVERED_COLOR = 0xFFFF0000; // red
    private static final float Z = 900f;
    private static final float TEXT_SCALE = 0.75f;
    private HashSet<String> cache = new HashSet<>();
    private class_364 hovered;
    private String hoveredName;

    @Override
    public void destroy() {
        this.cache.clear();
        this.cache = null;
        this.hovered = null;
        this.hoveredName = null;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean setHovered(class_364 hovered, boolean cached) {
        this.hovered = hovered;
        this.hoveredName = getClassName(hovered);
        if (cached) {
            this.cache.add(hoveredName);
        }
        return true;
    }

    @Override
    public void renderDeepest(class_310 minecraft, class_332 guiGraphics, class_437 screen, double mouseX, double mouseY) {
        class_364 child = findDeepestChild(screen, mouseX, mouseY);
        class_364 inspect = child != null ? child : screen;
        renderElement(guiGraphics, minecraft, inspect, DEEPEST_COLOR, getClassName(inspect), true);
    }

    @Override
    public void renderHovered(class_310 minecraft, class_332 guiGraphics) {
        if (hovered != null) {
            renderElement(guiGraphics, minecraft, hovered, HOVERED_COLOR, hoveredName, false);
        }
    }

    @Override
    public void renderCacheSize(class_310 minecraft, class_332 guiGraphics) {
        String sizeString = "Cache Size: " + cache.size();
        class_327 font = minecraft.field_1772;

        int textWidth = font.method_1727(sizeString);
        int textHeight = font.field_2000;

        float scale = TEXT_SCALE;
        int x = (int) (minecraft.method_22683().method_4486() - textWidth * scale - 1);
        int y = (int) (minecraft.method_22683().method_4502() - textHeight * scale - 1);

        class_4587 poseStack = guiGraphics.method_51448();
        poseStack.method_22903();
        poseStack.method_46416(0, 0, Z);
        poseStack.method_22905(scale, scale, 0);

        guiGraphics.method_25303(font, sizeString, (int) (x / scale), (int) (y / scale), 0xFFFFFFFF);

        poseStack.method_22909();
    }

    private void renderElement(class_332 guiGraphics, class_310 minecraft, class_364 element, int color, String label, boolean bottomLabel) {
        class_8030 rect = getBounds(element);
        class_4587 poseStack = guiGraphics.method_51448();
        class_327 font = minecraft.field_1772;

        poseStack.method_22903();
        poseStack.method_46416(0, 0, Z);
        guiGraphics.method_49601(rect.method_49620(), rect.method_49618(), rect.comp_1196(), rect.comp_1197(), color);

        int textWidth = font.method_1727(label);
        int screenWidth = minecraft.method_22683().method_4486();
        int textX = rect.method_49620() + 1;

        if ((textX + textWidth * TEXT_SCALE) > screenWidth) {
            textX = (int) (screenWidth - textWidth * TEXT_SCALE);
            if (textX < 0) textX = 0;
        }

        int textY = rect.method_49618() + 1;
        if (bottomLabel) {
            if (rect.comp_1197() == 0 && rect.comp_1196() == 0) {
                textY = minecraft.method_22683().method_4502() - (int) (font.field_2000 * TEXT_SCALE) - 1;
            } else {
                textY = rect.method_49618() - 1 + Math.max(0, rect.comp_1197() - (int) (font.field_2000 * TEXT_SCALE));
            }
        }

        poseStack.method_22905(TEXT_SCALE, TEXT_SCALE, 0);
        guiGraphics.method_25303(font, label, (int) (textX / TEXT_SCALE), (int) (textY / TEXT_SCALE), color);
        poseStack.method_22909();
    }

    private class_8030 getBounds(class_364 element) {
        if (element instanceof class_8021 le) {
            return new class_8030(le.method_46426(), le.method_46427(), le.method_25368(), le.method_25364());
        }
        return element.method_48202();
    }

    private String getClassName(class_364 element) {
        String namespace = Services.PLATFORM.isDevelopmentEnvironment() ? "named" : "intermediary";
        return Services.PLATFORM.unmapClassName(namespace, element.getClass().getName());
    }

    private @Nullable class_364 findDeepestChild(class_4069 parent, double mouseX, double mouseY) {
        Optional<class_364> child = parent.method_19355(mouseX, mouseY);
        if (child.isPresent()) {
            class_364 hoveredElement = child.get();
            if (hoveredElement instanceof class_4069 nestedParent) {
                class_364 deepChild = findDeepestChild(nestedParent, mouseX, mouseY);
                return (deepChild != null) ? deepChild : hoveredElement;
            }
            return hoveredElement;
        }
        return null;
    }
}
