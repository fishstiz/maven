package io.github.fishstiz.minecraftcursor.mixin;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_353;
import net.minecraft.class_4288;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import net.minecraft.class_5676;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.minecraft.class_7172.method_42399;

@Mixin(class_4288.class)
public abstract class MouseOptionsScreenMixin extends class_4667 {
    @Unique
    private static final class_2561 CURSOR_SETTINGS_TEXT = class_2561.method_43471("minecraft-cursor.options");

    @Shadow
    private class_353 list;

    protected MouseOptionsScreenMixin(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    @Inject(method = "init", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/MouseSettingsScreen;addWidget(Lnet/minecraft/client/gui/components/events/GuiEventListener;)Lnet/minecraft/client/gui/components/events/GuiEventListener;"))
    public void init(CallbackInfo ci) {
        class_7172<Boolean> button = class_7172.method_41750(
                "",
                method_42399(),
                false,
                value -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new CursorOptionsScreen(this, CursorManager.INSTANCE));
                    }
                });
        list.method_20406(button);
        class_5676<?> widget = (class_5676<?>) list.method_31046(button);
        assert widget != null;
        widget.method_25355(class_2561.method_43473().method_10852(CURSOR_SETTINGS_TEXT).method_27693("..."));
    }
}
