package io.github.fishstiz.minecraftcursor.gui.screen;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.gui.widget.MoreOptionsListWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.SelectedCursorButtonWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.SelectedCursorHotspotWidget;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7842;
import net.minecraft.class_7847;
import net.minecraft.class_7849;
import net.minecraft.class_8132;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class MoreOptionsScreen extends class_437 {
    private static final int FOOTER_SPACING = 8;
    private static final int HOTSPOT_WIDGET_SIZE = 96;
    private final class_8132 layout = new class_8132(this);
    private final class_437 previousScreen;
    private @Nullable SelectedCursorHotspotWidget hotspotWidget;
    private MoreOptionsListWidget list;
    private class_4185 inspectButton;
    private class_4185 doneButton;

    protected MoreOptionsScreen(class_437 previousScreen) {
        super(class_2561.method_43471("minecraft-cursor.options.more"));

        this.previousScreen = previousScreen;
    }

    @Override
    protected void method_25426() {
        this.list = new MoreOptionsListWidget(
                this.field_22787,
                field_22789,
                getContentHeight(),
                layout.method_48998(),
                layout.method_48998() + getContentHeight()
        );

        if (previousScreen instanceof CursorOptionsScreen optionsScreen && optionsScreen.body != null) {
            this.hotspotWidget = new SelectedCursorHotspotWidget(HOTSPOT_WIDGET_SIZE, optionsScreen.body.selectedCursorColumn);
            this.hotspotWidget.field_22764 = false;
            this.hotspotWidget.setChangeEventListener(this.list::handleChangeHotspotWidget);
            this.method_25429(this.hotspotWidget);
        }

        this.layout.method_48992(new class_7842(this.field_22785, this.field_22793));
        this.layout.method_48999(this.method_37063(this.list));
        this.layout.method_48996(this.createFooter());
        this.layout.method_48206(this::method_37063);
        this.layout.method_48222();
        this.method_48640();
    }

    private class_7849 createFooter() {
        class_7849 footer = new class_7849(0, 0, class_7849.class_7851.field_40789);

        class_2960 inspectIcon = new class_2960("minecraft", "textures/gui/sprites/icon/search.png");
        int iconSize = 12;
        int inspectSize = 20;

        class_4185 inspect = new SelectedCursorButtonWidget(inspectIcon, iconSize, iconSize, MinecraftCursor::toggleInspect);
        inspect.method_25358(inspectSize);

        this.doneButton = footer.method_46495(class_4185.method_46430(class_5244.field_24334, btn -> this.method_25419()).method_46431());
        this.inspectButton = footer.method_46496(inspect, class_7847.method_46481().method_46473(FOOTER_SPACING));

        return footer;
    }

    @Override
    protected void method_48640() {
        if (this.list != null) {
            this.layout.method_48222();
            this.list.position(field_22789, getContentHeight(), layout.method_48998());

            if (this.inspectButton != null & this.doneButton != null) {
                int footerWidth = this.inspectButton.method_25368() + this.doneButton.method_25368() + FOOTER_SPACING;
                int footerX = this.field_22789 / 2 - footerWidth / 2;

                this.inspectButton.method_46421(footerX);
                this.doneButton.method_46421(footerX + this.inspectButton.method_25368() + FOOTER_SPACING);
            }
        }
    }

    @Override
    public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25434(context);
        super.method_25394(context, mouseX, mouseY, delta);

        if (hotspotWidget == null) return;

        if (list.isEditingHotspot()) {
            int rowGap = list.getRowGap();
            int x = list.method_25342() - hotspotWidget.method_25368() - rowGap;
            int y = list.getYEntry(1) + rowGap / 2;

            hotspotWidget.method_48229(x, y);
            hotspotWidget.field_22764 = true;
            hotspotWidget.field_22763 = true;

            context.method_44379(x, layout.method_48998(), list.method_25342(), layout.method_48998() + getContentHeight());
            hotspotWidget.method_48579(context, mouseX, mouseY, delta);
            context.method_44380();
        } else {
            hotspotWidget.field_22764 = false;
            hotspotWidget.field_22763 = false;
        }
    }

    @Override
    public void method_25419() {
        list.applyConfig();

        if (this.field_22787 != null) {
            if (previousScreen instanceof CursorOptionsScreen options && options.body != null) {
                CursorOptionsScreen optionsScreen = new CursorOptionsScreen(options.previousScreen);
                this.field_22787.method_1507(optionsScreen);
                optionsScreen.selectCursor(options.getSelectedCursor());
            } else {
                this.field_22787.method_1507(previousScreen);
            }
        }
    }

    public int getContentHeight() {
        return field_22790 - layout.method_48998() - layout.method_48994();
    }
}
