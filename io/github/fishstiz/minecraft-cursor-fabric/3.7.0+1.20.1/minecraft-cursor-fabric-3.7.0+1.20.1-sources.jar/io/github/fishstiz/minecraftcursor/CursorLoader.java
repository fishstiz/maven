package io.github.fishstiz.minecraftcursor;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.config.AnimatedCursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfigLoader;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import javax.imageio.ImageIO;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;
import static io.github.fishstiz.minecraftcursor.MinecraftCursor.MOD_ID;

public class CursorLoader {
    private static final String IMG_TYPE = ".png";
    private static final String ANIMATION_TYPE = IMG_TYPE + ".mcmeta";
    private static final String CONFIG_PATH = "atlases/cursors.json";
    private static final String CURSORS_DIR = "textures/cursors/";
    private static CursorConfig resourceConfig;

    private CursorLoader() {
    }

    public static void resetConfig() {
        if (resourceConfig != null) {
            CONFIG.set_hash(resourceConfig.get_hash());
            CONFIG.layerSettings(resourceConfig.getSettings());

            for (Cursor cursor : CursorManager.INSTANCE.getCursors()) {
                cursor.applySettings(CONFIG.getOrCreateCursorSettings(cursor.getType()).copy());
            }
        } else {
            MinecraftCursor.LOGGER.error("Failed to apply resource config: Not Found.");
        }
    }

    public static class_2960 getLocation() {
        return new class_2960(MOD_ID, CURSORS_DIR);
    }

    public static void applyDefaultCursor() {
        CursorManager.INSTANCE.setCurrentCursor(CursorType.DEFAULT);
    }

    public static void reload(class_3300 manager) {
        applyDefaultCursor();
        loadConfig(manager);
        loadCursorTextures(manager);
        class_310.method_1551().execute(CursorLoader::applyDefaultCursor);
    }

    private static void loadConfig(class_3300 manager) {
        List<class_3298> configResources = manager.method_14489(new class_2960(MOD_ID, CONFIG_PATH));

        if (configResources.isEmpty()) return;

        getConfigFromResources(configResources).ifPresent(config -> {
            if (!config.get_hash().equals(CONFIG.get_hash())) {
                MinecraftCursor.LOGGER.info("[minecraft-cursor] New resource pack settings detected, updating config...");
                CONFIG.set_hash(config.get_hash());
                CONFIG.mergeSettings(config.getSettings());
                CONFIG.getGlobal().setActiveAll(false);
                CONFIG.save();
            }
            resourceConfig = config;
        });
    }

    private static Optional<CursorConfig> getConfigFromResources(List<class_3298> configResources) {
        CursorConfig combinedConfig = null;

        for (class_3298 configResource : configResources) {
            try (InputStream stream = configResource.method_14482()) {
                CursorConfig loadedConfig = CursorConfigLoader.fromStream(stream);

                if (combinedConfig == null) {
                    combinedConfig = loadedConfig;
                } else {
                    combinedConfig.layerSettings(loadedConfig.getSettings());
                }
            } catch (IOException e) {
                MinecraftCursor.LOGGER.error("[minecraft-cursor] Failed to load settings of resource pack '{}'", configResource.method_14480());
            }
        }

        return Optional.ofNullable(combinedConfig);
    }

    private static void loadCursorTextures(class_3300 manager) {
        for (Cursor cursor : CursorManager.INSTANCE.getCursors()) {
            loadCursorTexture(manager, cursor);
        }
    }

    public static void loadCursorTexture(class_3300 manager, Cursor cursor) {
        String basePath = CURSORS_DIR + cursor.getType().getKey();
        class_2960 location = new class_2960(MOD_ID, basePath + IMG_TYPE);
        class_3298 cursorResource = manager.method_14486(location).orElse(null);

        if (cursorResource == null) {
            MinecraftCursor.LOGGER.error("[minecraft-cursor] Cursor Type: '{}' not found", cursor.getType().getKey());
            return;
        }

        BufferedImage image = null;
        try (InputStream cursorStream = cursorResource.method_14482()) {
            image = ImageIO.read(cursorStream);
            if (image == null) {
                MinecraftCursor.LOGGER.error("[minecraft-cursor] Invalid file for cursor type '{}'", cursor.getType().getKey());
                return;
            }

            AnimatedCursorConfig animation = loadAnimation(manager, basePath, cursorResource);
            CursorManager.INSTANCE.loadCursor(cursor, location, image, animation);
        } catch (IOException e) {
            MinecraftCursor.LOGGER.error("[minecraft-cursor] Failed to load cursor image for '{}'", basePath);
        } finally {
            if (image != null) image.flush();
        }
    }

    private static AnimatedCursorConfig loadAnimation(class_3300 manager, String basePath, class_3298 cursorResource) {
        class_3298 animationResource = manager
                .method_14486(new class_2960(MOD_ID, basePath + ANIMATION_TYPE))
                .orElse(null);

        if (animationResource != null && animationResource.method_14480().equals(cursorResource.method_14480())) {
            try (InputStream stream = animationResource.method_14482()) {
                return CursorConfigLoader.getAnimationConfig(stream);
            } catch (IOException e) {
                MinecraftCursor.LOGGER.error("[minecraft-cursor] Failed to load animation config for '{}'", basePath);
            }
        }

        return null;
    }
}
