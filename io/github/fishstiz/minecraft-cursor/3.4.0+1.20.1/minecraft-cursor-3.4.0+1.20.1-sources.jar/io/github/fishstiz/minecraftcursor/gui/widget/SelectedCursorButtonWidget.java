package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class SelectedCursorButtonWidget extends class_4185 {
    private class_2960 icon;
    private int iconWidth;
    private int iconHeight;

    public SelectedCursorButtonWidget(class_2960 icon, int iconWidth, int iconHeight, Runnable onPress) {
        this(class_2561.method_43473(), onPress);

        this.icon = icon;
        this.iconWidth = iconWidth;
        this.iconHeight = iconHeight;
    }

    public SelectedCursorButtonWidget(class_2561 message, Runnable onPress) {
        super(0, 0, 150, 20, message, b -> onPress.run(), class_4185.field_40754);
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        super.method_25357(mouseX, mouseY);
        method_25365(false);
    }


    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_48579(context, mouseX, mouseY, delta);

        if (icon != null) {
            int iconX = method_46426() + (method_25368() - iconWidth) / 2;
            int iconY = method_46427() + (method_25364() - iconHeight) / 2;

            context.method_25290(
                    icon,
                    iconX, iconY,
                    0, 0,
                    iconWidth, iconHeight,
                    iconWidth, iconHeight
            );
        }
    }
}
