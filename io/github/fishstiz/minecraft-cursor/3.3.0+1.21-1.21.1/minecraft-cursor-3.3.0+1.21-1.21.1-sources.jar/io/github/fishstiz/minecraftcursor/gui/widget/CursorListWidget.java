package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.cursor.AnimatedCursor;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4264;
import net.minecraft.class_4265;
import net.minecraft.class_6379;
import net.minecraft.class_6382;

public class CursorListWidget extends class_4265<CursorListWidget.CursorWidgetEntry> {
    private static final int ITEM_HEIGHT = 32;
    private static final int SCROLLBAR_OFFSET = 6;
    private static final int ROW_GAP = 1;
    private final List<CursorWidgetEntry> entries = new ArrayList<>();
    private final CursorOptionsScreen optionsScreen;

    public CursorListWidget(class_310 client, int width, CursorOptionsScreen optionsScreen) {
        super(client, width + SCROLLBAR_OFFSET, optionsScreen.layout.method_57727(), optionsScreen.layout.method_48998(), ITEM_HEIGHT + ROW_GAP);
        this.optionsScreen = optionsScreen;
        populateEntries();
    }

    public void populateEntries() {
        List<Cursor> cursors = optionsScreen.getCursors();
        for (Cursor cursor : cursors) {
            CursorWidgetEntry entry = new CursorWidgetEntry(
                    cursor,
                    optionsScreen.layout.method_48998() + field_22741 * method_25340(),
                    field_22758 - SCROLLBAR_OFFSET,
                    ITEM_HEIGHT,
                    field_22740,
                    optionsScreen
            );
            entries.add(entry);
            this.method_25321(entry);
        }
    }

    @Override
    protected int method_25329() {
        return method_55442() - 6;
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        method_60322();
        for (CursorWidgetEntry entry : entries) {
            entry.button.method_46421(x);
        }
    }

    @Override
    protected void method_57713(class_332 context) {
    }

    @Override
    public void method_57715(class_332 context) {
    }

    public class CursorWidgetEntry extends Entry<CursorWidgetEntry> {
        public class_4264 button;

        public CursorWidgetEntry(Cursor cursor, int y, int width, int height, class_310 client, CursorOptionsScreen optionsScreen) {
            button = new CursorClickableWidget(0, y, width, height, cursor, client, optionsScreen);
        }

        @Override
        public void render(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
            button.method_25394(context, mouseX, mouseY, delta);
            button.method_46419(optionsScreen.layout.method_48998() + (field_22741 + ROW_GAP) * index - (int) Math.round(method_25341()));
        }

        @Override
        public List<? extends class_6379> selectableChildren() {
            return List.of(button);
        }

        @Override
        public List<? extends class_364> children() {
            return List.of(button);
        }
    }

    public static class CursorClickableWidget extends class_4264 {
        private static final String PREFIX_TEXT_KEY = "minecraft-cursor.options.cursor-type.";
        private static final int CURSOR_SIZE = 32;
        private static final int TEXTURE_SIZE = 16;
        private static final int PADDING_LEFT = 8;
        private static final int BACKGROUND_COLOR = 0x7F000000; // black 50%
        private static final int TEXT_COLOR = 0xFFFFFFFF; // white
        private static final int TEXT_DISABLED_COLOR = 0xFF555555; // dark gray
        private static final int BORDER_COLOR = 0xFFFFFFFF; // white
        private final class_310 client;
        private final CursorOptionsScreen optionsScreen;
        private final Cursor cursor;

        public CursorClickableWidget(int x, int y, int width, int height, Cursor cursor, class_310 client, CursorOptionsScreen optionsScreen) {
            super(x, y, width, height, class_2561.method_43473());
            this.client = client;
            this.optionsScreen = optionsScreen;
            this.cursor = cursor;
        }

        @Override
        public void method_25306() {
            optionsScreen.selectCursor(cursor);
        }

        @Override
        protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            renderBox(context);
            renderTexture(context);
            renderMessage(context);

            context.method_49601(method_46426(), method_46427(), method_25368(), method_25364(),
                    method_25367() || cursor == optionsScreen.getSelectedCursor() ? BORDER_COLOR : 0xFF000000);
        }

        private void renderBox(class_332 context) {
            int x2 = method_46426() + method_25368();
            int y2 = method_46427() + method_25364();
            context.method_25294(method_46426(), method_46427(), x2, y2, BACKGROUND_COLOR);
        }

        private void renderTexture(class_332 context) {
            int x = method_46426() + PADDING_LEFT;
            int y = method_46427() + (method_25364() / 2) - (TEXTURE_SIZE / 2);
            int frameIndex = 0;

            if (cursor instanceof AnimatedCursor animatedCursor) {
                frameIndex = optionsScreen.animationHelper.getCurrentSpriteIndex(animatedCursor);
            }

            int vOffset = CURSOR_SIZE * frameIndex;

            context.method_25293(
                    cursor.getSprite(),
                    x, y,
                    TEXTURE_SIZE, TEXTURE_SIZE, // width/height to stretch/shrink
                    0, vOffset, // starting point
                    CURSOR_SIZE, CURSOR_SIZE, // cropped width/height from actual image
                    cursor.getTrueWidth(), cursor.getTrueHeight() // actual width/height
            );
        }

        private void renderMessage(class_332 context) {
            int x = method_46426() + TEXTURE_SIZE + PADDING_LEFT * 2;
            int y = method_46427() + (method_25364() / 2) - Math.round(client.field_1772.field_2000 * 1.5f);
            class_2561 name = class_2561.method_43471(PREFIX_TEXT_KEY + cursor.getType().getKey());
            context.method_51439(client.field_1772, name, x, y + Math.round(method_25364() / 3.0f), cursor.isEnabled() ? TEXT_COLOR : TEXT_DISABLED_COLOR, false);
        }

        @Override
        protected void method_47399(class_6382 builder) {
        }
    }
}
