package io.github.fishstiz.minecraftcursor.gui.widget;

import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;

public class SelectedCursorSliderWidget extends class_357 {
    private final class_2561 prefix;
    private final double min;
    private final double max;
    private final double step;
    private final String suffix;
    private final Consumer<Double> onApply;
    private final @Nullable Runnable onRelease;
    private double translatedValue;

    SelectedCursorSliderWidget(
            class_2561 text,
            double defaultValue,
            double min,
            double max,
            double step,
            Consumer<Double> onApply,
            Runnable onRelease,
            SelectedCursorOptionsWidget optionsWidget
    ) {
        this(text, defaultValue, min, max, step, "", onApply, onRelease, optionsWidget);
    }

    SelectedCursorSliderWidget(
            class_2561 text,
            double defaultValue,
            double min,
            double max,
            double step,
            String suffix,
            Consumer<Double> onApply,
            SelectedCursorOptionsWidget optionsWidget
    ) {
        this(text, defaultValue, min, max, step, suffix, onApply, null, optionsWidget);
    }

    SelectedCursorSliderWidget(
            class_2561 text,
            double defaultValue,
            double min,
            double max,
            double step,
            String suffix,
            Consumer<Double> onApply,
            @Nullable Runnable onRelease,
            SelectedCursorOptionsWidget optionsWidget
    ) {
        super(optionsWidget.method_46426(), optionsWidget.method_46427(), optionsWidget.method_25368() / 2, SelectedCursorOptionsWidget.OPTIONS_HEIGHT, text, defaultValue);

        this.prefix = text;
        this.min = min;
        this.max = max;
        this.step = step;
        this.suffix = suffix;
        this.onApply = onApply;
        this.onRelease = onRelease;

        translateValue();
        method_25346();
    }

    public void method_25347(double translatedValue) {
        double clampedValue = Math.max(min, Math.min(translatedValue, max));
        field_22753 = (clampedValue - min) / (max - min);

        method_25344();
        method_25346();
    }

    private void translateValue() {
        double scaledValue = min + (field_22753 * (max - min));
        translatedValue = Math.round(scaledValue / step) * step;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_48579(context, mouseX, mouseY, delta);
        field_22762 = method_25405(mouseX, mouseY);
    }

    @Override
    protected void method_25344() {
        double previousTranslatedValue = translatedValue;

        translateValue();

        if (previousTranslatedValue != translatedValue) {
            onApply.accept(translatedValue);
        }
    }

    @Override
    protected void method_25346() {
        String formattedValue = String.format(step % 1 == 0 ? "%.0f" : "%.2f", translatedValue);
        method_25355(class_2561.method_43473().method_10852(prefix).method_10852(class_2561.method_30163(": " + formattedValue + suffix)));
    }

    public double getTranslatedValue() {
        return translatedValue;
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        super.method_25357(mouseX, mouseY);
        method_25365(false);

        if (this.onRelease != null) {
            this.onRelease.run();
        }
    }
}