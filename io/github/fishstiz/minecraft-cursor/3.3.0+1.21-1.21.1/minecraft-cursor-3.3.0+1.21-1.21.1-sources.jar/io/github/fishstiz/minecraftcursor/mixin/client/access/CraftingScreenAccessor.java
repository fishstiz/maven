package io.github.fishstiz.minecraftcursor.mixin.client.access;

import net.minecraft.class_1714;
import net.minecraft.class_479;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_479.class)
public interface CraftingScreenAccessor extends HandledScreenAccessor<class_1714> {
    @Accessor("recipeBook")
    class_507 getRecipeBook();
}
