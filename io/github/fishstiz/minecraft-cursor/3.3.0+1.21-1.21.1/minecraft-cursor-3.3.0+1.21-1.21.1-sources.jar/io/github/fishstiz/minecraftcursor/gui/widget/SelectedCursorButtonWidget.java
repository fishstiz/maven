package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class SelectedCursorButtonWidget extends class_4185 {
    public SelectedCursorButtonWidget(class_2561 message, Runnable onPress) {
        super(0, 0, 150, 20, message, b -> onPress.run(), class_4185.field_40754);
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        super.method_25357(mouseX, mouseY);
        method_25365(false);
    }
}
