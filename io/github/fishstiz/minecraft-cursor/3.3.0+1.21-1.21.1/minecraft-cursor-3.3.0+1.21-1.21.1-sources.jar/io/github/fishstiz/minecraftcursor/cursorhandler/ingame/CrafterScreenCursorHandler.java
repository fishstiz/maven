package io.github.fishstiz.minecraftcursor.cursorhandler.ingame;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.mixin.client.access.HandledScreenAccessor;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8881;
import net.minecraft.class_8882;
import net.minecraft.class_8898;

public class CrafterScreenCursorHandler extends HandledScreenCursorHandler<class_8881, class_8898> {
    @Override
    @SuppressWarnings("unchecked")
    public CursorType getCursorType(class_8898 crafterScreen, double mouseX, double mouseY) {
        CursorType cursorType = super.getCursorType(crafterScreen, mouseX, mouseY);
        if (cursorType != CursorType.DEFAULT) return cursorType;

        class_746 player = class_310.method_1551().field_1724;
        if (player == null) return CursorType.DEFAULT;

        class_1735 focusedSlot = ((HandledScreenAccessor<class_8881>) crafterScreen).getFocusedSlot();
        if (focusedSlot instanceof class_8882
                && ((HandledScreenAccessor<class_8881>) crafterScreen).getHandler().method_34255().method_7960()
                && !focusedSlot.method_7681()
                && !player.method_7325()) {
            return CursorType.POINTER;
        }
        return CursorType.DEFAULT;
    }
}
