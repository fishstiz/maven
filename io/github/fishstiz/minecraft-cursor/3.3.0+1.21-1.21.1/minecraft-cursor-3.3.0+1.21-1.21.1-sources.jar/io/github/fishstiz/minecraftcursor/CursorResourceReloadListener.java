package io.github.fishstiz.minecraftcursor;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.config.AnimatedCursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfigLoader;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

class CursorResourceReloadListener implements SimpleSynchronousResourceReloadListener {
    private static final String IMG_TYPE = ".png";
    private static final String ANIMATION_TYPE = IMG_TYPE + ".mcmeta";
    private static final String CONFIG_PATH = "atlases/cursors.json";
    private static final String CURSORS_DIR = "textures/cursors";
    private final CursorManager cursorManager;
    private final CursorConfig config;
    private final String namespace;

    CursorResourceReloadListener(CursorManager cursorManager, String namespace, CursorConfig config) {
        this.cursorManager = cursorManager;
        this.namespace = namespace;
        this.config = config;
    }

    @Override
    public class_2960 getFabricId() {
        return class_2960.method_60655(namespace, CURSORS_DIR);
    }

    @Override
    public void method_14491(class_3300 manager) {
        loadConfig(manager);
        loadCursorTextures(manager);
        cursorManager.setCurrentCursor(CursorType.DEFAULT);
    }

    private void loadConfig(class_3300 manager) {
        class_3298 configResource = manager.method_14486(class_2960.method_60655(namespace, CONFIG_PATH)).orElse(null);

        if (configResource == null) return;

        try (InputStream stream = configResource.method_14482()) {
            CursorConfig resourceConfig = CursorConfigLoader.fromStream(stream);
            if (!resourceConfig.get_hash().equals(config.get_hash())) {
                config.set_hash(resourceConfig.get_hash());
                config.setSettings(resourceConfig.getSettings());
                config.save();
                MinecraftCursor.LOGGER.info("New resource pack settings detected for minecraft-cursor '{}'", configResource.method_14480());
            }
        } catch (IOException e) {
            MinecraftCursor.LOGGER.error("Failed to load settings of resource pack '{}'", configResource.method_14480());
        }
    }

    private void loadCursorTextures(class_3300 manager) {
        for (CursorType cursorType : CursorTypeRegistry.types()) {
            String basePath = CURSORS_DIR + "/" + cursorType.getKey();
            loadCursorTexture(manager, cursorType, basePath);
        }
    }

    private void loadCursorTexture(class_3300 manager, CursorType cursorType, String basePath) {
        class_2960 cursorId = class_2960.method_60655(namespace, basePath + IMG_TYPE);
        class_3298 cursorResource = manager.method_14486(cursorId).orElse(null);

        if (cursorResource == null) return;

        BufferedImage image = null;
        try (InputStream cursorStream = cursorResource.method_14482()) {
            image = ImageIO.read(cursorStream);
            if (image == null) {
                MinecraftCursor.LOGGER.error("Invalid file for cursor type '{}'", cursorType);
                return;
            }

            AnimatedCursorConfig animaton = loadAnimationConfig(manager, basePath, cursorResource);
            cursorManager.loadCursorImage(cursorType, cursorId, image, config.getOrCreateCursorSettings(cursorType), animaton);
        } catch (IOException e) {
            MinecraftCursor.LOGGER.error("Failed to load cursor image for '{}'", basePath);
        } finally {
            if (image != null) image.flush();
        }
    }

    private AnimatedCursorConfig loadAnimationConfig(class_3300 manager, String basePath, class_3298 cursorResource) {
        class_3298 animationResource = manager
                .method_14486(class_2960.method_60655(namespace, basePath + ANIMATION_TYPE))
                .orElse(null);

        if (animationResource != null && animationResource.method_14480().equals(cursorResource.method_14480())) {
            try (InputStream stream = animationResource.method_14482()) {
                return CursorConfigLoader.getAnimationConfig(stream);
            } catch (IOException e) {
                MinecraftCursor.LOGGER.error("Failed to load animation config for '{}'", basePath);
            }
        }

        return null;
    }
}
