package io.github.fishstiz.minecraftcursor.cursorhandler.ingame;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.mixin.client.access.AdvancementsScreenAccessor;
import net.minecraft.class_454;
import net.minecraft.class_457;

public class AdvancementsScreenCursorHandler implements CursorHandler<class_457> {
    @Override
    public CursorType getCursorType(class_457 advancementsScreen, double mouseX, double mouseY) {
        if (!MinecraftCursor.CONFIG.isAdvancementTabsEnabled()) return CursorType.DEFAULT;

        int x = (advancementsScreen.field_22789 - class_457.field_32298) / 2;
        int y = (advancementsScreen.field_22790 - class_457.field_32299) / 2;
        for (class_454 tab : ((AdvancementsScreenAccessor) advancementsScreen).getTabs().values()) {
            if (tab.method_2316(x, y, mouseX, mouseY)
                    && tab != ((AdvancementsScreenAccessor) advancementsScreen).getSelectedTab()) {
                return CursorType.POINTER;
            }
        }
        return CursorType.DEFAULT;
    }
}
