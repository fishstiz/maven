package io.github.fishstiz.minecraftcursor.mixin.client.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_342;
import net.minecraft.class_361;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_513;

@Mixin(class_507.class)
public interface RecipeBookWidgetAccessor {
    @Invoker("isOpen")
    boolean invokeIsOpen();

    @Accessor("searchField")
    class_342 getSearchField();

    @Accessor("toggleCraftableButton")
    class_361 getToggleCraftableButton();

    @Accessor("tabButtons")
    List<class_512> getTabButtons();

    @Accessor("currentTab")
    class_512 getCurrentTab();

    @Accessor("recipesArea")
    class_513 getRecipesArea();
}
