package io.github.fishstiz.minecraftcursor.util;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class CursorTypeUtil {
    private CursorTypeUtil() {
    }

    private static final class_310 client = class_310.method_1551();

    public static boolean canShift() {
        long handle = client.method_22683().method_4490();
        return getCursorManager().getCursor(CursorType.SHIFT).getId() != 0
                && (class_3675.method_15987(handle, GLFW.GLFW_KEY_LEFT_SHIFT)
                || class_3675.method_15987(handle, GLFW.GLFW_KEY_RIGHT_SHIFT));
    }

    public static boolean isGrabbing() {
        return getCursorManager().getCursor(CursorType.GRABBING).getId() != 0
                && getCursorManager().getCurrentCursor().getType() == CursorType.GRABBING
                && isLeftClickHeld();
    }

    public static boolean isLeftClickHeld() {
        return GLFW.glfwGetMouseButton(client.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS;
    }

    private static class CursorManagerHolder {
        private static final CursorManager INSTANCE = io.github.fishstiz.minecraftcursor.MinecraftCursor.getCursorManager();
    }

    private static CursorManager getCursorManager() {
        return CursorManagerHolder.INSTANCE;
    }
}
