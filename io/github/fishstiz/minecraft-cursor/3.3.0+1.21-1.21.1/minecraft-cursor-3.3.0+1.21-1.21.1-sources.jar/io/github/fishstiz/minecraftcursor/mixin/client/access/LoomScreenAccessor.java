package io.github.fishstiz.minecraftcursor.mixin.client.access;

import net.minecraft.class_1726;
import net.minecraft.class_494;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_494.class)
public interface LoomScreenAccessor extends HandledScreenAccessor<class_1726> {
    @Accessor("canApplyDyePattern")
    boolean getCanApplyDyePattern();

    @Accessor("visibleTopRow")
    int getVisibleTopRow();
}
