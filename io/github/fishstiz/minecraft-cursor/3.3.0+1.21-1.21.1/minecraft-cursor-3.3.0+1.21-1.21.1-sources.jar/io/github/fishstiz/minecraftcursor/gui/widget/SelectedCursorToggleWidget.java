package io.github.fishstiz.minecraftcursor.gui.widget;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

public class SelectedCursorToggleWidget extends class_4185 {
    protected boolean value;
    protected class_2561 prefix;
    protected Consumer<Boolean> onPressConsumer;

    protected SelectedCursorToggleWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress, class_7841 narrationSupplier) {
        super(x, y, width, height, message, onPress, narrationSupplier);
    }

    public static SelectedCursorToggleWidget build(class_2561 prefix, boolean defaultValue, Consumer<Boolean> onPress) {
        return new SelectedCursorToggleWidget(0, 0, 150, 20,
                prefix, SelectedCursorToggleWidget::onPressButton, class_4185.field_40754)
                .initialize(prefix, defaultValue, onPress);
    }

    protected SelectedCursorToggleWidget initialize(class_2561 prefix, boolean defaultValue, Consumer<Boolean> onPress) {
        this.prefix = prefix;
        this.value = defaultValue;
        this.onPressConsumer = onPress;
        updateMessage();

        return this;
    }

    protected static void onPressButton(class_4185 buttonWidget) {
        SelectedCursorToggleWidget toggleWidget = (SelectedCursorToggleWidget) buttonWidget;
        toggleWidget.toggleValue();
        toggleWidget.onPressConsumer.accept(toggleWidget.value);
    }

    protected void toggleValue() {
        value = !value;
        updateMessage();
    }

    public void setValue(boolean value) {
        this.value = value;
        updateMessage();
    }

    protected void updateMessage() {
        class_2561 message = class_2561.method_43473()
                .method_10852(prefix)
                .method_27693(": ")
                .method_10852(value ? class_5244.field_24332 : class_5244.field_24333);

        method_25355(message);
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        super.method_25357(mouseX, mouseY);
        method_25365(false);
    }
}
