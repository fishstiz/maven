package io.github.fishstiz.minecraftcursor.gui.screen;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.gui.widget.SelectedCursorToggleWidget;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_7919;
import net.minecraft.class_8132;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;

public class RegistryOptionsScreen extends class_437 {
    private static final class_7919 ADAPTIVE_CURSOR_TOOLTIP = class_7919.method_47407(class_2561.method_43471("minecraft-cursor.options.more.adapt.tooltip"));
    private static final class_2561 ENABLED_TEXT = class_2561.method_43471("minecraft-cursor.options.enabled");
    private static final class_2561 ADAPTIVE_CURSOR_TEXT = class_2561.method_43471("minecraft-cursor.options.more.adapt");
    private static final class_2561 ITEM_SLOT_TEXT = class_2561.method_43471("minecraft-cursor.options.item_slot");
    private static final class_2561 ITEM_GRAB_TEXT = class_2561.method_43471("minecraft-cursor.options.item_grab");
    private static final class_2561 CREATIVE_TABS_TEXT = class_2561.method_43471("minecraft-cursor.options.creative_tabs");
    private static final class_2561 ENCHANTMENTS_TEXT = class_2561.method_43471("minecraft-cursor.options.enchantments");
    private static final class_2561 STONECUTTER_TEXT = class_2561.method_43471("minecraft-cursor.options.stonecutter");
    private static final class_2561 BOOK_EDIT_TEXT = class_2561.method_43471("minecraft-cursor.options.book_edit");
    private static final class_2561 LOOM_TEXT = class_2561.method_43471("minecraft-cursor.options.loom");
    private static final class_2561 ADVANCEMENTS_TEXT = class_2561.method_43471("minecraft-cursor.options.advancements");
    private static final class_2561 WORLD_ICON_TEXT = class_2561.method_43471("minecraft-cursor.options.world");
    private static final class_2561 SERVER_ICON_TEXT = class_2561.method_43471("minecraft-cursor.options.server");
    private static final int BUTTON_WIDTH = 40;
    private static final int ITEM_HEIGHT = 20;
    private static final int ROW_GAP = 6;
    private final class_8132 layout = new class_8132(this);
    private final class_437 previousScreen;
    private final CursorManager cursorManager;
    private RegistryListWidget body;

    protected RegistryOptionsScreen(class_437 previousScreen, CursorManager cursorManager) {
        super(class_2561.method_43471("minecraft-cursor.options.more"));
        this.previousScreen = previousScreen;
        this.cursorManager = cursorManager;
    }

    @Override
    protected void method_25426() {
        this.layout.method_57726(this.field_22785, this.field_22793);
        this.body = this.layout.method_48999(new RegistryListWidget(this.field_22787, this));
        this.layout.method_48996(class_4185.method_46430(class_5244.field_24334, btn -> this.method_25419()).method_46431());
        this.layout.method_48206(this::method_37063);
        this.refreshWidgetPositions();
    }

    protected void refreshWidgetPositions() {
        if (this.body != null) {
            this.layout.method_48222();
            this.body.method_57712(field_22789, layout);
        }
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            if (previousScreen instanceof CursorOptionsScreen screen && screen.body != null) {
                CursorOptionsScreen optionsScreen = new CursorOptionsScreen(screen.previousScreen, cursorManager);
                this.field_22787.method_1507(optionsScreen);
                optionsScreen.selectCursor(screen.getSelectedCursor());
            } else {
                this.field_22787.method_1507(previousScreen);
            }
        }
    }

    public void enableAll(boolean isEnabled) {
        body.options.forEach(option -> {
            option.toggleButton.field_22763 = isEnabled;
            option.toggleButton.setValue(isEnabled);
        });
        cursorManager.setIsAdaptive(isEnabled);

        CONFIG.getSettings().forEach((key, settings) -> settings.update(
                settings.getScale(),
                settings.getXHot(),
                settings.getYHot(),
                isEnabled
        ));
    }

    public class RegistryListWidget extends class_4265<RegistryListWidget.RegistryEntry> {
        public final List<RegistryEntry> options = new ArrayList<>();

        public RegistryListWidget(class_310 minecraftClient, RegistryOptionsScreen options) {
            super(minecraftClient, options.field_22789, options.layout.method_57727(), options.layout.method_48998(), ITEM_HEIGHT + ROW_GAP);
            populateEntries();
        }

        public void populateEntries() {
            boolean isAdaptive = cursorManager.isAdaptive();

            this.method_25321(new RegistryEntry(ADAPTIVE_CURSOR_TEXT));
            this.method_25321(new RegistryEntry(
                    ENABLED_TEXT, isAdaptive, true, ADAPTIVE_CURSOR_TOOLTIP, RegistryOptionsScreen.this::enableAll));
            addOptionEntry(ITEM_SLOT_TEXT, CONFIG.isItemSlotEnabled(), isAdaptive, CONFIG::setItemSlotEnabled);
            addOptionEntry(ITEM_GRAB_TEXT, CONFIG.isItemGrabbingEnabled(), isAdaptive, CONFIG::setItemGrabbingEnabled);
            addOptionEntry(CREATIVE_TABS_TEXT, CONFIG.isCreativeTabsEnabled(), isAdaptive, CONFIG::setCreativeTabsEnabled);
            addOptionEntry(ENCHANTMENTS_TEXT, CONFIG.isEnchantmentsEnabled(), isAdaptive, CONFIG::setEnchantmentsEnabled);
            addOptionEntry(STONECUTTER_TEXT, CONFIG.isStonecutterRecipesEnabled(), isAdaptive, CONFIG::setStonecutterRecipesEnabled);
            addOptionEntry(BOOK_EDIT_TEXT, CONFIG.isBookEditEnabled(), isAdaptive, CONFIG::setBookEditEnabled);
            addOptionEntry(LOOM_TEXT, CONFIG.isLoomPatternsEnabled(), isAdaptive, CONFIG::setLoomPatternsEnabled);
            addOptionEntry(ADVANCEMENTS_TEXT, CONFIG.isAdvancementTabsEnabled(), isAdaptive, CONFIG::setAdvancementTabsEnabled);
            addOptionEntry(WORLD_ICON_TEXT, CONFIG.isWorldIconEnabled(), isAdaptive, CONFIG::setWorldIconEnabled);
            addOptionEntry(SERVER_ICON_TEXT, CONFIG.isServerIconEnabled(), isAdaptive, CONFIG::setServerIconEnabled);
        }

        public void addOptionEntry(class_2561 label, boolean isEnabled, boolean defaultValue, Consumer<Boolean> onPress) {
            RegistryEntry entry = new RegistryEntry(label, isEnabled, defaultValue, onPress);
            options.add(entry);
            this.method_25321(entry);
        }

        public class RegistryEntry extends Entry<RegistryEntry> {
            public class_2561 label;
            public RegistryToggleWidget toggleButton;

            public RegistryEntry(class_2561 title) {
                this(class_2561.method_43473().method_10852(title).method_27695(class_124.field_1067, class_124.field_1054), false, false, null);
            }

            public RegistryEntry(class_2561 label, boolean defaultValue, boolean active, @Nullable Consumer<Boolean> onPress) {
                this(label, defaultValue, active, null, onPress);
            }

            public RegistryEntry(class_2561 label, boolean defaultValue, boolean active, @Nullable class_7919 tooltip, @Nullable Consumer<Boolean> onPress) {
                this.label = label;
                if (onPress != null) {
                    toggleButton = new RegistryToggleWidget(
                            method_31383() - BUTTON_WIDTH,
                            layout.method_48998() + field_22741 * method_25340() + ROW_GAP,
                            BUTTON_WIDTH,
                            field_22741 - ROW_GAP,
                            defaultValue,
                            tooltip,
                            onPress
                    );
                    toggleButton.field_22763 = active;
                }
            }

            @Override
            public List<? extends class_6379> selectableChildren() {
                return toggleButton != null ? List.of(toggleButton) : List.of();
            }

            @Override
            public List<? extends class_364> children() {
                return toggleButton != null ? List.of(toggleButton) : List.of();
            }

            @Override
            public void render(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
                int itemY = Math.round(y + entryHeight / 3.0f);
                if (toggleButton != null) {
                    context.method_51439(field_22793, label, x, itemY, 0xFFFFFFFF, false);
                    toggleButton.method_25394(context, mouseX, mouseY, tickDelta);
                    toggleButton.method_46421(method_31383() - BUTTON_WIDTH);
                    toggleButton.method_46419(layout.method_48998() + field_22741 * index + ROW_GAP - (int) Math.round(method_25341()));
                    return;
                }
                int titleX = x + (method_25322() / 2 - field_22793.method_27525(label) / 2);
                context.method_51439(field_22793, label, titleX, itemY, 0xFFFFFFFF, false);
            }
        }
    }

    public static class RegistryToggleWidget extends SelectedCursorToggleWidget {
        protected RegistryToggleWidget(int x, int y, int width, int height, boolean defaultValue, class_7919 tooltip, Consumer<Boolean> onPress) {
            super(x, y, width, height, class_2561.method_43473(), RegistryToggleWidget::onPressButton, class_4185.field_40754);
            value = defaultValue;
            onPressConsumer = onPress;
            updateMessage();

            if (tooltip != null) method_47400(tooltip);
        }

        @Override
        protected void updateMessage() {
            class_2561 message = value ? class_5244.field_24332 : class_5244.field_24333;
            method_25355(message);
        }

        @Override
        public void setValue(boolean value) {
            if (value == this.value) {
                return;
            }

            this.value = value;
            updateMessage();
            onPressConsumer.accept(value);
        }
    }
}
