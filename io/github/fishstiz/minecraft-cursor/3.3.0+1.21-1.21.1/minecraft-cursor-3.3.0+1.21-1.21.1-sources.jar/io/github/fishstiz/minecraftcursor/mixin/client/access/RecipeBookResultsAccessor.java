package io.github.fishstiz.minecraftcursor.mixin.client.access;

import net.minecraft.class_361;
import net.minecraft.class_508;
import net.minecraft.class_513;
import net.minecraft.class_514;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_513.class)
public interface RecipeBookResultsAccessor {
    @Accessor("hoveredResultButton")
    class_514 getHoveredResultButton();

    @Accessor("prevPageButton")
    class_361 getPrevPageButton();

    @Accessor("nextPageButton")
    class_361 getNextPageButton();

    @Accessor("alternatesWidget")
    class_508 getAlternatesWidget();
}
