package io.github.fishstiz.minecraftcursor.mixin.client.access;

import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_465.class)
public interface HandledScreenAccessor<T extends class_1703> {
    @Accessor("backgroundWidth")
    int getBackgroundWidth();

    @Accessor("backgroundHeight")
    int getBackgroundHeight();

    @Accessor("handler")
    T getHandler();

    @Accessor("focusedSlot")
    class_1735 getFocusedSlot();

    @Accessor("x")
    int getX();

    @Accessor("y")
    int getY();

    @Invoker("isPointWithinBounds")
    boolean invokeIsPointWithinBounds(int x, int y, int width, int height, double pointX, double pointY);
}
