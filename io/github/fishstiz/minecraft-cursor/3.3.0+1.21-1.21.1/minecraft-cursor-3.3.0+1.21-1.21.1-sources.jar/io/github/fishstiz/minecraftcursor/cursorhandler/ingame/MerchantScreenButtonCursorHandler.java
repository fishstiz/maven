package io.github.fishstiz.minecraftcursor.cursorhandler.ingame;

import io.github.fishstiz.minecraftcursor.api.CursorHandler;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_364;
import org.jetbrains.annotations.NotNull;

public class MerchantScreenButtonCursorHandler implements CursorHandler<class_364> {
    @Override
    public @NotNull TargetElement<class_364> getTargetElement() {
        return TargetElement.fromClassName("net.minecraft.class_492$class_493");
    }

    @Override
    public CursorType getCursorType(class_364 element, double mouseX, double mouseY) {
        return CursorTypeUtil.canShift() ? CursorType.SHIFT : CursorType.POINTER;
    }
}
