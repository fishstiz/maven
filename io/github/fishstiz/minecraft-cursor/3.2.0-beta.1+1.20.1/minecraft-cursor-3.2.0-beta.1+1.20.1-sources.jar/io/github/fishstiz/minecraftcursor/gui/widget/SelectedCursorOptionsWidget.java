package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_6382;

import static io.github.fishstiz.minecraftcursor.config.CursorConfig.Settings.Default.*;

public class SelectedCursorOptionsWidget extends ContainerWidget {
    protected static final int OPTIONS_HEIGHT = 24;
    private static final int GRID_PADDING = 4;
    private static final int BOX_WIDGET_TEXTURE_SIZE = 96;
    private static final class_2561 ENABLED_TEXT = class_2561.method_43471("minecraft-cursor.options.enabled");
    private static final class_2561 SCALE_TEXT = class_2561.method_43471("minecraft-cursor.options.scale");
    private static final class_2561 XHOT_TEXT = class_2561.method_43471("minecraft-cursor.options.xhot");
    private static final class_2561 YHOT_TEXT = class_2561.method_43471("minecraft-cursor.options.yhot");
    private static final String HOT_UNIT = "px";
    protected final CursorOptionsScreen optionsScreen;
    public SelectedCursorToggleWidget enableButton;
    public SelectedCursorSliderWidget scaleSlider;
    public SelectedCursorSliderWidget xhotSlider;
    public SelectedCursorSliderWidget yhotSlider;
    public SelectedCursorHotspotWidget cursorHotspot;
    public SelectedCursorTestWidget cursorTest;

    public SelectedCursorOptionsWidget(int width, CursorOptionsScreen optionsScreen) {
        super(0, optionsScreen.layout.method_48998(), width, optionsScreen.getContentHeight(), class_2561.method_43473());
        this.optionsScreen = optionsScreen;
        initWidgets();
    }

    @Override
    protected void method_44386(class_332 context) {
    }

    @Override
    public void method_48588(class_332 context, class_2960 texture, int x, int y, int u, int v, int hoveredVOffset, int width, int height, int textureWidth, int textureHeight) {
    }

    private void initWidgets() {
        Cursor cursor = optionsScreen.getSelectedCursor();

        enableButton = SelectedCursorToggleWidget.build(
                ENABLED_TEXT, cursor.isEnabled(), optionsScreen::onPressEnabled);
        scaleSlider = new SelectedCursorSliderWidget(
                SCALE_TEXT, cursor.getScale(), SCALE_MIN, SCALE_MAX, SCALE_STEP,
                optionsScreen::onChangeScale, optionsScreen::removeOverride, this);
        xhotSlider = new SelectedCursorSliderWidget(
                XHOT_TEXT, cursor.getXhot(),
                HOT_MIN, HOT_MAX, 1, HOT_UNIT,
                optionsScreen::onChangeXHot, this);
        yhotSlider = new SelectedCursorSliderWidget(
                YHOT_TEXT, cursor.getYhot(),
                HOT_MIN, HOT_MAX, 1, HOT_UNIT,
                optionsScreen::onChangeYHot, this);
        cursorHotspot = new SelectedCursorHotspotWidget(BOX_WIDGET_TEXTURE_SIZE, this);
        cursorTest = new SelectedCursorTestWidget(BOX_WIDGET_TEXTURE_SIZE, this);

        placeWidgets();
        refreshWidgets();
    }

    private void placeWidgets() {
        grid(enableButton, 0, 0);
        grid(scaleSlider, 1, 0);
        grid(xhotSlider, 0, 1);
        grid(yhotSlider, 1, 1);
        grid(cursorHotspot, 0, 2, true);
        grid(cursorTest, 1, 2, true);
    }

    private void grid(class_339 widget, int gridX, int gridY) {
        grid(widget, gridX, gridY, false);
    }

    private void grid(class_339 widget, int gridX, int gridY, boolean absolute) {
        if (!absolute) {
            widget.method_25358((method_25368() / 2) - GRID_PADDING);
            widget.field_22759 = OPTIONS_HEIGHT - GRID_PADDING;
        }
        widget.method_46421((method_46426() + ((method_25368() / 2) * gridX)) + 1);
        widget.method_46419((method_46427() + (OPTIONS_HEIGHT * (gridY))) + 1);
    }

    public void refreshWidgets() {
        Cursor cursor = optionsScreen.getSelectedCursor();

        enableButton.setValue(cursor.isEnabled());
        scaleSlider.method_25347(cursor.getScale());
        xhotSlider.method_25347(cursor.getXhot());
        yhotSlider.method_25347(cursor.getYhot());

        method_25396().forEach(widget -> widget.method_25365(false));
    }

    @Override
    public List<? extends class_364> method_25396() {
        return List.of(enableButton, scaleSlider, xhotSlider, yhotSlider, cursorHotspot, cursorTest);
    }

    @Override
    protected void method_44389(class_332 context, int mouseX, int mouseY, float delta) {
        enableButton.method_25394(context, mouseX, mouseY, delta);
        scaleSlider.method_25394(context, mouseX, mouseY, delta);
        xhotSlider.method_25394(context, mouseX, mouseY, delta);
        yhotSlider.method_25394(context, mouseX, mouseY, delta);
        cursorHotspot.method_25394(context, mouseX, mouseY, delta);
        cursorTest.method_48579(context, mouseX, mouseY, delta);
    }

    public void setHeight(int height) {
        this.field_22759 = height;
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        placeWidgets();
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }

    @Override
    protected int method_44391() {
        return 0;
    }

    @Override
    protected double method_44393() {
        return 0;
    }
}
