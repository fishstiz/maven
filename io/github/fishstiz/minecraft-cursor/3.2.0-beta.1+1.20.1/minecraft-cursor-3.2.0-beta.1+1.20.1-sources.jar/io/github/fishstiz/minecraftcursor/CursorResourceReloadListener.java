package io.github.fishstiz.minecraftcursor;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.config.CursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfigLoader;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import org.jetbrains.annotations.Nullable;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Optional;

class CursorResourceReloadListener implements SimpleSynchronousResourceReloadListener {
    private static final String IMG_TYPE = ".png";
    private static final String CONFIG_PATH = "atlases/cursors.json";
    private static final String CURSORS_DIR = "textures/cursors";
    private final CursorManager cursorManager;
    private final CursorConfig config;
    private final String namespace;

    CursorResourceReloadListener(CursorManager cursorManager, String namespace, CursorConfig config) {
        this.cursorManager = cursorManager;
        this.namespace = namespace;
        this.config = config;
    }

    @Override
    public class_2960 getFabricId() {
        return class_2960.method_43902(namespace, CURSORS_DIR);
    }

    @Override
    public void method_14491(class_3300 manager) {
        loadConfig(manager);
        loadCursorTextures(manager);
    }

    private void loadConfig(class_3300 manager) {
        Optional<class_3298> resourceOptional = manager.method_14486(class_2960.method_43902(namespace, CONFIG_PATH));

        if (resourceOptional.isEmpty()) return;

        try (InputStream stream = resourceOptional.get().method_14482()) {
            CursorConfig resourceConfig = CursorConfigLoader.fromStream(stream);
            if (!resourceConfig.get_hash().equals(config.get_hash())) {
                config.set_hash(resourceConfig.get_hash());
                config.setSettings(resourceConfig.getSettings());
                config.save();
                MinecraftCursor.LOGGER.info("Using cursor settings provided by resource pack");
            }
        } catch (IOException e) {
            MinecraftCursor.LOGGER.error("Failed to load resource pack's cursor settings");
        }
    }

    private void loadCursorTextures(class_3300 manager) {
        for (Map.Entry<class_2960, class_3298> entry : manager.method_14488(
                getFabricId().method_12832(),
                id -> getCursorTypeByIdentifierOrNull(id) != null).entrySet()
        ) {
            CursorType cursorType = getCursorTypeByIdentifierOrNull(entry.getKey());
            assert cursorType != null;

            BufferedImage image = null;
            try (InputStream stream = entry.getValue().method_14482()) {
                image = ImageIO.read(stream);

                if (image == null) {
                    MinecraftCursor.LOGGER.error("Invalid file for {}{}", cursorType, IMG_TYPE);
                    continue;
                }

                cursorManager.loadCursorImage(
                        cursorType,
                        entry.getKey(), // Identifier
                        image,
                        config.getOrCreateCursorSettings(cursorType)
                );
            } catch (IOException e) {
                MinecraftCursor.LOGGER.error("Failed to load cursor image {}", entry.getKey().method_12832());
            } finally {
                if (image != null) {
                    image.flush();
                }
            }
        }
    }

    private static @Nullable CursorType getCursorTypeByIdentifierOrNull(class_2960 id) {
        String[] path = id.method_12832().split("/");
        String name = path[path.length - 1].split(IMG_TYPE)[0];

        return CursorTypeRegistry.getCursorTypeOrNull(name);
    }
}
