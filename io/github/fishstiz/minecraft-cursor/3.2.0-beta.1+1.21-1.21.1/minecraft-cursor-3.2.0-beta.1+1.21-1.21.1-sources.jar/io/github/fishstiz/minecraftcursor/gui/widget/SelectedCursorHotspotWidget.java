package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorProvider;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class SelectedCursorHotspotWidget extends class_339 implements CursorProvider {
    private static final class_2960 BACKGROUND = class_2960.method_60655(MinecraftCursor.MOD_ID, "textures/gui/hotspot_background.png");
    private static final int HOTSPOT_RULER_COLOR = 0xFFFF0000; // red
    private static final int CURSOR_SIZE = 32;
    private final SelectedCursorOptionsWidget optionsWidget;

    public SelectedCursorHotspotWidget(int size, SelectedCursorOptionsWidget optionsWidget) {
        super(optionsWidget.method_46426(), optionsWidget.method_46427(), size, size, class_2561.method_43473());
        this.optionsWidget = optionsWidget;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        drawTexture(context, BACKGROUND);
        drawTexture(context, optionsWidget.optionsScreen.getSelectedCursor().getSprite());
        renderRuler(context);
        context.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), 0xFF000000);
    }

    private void drawTexture(class_332 context, class_2960 sprite) {
        context.method_25290(sprite, method_46426(), method_46427(), 0, 0, field_22758, field_22759, field_22758, field_22759);
    }

    private void renderRuler(class_332 context) {
        int xhot = (int) optionsWidget.xhotSlider.getTranslatedValue();
        int yhot = (int) optionsWidget.yhotSlider.getTranslatedValue();

        int rulerSize = getRulerSize();
        int xhotX1 = (method_46426() + xhot * rulerSize);
        int xhotX2 = (method_46426() + xhot * rulerSize) + rulerSize;
        int yhotY1 = (method_46427() + yhot * rulerSize);
        int yhotY2 = (method_46427() + yhot * rulerSize) + rulerSize;

        context.method_25294(xhotX1, method_46427(), xhotX2, method_55443(), HOTSPOT_RULER_COLOR);
        context.method_25294(method_46426(), yhotY1, method_55442(), yhotY2, HOTSPOT_RULER_COLOR);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        setHotspots(mouseX, mouseY);
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double deltaX, double deltaY) {
        setHotspots(mouseX, mouseY);
    }

    public void setHotspots(double mouseX, double mouseY) {
        int rulerSize = getRulerSize();

        int xhot = ((int) mouseX - method_46426()) / rulerSize;
        int yhot = ((int) mouseY - method_46427()) / rulerSize;

        optionsWidget.xhotSlider.method_25347(xhot);
        optionsWidget.yhotSlider.method_25347(yhot);
    }

    private int getRulerSize() {
        return method_25368() / CURSOR_SIZE;
    }

    @Override
    public CursorType getCursorType(double mouseX, double mouseY) {
        if (CursorTypeUtil.isLeftClickHeld() || CursorTypeUtil.isGrabbing()) {
            return CursorType.GRABBING;
        }
        return CursorType.POINTER;
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }
}
