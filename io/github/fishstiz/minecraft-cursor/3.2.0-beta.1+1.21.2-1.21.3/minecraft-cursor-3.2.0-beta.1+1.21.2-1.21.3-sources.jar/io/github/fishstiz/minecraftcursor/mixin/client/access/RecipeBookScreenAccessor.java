package io.github.fishstiz.minecraftcursor.mixin.client.access;

import net.minecraft.class_10260;
import net.minecraft.class_1729;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10260.class)
public interface RecipeBookScreenAccessor<T extends class_1729> extends HandledScreenAccessor<T> {
    @Accessor("recipeBook")
    class_507<T> getRecipeBook();
}
