package io.github.fishstiz.minecraftcursor;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.config.CursorConfig;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import org.lwjgl.glfw.GLFW;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class CursorManager {
    private final LinkedHashMap<String, Cursor> cursors = new LinkedHashMap<>();
    private final TreeMap<Integer, String> overrides = new TreeMap<>();
    private final class_310 client;
    private Cursor currentCursor;

    CursorManager(class_310 client) {
        this.client = client;

        Cursor defaultCursor = new Cursor(CursorType.DEFAULT, this::handleCursorLoad);
        cursors.put(defaultCursor.getType().getKey(), defaultCursor);
        currentCursor = defaultCursor;

        for (CursorType cursorType : CursorTypeRegistry.types()) {
            cursors.putIfAbsent(cursorType.getKey(), new Cursor(cursorType, this::handleCursorLoad));
        }
    }

    public void loadCursorImage(CursorType type, class_2960 sprite, BufferedImage image, CursorConfig.Settings settings) throws IOException {
        Cursor cursor = getCursor(type);
        cursor.loadImage(sprite, image, settings.getScale(), settings.getXHot(), settings.getYHot(), settings.isEnabled());
    }

    private void handleCursorLoad(CursorType cursorType) {
        Cursor current = getCurrentCursor();
        if (current != null && current.getType() == cursorType) {
            reloadCursor();
        }
    }

    void setCurrentCursor(CursorType type) {
        Cursor cursor = getCursor(overrides.isEmpty() ? type.getKey() : overrides.lastEntry().getValue());

        if (cursor == null || (type != CursorType.DEFAULT && cursor.getId() == 0) || !cursor.isEnabled()) {
            cursor = getCursor(CursorType.DEFAULT);
        }

        if (cursor == null || (currentCursor != null && cursor.getId() == currentCursor.getId())) {
            return;
        }

        currentCursor = cursor;
        GLFW.glfwSetCursor(client.method_22683().method_4490(), currentCursor.getId());
    }

    public void overrideCurrentCursor(CursorType type, int index) {
        if (getCursor(type).isEnabled()) {
            overrides.put(index, type.getKey());
        } else {
            overrides.remove(index);
        }
    }

    public void removeOverride(int index) {
        overrides.remove(index);
    }

    public void reloadCursor() {
        GLFW.glfwSetCursor(client.method_22683().method_4490(), getCurrentCursor().getId());
    }

    public Cursor getCurrentCursor() {
        return overrides.isEmpty()
                ? currentCursor
                : getCursor(overrides.lastEntry().getValue());
    }

    public Cursor getCursor(String key) {
        return cursors.computeIfAbsent(key, k -> new Cursor(CursorType.of(k), this::handleCursorLoad));
    }

    public Cursor getCursor(CursorType type) {
        return cursors.computeIfAbsent(type.getKey(), k -> new Cursor(type, this::handleCursorLoad));
    }

    public List<Cursor> getLoadedCursors() {
        List<Cursor> activeCursors = new ArrayList<>();
        for (Cursor cursor : cursors.values()) {
            if (cursor.isLoaded()) {
                activeCursors.add(cursor);
            }
        }
        return activeCursors;
    }

    public boolean isAdaptive() {
        return cursors.values().stream().anyMatch(cursor ->
                cursor.isEnabled() && CursorType.DEFAULT != cursor.getType()
        );
    }

    public void setIsAdaptive(boolean isAdaptive) {
        cursors.values().forEach(cursor -> {
            if (cursor.getType() != CursorType.DEFAULT) {
                cursor.enable(isAdaptive);
            }
        });
    }
}
