package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorProvider;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_6382;

public class SelectedCursorTestWidget extends class_339 implements CursorProvider {
    private static final class_2960 BACKGROUND = class_2960.method_60655(MinecraftCursor.MOD_ID, "textures/gui/test_background.png");
    private static final int HOTSPOT_RULER_COLOR = 0xFF00FF00; // green
    private final SelectedCursorOptionsWidget optionsWidget;
    class_4185 hoverButton = class_4185.method_46430(class_2561.method_43473(),
            b -> b.method_25365(false)).method_46437(20, 20).method_46431();

    public SelectedCursorTestWidget(int size, SelectedCursorOptionsWidget optionsWidget) {
        super(optionsWidget.method_46426(), optionsWidget.method_46427(), size, size, class_2561.method_43473());
        this.optionsWidget = optionsWidget;

        this.field_22763 = false;
    }

    private void placeButton() {
        int x = method_46426() + (method_25368() / 2 - hoverButton.method_25368() / 2);
        int y = method_46427() + (method_25364() / 2 - hoverButton.method_25364() / 2);
        hoverButton.method_48229(x, y);
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        Cursor cursor = optionsWidget.optionsScreen.getSelectedCursor();
        context.method_25290(class_1921::method_62277, BACKGROUND, method_46426(), method_46427(), 0, 0, field_22758, field_22759, field_22758, field_22759);

        if (cursor.isEnabled()) {
            hoverButton.method_25394(context, mouseX, mouseY, delta);
            renderRuler(context, mouseX, mouseY);
        } else {
            context.method_25294(method_46426(), method_46427(), method_55442(), method_55443(), 0x7F000000); // 50% black overlay
        }

        context.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), 0xFF000000);
        placeButton();
    }

    private void renderRuler(class_332 context, int mouseX, int mouseY) {
        if (method_25405(mouseX, mouseY)) {
            context.method_25292(method_46426(), method_55442() - 1, mouseY, HOTSPOT_RULER_COLOR);
            context.method_25301(mouseX, method_46427(), method_55443(), HOTSPOT_RULER_COLOR);
        }
    }

    @Override
    public CursorType getCursorType(double mouseX, double mouseY) {
        return optionsWidget.optionsScreen.getSelectedCursor().getType();
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return mouseX >= this.method_46426()
                && mouseY >= this.method_46427()
                && mouseX < this.method_55442()
                && mouseY < this.method_55443();
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        placeButton();
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }
}
