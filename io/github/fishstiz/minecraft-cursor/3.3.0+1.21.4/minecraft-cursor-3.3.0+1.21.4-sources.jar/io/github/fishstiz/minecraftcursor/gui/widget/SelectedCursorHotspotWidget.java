package io.github.fishstiz.minecraftcursor.gui.widget;

import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.api.CursorProvider;
import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.cursor.AnimatedCursor;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.screen.CursorOptionsScreen;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_6382;

public class SelectedCursorHotspotWidget extends class_339 implements CursorProvider {
    private static final class_2960 BACKGROUND = class_2960.method_60655(MinecraftCursor.MOD_ID, "textures/gui/hotspot_background.png");
    private static final int CURSOR_SIZE = 32;
    private static final int RULER_COLOR = 0xFFFF0000; // red
    private final SelectedCursorOptionsWidget optionsWidget;
    private boolean rulerRendered = true;
    private float rulerAlpha = 1f;

    public SelectedCursorHotspotWidget(int size, SelectedCursorOptionsWidget optionsWidget) {
        super(optionsWidget.method_46426(), optionsWidget.method_46427(), size, size, class_2561.method_43473());
        this.optionsWidget = optionsWidget;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25290(class_1921::method_62277, BACKGROUND, method_46426(), method_46427(), 0, 0, field_22758, field_22759, field_22758, field_22759);
        drawCursorTexture(context);
        renderRuler(context, mouseX, mouseY);
        context.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), 0xFF000000);
    }

    private void drawCursorTexture(class_332 context) {
        CursorOptionsScreen optionsScreen = optionsWidget.optionsScreen;
        Cursor cursor = optionsScreen.getSelectedCursor();
        int frameIndex = 0;

        if (cursor instanceof AnimatedCursor animatedCursor) {
            frameIndex = optionsScreen.animationHelper.getCurrentSpriteIndex(animatedCursor);
        }

        int vOffset = CURSOR_SIZE * frameIndex;

        context.method_25302(
                class_1921::method_62277,
                cursor.getSprite(),
                method_46426(), method_46427(),
                0, vOffset, // starting point
                field_22758, field_22759, // width/height to stretch/shrink
                CURSOR_SIZE, CURSOR_SIZE, // cropped width/height from actual image
                cursor.getTrueWidth(), cursor.getTrueHeight() // actual width/height
        );
    }

    private void renderRuler(class_332 context, int mouseX, int mouseY) {
        if (method_25405(mouseX, mouseY)) setRulerRendered(true, false);

        rulerAlpha = class_3532.method_16439(0.3f, rulerAlpha, rulerRendered ? 1f : 0f);

        if (rulerAlpha <= 0.01f) return;

        int xhot = (int) optionsWidget.xhotSlider.getTranslatedValue();
        int yhot = (int) optionsWidget.yhotSlider.getTranslatedValue();

        int rulerSize = getRulerSize();
        int xhotX1 = (method_46426() + xhot * rulerSize);
        int xhotX2 = (method_46426() + xhot * rulerSize) + rulerSize;
        int yhotY1 = (method_46427() + yhot * rulerSize);
        int yhotY2 = (method_46427() + yhot * rulerSize) + rulerSize;

        int alpha = (int) (rulerAlpha * 255);
        int blendedColor = (alpha << 24) | (RULER_COLOR & 0x00FFFFFF);

        context.method_25294(xhotX1, method_46427(), xhotX2, method_55443(), blendedColor);
        context.method_25294(method_46426(), yhotY1, method_55442(), yhotY2, blendedColor);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        setHotspots(mouseX, mouseY);
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double deltaX, double deltaY) {
        setHotspots(mouseX, mouseY);
    }

    public void setHotspots(double mouseX, double mouseY) {
        int rulerSize = getRulerSize();

        int xhot = ((int) mouseX - method_46426()) / rulerSize;
        int yhot = ((int) mouseY - method_46427()) / rulerSize;

        optionsWidget.xhotSlider.method_25347(xhot);
        optionsWidget.yhotSlider.method_25347(yhot);

        setRulerRendered(true, true);
    }

    private int getRulerSize() {
        return method_25368() / CURSOR_SIZE;
    }

    public void setRulerRendered(boolean rulerRendered, boolean immediate) {
        if (immediate) rulerAlpha = rulerRendered ? 1f : 0f;
        this.rulerRendered = rulerRendered;
    }

    @Override
    public CursorType getCursorType(double mouseX, double mouseY) {
        if (CursorTypeUtil.isLeftClickHeld() || CursorTypeUtil.isGrabbing()) {
            return CursorType.GRABBING;
        }
        return CursorType.POINTER;
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }
}
