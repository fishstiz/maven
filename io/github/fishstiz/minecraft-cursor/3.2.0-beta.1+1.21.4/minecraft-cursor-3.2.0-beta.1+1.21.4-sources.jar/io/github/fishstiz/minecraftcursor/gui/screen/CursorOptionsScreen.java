package io.github.fishstiz.minecraftcursor.gui.screen;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.widget.CursorListWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.SelectedCursorOptionsWidget;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8132;
import net.minecraft.class_9017;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;

public class CursorOptionsScreen extends class_437 {
    private static final class_2561 TITLE_TEXT = class_2561.method_43471("minecraft-cursor.options");
    private static final int CURSORS_COLUMN_WIDTH = 96;
    private static final int SELECTED_CURSOR_COLUMN_WIDTH = 200;
    private static final int COLUMN_GAP = 8;
    private final CursorManager cursorManager;
    private final List<Cursor> cursors;
    protected final class_437 previousScreen;
    public final class_8132 layout = new class_8132(this);
    protected CursorOptionsBody body;
    private Cursor selectedCursor;
    class_4185 moreButton;
    class_4185 doneButton;

    public CursorOptionsScreen(class_437 previousScreen, CursorManager cursorManager) {
        super(TITLE_TEXT);

        this.previousScreen = previousScreen;
        this.cursorManager = cursorManager;

        cursors = this.cursorManager.getLoadedCursors();
    }

    @Override
    protected void method_25426() {
        selectedCursor = cursorManager.getLoadedCursors().getFirst();

        this.layout.method_57726(this.field_22785, this.field_22793);
        this.body = this.layout.method_48999(new CursorOptionsBody(this));

        moreButton = class_4185.method_46430(class_2561.method_43471("minecraft-cursor.options.more").method_27693("..."),
                btn -> {
                    if (field_22787 != null) {
                        field_22787.method_1507(new RegistryOptionsScreen(this, cursorManager));
                    }
                }).method_46431();
        this.layout.method_48996(moreButton);

        doneButton = class_4185.method_46430(class_5244.field_24334, btn -> this.method_25419()).method_46431();
        this.layout.method_48996(doneButton);

        this.layout.method_48206(this::method_37063);

        if (this.body != null) {
            this.method_48640();
        }
    }

    @Override
    protected void method_48640() {
        this.layout.method_48222();
        if (this.body != null) {
            this.body.position(this.field_22789, this.layout);
        }
        int bodyWidth = CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH + COLUMN_GAP;
        moreButton.method_25358(bodyWidth / 2 - COLUMN_GAP / 2);
        moreButton.method_46421(field_22789 / 2 - moreButton.method_25368() - COLUMN_GAP / 2);
        doneButton.method_25358(bodyWidth / 2 - COLUMN_GAP / 2 - 2);
        doneButton.method_46421(field_22789 / 2 + COLUMN_GAP / 2);
    }

    public void onPressEnabled(boolean value) {
        selectedCursor.enable(value);
        updateSelectedCursorConfig();
    }

    public void onChangeScale(double value) {
        if (selectedCursor.getScale() != value && body != null) {
            cursorManager.overrideCurrentCursor(selectedCursor.getType(), -1);
        }

        selectedCursor.setScale(value);
        updateSelectedCursorConfig();
    }

    public void onChangeXHot(double value) {
        selectedCursor.setXhot((int) value);
        updateSelectedCursorConfig();
    }

    public void onChangeYHot(double value) {
        selectedCursor.setYhot((int) value);
        updateSelectedCursorConfig();
    }

    public void selectCursor(Cursor cursor) {
        updateSelectedCursorConfig();
        selectedCursor = cursor;

        if (body != null) {
            body.selectedCursorColumn.refreshWidgets();
        }
    }

    private void updateSelectedCursorConfig() {
        CONFIG.getOrCreateCursorSettings(selectedCursor.getType()).update(
                selectedCursor.getScale(),
                selectedCursor.getXhot(),
                selectedCursor.getYhot(),
                selectedCursor.isEnabled()
        );
    }

    public Cursor getSelectedCursor() {
        return selectedCursor;
    }

    public List<Cursor> getCursors() {
        return cursors;
    }

    @Override
    public void method_25419() {
        removeOverride();
        CONFIG.save();

        if (this.field_22787 != null) {
            this.field_22787.method_1507(previousScreen);
        }
    }

    public void removeOverride() {
        cursorManager.removeOverride(-1);
    }

    public class CursorOptionsBody extends class_9017 {
        public final CursorListWidget cursorsColumn;
        public final SelectedCursorOptionsWidget selectedCursorColumn;

        public CursorOptionsBody(CursorOptionsScreen optionsScreen) {
            super(optionsScreen.layout.method_46426(), optionsScreen.layout.method_48998(), optionsScreen.field_22789, optionsScreen.layout.method_57727(), class_2561.method_30163("BODY"));
            cursorsColumn = new CursorListWidget(field_22787, CURSORS_COLUMN_WIDTH, optionsScreen);
            selectedCursorColumn = new SelectedCursorOptionsWidget(SELECTED_CURSOR_COLUMN_WIDTH, optionsScreen);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
            boolean isScrolled = super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
            if (isScrolled && cursorsColumn.method_25405(mouseX, mouseY)) {
                cursorsColumn.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
            }
            return isScrolled;
        }

        @Override
        public List<? extends class_364> method_25396() {
            return List.of(cursorsColumn, selectedCursorColumn);
        }

        @Override
        protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            cursorsColumn.method_48579(context, mouseX, mouseY, delta);
            selectedCursorColumn.method_48579(context, mouseX, mouseY, delta);
        }

        public void position(int width, class_8132 layout) {
            this.method_55445(width, layout.method_57727());
            this.method_48229(this.method_46426(), layout.method_48998());
            this.method_53533(layout.method_57727());

            cursorsColumn.method_53533(layout.method_57727());
            selectedCursorColumn.method_53533(layout.method_57727());

            int cursorsColumnX = width / 2 - CURSORS_COLUMN_WIDTH;
            int selectedCursorColumnX = width / 2;
            int leftShift = (selectedCursorColumnX + SELECTED_CURSOR_COLUMN_WIDTH) -
                    (((CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH) / 2) + (width / 2));

            cursorsColumn.method_46421(cursorsColumnX - leftShift - COLUMN_GAP / 2);
            selectedCursorColumn.method_46421(selectedCursorColumnX - leftShift + COLUMN_GAP / 2);
        }

        @Override
        protected int method_44395() {
            return 0;
        }

        @Override
        protected double method_44393() {
            return 0;
        }

        @Override
        protected void method_47399(class_6382 builder) {
        }
    }
}
