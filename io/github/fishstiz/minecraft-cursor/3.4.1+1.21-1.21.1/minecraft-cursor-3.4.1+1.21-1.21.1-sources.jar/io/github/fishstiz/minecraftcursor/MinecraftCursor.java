package io.github.fishstiz.minecraftcursor;

import io.github.fishstiz.minecraftcursor.api.CursorType;
import io.github.fishstiz.minecraftcursor.api.MinecraftCursorInitializer;
import io.github.fishstiz.minecraftcursor.config.CursorConfig;
import io.github.fishstiz.minecraftcursor.config.CursorConfigLoader;
import io.github.fishstiz.minecraftcursor.impl.CursorControllerImpl;
import io.github.fishstiz.minecraftcursor.impl.CursorControllerProvider;
import io.github.fishstiz.minecraftcursor.impl.MinecraftCursorInitializerImpl;
import io.github.fishstiz.minecraftcursor.util.CursorTypeUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.concurrent.atomic.AtomicReference;

public class MinecraftCursor implements ClientModInitializer {
    public static final String MOD_ID = "minecraft-cursor";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final CursorConfig CONFIG = CursorConfigLoader
            .fromFile(new File(FabricLoader.getInstance().getConfigDir().toString(), MOD_ID + ".json"));

    private static MinecraftCursor instance;
    private final AtomicReference<CursorType> singleCycleCursor = new AtomicReference<>();
    private class_437 visibleNonCurrentScreen;

    @Override
    public void onInitializeClient() {
        instance = this;

        new MinecraftCursorInitializerImpl().init(CursorManager.INSTANCE, CursorTypeResolver.INSTANCE);
        FabricLoader.getInstance().getEntrypointContainers(MOD_ID, MinecraftCursorInitializer.class).forEach(entrypoint -> {
            try {
                entrypoint.getEntrypoint().init(CursorManager.INSTANCE, CursorTypeResolver.INSTANCE);
            } catch (LinkageError | Exception e) {
                LOGGER.error(
                        "Invalid implementation of MinecraftCursorInitializer in mod: {}",
                        entrypoint.getProvider().getMetadata().getId()
                );
            }
        });

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(CursorResourceReloadListener.INSTANCE);
        CursorControllerProvider.init(CursorControllerImpl.INSTANCE);

        ScreenEvents.BEFORE_INIT.register(this::beforeScreenInit);
        ClientTickEvents.START_CLIENT_TICK.register(this::tick);
    }

    private void beforeScreenInit(class_310 client, class_437 screen, int width, int height) {
        if (client.field_1755 == null) {
            CursorManager.INSTANCE.setCurrentCursor(CursorType.DEFAULT);
            visibleNonCurrentScreen = screen;
            return;
        }
        visibleNonCurrentScreen = null;
        ScreenEvents.afterRender(client.field_1755).register(this::afterRenderScreen);
    }

    private void afterRenderScreen(class_437 currentScreen, class_332 context, int mouseX, int mouseY, float tickDelta) {
        CursorManager.INSTANCE.setCurrentCursor(getCursorType(currentScreen, mouseX, mouseY));
    }

    private void tick(class_310 client) {
        if (client.field_1755 == null && visibleNonCurrentScreen != null && !client.field_1729.method_1613()) {
            double scale = client.method_22683().method_4495();
            double mouseX = client.field_1729.method_1603() / scale;
            double mouseY = client.field_1729.method_1604() / scale;
            CursorManager.INSTANCE.setCurrentCursor(getCursorType(visibleNonCurrentScreen, mouseX, mouseY));
        } else if (client.field_1755 == null && visibleNonCurrentScreen == null) {
            CursorManager.INSTANCE.setCurrentCursor(CursorType.DEFAULT);
        }
    }

    private CursorType getCursorType(class_437 currentScreen, double mouseX, double mouseY) {
        if (!CursorManager.INSTANCE.isAdaptive()) return CursorType.DEFAULT;

        if (CursorTypeUtil.isGrabbing()) return CursorType.GRABBING;

        if (singleCycleCursor.get() != null) {
            CursorType cursorType = singleCycleCursor.get();
            singleCycleCursor.set(null);
            return cursorType;
        }

        CursorType cursorType = CursorTypeResolver.INSTANCE.getCursorType(currentScreen, mouseX, mouseY);
        cursorType = cursorType != CursorType.DEFAULT ? cursorType
                : currentScreen.method_19355(mouseX, mouseY)
                .map(element -> CursorTypeResolver.INSTANCE.getCursorType(element, mouseX, mouseY))
                .orElse(CursorType.DEFAULT);

        return cursorType;
    }

    public static MinecraftCursor getInstance() {
        if (instance == null) {
            throw new IllegalStateException("MinecraftCursor not yet initialized.");
        }
        return instance;
    }

    public synchronized void setSingleCycleCursor(CursorType cursorType) {
        singleCycleCursor.set(cursorType);
    }
}
