package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_339;

public abstract class SelectedCursorClickableWidget extends class_339 {
    public SelectedCursorClickableWidget(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    public int getRight() {
        return this.method_46426() + this.method_25368();
    }

    public int getBottom() {
        return this.method_46427() + this.method_25364();
    }
}
