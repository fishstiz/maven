package io.github.fishstiz.minecraftcursor.gui.screen;

import io.github.fishstiz.minecraftcursor.CursorManager;
import io.github.fishstiz.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.minecraftcursor.cursor.AnimatedCursor;
import io.github.fishstiz.minecraftcursor.cursor.Cursor;
import io.github.fishstiz.minecraftcursor.gui.widget.ContainerWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.CursorListWidget;
import io.github.fishstiz.minecraftcursor.gui.widget.SelectedCursorOptionsWidget;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_7842;
import net.minecraft.class_8132;

import static io.github.fishstiz.minecraftcursor.MinecraftCursor.CONFIG;

public class CursorOptionsScreen extends class_437 {
    private static final class_2561 TITLE_TEXT = class_2561.method_43471("minecraft-cursor.options");
    private static final int CURSORS_COLUMN_WIDTH = 96;
    private static final int SELECTED_CURSOR_COLUMN_WIDTH = 200;
    private static final int COLUMN_GAP = 8;
    private final CursorManager cursorManager;
    private final List<Cursor> cursors;
    protected final class_437 previousScreen;
    public final class_8132 layout = new class_8132(this);
    public final CursorAnimationHelper animationHelper = new CursorAnimationHelper();
    protected CursorOptionsBody body;
    private Cursor selectedCursor;
    class_4185 moreButton;
    class_4185 doneButton;

    public CursorOptionsScreen(class_437 previousScreen, CursorManager cursorManager) {
        super(TITLE_TEXT);

        this.previousScreen = previousScreen;
        this.cursorManager = cursorManager;

        cursors = this.cursorManager.getLoadedCursors();
    }

    @Override
    protected void method_25426() {
        selectedCursor = cursorManager.getLoadedCursors().get(0);

        this.layout.method_48992(new class_7842(this.field_22785, this.field_22793));
        this.body = this.layout.method_48999(new CursorOptionsBody());

        moreButton = class_4185.method_46430(class_2561.method_43471("minecraft-cursor.options.more").method_27693("..."),
                btn -> {
                    if (field_22787 != null) {
                        field_22787.method_1507(new RegistryOptionsScreen(this, cursorManager));
                    }
                }).method_46431();
        this.layout.method_48996(moreButton);

        doneButton = class_4185.method_46430(class_5244.field_24334, btn -> this.method_25419()).method_46431();
        this.layout.method_48996(doneButton);

        this.layout.method_48206(this::method_37063);
        this.method_37063(body.cursorsColumn);

        if (this.body != null) {
            this.refreshWidgetPositions();
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_25434(context);
        body.method_25394(context, mouseX, mouseY, delta);
        moreButton.method_25394(context, mouseX, mouseY, delta);
        doneButton.method_25394(context, mouseX, mouseY, delta);
    }

    protected void refreshWidgetPositions() {
        this.layout.method_48222();
        if (this.body != null) {
            this.body.position(this.field_22789, this.layout);
        }
        int bodyWidth = CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH + COLUMN_GAP;
        moreButton.method_25358(bodyWidth / 2 - COLUMN_GAP / 2);
        moreButton.method_46421(field_22789 / 2 - moreButton.method_25368() - COLUMN_GAP / 2);
        doneButton.method_25358(bodyWidth / 2 - COLUMN_GAP / 2 - 2);
        doneButton.method_46421(field_22789 / 2 + COLUMN_GAP / 2);
    }

    public void onPressEnabled(boolean value) {
        selectedCursor.enable(value);
        updateSelectedCursorConfig();
    }

    public void onChangeScale(double value) {
        if (selectedCursor.getScale() != value && body != null) {
            cursorManager.overrideCurrentCursor(selectedCursor.getType(), -1);
        }

        selectedCursor.setScale(value);
        updateSelectedCursorConfig();
    }

    public void onChangeXHot(double value) {
        selectedCursor.setXhot((int) value);
        updateSelectedCursorConfig();
    }

    public void onChangeYHot(double value) {
        selectedCursor.setYhot((int) value);
        updateSelectedCursorConfig();
    }

    public void selectCursor(Cursor cursor) {
        updateSelectedCursorConfig();
        selectedCursor = cursor;

        if (body != null) {
            body.selectedCursorColumn.refreshWidgets();
        }
    }

    public void onPressAnimate(boolean value) {
        if (selectedCursor instanceof AnimatedCursor animatedCursor) {
            animatedCursor.setAnimated(value);
            CONFIG.getOrCreateCursorSettings(selectedCursor.getType()).setAnimated(animatedCursor.isAnimated());
        }
    }

    public void onResetAnimation() {
        if (selectedCursor instanceof AnimatedCursor animatedCursor) {
            animationHelper.reset(animatedCursor);
        }
    }

    private void updateSelectedCursorConfig() {
        CONFIG.getOrCreateCursorSettings(selectedCursor.getType()).update(
                selectedCursor.getScale(),
                selectedCursor.getXhot(),
                selectedCursor.getYhot(),
                selectedCursor.isEnabled()
        );
    }

    public Cursor getSelectedCursor() {
        return selectedCursor;
    }

    public List<Cursor> getCursors() {
        return cursors;
    }

    @Override
    public void method_25419() {
        removeOverride();
        CONFIG.save();

        if (this.field_22787 != null) {
            this.field_22787.method_1507(previousScreen);
        }
    }

    public int getContentHeight() {
        return field_22790 - layout.method_48998() - layout.method_48994();
    }

    public void removeOverride() {
        cursorManager.removeOverride(-1);
    }

    public class CursorOptionsBody extends ContainerWidget {
        public final CursorListWidget cursorsColumn;
        public final SelectedCursorOptionsWidget selectedCursorColumn;

        public CursorOptionsBody() {
            super(layout.method_46426(), layout.method_48998(), CursorOptionsScreen.this.field_22789, CursorOptionsScreen.this.getContentHeight(), class_2561.method_43473());
            cursorsColumn = new CursorListWidget(field_22787, CURSORS_COLUMN_WIDTH, CursorOptionsScreen.this);
            selectedCursorColumn = new SelectedCursorOptionsWidget(SELECTED_CURSOR_COLUMN_WIDTH, CursorOptionsScreen.this);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double amount) {
            MinecraftCursor.LOGGER.info("SCROLLING");
            if (cursorsColumn.method_25405(mouseX, mouseY)) {
                MinecraftCursor.LOGGER.info("SCROLL THIS");

                return cursorsColumn.method_25401(mouseX, mouseY, amount);
            }
            return super.method_25401(mouseX, mouseY, amount);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return List.of(cursorsColumn, selectedCursorColumn);
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            cursorsColumn.method_25394(context, mouseX, mouseY, delta);
            selectedCursorColumn.method_25394(context, mouseX, mouseY, delta);
        }

        public void position(int width, class_8132 layout) {
            this.field_22759 = method_44391();
            this.field_22758 = width;
            this.method_48229(this.method_46426(), layout.method_48998());

            cursorsColumn.setHeight(getContentHeight());
            selectedCursorColumn.setHeight(getContentHeight());

            int cursorsColumnX = width / 2 - CURSORS_COLUMN_WIDTH;
            int selectedCursorColumnX = width / 2;
            int leftShift = (selectedCursorColumnX + SELECTED_CURSOR_COLUMN_WIDTH) -
                    (((CURSORS_COLUMN_WIDTH + SELECTED_CURSOR_COLUMN_WIDTH) / 2) + (width / 2));

            cursorsColumn.method_25333(cursorsColumnX - leftShift - COLUMN_GAP / 2);
            selectedCursorColumn.method_46421(selectedCursorColumnX - leftShift + COLUMN_GAP / 2);
        }

        @Override
        protected void method_47399(class_6382 builder) {
        }

        @Override
        protected int method_44391() {
            return 0;
        }

        @Override
        protected double method_44393() {
            return 0;
        }

        @Override
        protected void method_44389(class_332 context, int mouseX, int mouseY, float delta) {
            this.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
