package io.github.fishstiz.minecraftcursor.mixin.client.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_454;
import net.minecraft.class_457;

@Mixin(class_457.class)
public interface AdvancementsScreenAccessor {
    @Accessor("tabs")
    Map<class_161, class_454> getTabs();

    @Accessor("selectedTab")
    class_454 getSelectedTab();
}
