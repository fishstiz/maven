package io.github.fishstiz.minecraftcursor.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_7528;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import org.jetbrains.annotations.Nullable;

public abstract class ContainerWidget extends class_7528 implements class_4069 {
    @Nullable
    private class_364 focusedElement;
    private boolean dragging;

    public ContainerWidget(int i, int j, int k, int l, class_2561 text) {
        super(i, j, k, l, text);
    }

    @Override
    public final boolean method_25397() {
        return this.dragging;
    }

    @Override
    public final void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Nullable
    @Override
    public class_364 method_25399() {
        return this.focusedElement;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focusedElement != null) {
            this.focusedElement.method_25365(false);
        }

        if (focused != null) {
            focused.method_25365(true);
        }

        this.focusedElement = focused;
    }

    @Nullable
    @Override
    public class_8016 method_48205(class_8023 navigation) {
        return class_4069.super.method_48205(navigation);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
//        boolean bl = this.checkScrollbarDragged(mouseX, mouseY, button);
//        return ParentElement.super.mouseClicked(mouseX, mouseY, button) || bl;
        return class_4069.super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        super.method_25406(mouseX, mouseY, button);
        return class_4069.super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        return class_4069.super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25370() {
        return class_4069.super.method_25370();
    }

    @Override
    public void method_25365(boolean focused) {
        class_4069.super.method_25365(focused);
    }
}