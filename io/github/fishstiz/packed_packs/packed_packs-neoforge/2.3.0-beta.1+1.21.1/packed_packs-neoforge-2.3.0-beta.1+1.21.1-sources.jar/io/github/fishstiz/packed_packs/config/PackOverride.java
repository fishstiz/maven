package io.github.fishstiz.packed_packs.config;

import com.google.gson.*;
import com.google.gson.annotations.JsonAdapter;
import io.github.fishstiz.packed_packs.PackedPacks;
import net.minecraft.server.packs.repository.Pack;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import java.util.Objects;

@JsonAdapter(PackOverride.Adapter.class)
public final class PackOverride {
    private static final String HIDDEN_SERIALIZED_NAME = "hidden";
    private static final String REQUIRED_SERIALIZED_NAME = "required";
    private static final String POSITION_SERIALIZED_NAME = "position";
    private @Nullable Boolean hidden;
    private @Nullable Boolean required;
    private @Nullable Position position;

    public PackOverride() {
    }

    public PackOverride(@Nullable Boolean hidden, @Nullable Boolean required, @Nullable PackOverride.Position position) {
        this.hidden = hidden;
        this.required = required;
        this.position = position;
    }

    public boolean hasOverride() {
        return Boolean.TRUE.equals(this.hidden) || this.required != null || this.position != null;
    }

    public @Nullable Boolean hidden() {
        return hidden;
    }

    void setHidden(@Nullable Boolean hidden) {
        this.hidden = hidden;
    }

    public @Nullable Boolean required() {
        return required;
    }

    void setRequired(@Nullable Boolean required) {
        this.required = required;
    }

    public @Nullable Position position() {
        return position;
    }

    void setPosition(@Nullable Position position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        PackOverride other = (PackOverride) obj;
        return Objects.equals(other.hidden, this.hidden) &&
               Objects.equals(other.required, this.required) &&
               other.position == this.position;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.hidden, this.required, this.position);
    }

    public enum Position {
        UNFIXED,
        TOP,
        BOTTOM;

        public boolean fixed() {
            return this != UNFIXED;
        }

        public Pack.@Nullable Position override() {
            return switch (this) {
                case TOP -> Pack.Position.TOP;
                case BOTTOM -> Pack.Position.BOTTOM;
                default -> null;
            };
        }
    }

    static class Adapter implements JsonSerializer<PackOverride>, JsonDeserializer<PackOverride> {
        @Override
        public JsonElement serialize(PackOverride src, Type typeOfSrc, JsonSerializationContext context) {
            if (!src.hasOverride()) return null;

            JsonObject obj = new JsonObject();
            if (src.hidden() != null) obj.addProperty(HIDDEN_SERIALIZED_NAME, src.hidden());
            if (src.required() != null) obj.addProperty(REQUIRED_SERIALIZED_NAME, src.required());
            if (src.position() != null) obj.addProperty(POSITION_SERIALIZED_NAME, src.position().name());
            return obj;
        }

        @Override
        public PackOverride deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            JsonObject obj = json.getAsJsonObject();

            Boolean hidden = obj.has(HIDDEN_SERIALIZED_NAME) ? obj.get(HIDDEN_SERIALIZED_NAME).getAsBoolean() : null;
            Boolean required = obj.has(REQUIRED_SERIALIZED_NAME) ? obj.get(REQUIRED_SERIALIZED_NAME).getAsBoolean() : null;
            Position position = null;

            if (obj.has(POSITION_SERIALIZED_NAME)) {
                try {
                    position = Position.valueOf(obj.get(POSITION_SERIALIZED_NAME).getAsString().toUpperCase());
                } catch (IllegalArgumentException e) {
                    PackedPacks.LOGGER.error("[packed_packs] Invalid value for key 'position': '{}'. Expected one of {}", position, Position.values());
                }
            }

            return new PackOverride(hidden, required, position);
        }
    }
}
