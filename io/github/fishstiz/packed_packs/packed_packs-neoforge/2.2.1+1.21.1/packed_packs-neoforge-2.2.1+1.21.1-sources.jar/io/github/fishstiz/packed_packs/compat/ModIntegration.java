package io.github.fishstiz.packed_packs.compat;

import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import io.github.fishstiz.packed_packs.api.Preference;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Constructor;

public abstract class ModIntegration implements PackedPacksInitializer {
    protected abstract ModContext mod();

    protected abstract void onInitLoaded(PackedPacksApi api);

    protected @NotNull ResourceLocation id() {
        return id(this.mod());
    }

    @Override
    public final void onInitialize(@NotNull PackedPacksApi api) {
        if (this.mod().isLoaded()) {
            this.onInitLoaded(api);
        }
    }

    public static ResourceLocation id(ModContext mod) {
        return PackedPacks.id(mod.getId());
    }

    public static Component getWidgetPrefText(Preference<?> key) {
        return Component.translatable("packed_packs.preferences.widgets." + key.id().getPath());
    }

    public static Runnable createScreenSetter(String className, ScreenArg<?>... screenArgs) {
        try {
            Object[] args = new Object[screenArgs.length];
            Class<?>[] argTypes = new Class[screenArgs.length];
            for (int i = 0; i < screenArgs.length; i++) {
                args[i] = screenArgs[i].arg();
                argTypes[i] = screenArgs[i].type();
            }

            Constructor<? extends Screen> screenCtor = Class.forName(className)
                    .asSubclass(Screen.class)
                    .getConstructor(argTypes);

            return () -> {
                try {
                    Minecraft.getInstance().setScreen(screenCtor.newInstance(args));
                } catch (Exception e) {
                    PackedPacks.LOGGER.error("[packed_packs] Failed to open mod screen: '{}'", className, e);
                }
            };
        } catch (Exception e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to create screen setter for mod screen: '{}'", className, e);
            return FunctionUtils.nop();
        }
    }

    public record ScreenArg<T>(Class<T> type, T arg) {
        public static ScreenArg<Screen> parent(Screen parent) {
            return new ScreenArg<>(Screen.class, parent);
        }
    }
}
