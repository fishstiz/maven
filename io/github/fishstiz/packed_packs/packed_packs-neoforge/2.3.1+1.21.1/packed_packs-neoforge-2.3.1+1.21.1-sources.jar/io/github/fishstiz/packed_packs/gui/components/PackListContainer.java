package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.Justification;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.states.PackListKey;
import io.github.fishstiz.packed_packs.gui.states.PackListType;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.states.PackListState;
import io.github.fishstiz.packed_packs.gui.actions.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.states.PackListComputed;
import io.github.fishstiz.packed_packs.pack.PackIconCache;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksContext;
import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.gui.states.ProfileSelection;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import io.github.fishstiz.packed_packs.util.PackUtil;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.AbstractContainerEventHandler;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.Layout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.client.gui.navigation.ScreenDirection;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;
import static net.minecraft.client.gui.navigation.FocusNavigationEvent.*;

public class PackListContainer extends AbstractWidget implements FocusPathProvider, Layout, ContainerEventHandlerPatch {
    private final @Nullable PackListContainer head;
    private final PackedPacksContext context;
    private final PackList packList;
    private final PackListComputed state;
    private @Nullable Folder folder;
    private @Nullable GuiEventListener focused;
    private boolean dragging;
    private List<GuiEventListener> children;
    private boolean entriesDirty;

    private PackListContainer(@Nullable PackListContainer head, PackedPacksContext context, PackListComputed state) {
        super(0, 0, 0, 0, CommonComponents.EMPTY);
        this.head = head;
        this.context = context;
        this.state = state;
        this.packList = new PackList(context, state);
        this.children = List.of(this.packList);
    }

    private PackListContainer(PackListContainer head, PackListKey key) {
        this(head, head.context, new PackListComputed(key));
    }

    public static PackListContainer createHead(PackedPacksContext context, PackListType type) {
        PackListKey key = PackListKey.head(type);
        PackListComputed computed = new PackListComputed(
                key,
                context.state().value().getHeadList(type),
                context.state().value().profiles()
        );

        PackListContainer root = new PackListContainer(null, context, computed);

        context.state().subscribe(
                "PackListContainer@" + key,
                value -> {
                    root.onStateChanged(value.getHeadList(type), value.profiles(), type.available());
                    root.onStateChanged(value.dragging());
                }
        );

        return root;
    }

    private void updateChild(GuiEventListener target) {
        this.children = List.of(target);
        if (getFocused() != null) {
            setFocused(target);
        }
    }

    private void onStateChanged(ActiveAction.@Nullable Dragging dragging) {
        state.onDrag(dragging);

        if (folder != null) {
            folder.listContainer.onStateChanged(dragging);
        }
    }

    private void onStateChanged(PackListState newState, ProfileSelection newProfiles, boolean folderUnlockable) {
        PackListState prev = this.state.state();
        ProfileSelection prevProfiles = this.state.profiles();

        if (prev == newState && newProfiles == prevProfiles) {
            return;
        }

        this.state.onStateChanged(newState, newProfiles);

        PackListState folderState = newState.folder();

        if ((folderState == null) != (this.folder == null)) {
            if (folderState != null) {
                Folder newFolder = new Folder(head == null ? this : head, this.state.key().nest(), folderState);
                this.folder = newFolder;
                updateChild(newFolder);
                ComponentPath path = newFolder.nextFocusPath(new InitialFocus());
                if (path != null) path.applyFocus(true);
            } else {
                this.folder.onClose();
                this.folder = null;
                updateChild(packList);
            }
        }

        if (this.folder != null && folderState != null) {
            this.folder.onStateChanged(folderState, newProfiles, folderUnlockable && !newState.module());
            entriesDirty = entriesDirty || prev.visiblePacks() != newState.visiblePacks() || prevProfiles != newProfiles;
        } else if (entriesDirty || prev.visiblePacks() != newState.visiblePacks() || prevProfiles != newProfiles) {
            packList.rebuildEntries();
            entriesDirty = false;
        }
    }

    public boolean extractDropCandidateRenderState(
            GuiGraphics graphics,
            ActiveAction.Dragging dragging,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        PackListContainer leafContainer = this;

        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if ((leafContainer.packList.extractDropCandidateRenderState(graphics, dragging, mouseX, mouseY, partialTick)
             || dragging.src().equals(leafContainer.state.key()))
            && leafContainer.packList.isHovered()) {
            return true;
        }

        PackListContainer root = this.head == null ? this : this.head;
        if (state.key().type().available() && !state.isLocked() && state.canDrop(0)) {
            renderDropToDisabledZone(root, graphics);
            return root.isHovered();
        }

        return false;
    }

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        packList.render(graphics, mouseX, mouseY, partialTick);
        if (this.folder != null) {
            this.folder.render(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        if (this.folder != null) {
            this.folder.listContainer.updateNarration(output.nest());
        } else {
            packList.updateNarration(output.nest());
        }
    }

    public void visitLeafList(Consumer<PackList> visitor) {
        if (state.state().folder() != null && this.folder != null) {
            this.folder.listContainer.visitLeafList(visitor);
        } else {
            visitor.accept(packList);
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        if (state.isLocked()) {
            context.dispatch(new PackListIntent.Drop(dragging.src()));
            return;
        }

        PackListContainer leafContainer = this;
        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if (state.key().type().enabled()) {
            leafContainer.packList.onDrop(dragging, mouseX, mouseY);
            return;
        }

        boolean dropCandidate = leafContainer.state.isDropCandidate() || dragging.src().equals(leafContainer.state.key());
        if (leafContainer.packList.isHovered() && dropCandidate) {
            leafContainer.packList.onDrop(dragging, mouseX, mouseY);
            return;
        }

        context.dispatch(new PackListIntent.Drop(dragging.src(), state.key(), 0));
    }

    @Override
    public List<GuiEventListener> children() {
        return this.children;
    }

    @Override
    public boolean isDragging() {
        return this.dragging;
    }

    @Override
    public void setDragging(boolean isDragging) {
        this.dragging = isDragging;
    }

    @Override
    public @Nullable GuiEventListener getFocused() {
        return this.focused;
    }

    @Override
    public void setFocused(boolean focused) {
        super.setFocused(focused);
        if (!focused) {
            setFocused(null);
        } else {
            setFocused(this.folder == null ? packList : this.folder);
        }
    }

    @Override
    public void setFocused(@Nullable GuiEventListener focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.setFocused(false);
            }
            if (focused != null) {
                focused.setFocused(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public @Nullable ComponentPath getFocusPath(FocusTarget target) {
        FocusPathProvider child = this.folder != null ? this.folder : packList;
        return ComponentPath.path(this, child.getFocusPath(target));
    }

    @Override
    public @Nullable ComponentPath nextFocusPath(FocusNavigationEvent event) {
        GuiEventListener child = this.folder != null ? this.folder : packList;
        return ComponentPath.path(this, child.nextFocusPath(event));
    }

    @Override
    public void setHeight(int height) {
        super.setHeight(height);
        if (head == null) {
            packList.setHeight(height);
        }
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void setWidth(int width) {
        super.setWidth(width);
        if (head == null) {
            packList.setWidth(width);
        }
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void setX(int x) {
        super.setX(x);
        if (head == null) {
            packList.setX(x);
        }
        repositionFolder();
    }

    @Override
    public void setY(int y) {
        super.setY(y);
        if (head == null) {
            packList.setY(y);
        }
        repositionFolder();
    }

    @Override
    public void setSize(int width, int height) {
        super.setSize(width, height);
        setWidth(width);
        setHeight(height);
    }

    @Override
    public void setPosition(int x, int y) {
        super.setPosition(x, y);
        setX(x);
        setY(y);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public void visitChildren(Consumer<LayoutElement> visitor) {
        visitor.accept(this);
    }

    @Override
    public void arrangeElements() {
        packList.initializeEntries();
        if (this.folder != null) this.folder.arrangeElements();
    }

    private void repositionFolder() {
        if (this.folder != null) this.folder.repositionElements();
    }

    public void rebuildEntries() {
        packList.rebuildEntries();
        if (folder != null) {
            folder.listContainer.rebuildEntries();
        }
    }

    static class Folder extends AbstractContainerEventHandler implements FocusPathProvider, FZContextMenu.Source, ContainerEventHandlerPatch, Renderable, FZComponent {
        private static final int HEADER_SIZE = 16;
        private static final int LAYOUT_SPACING = SPACING / 2;
        private final PackListContainer root;
        private final FZIcon background;
        private final PackListContainer listContainer;
        private final FZText folderTitle;
        private final FZButton recallButton;
        private final FZIconButton lockButton;
        private final WrappedLayout<FZFlexLayout> header;
        private final FZLayout layout;
        private PackListState folderState;
        private PackNode.Parent parent;
        private List<GuiEventListener> children = Collections.emptyList();
        private List<Renderable> renderables = Collections.emptyList();
        private boolean childOpened;
        private boolean closed;

        Folder(PackListContainer head, PackListKey key, PackListState state) {
            this.root = head;
            this.folderState = state;
            this.parent = Objects.requireNonNull(state.parent(), "folder parent cannot be null");
            this.listContainer = new PackListContainer(head, key);
            this.background = FZIcon.builder(ResourceLocation.withDefaultNamespace("popup/background")).build();
            FZIconButton closeButton = FZIconButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .icon(new WidgetElements(key.depth() > 1 ? ARROW_UP_SPRITE : CROSS_SPRITE, 16, 16))
                    .onPress(() -> head.context.dispatch(new PackListIntent.CloseFolder(key.unnest())))
                    .focusOnInteraction(false)
                    .build();
            PackIconCache iconCache = head.context.iconCache();
            FZIcon folderIcon = FZIcon.builder(GuiUtils.lazyTexture(() -> iconCache.get(this.parent), 16, 16))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .build();
            this.folderTitle = FZText.builder(parent.title())
                    .height(HEADER_SIZE)
                    .build();
            this.recallButton = FZButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .message(Component.literal("<<"))
                    .tooltip(Component.translatable("packed_packs.folder.recall"))
                    .visible(key.type().available())
                    .onPress(() -> head.context.dispatch(new PackListIntent.Recall(key, this.parent)))
                    .build();
            this.lockButton = FZIconButton.builder()
                    .icon(new WidgetElements(
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL),
                            Renderables.sprite(LOCK_SPRITE_SMALL),
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL),
                            16,
                            16
                    ))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .onPress(() -> head.context.dispatch(
                            new PackListIntent.UpdateModule(key, this.parent, !this.folderState.module())
                    ))
                    .build();

            FZFlexLayout section = FZFlexLayout.vertical(head).spacing(LAYOUT_SPACING);
            {
                FZFlexLayout header = section.child(FZFlexLayout.horizontal(), section.flexChildHorizontalSettings());
                {
                    FZFlexLayout wrapped = FZFlexLayout.horizontal();
                    wrapped.spacing(LAYOUT_SPACING).alignContents(Justification.CENTER);
                    wrapped.child(closeButton);
                    wrapped.child(folderIcon);
                    wrapped.child(folderTitle, wrapped.flexChildHorizontalSettings());
                    wrapped.child(recallButton);
                    wrapped.child(lockButton);

                    this.header = header.child(WrappedLayout.wrap(wrapped), header.flexChildHorizontalSettings());
                }
                section.child(listContainer.packList, section.flexChildSettings());
            }

            this.layout = FZComposedLayout.compose(section).padding(SPACING).clamp(head::getRectangle);

            arrangeElements();
            updateChildren();
        }

        private void updateChildren() {
            if (folderState.folder() == null) {
                this.renderables = List.of(background, header, listContainer);
                this.children = List.of(header, listContainer);
                this.childOpened = false;
            } else {
                this.renderables = List.of(listContainer);
                this.children = List.of(listContainer);
                this.childOpened = true;
            }
        }

        private void onStateChanged(PackListState folderState, ProfileSelection profiles, boolean unlockable) {
            PackListState prevFolderState = this.folderState;
            this.folderState = folderState;

            lockButton.active = unlockable && !profiles.isLocked();
            recallButton.active = !folderState.module() && !profiles.isLocked();

            if (prevFolderState.parent() != folderState.parent()) { // I don't think this will ever be true, but just in case
                this.parent = Objects.requireNonNull(folderState.parent(), "folder parent cannot be null");
                folderTitle.setMessage(parent.title());
            }
            if ((prevFolderState.folder() == null) != (folderState.folder() == null)) {
                updateChildren();
            }

            listContainer.onStateChanged(folderState, profiles, unlockable);
        }

        private void onClose() {
            this.closed = true;

            listContainer.context.resources().saveFolderMetadata(this.parent);

            if (listContainer.folder != null) {
                listContainer.folder.onClose();
            }
        }

        @Override
        public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            for (Renderable renderable : this.renderables) {
                renderable.render(graphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            PackNode.Parent pack = this.parent;

            if (this.childOpened) {
                FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
                return;
            }

            collector.addEntry(builder -> builder
                    .message(pack.title())
                    .icon(padded16Rect(Renderables.texture(listContainer.context.iconCache().get(pack), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false));

            collector.addEntry(builder -> builder
                    .message(CommonComponents.GUI_BACK.copy().append(CommonComponents.ELLIPSIS))
                    .onPress(() -> root.context.dispatch(new PackListIntent.CloseFolder(listContainer.state.key().unnest()))));

            if (!listContainer.packList.isHovered()) {
                if (listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack)) {
                    collector.addEntry(builder -> builder
                            .message(RENAME_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.OpenRenameModal(listContainer.state.key(), pack))));
                    collector.addEntry(builder -> builder
                            .message(DELETE_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.Delete(listContainer.state.key(), pack))));
                }

                collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(pack.path())));
                collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(pack.path())));
            }

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        void repositionElements() {
            if (root.getX() != 0 && (layout.getX() != root.getX())
                || root.getY() != 0 && (layout.getY() != root.getY())) {
                listContainer.setPosition(root.getX(), root.getY());
                layout.setPosition(root.getX(), root.getY());
                background.setPosition(root.getX(), root.getY());
            }
        }

        void arrangeElements() {
            if ((root.getWidth() != 0 && layout.getWidth() != root.getWidth())
                || (root.getHeight() != 0 && layout.getHeight() != root.getHeight())) {
                listContainer.setSize(root.getWidth(), root.getHeight());
                layout.fidgetz$setSize(root.getWidth(), root.getHeight());
                background.setSize(root.getWidth(), root.getHeight());
            }

            repositionElements();
        }

        @Override
        public @Nullable ComponentPath getFocusPath(FocusTarget target) {
            return ComponentPath.path(this, listContainer.getFocusPath(target));
        }

        @Override
        public @Nullable ComponentPath nextFocusPath(FocusNavigationEvent event) {
            if (this.childOpened) {
                return ComponentPath.path(this, listContainer.nextFocusPath(event));
            }

            if (event instanceof InitialFocus) {
                ComponentPath path = listContainer.nextFocusPath(event);
                return path == null ? ComponentPath.path(this, NavigationUtils.initialFocus(header)) : ComponentPath.path(this, path);
            }

            GuiEventListener focused = this.getFocused();
            if (focused != null) {
                if (event instanceof ArrowNavigation arrowNavigation && (focused == this.header || focused == this.listContainer)) {
                    ScreenDirection direction = arrowNavigation.direction();
                    ComponentPath inner = focused.nextFocusPath(event);
                    if (inner != null) {
                        return ComponentPath.path(this, inner);
                    }

                    if (focused == this.header ? direction == ScreenDirection.DOWN : direction == ScreenDirection.UP) {
                        GuiEventListener target = focused == this.header ? this.listContainer : this.header;
                        ComponentPath path = target.nextFocusPath(arrowNavigation);
                        if (path != null) {
                            return ComponentPath.path(this, path);
                        }
                    }

                    return ComponentPath.path(this, focused.nextFocusPath(event));
                } else if (event instanceof TabNavigation) {
                    return super.nextFocusPath(event);
                } else {
                    return ComponentPath.path(this, focused.nextFocusPath(event));
                }
            }

            if (!(event instanceof ArrowNavigation(ScreenDirection direction))) {
                return super.nextFocusPath(event);
            }

            boolean headerFirst = direction == ScreenDirection.DOWN;
            GuiEventListener first = headerFirst ? this.header : this.listContainer;
            GuiEventListener second = headerFirst ? this.listContainer : this.header;

            ComponentPath path = first.nextFocusPath(event);
            if (path == null) {
                path = second.nextFocusPath(event);
            }
            if (path != null) {
                return ComponentPath.path(this, path);
            }

            return super.nextFocusPath(event);
        }

        @Override
        public boolean fidgetz$shouldTakeFocusAfterInteraction() {
            return !closed;
        }

        @Override
        public void setFocused(boolean isFocused) {
            if (!isFocused) {
                setFocused(null);
            }
        }

        @Override
        public void setFocused(@Nullable GuiEventListener focused) {
            if (getFocused() != focused) {
                super.setFocused(focused);
            }
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            return ContainerEventHandlerPatch.super.mouseClicked(mouseX, mouseY, button) && !closed;
        }

        @Override
        public boolean isMouseOver(double mouseX, double mouseY) {
            return getRectangle().containsPoint((int) mouseX, (int) mouseY);
        }

        @Override
        public List<GuiEventListener> children() {
            return children;
        }

        @Override
        public ScreenRectangle getRectangle() {
            return layout.getRectangle();
        }
    }
}
