package io.github.fishstiz.packed_packs.impl;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import net.minecraft.network.chat.Component;

public class TestImpl implements PackedPacksInitializer {
    @Override
    public void onInitialize(PackedPacksApi api) {
        api.eventBus().register(ContextMenuEvent.Screen.class, ResourceUtil.id("test"), event -> {
            event.addItem(item -> item.setLabel(Component.literal("SEPARATOR TESTS")).addSeparatorAbove().applyDevStyle());

            event.addItem(item -> item.setLabel(Component.literal("SEP BELOW")).addSeparatorBelow());
            event.addItem(item -> item.setLabel(Component.literal("SEP ABOVE")));
            event.addItem(item -> item.setLabel(Component.literal("NO SEP")));
            event.addItem(item -> item.setLabel(Component.literal("SEP BELOW")));
            event.addItem(item -> item.setLabel(Component.literal("SEP ABOVE AND BELOW")).addSeparatorAbove().addSeparatorBelow());

            event.addItem(item -> item.setLabel(Component.literal("SEP ABOVE PARENT"))
                    .addChild(child -> child.setLabel(Component.literal("SEP BELOW")).addSeparatorBelow())
                    .addChild(child -> child.setLabel(Component.literal("SEP ABOVE")))
                    .addChild(child -> child.setLabel(Component.literal("NO SEP")))
                    .addChild(child -> child.setLabel(Component.literal("SEB BELOW")).addSeparatorBelow())
                    .addChild(child -> child.setLabel(Component.literal("SEP ABOVE AND BELOW")).addSeparatorBelow().addSeparatorAbove())
                    .addChild(child -> child.setLabel(Component.literal("SEP ABOVE")).addSeparatorAbove())
                    .addChild(child -> child.setLabel(Component.literal("NO SEP")))
                    .addChild(child -> child.setLabel(Component.literal("SEP BELOW")))
                    .addChild(child -> child.setLabel(Component.literal("SEB ABOVE")).addSeparatorAbove()));
        });
    }
}
