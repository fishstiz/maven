package io.github.fishstiz.packed_packs.impl.gui;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.fidgetz.v0.gui.components.FZPopoverMenuItem;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuItemSpec;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7919;

public class ContextMenuItemSpecImpl implements ContextMenuItemSpec {
    private final boolean devStyle;
    private final FZPopoverMenuItem.Builder itemBuilder = FZPopoverMenuItem.builder();
    private boolean separatorBelow;
    private boolean separatorAbove;

    public ContextMenuItemSpecImpl(boolean devStyle) {
        this.devStyle = devStyle;
        if (devStyle) this.applyDevStyle();
    }

    @Override
    public ContextMenuItemSpec label(class_2561 label) {
        this.itemBuilder.message(label);
        return this;
    }

    @Override
    public ContextMenuItemSpec action(Runnable action) {
        this.itemBuilder.onPress(action);
        return this;
    }

    @Override
    public ContextMenuItemSpec icon(class_2960 guiSprite) {
        this.itemBuilder.icon(GuiUtils.padded16Sprite(guiSprite));
        return this;
    }

    @Override
    public ContextMenuItemSpec tooltip(class_7919 tooltip) {
        this.itemBuilder.tooltip(tooltip);
        return this;
    }

    @Override
    public ContextMenuItemSpec active(BooleanSupplier active) {
        this.itemBuilder.active(active);
        return this;
    }

    @Override
    public ContextMenuItemSpec closeOnInteract(boolean closeOnInteract) {
        this.itemBuilder.closeOnInteraction(closeOnInteract);
        return this;
    }

    @Override
    public ContextMenuItemSpec child(Consumer<ContextMenuItemSpec> configurator) {
        ContextMenuItemSpecImpl childBuilder = new ContextMenuItemSpecImpl(this.devStyle);
        configurator.accept(childBuilder);
        if (childBuilder.separatorAbove) itemBuilder.nextSection();
        itemBuilder.child(childBuilder.itemBuilder.build());
        if (childBuilder.separatorBelow) itemBuilder.nextSection();
        return this;
    }

    @Override
    public ContextMenuItemSpec separatorBelow() {
        this.separatorBelow = true;
        return this;
    }

    @Override
    public ContextMenuItemSpec separatorAbove() {
        this.separatorAbove = true;
        return this;
    }

    @Override
    public ContextMenuItemSpec asToggle(BooleanSupplier value, BooleanConsumer onChange) {
        this.itemBuilder.icon(GuiUtils.toggleRect(value)).onPress(() -> onChange.accept(!value.getAsBoolean()));
        return this;
    }

    @Override
    public ContextMenuItemSpec applyDevStyle() {
        GuiUtils.buildDevEntry(this.itemBuilder);
        return this;
    }

    public void apply(FZContextMenu.Collector collector) {
        if (separatorAbove) {
            collector.nextSection();
        }
        collector.addEntry(itemBuilder.build());
        if (separatorBelow) {
            collector.nextSection();
        }
    }
}
