package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.DevConfig;
import io.github.fishstiz.packed_packs.config.DevConfig.ResourcePacks.LoadDefaultCondition;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.gui.UiEffect;
import io.github.fishstiz.packed_packs.gui.actions.intents.Intent;
import io.github.fishstiz.packed_packs.gui.actions.intents.ProfileIntent;
import io.github.fishstiz.packed_packs.gui.layouts.ProfileTitleLayout;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksContext;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.gui.states.ProfilesState;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_11876;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8012;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class ProfileList extends FZAbstractListWidget<ProfileList.Entry> implements class_8133 {
    private static final class_2561 EMPTY_TEXT = class_2561.method_43471("packed_packs.profile.empty");
    private final Consumer<? super Intent> dispatcher;
    private final Consumer<UiEffect> effectDispatcher;
    private final class_3264 packType;
    private ProfilesState state = ProfilesState.empty();
    private boolean devMode;
    private @Nullable io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry dragged;

    public ProfileList(PackedPacksContext context) {
        this.dispatcher = context::dispatch;
        this.effectDispatcher = context::dispatch;
        this.packType = context.packType();
        onStateChanged(context.state().value());
        context.state().subscribe("ProfileList", this::onStateChanged);
    }

    @Override
    protected int maxContentWidth() {
        return 0;
    }

    private void onStateChanged(PackedPacksState newState) {
        ProfilesState prev = this.state;
        boolean devModeChanged = devMode != newState.devMode();

        if (prev == newState.profiles() && !devModeChanged) {
            return;
        }

        this.state = newState.profiles();
        this.devMode = newState.devMode();

        if (prev.profiles() != this.state.profiles() || prev.defaultProfile() != this.state.defaultProfile()) {
            rebuildEntries();
        } else {
            for (io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry : method_25396()) {
                entry.onStateChanged(devModeChanged);
            }
        }
    }

    @Override
    protected void clearEntries() {
        this.dragged = null;
        super.clearEntries();
    }

    private void rebuildEntries() {
        io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused = method_25399();
        Profile previousFocused = focused == null ? null : focused.profile;
        double scrollAmount = method_44387();

        clearEntries();

        Profile defaultProfile = state.defaultProfile();
        List<Profile> profiles = new ObjectArrayList<>(state.profiles());

        int i = 0;
        if (defaultProfile != null) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = new io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry(defaultProfile, i++);
            addEntry(entry);
            profiles.remove(defaultProfile);
            if (previousFocused != null
                && (previousFocused == defaultProfile || previousFocused.getId().equals(defaultProfile.getId()))) {
                method_25395(entry);
            }
        }

        for (Profile profile : profiles) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = new io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry(profile, i++);
            addEntry(entry);
            if (previousFocused != null && previousFocused.getId().equals(profile.getId())) {
                method_25395(entry);
            }
        }

        repositionEntries();
        method_44382(scrollAmount);
    }

    @Override
    public void method_53533(int height) {
        int previousHeight = method_25364();
        super.method_53533(height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    public void method_55445(int width, int height) {
        int previousHeight = method_25364();
        super.method_55445(width, height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    private int draggedTop(io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry, int mouseY) {
        int height = entry.method_25364();
        return Math.clamp(mouseY - height / 2, method_46427(), method_55443() - height);
    }

    private int dropIndex(io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry, int mouseY) {
        io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry first = method_25396().getFirst();
        int height = entry.method_25364();
        int dropIndex = Math.floorDiv(draggedTop(entry, mouseY) + height / 2 - first.method_46427(), height);
        return Math.clamp(dropIndex, first.isDefault() ? 1 : 0, method_25396().size() - 1);
    }

    private void drop(io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry dragged, int mouseY) {
        this.dragged = null;
        int index = dropIndex(dragged, mouseY);

        List<io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry> entries = method_25396();
        if (index < 0 || index >= entries.size()) {
            return;
        }

        int from = dragged.getIndex();
        int to = state.profiles().indexOf(entries.get(index).profile);
        if (to == -1 || from == to) {
            return;
        }

        dispatcher.accept(new ProfileIntent.Move(dragged.profile, index));
    }

    private void extractDraggedRenderState(io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry dragged, class_332 graphics, int mouseY, float partialTick) {
        int from = dragged.getIndex();
        int height = dragged.method_25364();

        if (mouseY < method_46427() + height / 2) {
            scroll(-method_44393() * partialTick);
        } else if (mouseY > method_55443() - height / 2) {
            scroll(method_44393() * partialTick);
        }

        int dropIndex = dropIndex(dragged, mouseY);
        int start = dropIndex < from ? dropIndex : from + 1;
        int end = dropIndex < from ? from : dropIndex + 1;
        int shift = dropIndex < from ? height : -height;

        List<io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry> entries = method_25396();
        class_8030 bounds = method_48202();

        for (int i = 0; i < entries.size(); i++) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = entries.get(i);
            if (entry != dragged && (i < start || i >= end) && entry.method_48202().method_48252(bounds)) {
                entry.method_25394(graphics, -1, -1, partialTick);
            }
        }

        class_8030 shiftedBounds = new class_8030(bounds.method_49620(), bounds.method_49618() - shift, bounds.comp_1196(), bounds.comp_1197());
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(0, shift);
        for (int i = start; i < end; i++) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = entries.get(i);
            if (entry.method_48202().method_48252(shiftedBounds)) {
                entry.method_25394(graphics, -1, -1, partialTick);
            }
        }
        graphics.method_51448().popMatrix();

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(0, draggedTop(dragged, mouseY) - dragged.method_46427());
        dragged.method_25394(graphics, -1, -1, partialTick);
        graphics.method_51448().popMatrix();

        graphics.method_74037(class_11876.field_62456);
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (dragged != null && method_25399() == dragged) {
            setHovered(null);
            extractDraggedRenderState(dragged, graphics, mouseY, partialTick);
        } else {
            super.extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
        }

        if (method_25396().isEmpty()) {
            method_75799(
                    graphics.method_75787(this, class_332.class_12228.field_63850),
                    EMPTY_TEXT,
                    0
            );
        }
    }

    @Override
    protected void extractFocusedRenderState(class_332 graphics, io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused) {
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void method_48222() {
        repositionEntries();
    }

    protected final class Entry extends FZAbstractListWidget.Entry implements FZContextMenu.Source {
        private static final RenderableRectangle HANDLE_SPRITE = Renderables.sprite(PackedPacks.id("icon/ellipsis_vertical"));
        private static final RenderableRectangle INACTIVE_HANDLE_SPRITE = Renderables.sprite(
                PackedPacks.id("icon/ellipsis_vertical"),
                class_8012.field_44941
        );
        private static final class_2960 STAR_OUTLINE_SPRITE = PackedPacks.id("icon/star_outline");
        private final List<class_339> children = new ArrayList<>();
        private final FZFlexLayout layout;
        private final Profile profile;
        private final int index;
        private FZIconButton dragHandle;
        private FZButton selectButton;
        private boolean prevDefault;
        private boolean prevLocked;

        private Entry(Profile profile, int index) {
            this.index = index;
            this.profile = profile;
            this.layout = FZFlexLayout.horizontal();

            buildWidgets(state.defaultProfile() == profile, profile.isLocked());

            layout.method_48222();
        }

        private <T extends class_339> T addChild(T widget) {
            children.add(widget);
            if (widget instanceof FZHoverableElement hoverableElement) {
                hoverableElement.fidgetz$setHovered(fidgetz$isHovered());
            }
            return widget;
        }

        private void updateTooltip() {
            String desc = profile.getDescription();
            if (desc.isEmpty()) {
                selectButton.method_47400(null);
            } else {
                selectButton.method_47400(class_7919.method_47407(class_2561.method_43473()
                        .method_10852(class_2561.method_43470(profile.getName()).method_27692(class_124.field_1067))
                        .method_10852(class_5244.field_33849)
                        .method_10852(class_2561.method_43470(desc))
                ));
            }
        }

        private void buildWidgets(boolean isDefault, boolean isLocked) {
            boolean deleteActive = !isLocked && !isDefault;

            this.dragHandle = addChild(layout.child(FZIconButton.builder()
                    .size(16, 20)
                    .id("DragHandle")
                    .icon(new WidgetElements(isDefault ? INACTIVE_HANDLE_SPRITE : HANDLE_SPRITE, 16, 16))
                    .active(!isDefault)
                    .build()));

            this.selectButton = addChild(layout.child(FZButton.builder()
                    .id("SelectButton")
                    .message(class_2561.method_43470(profile.getName()))
                    .onPress(() -> dispatcher.accept(new ProfileIntent.Select(profile)))
                    .active(state.selectedProfile() != profile)
                    .build(), layout.flexChildHorizontalSettings()));
            updateTooltip();

            if (!isLocked) {
                addChild(layout.child(FZIconButton.builder()
                        .id("EditButton")
                        .square()
                        .icon(new WidgetElements(PackedPacks.id("icon/edit"), 16, 16))
                        .onPress(() -> effectDispatcher.accept(new UiEffect.OpenDialog((container, closer) ->
                                FZModal.builder(container, ProfileTitleLayout.createForm(profile, dispatcher, () -> {
                                            updateTooltip();
                                            closer.run();
                                        }))
                                        .id("ProfileEditDialog")
                                        .margin(SPACING)
                                        .padding((int) (SPACING * 1.5))
                                        .captureClick()
                                        .captureFocus()
                                        .buildAndOpen()
                        )))
                        .build()));
            }

            addChild(layout.child(FZIconButton.builder()
                    .square()
                    .id("DeleteButton")
                    .message(class_2561.method_43471("packed_packs.profile.delete"))
                    .tooltip(deleteActive ? class_2561.method_43471("packed_packs.profile.delete.info") : null)
                    .icon(getDeleteIcon(isDefault, isLocked))
                    .onPress(() -> dispatcher.accept(new ProfileIntent.Delete(profile)))
                    .active(deleteActive)
                    .build()));

            if (devMode) {
                addChild(layout.child(FZIconButton.builder()
                        .id("DefaultButton")
                        .square()
                        .icon(new WidgetElements(isDefault ? STAR_SPRITE : STAR_OUTLINE_SPRITE, 16, 16))
                        .tooltip(isDefault
                                ? class_2561.method_43471("packed_packs.profile.default.unset")
                                : class_2561.method_43471("packed_packs.profile.default.set"))
                        .onPress(this::toggleDefault)
                        .build()));

                addChild(layout.child(FZIconButton.builder(isLocked ? LOCK_SPRITES : UNLOCK_SPRITES)
                        .id("LockButton")
                        .square()
                        .tooltip(isLocked
                                ? class_2561.method_43471("packed_packs.profile.unlock")
                                : class_2561.method_43471("packed_packs.profile.lock"))
                        .onPress(this::toggleLock)
                        .build()));
            }

            this.prevDefault = isDefault;
            this.prevLocked = isLocked;
        }

        private void rebuildWidgets(boolean isDefault, boolean isLocked) {
            children.clear();
            layout.removeChildren();

            class_364 focused = method_25399();
            method_25395(null);
            buildWidgets(isDefault, isLocked);

            if (focused instanceof FZComponent previousFocusedComponent) {
                String id = previousFocusedComponent.fidgetz$componentId();
                for (class_339 child : children) {
                    if (child instanceof FZComponent component && Objects.equals(id, component.fidgetz$componentId())) {
                        method_25395(child);
                    }
                }
            }

            layout.method_48222();
            layout.fidgetz$setWidth(method_25368());
            layout.method_48229(method_46426(), method_46427());
        }

        private void onStateChanged(boolean devModeChanged) {
            boolean isDefault = isDefault();
            boolean isLocked = profile.isLocked();

            if (devModeChanged || isDefault != prevDefault || isLocked != prevLocked) {
                rebuildWidgets(isDefault, isLocked);
                return;
            }

            String name = profile.getName();
            if (!name.equals(this.selectButton.method_25369().getString())) {
                this.selectButton.method_25355(class_2561.method_43470(name));
            }

            this.selectButton.field_22763 = state.selectedProfile() != profile;
        }

        @Override
        public int getIndex() {
            return index;
        }

        private boolean isDefault() {
            return state.defaultProfile() == profile;
        }

        private void toggleDefault() {
            dispatcher.accept(new ProfileIntent.SetDefault(isDefault() ? null : profile));
        }

        private void toggleLock() {
            dispatcher.accept(new ProfileIntent.ToggleLock(profile));
        }

        private static WidgetElements getDeleteIcon(boolean isDefault, boolean isLocked) {
            if (isDefault) {
                return new WidgetElements(STAR_SPRITE, 16, 16);
            } else if (isLocked) {
                return new WidgetElements(LOCK_SPRITE_DISABLED, 20, 20);
            } else {
                return new WidgetElements(TRASH_SPRITE, 16, 16);
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            for (class_339 child : children) {
                child.method_25394(graphics, mouseX, mouseY, partialTick);
            }

            if (this.dragHandle.method_37303() && this.dragHandle.method_49606()) {
                graphics.method_74037(class_11876.field_62456);
            }
        }

        private static WidgetElements createIcon(Supplier<class_2960> sprite) {
            return padded16Rect(GuiUtils.lazySprite(sprite));
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            if (!devMode) return;

            collector.nextSection();

            collector.addEntry(builder -> buildDevEntry(builder)
                    .message(class_2561.method_43471("packed_packs.profile.default." + (isDefault() ? "unset" : "set")))
                    .icon(createIcon(() -> isDefault() ? STAR_SPRITE : STAR_OUTLINE_SPRITE))
                    .onPress(this::toggleDefault));

            collector.addEntry(builder -> buildDevEntry(builder
                    .message(class_2561.method_43471("packed_packs.profile." + (state.isLocked() ? "unlock" : "lock")))
                    .icon(createIcon(() -> state.isLocked() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL))
                    .onPress(this::toggleLock)));

            if (!isDefault() || packType == class_3264.field_14190) {
                return;
            }

            DevConfig.ResourcePacks config = DevConfig.get().getResourcepacks();

            FZPopoverMenuItem.Builder loadConditionEntry = buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.info")));

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .closeOnInteraction(false)
                    .build());

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_FILE))
                    .closeOnInteraction(false)
                    .build());

            collector.addEntry(loadConditionEntry.build());
        }

        @Override
        public boolean method_25403(class_11909 event, double dx, double dy) {
            if (method_25399() == this.dragHandle) {
                dragged = this;
                return true;
            }

            return super.method_25403(event, dx, dy);
        }

        @Override
        public boolean method_25406(class_11909 event) {
            if (method_25399() == this.dragHandle) {
                drop(this, (int) event.comp_4799());
            }

            return super.method_25406(event);
        }

        @Override
        public void method_46421(int x) {
            super.method_46421(x);
            layout.method_46421(x);
        }

        @Override
        public void method_46419(int y) {
            super.method_46419(y);
            layout.method_46419(y);
        }

        @Override
        protected void setWidth(int width) {
            super.setWidth(width);
            layout.fidgetz$setWidth(method_25368());
        }

        @Override
        protected void setBounds(int x, int y, int width, int height) {
            super.setBounds(x, y, width, height);
            layout.method_48229(x, y);
            layout.fidgetz$setWidth(width);
        }

        @Override
        public int method_25364() {
            return layout.method_25364();
        }

        @Override
        public List<class_339> method_25396() {
            return children;
        }
    }
}