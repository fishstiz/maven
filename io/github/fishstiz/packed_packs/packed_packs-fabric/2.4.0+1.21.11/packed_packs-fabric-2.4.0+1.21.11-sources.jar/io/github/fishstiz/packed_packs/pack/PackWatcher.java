package io.github.fishstiz.packed_packs.pack;

import io.github.fishstiz.fidgetz.v0.utils.timer.ConcurrentPollingDebouncer;
import io.github.fishstiz.fidgetz.v0.utils.timer.PollingDebouncer;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.FolderPackMeta;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import net.minecraft.class_156;

import static io.github.fishstiz.packed_packs.util.PackUtil.hasFolderConfig;
import static io.github.fishstiz.packed_packs.util.PackUtil.hasMcmeta;
import static java.nio.file.Files.isDirectory;
import static net.minecraft.class_156.method_18349;

/**
 * Migrated from {@link java.nio.file.WatchService} due to registered subdirectories locking parent directory on Windows.
 *
 * @see <a href="https://bugs.openjdk.org/browse/JDK-6972833">JDK-6972833</a>
 */
public class PackWatcher implements AutoCloseable {
    private static final long POLL_INTERVAL_MS = 1000;
    private static final long DEBOUNCED_CHANGE_DELAY_MS = 1000;
    private final FileAlterationMonitor monitor = new FileAlterationMonitor(POLL_INTERVAL_MS);
    private final DirectoryListener directoryListener = new DirectoryListener();
    private final PollingDebouncer<Path> onChangeCallback;
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final AtomicInteger pauseCount = new AtomicInteger(0);

    private long lastPollTime;

    public PackWatcher(Collection<Path> directories, Consumer<Path> onChangeCallback) {
        this.monitor.setThreadFactory(ignored -> {
            throw new IllegalStateException("PackWatcher monitor should not be creating a new thread.");
        });
        this.onChangeCallback = new ConcurrentPollingDebouncer<>(path -> {
            if (!this.closed.get() && this.pauseCount.get() == 0) {
                onChangeCallback.accept(path);
            }
        }, DEBOUNCED_CHANGE_DELAY_MS);
        directories.forEach(this::addDirectory);
    }

    private void addDirectory(Path directory) {
        if (!isDirectory(directory)) return;

        Path normalizedPath = directory.toAbsolutePath().normalize();
        FileAlterationObserver observer;
        try {
            observer = FileAlterationObserver.builder()
                    .setFile(directory.toFile())
                    .setFileFilter(new Filter(normalizedPath))
                    .setIOCase(IOCase.SENSITIVE).get();
        } catch (IOException e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to create observer for directory: '{}' ", directory, e);
            return;
        }

        observer.addListener(this.directoryListener);

        method_18349().execute(() -> {
            if (this.closed.get()) return;
            try {
                observer.initialize();
                if (!this.closed.get()) {
                    this.monitor.addObserver(observer);
                } else {
                    observer.destroy();
                }
            } catch (Exception e) {
                PackedPacks.LOGGER.error("[packed_packs] Failed to initialize observer for directory {}.", normalizedPath, e);
            }
        });
    }

    /**
     * poll on main thread
     */
    public void poll() {
        long currentTime = class_156.method_658();
        if (currentTime - this.lastPollTime >= this.monitor.getInterval()) {
            method_18349().execute(() -> this.monitor.getObservers().forEach(FileAlterationObserver::checkAndNotify));
            this.lastPollTime = currentTime;
        }
        this.onChangeCallback.poll();
    }

    public void pause() {
        this.pauseCount.incrementAndGet();
        this.onChangeCallback.abort();
    }

    public void resume() {
        this.pauseCount.decrementAndGet();
    }

    public void consumeChanges() {
        this.pause();
        method_18349().execute(() -> {
            this.monitor.getObservers().forEach(FileAlterationObserver::checkAndNotify);
            this.onChangeCallback.abort();
            this.resume();
        });
    }

    @Override
    public void close() {
        if (!this.closed.compareAndSet(false, true)) {
            return;
        }
        this.onChangeCallback.abort();
        method_18349().execute(() -> {
            for (FileAlterationObserver observer : this.monitor.getObservers()) {
                try {
                    observer.destroy();
                } catch (Exception e) {
                    PackedPacks.LOGGER.error("[packed_packs] Error occurred while closing observer for {}", observer.getDirectory(), e);
                }
            }
        });
    }

    private record Filter(Path root) implements FileFilter {
        private static final int DIRECTORY_PACK_DEPTH = 1;

        @Override
        public boolean accept(File pathname) {
            Path path = pathname.toPath();
            int depth = this.root.relativize(path.toAbsolutePath().normalize()).getNameCount();

            if (depth == 0 || depth == DIRECTORY_PACK_DEPTH) {
                return true;
            }

            return hasMcmeta(path.getParent()) || hasFolderConfig(path.getParent());
        }
    }

    private class DirectoryListener extends FileAlterationListenerAdaptor {
        private DirectoryListener() {
        }

        @Override
        public void onDirectoryCreate(File directory) {
            this.onEvent(directory);
        }

        @Override
        public void onDirectoryChange(File directory) {
            this.onEvent(directory);
        }

        @Override
        public void onDirectoryDelete(File directory) {
            this.onEvent(directory);
        }

        @Override
        public void onFileCreate(File file) {
            this.onEvent(file);
        }

        @Override
        public void onFileChange(File file) {
            this.onEvent(file);
        }

        @Override
        public void onFileDelete(File file) {
            this.onEvent(file);
        }

        private void onEvent(File file) {
            Path path = file.toPath().toAbsolutePath().normalize();
            if (!path.endsWith(FolderPackMeta.FILENAME)) {
                PackWatcher.this.onChangeCallback.accept(path);
            }
        }
    }
}
