package io.github.fishstiz.packed_packs.gui.layouts;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.state.FZMutableRef;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.config.ProfileManager;
import io.github.fishstiz.packed_packs.gui.actions.intents.Intent;
import io.github.fishstiz.packed_packs.gui.actions.intents.ProfileIntent;
import io.github.fishstiz.packed_packs.gui.states.ProfilesState;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_5244;
import net.minecraft.class_7529;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class ProfileTitleLayout {
    public static FZFlexLayout create(FZRef<ProfilesState> state, Consumer<? super Intent> dispatcher) {
        FZIconButton editButton = FZIconButton.bind(
                "ProfileNameEditButton",
                state.map(profilesState -> FZIconButton.builder()
                        .square()
                        .tooltip(class_2561.method_43471("packed_packs.profile.edit"))
                        .icon(getEditIcon(profilesState))
                        .visible(profilesState.selectedProfile() != null)
                        .active(profilesState.canRename())
                        .onPress(() -> dispatcher.accept(new ProfileIntent.ToggleRenaming()))
                        .toProps()
                )
        );

        FZTextField nameField = FZTextField.bind(
                "ProfileNameField",
                state.map(s -> {
                    Profile profile = s.selectedProfile();
                    return FZTextField.builder()
                            .height(20)
                            .visible(profile != null)
                            .active(profile != null)
                            .hint(profile == null ? NO_PROFILE_TEXT : ProfileManager.getDefaultNameComponent())
                            .maxLength(ProfileManager.getNameMaxLength())
                            .text(profile == null ? "" : profile.getName())
                            .onChange(e -> {
                                if (profile == null) return;
                                dispatcher.accept(new ProfileIntent.Rename(profile, e.value()));
                            })
                            .toProps();
                })
        );

        FZFlexLayout title = FZFlexLayout.horizontal().spacing(SPACING);
        {
            title.defaultChildSettings().visible();

            title.child(editButton);
            title.child(
                    WrappedComponent.bind(
                            "ProfileNameContainer",
                            state.map(profilesState -> profilesState.canRename() && profilesState.renaming()
                                    ? nameField
                                    : buildNameReadonly(profilesState)
                            )
                    ),
                    title.flexChildHorizontalSettings()
            );
        }

        return title;
    }

    private static FZText buildNameReadonly(ProfilesState profilesState) {
        Profile selected = profilesState.selectedProfile();
        return FZText.builder(getDisplayName(selected))
                .height(20)
                .visible(selected != null)
                .build();
    }

    private static class_2561 getDisplayName(@Nullable Profile profile) {
        if (profile == null) return class_5244.field_39003;
        String name = profile.getName();
        return name.isBlank()
                ? class_339.class_12230.method_75800(ProfileManager.getDefaultNameComponent())
                : class_2561.method_43470(name);
    }

    private static WidgetElements getEditIcon(ProfilesState profilesState) {
        Profile selected = profilesState.selectedProfile();
        Profile main = profilesState.defaultProfile();

        if (profilesState.canRename()) {
            return new WidgetElements(WidgetRenderables.noFocus(PackedPacks.id("icon/edit"), PackedPacks.id("icon/edit_inactive")), 16, 16);
        }
        if (Objects.equals(main, selected)) {
            return new WidgetElements(STAR_SPRITE, 16, 16);
        }

        return new WidgetElements(LOCK_SPRITE_DISABLED, 20, 20);
    }

    public static FZFlexLayout createForm(Profile profile, Consumer<? super Intent> dispatcher, Runnable closer) {
        FZMutableRef<ProfileIntent.Rename> draft = new FZMutableRef<>(new ProfileIntent.Rename(
                profile,
                profile.getName(),
                profile.getDescription()
        ));

        Runnable handleSubmit = () -> {
            dispatcher.accept(draft.value());
            closer.run();
        };

        FZFlexLayout layout = FZFlexLayout.vertical().maxWidth(300).spacing(SPACING);
        layout.defaultChildSettings().flexCross();

        FZFlexLayout header = layout.child(FZFlexLayout.horizontal().spacing(SPACING));
        header.defaultChildSettings().method_46474();
        header.child(
                FZText.builder(class_2561.method_43471("packed_packs.profile.dialog.edit").method_27692(class_124.field_1067))
                        .build(),
                header.flexChildSettings()
        );
        header.child(FZIconButton.builder()
                .square()
                .icon(new WidgetElements(CROSS_SPRITE, 16, 16))
                .onPress(closer)
                .build());

        class_2561 nameMessage = class_2561.method_43471("packed_packs.profile.dialog.name");
        layout.child(FZTextField.bind("Name", draft.map(ProfileIntent.Rename::name).map(value ->
                FZTextField.builder()
                        .text(value)
                        .message(nameMessage)
                        .hint(nameMessage)
                        .maxLength(ProfileManager.getNameMaxLength())
                        .onChange(e -> draft.set(prev -> new ProfileIntent.Rename(prev.profile(), e.value(), prev.description())))
                        .onConfirm(e -> {
                            handleSubmit.run();
                            e.confirm();
                        })
                        .toProps()
        )));

        class_2561 descMessage = class_2561.method_43471("packed_packs.profile.dialog.description");
        class_7529 descBox = layout.child(class_7529.method_71507()
                .method_71510(descMessage)
                .method_71509(class_310.method_1551().field_1772, 300, 60, descMessage));
        descBox.method_44402(ProfileManager.getDescMaxLength());
        descBox.method_71506(10);
        descBox.method_44400(draft.value().description());
        descBox.method_44401(value -> draft.set(prev -> new ProfileIntent.Rename(prev.profile(), prev.name(), value)));

        FZFlexLayout footer = layout.child(
                FZFlexLayout.horizontal().spacing(SPACING),
                layout.newChildSettings().method_46471(SPACING)
        );

        footer.defaultChildSettings().flexMain();
        footer.child(FZButton.builder()
                .message(class_5244.field_24334)
                .onPress(handleSubmit)
                .build());
        footer.child(FZButton.builder()
                .message(class_5244.field_24335)
                .onPress(closer)
                .build());

        return layout;
    }
}
