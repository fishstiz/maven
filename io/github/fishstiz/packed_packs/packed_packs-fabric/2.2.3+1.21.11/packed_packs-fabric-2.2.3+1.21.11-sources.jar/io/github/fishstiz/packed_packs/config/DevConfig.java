package io.github.fishstiz.packed_packs.config;

import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jspecify.annotations.Nullable;

import java.io.Serializable;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.minecraft.class_3264;

public final class DevConfig {
    private static final String FILENAME = "config.meta.json";
    private static final DevConfig INSTANCE = JsonLoader.loadOrDefault(getPath(), DevConfig.class, () -> {
        DevConfig devConfig = new DevConfig();
        devConfig.resourcepacks.setLoadDefaultCondition(ResourcePacks.LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE);
        return devConfig;
    });

    private final ResourcePacks resourcepacks = new ResourcePacks();
    private final DataPacks datapacks = new DataPacks();

    private static Path getPath() {
        return PackedPacks.getConfigDir().resolve(FILENAME);
    }

    public static DevConfig get() {
        return INSTANCE;
    }

    public static Packs packs(class_3264 packType) {
        return INSTANCE.get(packType);
    }

    public Packs get(class_3264 packType) {
        return switch (packType) {
            case field_14188 -> this.resourcepacks;
            case field_14190 -> this.datapacks;
        };
    }

    public DataPacks getDatapacks() {
        return this.datapacks;
    }

    public ResourcePacks getResourcepacks() {
        return this.resourcepacks;
    }

    public void save() {
        JsonLoader.saveJson(this, getPath());
    }

    private DevConfig() {
    }

    public abstract static sealed class Packs implements Serializable {
        private static final String REGEX_PREFIX = "regex:";
        private final Map<String, String> aliases = new Object2ObjectLinkedOpenHashMap<>();
        private transient @Nullable Map<Pattern, String> aliasPatterns;
        private @Nullable String defaultProfile;

        public abstract class_3264 packType();

        public static boolean isRegexPrefixed(String alias) {
            return alias.startsWith(REGEX_PREFIX);
        }

        public static Pattern getRegexPrefixPattern() {
            return Pattern.compile("^" + Pattern.quote(REGEX_PREFIX));
        }

        public boolean hasAliases() {
            return !this.aliases.isEmpty();
        }

        public List<String> getAliases(String packId) {
            return CollectionUtils.reverseLookup(packId, this.aliases);
        }

        public boolean hasAlias(String packId) {
            return this.aliases.containsValue(packId);
        }

        public boolean isAlias(String packId) {
            return this.aliases.containsKey(packId);
        }

        public void putAlias(String aliasId, String canonicalId) {
            this.aliases.put(aliasId, canonicalId);
            this.aliases.remove(canonicalId);
        }

        public @Nullable String resolveCanonicalId(String aliasId) {
            String exact = this.aliases.get(aliasId);
            if (exact != null) return exact;

            Map<Pattern, String> patternMap = this.getAliasPatterns();
            if (patternMap == null) return null;

            for (Map.Entry<Pattern, String> patternEntry : patternMap.entrySet()) {
                if (patternEntry.getKey().matcher(aliasId).matches()) {
                    return patternEntry.getValue();
                }
            }

            return null;
        }

        private @Nullable Map<Pattern, String> getAliasPatterns() {
            if (this.aliases.isEmpty()) return null;

            if (this.aliasPatterns == null) {
                Map<Pattern, String> patterns = new Object2ObjectOpenHashMap<>();
                Pattern regexPrefixPattern = getRegexPrefixPattern();

                for (Map.Entry<String, String> aliasEntry : this.aliases.entrySet()) {
                    String alias = aliasEntry.getKey();
                    String canonicalId = aliasEntry.getValue();
                    if (isRegexPrefixed(alias)) {
                        try {
                            patterns.put(Pattern.compile(alias.replaceFirst(regexPrefixPattern.pattern(), "")), canonicalId);
                        } catch (PatternSyntaxException e) {
                            PackedPacks.LOGGER.error("[packed_packs] Invalid regex syntax '{}' for id '{}'", alias, canonicalId, e);
                        }
                    }
                }
                this.aliasPatterns = Collections.unmodifiableMap(patterns);
            }

            return this.aliasPatterns;
        }

        public void setAliases(String packId, List<String> aliases) {
            this.aliases.values().removeIf(v -> Objects.equals(v, packId));
            for (String alias : aliases) {
                this.aliases.put(alias, packId);
            }
            this.aliasPatterns = null;
        }

        @Nullable String getDefaultProfile() {
            return this.defaultProfile;
        }

        void setDefaultProfile(@Nullable Profile profile) {
            this.defaultProfile = profile == null ? null : profile.getId();
        }
    }

    public static final class ResourcePacks extends Packs {
        private LoadDefaultCondition loadDefaultCondition = LoadDefaultCondition.NO_OPTIONS_FILE;

        public void setLoadDefaultCondition(LoadDefaultCondition loadDefaultCondition) {
            this.loadDefaultCondition = loadDefaultCondition;
        }

        public LoadDefaultCondition getLoadDefaultCondition() {
            return Objects.requireNonNullElse(this.loadDefaultCondition, LoadDefaultCondition.NO_OPTIONS_FILE);
        }

        public enum LoadDefaultCondition {
            NO_OPTIONS_FILE,
            NO_OPTIONS_OR_VERSION_FILE
        }

        @Override
        public class_3264 packType() {
            return class_3264.field_14188;
        }
    }

    public static final class DataPacks extends Packs {
        @Override
        public class_3264 packType() {
            return class_3264.field_14190;
        }
    }
}
