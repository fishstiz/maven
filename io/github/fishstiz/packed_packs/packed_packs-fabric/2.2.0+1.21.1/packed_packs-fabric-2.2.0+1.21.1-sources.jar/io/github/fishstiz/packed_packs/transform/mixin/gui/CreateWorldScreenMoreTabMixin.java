package io.github.fishstiz.packed_packs.transform.mixin.gui;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreenPreloader;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_525;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "net.minecraft.client.gui.screens.worldselection.CreateWorldScreen$MoreTab")
public abstract class CreateWorldScreenMoreTabMixin {
    @Final
    @Shadow(aliases = {"this$0", "field_42178"})
    class_525 this$0;

    @Shadow
    @Final
    private static class_2561 DATA_PACKS_LABEL;

    @ModifyExpressionValue(method = "<init>", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/components/Button$Builder;build()Lnet/minecraft/client/gui/components/Button;"
    ))
    private class_4185 preloadPackedPacksScreen(class_4185 original) {
        if (original.method_25369() == DATA_PACKS_LABEL) {
            PackedPacksScreenPreloader.attach(this$0, original);
        }
        return original;
    }
}
