package io.github.fishstiz.packed_packs.pack.folder;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.JsonLoader;
import io.github.fishstiz.packed_packs.config.FolderPackMeta;
import io.github.fishstiz.packed_packs.transform.interfaces.FilePack;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectImmutableList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_3262;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_7699;
import net.minecraft.class_9224;
import net.minecraft.class_9225;
import net.minecraft.server.packs.*;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class FolderPack extends class_3288 implements FilePack {
    public static final class_2561 FOLDER_OPEN_TEXT = class_2561.method_43471("packed_packs.folder.open");
    public static final class_2561 FOLDER_DESCRIPTION = class_2561.method_43471("packed_packs.folder");
    public static final class_9225 FOLDER_SELECTION_CONFIG = new class_9225(false, class_3289.field_14280, false);
    public static final class_7679 FOLDER_METADATA = new class_7679(FOLDER_DESCRIPTION, class_3281.field_14224, class_7699.method_45397(), Collections.emptyList());
    private final CompletableFuture<FolderPackMeta> folderPackMetaFuture;
    private CompletableFuture<List<class_3288>> orderedContentsFuture;
    private final Path path;

    private FolderPack(
            class_9224 locationInfo,
            FolderResourcesSupplier resourcesSupplier,
            CompletableFuture<FolderPackMeta> folderPackMetaFuture,
            CompletableFuture<List<class_3288>> orderedContentsFuture
    ) {
        super(locationInfo, resourcesSupplier, FOLDER_METADATA, FOLDER_SELECTION_CONFIG);
        this.folderPackMetaFuture = folderPackMetaFuture;
        this.orderedContentsFuture = orderedContentsFuture;
        this.path = resourcesSupplier.path();
    }

    public FolderPack(FolderLocationInfo locationInfo, FolderPackMeta folderPackMeta, List<class_3288> contents) {
        this(locationInfo.packLocationInfo(), new FolderResourcesSupplier(locationInfo.path()),
                CompletableFuture.completedFuture(folderPackMeta), CompletableFuture.completedFuture(contents));
    }

    public static FolderPack createAndPreloadMetadata(FolderLocationInfo folderLocationInfo, List<class_3288> contents) {
        class_9224 locationInfo = folderLocationInfo.packLocationInfo();
        FolderResourcesSupplier resourcesSupplier = new FolderResourcesSupplier(folderLocationInfo.path());
        CompletableFuture<FolderPackMeta> folderPackMetaFuture = CompletableFuture.supplyAsync(() -> {
            try (class_3262 resources = resourcesSupplier.method_52425(locationInfo, FOLDER_METADATA)) {
                var configIoSupplier = resources.method_14410(FolderResources.FOLDER_CONFIG_FILENAME);
                if (configIoSupplier == null) {
                    throw new RuntimeException("FolderPack does not supply metadata");
                }
                try (InputStream inputStream = configIoSupplier.get()) {
                    return JsonLoader.loadOrDefault(inputStream, FolderPackMeta.class, FolderPackMeta::new);
                }
            } catch (IOException e) {
                if (!(e instanceof NoSuchFileException)) {
                    PackedPacks.LOGGER.error("[packed_packs] Failed to load folder pack metadata from '{}'", locationInfo.comp_2329(), e);
                }
                return new FolderPackMeta();
            }
        }, class_156.method_18349());
        CompletableFuture<List<class_3288>> orderedContentsFuture = folderPackMetaFuture.thenApply(metadata -> {
            Map<String, class_3288> contentById = new Object2ObjectOpenHashMap<>(contents.size(), 0.99f);
            for (class_3288 pack : contents) {
                contentById.put(pack.method_14463(), pack);
            }

            List<String> orderedIds = metadata.getPackIds();
            Set<class_3288> seen = new ObjectOpenHashSet<>();
            List<class_3288> ordered = new ObjectArrayList<>(contents.size());

            for (String id : orderedIds) {
                class_3288 pack = contentById.get(id);
                if (pack != null && seen.add(pack)) ordered.add(pack);
            }

            for (class_3288 pack : contents) {
                if (seen.add(pack)) ordered.add(pack);
            }

            return new ObjectImmutableList<>(ordered);
        });
        return new FolderPack(locationInfo, resourcesSupplier, folderPackMetaFuture, orderedContentsFuture);
    }

    public FolderPackMeta folderMetadata() {
        return this.folderPackMetaFuture.join();
    }

    public List<class_3288> contents() {
        return this.orderedContentsFuture.join();
    }

    public List<class_3288> flatten() {
        List<class_3288> contents = this.contents();
        List<class_3288> result = new ObjectArrayList<>(contents.size() + 1);
        result.add(this);
        result.addAll(contents);
        return result;
    }

    public void setContents(List<class_3288> contents) {
        FolderPackMeta metadata = this.folderMetadata();
        if (metadata.trySetPacks(contents)) {
            metadata.save(this.path.resolve(FolderResources.FOLDER_CONFIG_FILENAME));
            this.orderedContentsFuture = CompletableFuture.completedFuture(new ObjectImmutableList<>(contents));
        }
    }

    @Override
    public Path packed_packs$getPath() {
        return this.path;
    }
}
