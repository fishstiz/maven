package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionModelAccessor;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5375;

public record PackSelectionScreenArgs(
        class_3283 repository,
        Consumer<class_3283> output,
        Path packDir,
        class_2561 title
) {
    public static PackSelectionScreenArgs extract(class_5375 screen) {
        PackSelectionScreenAccessor packScreen = (PackSelectionScreenAccessor) screen;
        PackSelectionModelAccessor model = (PackSelectionModelAccessor) packScreen.packed_packs$model();
        return new PackSelectionScreenArgs(
                model.packed_packs$getRepository(),
                model.packed_packs$getOutput(),
                packScreen.packed_packs$getPackDir(),
                screen.method_25440()
        );
    }

    public static PackSelectionScreenArgs dummy(class_310 minecraft) {
        return new PackSelectionScreenArgs(
                new class_3283(),
                FunctionUtils.nopConsumer(),
                minecraft.method_1479(),
                class_5244.field_39003
        );
    }

    public class_3264 packType() {
        return this.repository == class_310.method_1551().method_1520()
                ? class_3264.field_14188
                : class_3264.field_14190;
    }

    public class_5375 createScreen() {
        return new class_5375(this.repository, this.output, this.packDir, this.title);
    }

    public class_5375 createScreen(@Nullable class_437 previous) {
        class_5375 packScreen = this.createScreen();
        ((PackSelectionScreenAccessor) packScreen).packed_packs$setPrevious(previous);
        return packScreen;
    }

    public class_5375 createDummy() {
        class_5375 packScreen = this.createScreen();
        ((PackSelectionScreenAccessor) packScreen).packed_packs$closeWatcher();
        return packScreen;
    }
}
