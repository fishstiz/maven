package io.github.fishstiz.packed_packs.gui.layouts;

import io.github.fishstiz.fidgetz.v0.gui.components.FZText;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

public class WrappedLayout implements FZLayout {
    private final FZLayout layout;

    protected WrappedLayout(FZLayout layout) {
        this.layout = layout;
    }

    static FZLayout error(class_2561 message) {
        FZFlexLayout layout = FZFlexLayout.vertical().maxWidth(250);
        layout.child(FZText.builder(class_2561.method_43470("Error!").method_27692(class_124.field_1067)).build());
        layout.child(FZText.builder(message).build());
        return layout;
    }

    @Override
    public void method_48227(Consumer<class_8021> consumer) {
        layout.method_48227(consumer);
    }

    @Override
    public void method_48206(Consumer<class_339> widgetVisitor) {
        layout.method_48206(widgetVisitor);
    }

    @Override
    public void method_48222() {
        layout.method_48222();
    }

    @Override
    public void method_46421(int i) {
        layout.method_46421(i);
    }

    @Override
    public void method_46419(int i) {
        layout.method_46419(i);
    }

    @Override
    public int method_46426() {
        return layout.method_46426();
    }

    @Override
    public int method_46427() {
        return layout.method_46427();
    }

    @Override
    public int method_25368() {
        return layout.method_25368();
    }

    @Override
    public int method_25364() {
        return layout.method_25364();
    }

    @Override
    public class_8030 method_48202() {
        return layout.method_48202();
    }

    @Override
    public void method_48229(int x, int y) {
        layout.method_48229(x, y);
    }

    @Override
    public void fidgetz$setWidth(int width) {
        layout.fidgetz$setWidth(width);
    }

    @Override
    public void fidgetz$setHeight(int height) {
        layout.fidgetz$setHeight(height);
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        layout.fidgetz$setSize(width, height);
    }

    @Override
    public boolean fidgetz$isVisible() {
        return layout.fidgetz$isVisible();
    }
}
