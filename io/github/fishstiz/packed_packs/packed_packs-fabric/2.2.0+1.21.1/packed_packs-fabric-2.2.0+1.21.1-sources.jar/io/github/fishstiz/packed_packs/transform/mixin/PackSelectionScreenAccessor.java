package io.github.fishstiz.packed_packs.transform.mixin;

import io.github.fishstiz.packed_packs.transform.interfaces.ChildScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_5369;
import net.minecraft.class_5375;

@Mixin(class_5375.class)
public interface PackSelectionScreenAccessor extends ChildScreen {
    @Accessor("model")
    class_5369 packed_packs$model();

    @Invoker("reload")
    void packed_packs$reload();

    @Invoker("closeWatcher")
    void packed_packs$closeWatcher();

    @Accessor("packDir")
    Path packed_packs$getPackDir();

    @Invoker("copyPacks")
    static void packed_packs$copyPacks(class_310 minecraft, List<Path> files, Path targetDir) {
        throw new AssertionError();
    }
}
