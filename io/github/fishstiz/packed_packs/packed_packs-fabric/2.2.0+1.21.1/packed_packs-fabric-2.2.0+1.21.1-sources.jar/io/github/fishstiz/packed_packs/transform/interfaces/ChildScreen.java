package io.github.fishstiz.packed_packs.transform.interfaces;

import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

public interface ChildScreen {
    void packed_packs$setPrevious(@Nullable class_437 previous);

    @Nullable class_437 packed_packs$getPrevious();
}
