package io.github.fishstiz.packed_packs.pack.folder;

import io.github.fishstiz.packed_packs.util.PackUtil;
import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_9224;

public record FolderLocationInfo(String id, String name, Path path) {
    public FolderLocationInfo {
        path = path.toAbsolutePath().normalize();
    }

    public static FolderLocationInfo fromPath(Path path) {
        Path normalized = path.toAbsolutePath().normalize();
        String name = PackUtil.generatePackName(normalized);
        String id = PackUtil.generatePackId(name);
        return new FolderLocationInfo(id, name, normalized);
    }

    public class_9224 packLocationInfo() {
        return new class_9224(this.id, class_2561.method_43470(this.name), PackUtil.PACK_SOURCE, Optional.empty());
    }
}
