package io.github.fishstiz.packed_packs.util;

import io.github.fishstiz.fidgetz.v0.gui.components.FZPopoverMenuItem;
import io.github.fishstiz.fidgetz.v0.gui.components.WidgetElements;
import io.github.fishstiz.fidgetz.v0.gui.components.WidgetRenderables;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class GuiUtils {
    public static final int SPACING = 8;
    public static final RenderableRectangle WHITE_OVERLAY = Renderables.fill(Colors.alpha(Colors.WHITE, 0.25f));
    public static final RenderableRectangle BLACK_OVERLAY = Renderables.fill(Colors.alpha(Colors.BLACK, 0.25f));
    public static final WidgetRenderables DEV_MODE_ENTRY_BACKGROUND = new WidgetRenderables(
            BLACK_OVERLAY,
            BLACK_OVERLAY,
            BLACK_OVERLAY.then(Renderables.fill(Colors.alpha(Colors.WHITE, 0.1f)))
    );
    public static final RenderableRectangle HAMBURGER_RECT = Renderables.sprite(PackedPacks.id("icon/hamburger"));
    public static final class_2960 CROSS_SPRITE = PackedPacks.id("icon/cross");
    public static final class_2960 LOCK_SPRITE = class_2960.method_60656("widget/locked_button");
    public static final class_2960 LOCK_SPRITE_DISABLED = class_2960.method_60656("widget/locked_button_disabled");
    public static final class_2960 UNLOCK_SPRITE_SMALL = PackedPacks.id("icon/unlock");
    public static final class_2960 LOCK_SPRITE_SMALL = PackedPacks.id("icon/lock");
    public static final class_2960 STAR_SPRITE = PackedPacks.id("icon/star");
    public static final class_2960 TRASH_SPRITE = PackedPacks.id("icon/trash");
    public static final class_2960 RADIO_OFF_SPRITE = PackedPacks.id("icon/radio_off");
    public static final class_2960 RADIO_ON_SPRITE = PackedPacks.id("icon/radio_on");
    public static final class_2561 OPTIONS_TEXT = class_2561.method_43471("packed_packs.options.title");
    public static final class_2561 OPEN_FILE_TEXT = class_2561.method_43471("packed_packs.file.open");
    public static final class_2561 OPEN_PARENT_TEXT = class_2561.method_43471("packed_packs.file.parent.open");
    public static final class_2561 RENAME_FILE_TEXT = class_2561.method_43471("packed_packs.file.rename");
    public static final class_2561 DELETE_FILE_TEXT = class_2561.method_43471("packed_packs.file.delete");

    public static FZFlexLayout vertical() {
        return FZFlexLayout.vertical().spacing(SPACING);
    }

    public static FZFlexLayout horizontal() {
        return FZFlexLayout.horizontal().spacing(SPACING);
    }

    public static class_2960 toggleIcon(boolean toggled) {
        return toggled ? RADIO_ON_SPRITE : RADIO_OFF_SPRITE;
    }

    public static FZPopoverMenuItem.Builder buildDevEntry(FZPopoverMenuItem.Builder builder) {
        return builder.background(DEV_MODE_ENTRY_BACKGROUND);
    }

    public static RenderableRectangle createRect(Supplier<class_2960> spriteGetter) {
        return new Icon(spriteGetter);
    }

    public static WidgetElements padded16Rect(RenderableRectangle rect) {
        return new WidgetElements(rect, 16, 16).marginLeft(-4);
    }

    public static WidgetElements padded16Sprite(class_2960 sprite) {
        return padded16Rect(Renderables.sprite(sprite));
    }

    public static WidgetElements toggleRect(BooleanSupplier toggled) {
        return new WidgetElements(createRect(() -> toggleIcon(toggled.getAsBoolean())), 8, 8);
    }

    private record Icon(Supplier<class_2960> spriteGetter) implements RenderableRectangle {
        @Override
        public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
            GuiGraphicsUtils.sprite(graphics, spriteGetter.get(), left, top, width, height);
        }
    }

    private GuiUtils() {
    }
}
