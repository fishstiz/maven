package io.github.fishstiz.packed_packs.gui.components.pack;

import io.github.fishstiz.fidgetz.gui.components.*;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.util.DrawUtil;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import io.github.fishstiz.packed_packs.gui.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.model.PackedPacksViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.pack.PackAssetManager;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.apache.commons.io.FilenameUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.regex.Pattern;
import net.minecraft.class_11908;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8667;

import static io.github.fishstiz.packed_packs.util.PackUtil.ZIP_PACK_EXTENSION;
import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.CROSS_SPRITE;
import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.SPACING;

public class FileRenameModal extends Modal<class_8667> {
    private static final int MAX_LENGTH = 255;
    private static final int CONTENT_WIDTH = 256;
    private static final int SHADOW_SIZE = 24;
    private static final Pattern ILLEGAL_CHAR_PATTERN = Pattern.compile(".*[<>:\"/\\\\|?*].*");
    private final RenderableRectWidget<Void> sprite;
    private final FidgetzText<Void> title;
    private final ToggleableEditBox<Void> nameEditor;
    private final FidgetzButton<Void> saveButton;
    private final PackedPacksViewModel viewModel;
    private String oldName;

    public <S extends class_437 & ToggleableDialogContainer> FileRenameModal(S screen, PackedPacksViewModel viewModel) {
        super(Modal.builder(screen, class_8667.method_52741().method_52735(SPACING)).padding(SPACING).setFocusOnOpen(true));
        this.viewModel = viewModel;

        this.sprite = this.addRenderableOnly(RenderableRectWidget.<Void>builder(PackAssetManager.DEFAULT_ICON)
                .makeSquare()
                .build());
        this.title = this.addRenderableOnly(FidgetzText.<Void>builder()
                .makeSquare()
                .setOffsetY(1)
                .setShadow(true)
                .build());
        FidgetzButton<Void> closeButton = this.addRenderableWidget(FidgetzButton.<Void>builder()
                .makeSquare()
                .setOnPress(this::closeModal)
                .setSprite(CROSS_SPRITE)
                .build());
        this.nameEditor = this.addRenderableWidget(ToggleableEditBox.<Void>builder()
                .setWidth(CONTENT_WIDTH)
                .setEditable(true)
                .addListener(this::handleChange)
                .setMaxLength(MAX_LENGTH)
                .setFilter(this::testInput)
                .build());
        FidgetzButton<Void> cancelButton = this.addRenderableWidget(FidgetzButton.<Void>builder()
                .setOnPress(this::closeModal)
                .setMessage(class_5244.field_24335)
                .build());
        this.saveButton = this.addRenderableWidget(FidgetzButton.<Void>builder()
                .setOnPress(this::saveName)
                .setMessage(class_5244.field_24334)
                .build());

        FlexLayout titleLayout = FlexLayout.horizontal(this::getContentWidth).spacing(SPACING);
        titleLayout.addChild(this.sprite);
        titleLayout.addFlexChild(this.title);
        titleLayout.addChild(closeButton);

        FlexLayout buttonLayout = FlexLayout.horizontal(this::getContentWidth).spacing(SPACING);
        buttonLayout.addFlexChild(cancelButton);
        buttonLayout.addFlexChild(this.saveButton);

        this.root().layout().method_52736(titleLayout);
        this.root().layout().method_52736(this.nameEditor);
        this.root().layout().method_52736(buttonLayout);

        this.viewModel.subscribe(PackedPacksState::renamingPack, this::refresh);
    }

    private int getContentWidth() {
        return CONTENT_WIDTH;
    }

    private void clearReferences() {
        this.oldName = null;
        this.sprite.setRenderableRect(PackAssetManager.DEFAULT_ICON);
        this.title.method_25355(class_5244.field_39003);
        this.nameEditor.method_1852("");
    }

    @Override
    public void setOpen(boolean open) {
        var renameContext = this.viewModel.state().renamingPack();
        if (!open && renameContext != null) {
            this.viewModel.dispatch(new PackListIntent.CloseRename(renameContext.target(), renameContext.ctx()));
        }
    }

    private void refresh(ActiveAction.@Nullable RenamingPack renameContext) {
        if (renameContext == null) {
            super.setOpen(false);
            this.method_25395(null);
            this.clearReferences();
            return;
        }

        this.method_25395(this.nameEditor);
        this.sprite.setRenderableRect(renameContext.ctx().sprite());
        this.title.method_25355(renameContext.ctx().pack().method_14457());

        this.oldName = sanitizeNameForEdit(renameContext.ctx().pack());
        this.nameEditor.method_1852(this.oldName);
        this.nameEditor.method_1887(PackUtil.isZipPack(renameContext.ctx().pack()) ? ZIP_PACK_EXTENSION : null);
        this.saveButton.field_22763 = false;

        this.repositionElements();
        super.setOpen(true);
    }

    private boolean testInput(String input) {
        if (input == null || (!input.isEmpty() && input.isBlank())) {
            return false;
        }
        return testIllegalChars(input);
    }

    private boolean canSave(String input) {
        if (input == null || input.isBlank()) {
            return false;
        }
        var renameContext = this.viewModel.state().renamingPack();
        if (renameContext == null || PackUtil.validatePackPath(renameContext.ctx().pack()) == null) {
            return false;
        }
        String trimmed = input.trim();
        if (Objects.equals(this.oldName, trimmed)) {
            return false;
        }
        return testIllegalChars(input);
    }

    private void handleChange(String name) {
        this.saveButton.field_22763 = this.canSave(name);
    }

    private boolean saveName() {
        String newName = this.nameEditor.method_1882();
        if (!this.canSave(newName)) return false;

        var renameContext = this.viewModel.state().renamingPack();
        if (renameContext != null) {
            String sanitizedName = sanitizeNameForSave(renameContext.ctx().pack(), newName);
            this.viewModel.dispatch(new PackListIntent.Rename(renameContext.target(), renameContext.ctx(), sanitizedName));
            return true;
        }

        return false;
    }

    private static String sanitizeNameForEdit(class_3288 pack) {
        String name = pack.method_14457().getString();
        return PackUtil.isZipPack(pack) ? name.replaceFirst(Pattern.quote(ZIP_PACK_EXTENSION) + "$", "") : name;
    }

    private static String sanitizeNameForSave(class_3288 pack, String newName) {
        newName = FilenameUtils.getName(newName).trim();
        return PackUtil.isZipPack(pack) ? newName + ZIP_PACK_EXTENSION : newName;
    }

    private static boolean testIllegalChars(@NotNull String input) {
        input = input.trim();
        if (!input.equals(FilenameUtils.getName(input))) {
            return false;
        }
        return !ILLEGAL_CHAR_PATTERN.matcher(input).matches();
    }

    @Override
    protected void renderBackground(class_332 guiGraphics, int x, int y, int width, int height, int mouseX, int mouseY, float partialTick) {
        DrawUtil.renderDropShadow(guiGraphics, x, y, width, height, SHADOW_SIZE);
        super.renderBackground(guiGraphics, x, y, width, height, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25404(@NotNull class_11908 keyEvent) {
        boolean keyPressed = super.method_25404(keyEvent);
        if (!keyPressed && keyEvent.comp_4795() == class_3675.field_31957 && this.saveName()) {
            GuiUtil.playClickSound();
            return this.viewModel.state().renamingPack() != null;
        }
        return keyPressed;
    }

    @Override
    public @Nullable class_8016 method_48205(@NotNull class_8023 event) {
        if (this.viewModel.state().renamingPack() == null) {
            return null;
        }
        if (event instanceof class_8023.class_8025) {
            return class_8016.method_48194(this.nameEditor, this);
        }
        return super.method_48205(event);
    }
}
