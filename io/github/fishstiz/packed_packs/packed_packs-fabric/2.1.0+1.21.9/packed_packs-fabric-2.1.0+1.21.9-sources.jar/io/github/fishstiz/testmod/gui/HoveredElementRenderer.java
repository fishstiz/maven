package io.github.fishstiz.testmod.gui;

import io.github.fishstiz.fidgetz.util.DrawUtil;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import io.github.fishstiz.testmod.TestFeature;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;


public class HoveredElementRenderer extends TestFeatureRenderer {
    private static final int COLOR = 0xFF00FF00;
    private final class_310 minecraft;

    public HoveredElementRenderer(TestFeature feature) {
        super(feature);
        this.minecraft = class_310.method_1551();
    }

    @Override
    protected int renderFeature(class_332 guiGraphics, int mouseX, int mouseY, int y, float partialTick) {
        class_437 screen = minecraft.field_1755;
        if (screen == null) return y;

        class_364 hovered = GuiUtil.findHovered(screen, mouseX, mouseY);
        hovered = hovered != null ? hovered : screen;

        class_8030 bounds = getBounds(hovered);
        String label = hovered.getClass().getName();
        int labelX = clampX(minecraft.method_22683(), minecraft.field_1772, bounds.method_49620() + 2, label);
        int labelY = bounds.method_49618() + 2;

        DrawUtil.renderOutline(guiGraphics, bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197(), COLOR);
        guiGraphics.method_25303(minecraft.field_1772, label, labelX, labelY, COLOR);

        return y;
    }

    private static int clampX(class_1041 window, class_327 font, int x, String label) {
        int textWidth = font.method_1727(label);
        int screenWidth = window.method_4486();
        if (x + textWidth > screenWidth) {
            x = screenWidth - textWidth - 2;
        }
        return Math.max(0, x);
    }

    private static class_8030 getBounds(@Nullable class_364 element) {
        if (element instanceof class_8021 layoutElement) return layoutElement.method_48202();
        return element != null ? element.method_48202() : class_8030.method_48248();
    }
}
