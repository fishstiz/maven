package io.github.fishstiz.packed_packs.gui.components.pack;

import io.github.fishstiz.fidgetz.gui.components.*;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuItemBuilder;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.util.DrawUtil;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import io.github.fishstiz.fidgetz.util.lang.ObjectsUtil;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.components.contextmenu.PackMenuHeader;
import io.github.fishstiz.packed_packs.gui.model.PackListUtils;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.transform.interfaces.FilePack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8027;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.*;

public class PackListContainer extends class_339 implements FocusPathProvider, class_8133, ContextMenuContainer, ContainerEventHandlerPatch {
    private final @Nullable PackListContainer root;
    private final ScreenContext screenContext;
    private final PackListViewModel viewModel;
    private final PackList packList;
    private PackListContainer.@Nullable Folder folder;
    private @Nullable class_364 focused;
    private boolean dragging;
    private List<class_364> children;

    private PackListContainer(@Nullable PackListContainer root, ScreenContext screenContext, PackListViewModel viewModel) {
        super(0, 0, 0, 0, class_5244.field_39003);
        this.root = root;
        this.screenContext = screenContext;
        this.viewModel = viewModel;
        this.packList = new PackList(screenContext, viewModel);
        this.viewModel.subscribe(PackListViewModel.Property.FOLDER, this::refresh);
        this.children = List.of(this.packList);
        this.refresh();
    }

    private PackListContainer(PackListContainer root, PackListViewModel.Module viewModel) {
        this(root, root.screenContext, viewModel);
    }

    public PackListContainer(ScreenContext screenContext, PackListViewModel viewModel) {
        this(null, screenContext, viewModel);
    }

    private void updateState(class_364 target) {
        this.children = List.of(target);
        this.method_25395(target);
    }

    private void refresh() {
        boolean isOpened = this.viewModel.isFolderOpened();
        if (isOpened == (this.folder != null)) {
            return;
        }

        if (isOpened) {
            Folder newFolder = new Folder(this.root == null ? this : this.root, this.viewModel.createFolderSlice());
            this.folder = newFolder;
            this.updateState(newFolder);
            ObjectsUtil.ifPresent(newFolder.method_48205(new class_8023.class_8025()), path -> path.method_48195(true));
        } else {
            this.folder = null;
            this.updateState(this.packList);
        }
    }

    public boolean renderDroppableZone(ActiveAction.Dragging dragging, class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.folder != null) {
            return this.folder.listContainer.renderDroppableZone(dragging, guiGraphics, mouseX, mouseY, partialTick);
        }
        this.packList.renderDroppableZone(guiGraphics, dragging, mouseX, mouseY, partialTick);
        if (this.packList.method_25405(mouseX, mouseY)) {
            return dragging.target() == this.packList.key() || PackListUtils.canInteract(dragging.target(), this.packList.key());
        }
        return false;
    }

    @Override
    protected void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.packList.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        if (this.folder != null) {
            this.folder.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_47399(@NotNull class_6382 narrationElementOutput) {
        if (this.folder != null) {
            this.folder.listContainer.method_37020(narrationElementOutput.method_37031());
        } else {
            this.packList.method_37020(narrationElementOutput.method_37031());
        }
    }

    public void visitPackLists(Consumer<PackList> visitor) {
        visitor.accept(this.packList);
        if (this.viewModel.isFolderOpened() && this.folder != null) {
            this.folder.listContainer.visitPackLists(visitor);
        }
    }

    public void visitDeepestList(Consumer<PackList> visitor) {
        if (this.viewModel.isFolderOpened() && this.folder != null) {
            this.folder.listContainer.visitDeepestList(visitor);
        } else {
            visitor.accept(this.packList);
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        this.visitDeepestList(list -> list.onDrop(dragging, mouseX, mouseY));
    }

    @Override
    public @NotNull List<class_364> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean isDragging) {
        this.dragging = isDragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            this.method_25395(null);
        } else {
            this.method_25395(this.folder == null ? this.packList : this.folder);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }
            if (focused != null) {
                focused.method_25365(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        FocusPathProvider child = this.folder != null ? this.folder : this.packList;
        return class_8016.method_48192(this, child.getFocusPath(target));
    }

    @Override
    public @Nullable class_8016 method_48205(@NotNull class_8023 event) {
        class_364 child = this.folder != null ? this.folder : this.packList;
        return class_8016.method_48192(this, child.method_48205(event));
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        this.packList.method_53533(height);
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        this.packList.method_25358(width);
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        this.packList.method_46421(x);
        this.repositionFolder();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        this.packList.method_46419(y);
        this.repositionFolder();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        this.method_25358(width);
        this.method_53533(height);
    }

    @Override
    public void method_48229(int x, int y) {
        super.method_48229(x, y);
        this.method_46421(x);
        this.method_46419(y);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        if (this.root != null && this.viewModel.isFolderOpened() && this.folder != null) {
            return this.root.method_25405(mouseX, mouseY);
        }
        return super.method_25405(mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public void method_48227(Consumer<class_8021> visitor) {
        visitor.accept(this);
    }

    @Override
    public void method_48222() {
        if (this.folder != null) this.folder.arrangeElements();
    }

    private void repositionFolder() {
        if (this.folder != null) this.folder.repositionElements();
    }

    int getMaxFolderWidth() {
        return this.method_25368() - SPACING * 2;
    }

    int getMaxFolderHeight() {
        return this.method_25364() - SPACING * 2;
    }

    static class Folder extends class_362 implements FocusPathProvider, ContextMenuContainer, ContainerEventHandlerPatch, class_4068 {
        private static final int HEADER_SIZE = 16;
        private static final int LAYOUT_SPACING = SPACING / 2;
        private final PackListContainer root;
        private final RenderableRectWidget<Void> background;
        private final LayoutWrapper<FlexLayout> layout;
        private final FidgetzButton<Void> closeButton;
        private final RenderableRectWidget<Void> folderIcon;
        private final FidgetzText<Void> folderTitle;
        private final PackListViewModel.Module viewModel;
        private final PackListContainer listContainer;
        private final Runnable unsubscribe;
        private List<class_364> children = Collections.emptyList();
        private List<class_4068> renderables = Collections.emptyList();

        Folder(PackListContainer root, PackListViewModel.Module viewModel) {
            this.root = root;
            this.viewModel = viewModel;

            this.background = RenderableRectWidget.<Void>builder(DrawUtil.DEMO_BACKGROUND).build();
            this.folderIcon = RenderableRectWidget.<Void>builder(this.viewModel.sprite())
                    .makeSquare(HEADER_SIZE)
                    .build();
            this.folderTitle = FidgetzText.<Void>builder()
                    .setHeight(HEADER_SIZE)
                    .setOffsetY(1)
                    .build();
            this.closeButton = FidgetzButton.<Void>builder()
                    .makeSquare(HEADER_SIZE)
                    .setSprite(CROSS_SPRITE)
                    .setOnPress(this.viewModel::close)
                    .build();
            this.listContainer = new PackListContainer(root, viewModel);

            FlexLayout header = FlexLayout.horizontal(this.root::getMaxFolderWidth).spacing(LAYOUT_SPACING);
            header.addChild(this.closeButton);
            header.addChild(this.folderIcon);
            header.addFlexChild(this.folderTitle);

            FlexLayout contents = FlexLayout.horizontal(this.root::getMaxFolderWidth);
            contents.addFlexChild(this.listContainer, true);

            FlexLayout body = FlexLayout.vertical(this.root::getMaxFolderHeight).spacing(LAYOUT_SPACING);
            body.addChild(header);
            body.addFlexChild(contents);

            this.layout = new LayoutWrapper<>(body);
            this.layout.setPadding(SPACING);

            this.refresh();
            this.arrangeElements();
            this.refreshChild();

            Runnable unsubscribeCurrentFolder = this.viewModel.subscribeToCurrentFolder(this::refresh);
            Runnable unsubscribeChildFolder = this.viewModel.subscribe(PackListViewModel.Property.FOLDER, this::refreshChild);

            this.unsubscribe = () -> {
                unsubscribeCurrentFolder.run();
                unsubscribeChildFolder.run();
            };
        }

        private void refresh() {
            FolderPack folderPack = this.viewModel.currentFolder();

            if (folderPack == null) {
                this.unsubscribe.run();
                this.children = Collections.emptyList();
                this.renderables = Collections.emptyList();
                return;
            }

            this.folderTitle.method_25355(folderPack.method_14457());
            this.folderIcon.setRenderableRect(this.viewModel.sprite());
        }

        private void refreshChild() {
            if (!this.viewModel.isFolderOpened()) {
                this.renderables = List.of(this.background, this.folderIcon, this.folderTitle, this.closeButton, this.listContainer);
                this.children = List.of(this.closeButton, this.listContainer);
            } else {
                this.renderables = List.of(this.listContainer);
                this.children = List.of(this.listContainer);
            }
        }

        @Override
        public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
            for (class_4068 renderable : this.renderables) {
                renderable.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public void buildItems(ContextMenuItemBuilder builder, int mouseX, int mouseY) {
            ContextMenuContainer.super.buildItems(builder.whenNonNull(this.viewModel.currentFolder())
                            .ifTrue((pack, menuBuilder) -> menuBuilder
                                    .add(new PackMenuHeader(pack, this.viewModel.sprite()))
                                    .simpleItem(class_5244.field_24339.method_27661().method_10852(class_5244.field_39678), this.viewModel::close)
                                    .when(this.method_19355(mouseX, mouseY).isEmpty())
                                    .ifTrue(b -> b
                                            .whenNonNull(ObjectsUtil.mapOrNull(pack, FilePack::packed_packs$getPath))
                                            .ifTrue((path, operationsMenuBuilder) -> operationsMenuBuilder
                                                    .separator()
                                                    .simpleItem(RENAME_FILE_TEXT, this.viewModel::fileModifiable, this.viewModel::openRename)
                                                    .simpleItem(DELETE_FILE_TEXT, this.viewModel::fileModifiable, this.viewModel::delete)
                                                    .simpleItem(OPEN_FILE_TEXT, () -> PackUtil.openPack(pack))
                                                    .simpleItem(OPEN_PARENT_TEXT, () -> PackUtil.openParent(pack))
                                            )
                                    )
                            ),
                    mouseX,
                    mouseY
            );
        }

        void repositionElements() {
            this.layout.method_48229(this.root.method_46426(), this.root.method_46427());
            this.background.method_48229(this.root.method_46426(), this.root.method_46427());
        }

        void arrangeElements() {
            if (this.layout.method_25368() != this.root.method_25368() || this.layout.method_25364() != this.root.method_25364()) {
                this.layout.method_48222();
                this.background.method_55445(this.root.method_25368(), this.root.method_25364());
                this.repositionElements();
            }
        }

        @Override
        public @Nullable class_8016 getFocusPath(FocusTarget target) {
            return class_8016.method_48192(this, this.listContainer.getFocusPath(target));
        }

        @Override
        public @Nullable class_8016 method_48205(@NotNull class_8023 event) {
            if (this.viewModel.isFolderOpened()) {
                return class_8016.method_48192(this, this.listContainer.method_48205(event));
            }

            if (event instanceof class_8023.class_8025) {
                class_8016 path = this.listContainer.method_48205(event);
                return path == null ? class_8016.method_48194(this.closeButton, this) : class_8016.method_48192(this, path);
            }

            if (!this.method_25370() &&
                event instanceof class_8023.class_8024(ScreenDirection direction) &&
                direction.method_48237() == class_8027.field_41822) {
                class_8016 path = this.listContainer.method_48205(event);
                if (path != null) {
                    return class_8016.method_48192(this, path);
                }
            }

            return super.method_48205(event);
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (this.method_25399() != focused) {
                super.method_25395(focused);
            }
        }

        @Override
        public void method_25365(boolean isFocused) {
            if (!isFocused) {
                this.method_25395(null);
            }
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) && this.viewModel.isOpened();
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return GuiUtil.containsPoint(this.layout, mouseX, mouseY);
        }

        @Override
        public @NotNull List<class_364> method_25396() {
            return this.children;
        }

        @Override
        public @NotNull class_8030 method_48202() {
            return this.layout.method_48202();
        }
    }
}
