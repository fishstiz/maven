package io.github.fishstiz.packed_packs.gui.components.contextmenu;

import io.github.fishstiz.fidgetz.gui.components.contextmenu.MenuItem;
import io.github.fishstiz.fidgetz.gui.renderables.ColoredRect;
import io.github.fishstiz.fidgetz.gui.renderables.RenderableRect;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import net.minecraft.class_2561;
import net.minecraft.class_3288;

public record PackMenuHeader(class_3288 pack, Sprite icon) implements MenuItem {
    private static final RenderableRect BACKGROUND = new ColoredRect(Theme.GRAY_500.getARGB());

    @Override
    public RenderableRect background() {
        return BACKGROUND;
    }

    @Override
    public class_2561 text() {
        return this.pack.method_14457();
    }

    @Override
    public boolean shouldAutoSeparate() {
        return false;
    }

    @Override
    public boolean active() {
        return false;
    }

    @Override
    public void run() {
    }

    @Override
    public int textColor() {
        return Theme.WHITE.getARGB();
    }
}
