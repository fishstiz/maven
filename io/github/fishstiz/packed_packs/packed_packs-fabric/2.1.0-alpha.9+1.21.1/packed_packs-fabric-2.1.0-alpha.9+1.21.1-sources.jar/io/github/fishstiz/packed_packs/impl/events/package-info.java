@ApiStatus.Internal
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.packed_packs.impl.events;

import org.jetbrains.annotations.ApiStatus;