package io.github.fishstiz.packed_packs.pack;

import java.util.List;
import net.minecraft.class_3288;

public record PackGroup(List<class_3288> selected, List<class_3288> unselected) {
}