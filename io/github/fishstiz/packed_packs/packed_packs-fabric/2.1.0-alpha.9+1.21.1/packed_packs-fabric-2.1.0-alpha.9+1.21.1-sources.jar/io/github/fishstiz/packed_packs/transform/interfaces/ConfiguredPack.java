package io.github.fishstiz.packed_packs.transform.interfaces;

import io.github.fishstiz.packed_packs.pack.PackOptionsResolver;
import net.minecraft.class_3288;
import net.minecraft.class_9225;

public interface ConfiguredPack {
    default void packed_packs$setConfigurationResolver(PackOptionsResolver resolver) {
    }

    default boolean packed_packs$isHidden() {
        return false;
    }

    default boolean packed_packs$isConfigured() {
        return false;
    }

    class_9225 packed_packs$originalConfig();

    class_3288.class_7679 packed_packs$getMetadata();
}
