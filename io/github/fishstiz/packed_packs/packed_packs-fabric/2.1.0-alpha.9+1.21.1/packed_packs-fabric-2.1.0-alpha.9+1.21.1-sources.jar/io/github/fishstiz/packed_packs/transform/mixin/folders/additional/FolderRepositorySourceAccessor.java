package io.github.fishstiz.packed_packs.transform.mixin.folders.additional;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.nio.file.Path;
import net.minecraft.class_3279;

@Mixin(class_3279.class)
public interface FolderRepositorySourceAccessor {
    @Accessor("folder")
    Path packed_packs$getFolder();
}
