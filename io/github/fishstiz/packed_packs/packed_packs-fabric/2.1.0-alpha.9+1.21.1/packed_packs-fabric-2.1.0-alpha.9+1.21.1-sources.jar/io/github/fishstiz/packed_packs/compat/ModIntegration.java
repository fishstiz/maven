package io.github.fishstiz.packed_packs.compat;

import io.github.fishstiz.fidgetz.util.lang.FunctionsUtil;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import io.github.fishstiz.packed_packs.api.PreferenceRegistry;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Constructor;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;

public abstract class ModIntegration implements PackedPacksInitializer {
    protected abstract ModContext mod();

    protected abstract void onInitLoaded(PackedPacksApi api);

    protected @NotNull class_2960 id() {
        return id(this.mod());
    }

    @Override
    public final void onInitialize(@NotNull PackedPacksApi api) {
        if (this.mod().isLoaded()) {
            this.onInitLoaded(api);
        }
    }

    public static class_2960 id(ModContext mod) {
        return ResourceUtil.id(mod.getId());
    }

    public static class_2561 getWidgetPrefText(PreferenceRegistry.Key<?> key) {
        return ResourceUtil.getText("preferences.widgets." + key.id().method_12832());
    }

    public static Runnable createScreenSetter(String className, ScreenArg<?>... screenArgs) {
        try {
            Object[] args = new Object[screenArgs.length];
            Class<?>[] argTypes = new Class[screenArgs.length];
            for (int i = 0; i < screenArgs.length; i++) {
                args[i] = screenArgs[i].arg();
                argTypes[i] = screenArgs[i].type();
            }

            Constructor<? extends class_437> screenCtor = Class.forName(className)
                    .asSubclass(class_437.class)
                    .getConstructor(argTypes);

            return () -> {
                try {
                    class_310.method_1551().method_1507(screenCtor.newInstance(args));
                } catch (ReflectiveOperationException e) {
                    PackedPacks.LOGGER.error("[packed_packs] Error opening mod screen: '{}'", className, e);
                }
            };
        } catch (ReflectiveOperationException e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to create screen setter for mod screen: '{}'", className, e);
            return FunctionsUtil.nop();
        }
    }

    public record ScreenArg<T>(Class<T> type, T arg) {
        public static ScreenArg<class_437> parent(class_437 parent) {
            return new ScreenArg<>(class_437.class, parent);
        }
    }
}
