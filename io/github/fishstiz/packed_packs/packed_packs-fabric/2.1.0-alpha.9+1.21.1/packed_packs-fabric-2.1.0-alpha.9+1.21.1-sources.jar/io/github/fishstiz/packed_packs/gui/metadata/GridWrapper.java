package io.github.fishstiz.packed_packs.gui.metadata;

import net.minecraft.class_8133;

public record GridWrapper<T extends class_8133>(T layout, int spacing) {
}
