package io.github.fishstiz.packed_packs.gui.model;

import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.packed_packs.config.PackConfigs;
import io.github.fishstiz.packed_packs.pack.PackOptionsContext;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_3288;

public record PackListContext(
        PackConfigs configs,
        PackOptionsContext options,
        BiConsumer<FolderPack, List<class_3288>> folderSaver,
        Predicate<class_3288> fileModifiable,
        Function<class_3288, Sprite> iconFactory
) {
}
