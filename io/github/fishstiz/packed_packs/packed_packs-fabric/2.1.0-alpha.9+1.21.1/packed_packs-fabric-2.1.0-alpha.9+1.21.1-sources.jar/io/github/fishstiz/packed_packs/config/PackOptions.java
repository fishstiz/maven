package io.github.fishstiz.packed_packs.config;

import net.minecraft.class_3288;
import net.minecraft.class_9225;

public interface PackOptions {
    boolean isHidden(class_3288 pack);

    boolean isRequired(class_3288 pack);

    boolean isFixed(class_3288 pack);

    class_3288.class_3289 getPosition(class_3288 pack);

    class_9225 getSelectionConfig(class_3288 pack);
}
