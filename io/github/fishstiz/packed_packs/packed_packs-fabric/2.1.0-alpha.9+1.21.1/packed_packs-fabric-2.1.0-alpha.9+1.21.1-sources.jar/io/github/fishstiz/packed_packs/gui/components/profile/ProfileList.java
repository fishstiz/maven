package io.github.fishstiz.packed_packs.gui.components.profile;

import io.github.fishstiz.fidgetz.gui.components.AbstractFixedListWidget;
import io.github.fishstiz.fidgetz.gui.components.FidgetzButton;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuItemBuilder;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuProvider;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.ButtonSprites;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.fidgetz.util.ARGBColor;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import io.github.fishstiz.fidgetz.util.debounce.PollingDebouncer;
import io.github.fishstiz.fidgetz.util.debounce.SimplePollingDebouncer;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.model.ProfilesViewModel;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import io.github.fishstiz.packed_packs.util.constants.GuiConstants;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_6379;
import net.minecraft.class_7919;

import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.*;

class ProfileList extends AbstractFixedListWidget<ProfileList.Entry> implements ContextMenuContainer {
    private static final int ITEM_HEIGHT = 20;
    private static final class_2561 EMPTY_TEXT = ResourceUtil.getText("profile.empty");
    private static final class_2561 DELETE_TEXT = ResourceUtil.getText("profile.delete");
    private static final class_7919 DELETE_INFO = class_7919.method_47407(ResourceUtil.getText("profile.delete.info"));
    private static final Sprite TRASH_SPRITE = Sprite.of16(ResourceUtil.getIcon("trash"));
    private static final Sprite STAR_OUTLINE_SPRITE = Sprite.of16(ResourceUtil.getIcon("star_outline"));
    private final ButtonSprites cachedStarSprites = ButtonSprites.of(STAR_SPRITE);
    private final ButtonSprites cachedLockedSprites = ButtonSprites.unclamp(LOCK_SPRITE);
    private final ButtonSprites cachedTrashSprites = ButtonSprites.of(TRASH_SPRITE);
    private final PollingDebouncer<Void> debouncedRefresh = new SimplePollingDebouncer<>(this::refresh, 200);
    private final ProfilesViewModel viewModel;

    ProfileList(ProfilesViewModel viewModel) {
        super(ITEM_HEIGHT, DEFAULT_SCROLLBAR_OFFSET, 0, 0);
        this.viewModel = viewModel;
        this.refresh();
        this.viewModel.subscribe(ProfilesViewModel.Property.PROFILES, this::refresh);
    }

    void scheduleRefresh() {
        this.debouncedRefresh.run();
    }

    @Override
    public void method_25339() {
        this.method_25396().forEach(e -> e.unsubscribe.run());
        super.method_25339();
    }

    private void refresh() {
        this.method_25339();
        this.viewModel.forEachEntry((entry, i) -> this.method_25321(new io.github.fishstiz.packed_packs.gui.components.profile.ProfileList.Entry(entry, i)));
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.debouncedRefresh.poll();

        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        if (this.method_25396().isEmpty()) {
            method_52718(
                    guiGraphics,
                    this.field_22740.field_1772,
                    EMPTY_TEXT,
                    this.method_46426() + SPACING,
                    this.method_46427() + SPACING,
                    this.method_55442() - SPACING,
                    this.method_55443() - SPACING,
                    Theme.WHITE.getARGB()
            );
        }
    }

    public class Entry extends AbstractFixedListWidget<io.github.fishstiz.packed_packs.gui.components.profile.ProfileList.Entry>.Entry implements ContextMenuProvider {
        private final List<FidgetzButton<Void>> children;
        private final FidgetzButton<Void> selectButton;
        private final FidgetzButton<Void> deleteButton;
        private final ProfilesViewModel.Entry viewModel;
        private final Runnable unsubscribe;

        protected Entry(ProfilesViewModel.Entry viewModel, int index) {
            super(index);
            this.viewModel = viewModel;
            this.deleteButton = FidgetzButton.<Void>builder()
                    .makeSquare(this.method_25364())
                    .setMessage(DELETE_TEXT)
                    .setSprite(this.getButtonSprites())
                    .setOnPress(this.viewModel::delete)
                    .build();
            this.deleteButton.field_22763 = !viewModel.isLocked() && !viewModel.isDefault();
            if (this.deleteButton.field_22763) this.deleteButton.method_47400(DELETE_INFO);

            this.selectButton = FidgetzButton.<Void>builder()
                    .setMessage(this.viewModel.name())
                    .setOnPress(this.viewModel::select)
                    .build();
            this.selectButton.field_22763 = !this.viewModel.isSelected();

            this.refresh();
            this.children = List.of(this.selectButton, this.deleteButton);
            this.unsubscribe = ProfileList.this.viewModel.subscribe(ProfilesViewModel.Property.ALL, this::refresh);
        }

        private ButtonSprites getButtonSprites() {
            return this.viewModel.isDefault()
                    ? ProfileList.this.cachedStarSprites : this.viewModel.isLocked()
                    ? ProfileList.this.cachedLockedSprites : ProfileList.this.cachedTrashSprites;
        }

        private void refresh() {
            this.selectButton.field_22763 = !this.viewModel.isSelected();
            this.deleteButton.field_22763 = !this.viewModel.isLocked() && !this.viewModel.isDefault();
            this.deleteButton.setSprites(this.getButtonSprites());
        }

        @Override
        public void method_25343(@NotNull class_332 guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            this.deleteButton.method_48229(left, top);
            this.selectButton.method_48229(left + this.deleteButton.method_25368(), top);
            this.selectButton.method_25358(width - this.deleteButton.method_25368());

            this.deleteButton.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            this.selectButton.method_25394(guiGraphics, mouseX, mouseY, partialTick);

            if (Config.get().isDevMode()) {
                boolean hasProperty = true;
                int borderColor;

                if (this.viewModel.isDefault() && this.viewModel.isLocked()) {
                    borderColor = Theme.PURPLE_500.getARGB();
                } else if (this.viewModel.isDefault()) {
                    borderColor = Theme.BLUE_500.getARGB();
                } else if (this.viewModel.isLocked()) {
                    borderColor = Theme.RED_700.getARGB();
                } else {
                    borderColor = Theme.WHITE.getARGB();
                    hasProperty = false;
                }

                boolean hovered = guiGraphics.method_58135(mouseX, mouseY) && GuiUtil.isHovered(this, mouseX, mouseY);
                if (hasProperty || hovered) {
                    guiGraphics.method_49601(left, top, width, height, borderColor);
                }
                if (hovered) {
                    int foregroundColor = ARGBColor.withAlpha(borderColor, 0.25f);
                    guiGraphics.method_25294(left, top, left + width, top + height, foregroundColor);
                }
            }
        }

        @Override
        public @NotNull List<? extends class_364> method_25396() {
            return this.children;
        }

        @Override
        public @NotNull List<? extends class_6379> method_37025() {
            return this.children;
        }

        @Override
        public void method_48206(Consumer<class_339> consumer) {
            this.children.forEach(consumer);
        }

        @Override
        public void buildItems(ContextMenuItemBuilder builder, int mouseX, int mouseY) {
            if (!Config.get().isDevMode()) return;

            builder.separatorIfNonEmpty();
            builder.add(GuiConstants.devItem(ResourceUtil.getText("profile.default." + (this.viewModel.isDefault() ? "unset" : "set")))
                    .icon(() -> this.viewModel.isDefault() ? STAR_SPRITE : STAR_OUTLINE_SPRITE)
                    .action(this.viewModel::toggleDefault)
                    .build());
            builder.add(GuiConstants.devItem(ResourceUtil.getText("profile." + (this.viewModel.isLocked() ? "unlock" : "lock")))
                    .icon(() -> this.viewModel.isLocked() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL)
                    .action(this.viewModel::toggleLock)
                    .build());
        }
    }
}
