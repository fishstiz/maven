package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.gui.components.*;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenu;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuItemBuilder;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.fidgetz.util.lang.CollectionsUtil;
import io.github.fishstiz.fidgetz.util.lang.ObjectsUtil;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializeLayoutEvent;
import io.github.fishstiz.packed_packs.api.events.ScreenClosingEvent;
import io.github.fishstiz.packed_packs.compat.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.packed_packs.config.*;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.UiEffect;
import io.github.fishstiz.packed_packs.gui.components.PreferenceToggle;
import io.github.fishstiz.packed_packs.gui.components.profile.ProfilesSidebar;
import io.github.fishstiz.packed_packs.gui.states.DragActionRenderer;
import io.github.fishstiz.packed_packs.gui.components.contextmenu.*;
import io.github.fishstiz.packed_packs.gui.components.pack.*;
import io.github.fishstiz.packed_packs.gui.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.layouts.OptionsLayout;
import io.github.fishstiz.packed_packs.gui.layouts.PackLayout;
import io.github.fishstiz.packed_packs.gui.metadata.PackSelectionScreenArgs;
import io.github.fishstiz.packed_packs.gui.model.*;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.context.ScreenContextImpl;
import io.github.fishstiz.packed_packs.impl.events.ContextMenuEventImpl;
import io.github.fishstiz.packed_packs.pack.*;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionModelAccessor;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import io.github.fishstiz.packed_packs.util.PackUtil;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_403;
import net.minecraft.class_410;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5375;
import net.minecraft.class_7919;
import net.minecraft.class_8669;

import static net.minecraft.class_3675.*;
import static io.github.fishstiz.packed_packs.util.InputUtil.*;
import static io.github.fishstiz.packed_packs.util.PackUtil.joinPackNames;
import static io.github.fishstiz.packed_packs.util.PackUtil.validatePaths;
import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.*;

public class PackedPacksScreen extends class_437 implements HoverStateHandler, ToggleableDialogContainer, ContextMenuContainer {
    private static final class_2561 OPEN_FOLDER_TEXT = class_2561.method_43471("pack.openFolder");
    private final class_437 previous;
    private final PackSelectionScreenArgs original;
    private final PackedPacksViewModel viewModel;
    private final ScreenContext context;
    private final LayoutWrapper<FlexLayout> layout;
    private final ProfilesSidebar profilesSidebar;
    private final PackLayout availableLayout;
    private final PackLayout enabledLayout;
    private final ContextMenu contextMenu;
    private final Modal<OptionsLayout> optionsModal;
    private final List<ToggleableDialog<?>> dialogs;
    private final DragActionRenderer dragActionRenderer;
    private @Nullable class_364 hoveredElement;
    private boolean refreshOnInit = true;
    private boolean initialized = false;

    static {
        // force load API
        //noinspection ResultOfMethodCallIgnored,resource
        class_156.method_18349().execute(PackedPacksApiImpl::getInstance);
    }

    private PackedPacksScreen(class_310 minecraft, class_437 previous, PackSelectionScreenArgs original, InitMode initMode) {
        super(ResourceUtil.getModName());

        this.field_22787 = minecraft;
        this.previous = previous;
        this.original = original;
        this.viewModel = new PackedPacksViewModel(this.field_22787, original, initMode);
        this.context = new ScreenContextImpl(previous, this, this.viewModel, original, Config.get().isDevMode());
        this.viewModel.startWatcher(this.context);

        Components components = Components.create(this, this.context, this.viewModel);
        this.profilesSidebar = components.profilesSidebar();
        this.availableLayout = components.availableLayout();
        this.enabledLayout = components.enabledLayout();
        this.contextMenu = components.contextMenu();
        this.optionsModal = components.optionsModal();
        this.dialogs = components.dialogs();

        this.dragActionRenderer = new DragActionRenderer(this.field_22787.field_1772, this.dialogs.isEmpty() ? 1 : this.dialogs.getLast().getZ() + 1);
        this.layout = new LayoutWrapper<>(FlexLayout.vertical(this::getMaxHeight).spacing(SPACING));
        this.layout.setPadding(SPACING);

        this.viewModel.addEffectListener(this::onUiEffect);
    }

    public PackedPacksScreen(class_310 minecraft, class_437 previous, PackSelectionScreenArgs original) {
        this(minecraft, previous, original, new InitMode.Default());
    }

    public PackedPacksScreen(class_310 minecraft, class_437 previous, PackSelectionScreenArgs original, Profile profile) {
        this(minecraft, previous, original, new InitMode.WithProfile(profile));
    }

    public PackedPacksScreen(class_310 minecraft, class_437 previous, PackSelectionScreenArgs original, PackGroup packs) {
        this(minecraft, previous, original, new InitMode.WithPacks(packs));
    }

    @Override
    public void method_49589() {
        if (this.initialized) {
            this.viewModel.onMounted();
            this.viewModel.refreshRepository();
            this.viewModel.startWatcher(this.context);
        }
    }

    @Override
    public void method_25432() {
        this.viewModel.stopWatcher();
        this.viewModel.onUnmounted();
    }

    @Override
    protected void method_25426() {
        if (this.initialized) return;

        InitializeLayoutEvent event = PackedPacksApiImpl.getInstance().eventBus().post(new InitializeLayoutEvent(this.context));
        this.layout.layout().addChild(this.createHeader(event));
        this.layout.layout().addFlexChild(this.createContents());
        this.layout.layout().addChild(this.createFooter(event));

        this.dialogs.forEach(this::method_25429);
        this.layout.method_48206(this::method_37063);
        CollectionsUtil.forEachReverse(this.dialogs, this::method_37060);
        this.method_48640();

        this.viewModel.onMounted();
        if (this.refreshOnInit) this.viewModel.refreshRepository();

        this.initialized = true;
    }

    private void addExtensions(FlexLayout layout, InitializeLayoutEvent.Pos pos, InitializeLayoutEvent extensions) {
        extensions.getPendingWidgets(pos).forEach(layout::addChild);
    }

    private FlexLayout createHeader(InitializeLayoutEvent extensions) {
        FlexLayout header = FlexLayout.horizontal(this::getMaxWidth).spacing(SPACING);

        header.addChild(FidgetzButton.builder()
                .makeSquare()
                .setMessage(ProfilesViewModel.TITLE_TEXT)
                .setTooltip(class_7919.method_47407(ProfilesViewModel.TITLE_TEXT))
                .setSprite(HAMBURGER_SPRITE)
                .setOnPress(this.profilesSidebar::toggle)
                .build());

        header.addChild(PreferenceToggle.wrap(Preferences.ACTION_BAR_WIDGET, FidgetzButton.<Void>builder()
                .makeSquare()
                .setTooltip(class_7919.method_47407(ResourceUtil.getText("toggle_actionbar.info")))
                .setSprite(Sprite.of16(ResourceUtil.getIcon("filter")))
                .setOnPress(this::toggleActionBar)
                .build()));

        header.addFlexChild(this.profilesSidebar.createProfileHeader());

        this.addExtensions(header, InitializeLayoutEvent.Pos.AFTER_TITLE, extensions);

        header.addChild(PreferenceToggle.wrap(Preferences.OPTIONS_WIDGET, FidgetzButton.<Void>builder()
                .makeSquare()
                .setMessage(OPTIONS_TEXT)
                .setTooltip(class_7919.method_47407(OPTIONS_TEXT.method_27661().method_10852(class_5244.field_39678)))
                .setSprite(Sprite.of16(ResourceUtil.getIcon("gear")))
                .setOnPress(this.optionsModal::toggle)
                .build()));

        header.addChild(PreferenceToggle.wrap(Preferences.ORIGINAL_SCREEN_WIDGET, FidgetzButton.<Void>builder()
                .makeSquare()
                .setTooltip(class_7919.method_47407(ResourceUtil.getText("original_screen.info").method_10852(class_5244.field_39678)))
                .setSprite(Sprite.of16(ResourceUtil.getIcon("exit")))
                .setOnPress(() -> {
                    if (this.previous instanceof class_5375) {
                        this.method_25419();
                    } else {
                        this.field_22787.method_1507(this.original.createScreen(this.previous));
                    }
                })
                .build()));

        return header;
    }

    private FlexLayout createContents() {
        FlexLayout contents = FlexLayout.horizontal(this::getMaxWidth).spacing(SPACING);
        contents.addFlexChild(this.availableLayout, true);
        contents.addFlexChild(this.enabledLayout, true);
        return contents;
    }

    private FlexLayout createFooter(InitializeLayoutEvent extensions) {
        FlexLayout footer = FlexLayout.horizontal(this::getMaxWidth).spacing(SPACING);
        FlexLayout firstColumn = FlexLayout.horizontal().spacing(SPACING);
        FlexLayout secondColumn = FlexLayout.horizontal().spacing(SPACING);

        this.addExtensions(firstColumn, InitializeLayoutEvent.Pos.BEFORE_FOOTER, extensions);

        firstColumn.addFlexChild(FidgetzButton.builder()
                .setMessage(OPEN_FOLDER_TEXT)
                .setTooltip(class_7919.method_47407(class_2561.method_43471("pack.folderInfo")))
                .setOnPress(this.viewModel::openBaseDir)
                .build());

        this.addExtensions(firstColumn, InitializeLayoutEvent.Pos.AFTER_LEFT_FOOTER, extensions);

        if (this.context.isClientResources()) {
            secondColumn.addFlexChild(FidgetzButton.builder().setMessage(ResourceUtil.getText("apply")).setOnPress(this.viewModel::commit).build());
        }

        this.addExtensions(secondColumn, InitializeLayoutEvent.Pos.BEFORE_RIGHT_FOOTER, extensions);

        secondColumn.addFlexChild(FidgetzButton.builder().setMessage(class_5244.field_24334).setOnPress(this::method_25419).build());

        this.addExtensions(secondColumn, InitializeLayoutEvent.Pos.AFTER_FOOTER, extensions);

        footer.addFlexChild(firstColumn);

        this.addExtensions(footer, InitializeLayoutEvent.Pos.BETWEEN_RIGHT_FOOTER, extensions);

        footer.addFlexChild(secondColumn);

        return footer;
    }

    public int getMaxHeight() {
        return this.field_22790 - SPACING * 2;
    }

    public int getMaxWidth() {
        return this.field_22789 - SPACING * 2;
    }

    private void toggleActionBar() {
        Config.get().setShowActionBar(!Config.get().isShowActionBar());
        this.repositionLists();
    }

    private void repositionLists() {
        this.availableLayout.setHeaderVisibility(Config.get().isShowActionBar());
        this.enabledLayout.setHeaderVisibility(Config.get().isShowActionBar());
    }

    @Override
    protected void method_48640() {
        this.layout.method_48222();
        this.layout.method_48229(0, 0);
        this.dialogs.forEach(ToggleableDialog::repositionElements);
        this.contextMenu.setOpen(false);
        this.repositionLists();
    }

    @Override
    protected void method_41843() {
        if (this.field_22787 == null) return;

        PackedPacksScreen screen;
        Profile profile = this.viewModel.getSelectedProfile();
        if (profile != null) {
            screen = new PackedPacksScreen(this.field_22787, this.previous, this.original, profile);
        } else {
            PackGroup packs = new PackGroup(this.viewModel.getEnabledPacks(), this.viewModel.getAvailablePacks());
            screen = new PackedPacksScreen(this.field_22787, this.previous, this.original, packs);
        }
        screen.refreshOnInit = false;
        this.field_22787.method_1507(screen);
    }

    @Override
    public void method_29638(@NotNull List<Path> files) {
        this.field_22787.method_1507(new class_410(
                confirmed -> {
                    if (!confirmed) {
                        this.field_22787.method_1507(this);
                        return;
                    }
                    PackUtil.PathValidationResults results = validatePaths(files);
                    if (!results.symlinkWarnings().isEmpty()) {
                        this.field_22787.method_1507(class_8669.method_52750(() -> this.field_22787.method_1507(this)));
                        return;
                    }
                    if (!results.valid().isEmpty()) {
                        class_5375.method_29669(this.field_22787, results.valid(), this.viewModel.getBaseDir());
                        this.viewModel.refreshRepository();
                    }
                    if (!results.rejected().isEmpty()) {
                        String rejectedNames = joinPackNames(results.rejected());
                        this.field_22787.method_1507(new class_403(
                                () -> this.field_22787.method_1507(this),
                                class_2561.method_43471("pack.dropRejected.title"),
                                class_2561.method_43469("pack.dropRejected.message", rejectedNames)
                        ));
                        return;
                    }
                    this.field_22787.method_1507(this);
                },
                class_2561.method_43471("pack.dropConfirm"),
                class_2561.method_43470(joinPackNames(files))
        ));
    }

    @Override
    public void method_25419() {
        var closingEvent = PackedPacksApiImpl.getInstance().eventBus().post(new ScreenClosingEvent(this.context));
        if (closingEvent.isCommitted() || this.viewModel.shouldCommitOnClose()) {
            this.viewModel.commit();
        }
        if (this.context.isServerData() && !(this.previous instanceof class_5375)) {
            return;
        }
        if (this.previous instanceof PackSelectionScreenAccessor packScreen) {
            ((PackSelectionModelAccessor) packScreen.getModel()).packed_packs$reset();
            packScreen.invokeReload();
        }
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.previous);
        }
    }

    @Override
    public void method_25393() {
        this.viewModel.pollWatcher();
    }

    private PackLayout getPackLayout(PackListType type) {
        return switch (type) {
            case AVAILABLE -> this.availableLayout;
            case ENABLED -> this.enabledLayout;
        };
    }

    private void visitDeepestList(PackListType type, Consumer<PackList> visitor) {
        this.getPackLayout(type).container().visitDeepestList(visitor);
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.method_25399() != focused) {
            super.method_25395(focused);
        }
    }

    private void applyFocusTarget(PackListType type, FocusTarget target) {
        this.method_48267();
        PackListContainer listContainer = this.getPackLayout(type).container();
        this.method_25395(listContainer);
        ObjectsUtil.ifPresent(listContainer.getFocusPath(target), path -> path.method_48195(true));
    }

    private void onUiEffect(UiEffect effect) {
        switch (effect) {
            case UiEffect.ScrollToTop(PackListType type) -> this.visitDeepestList(type, PackList::scrollToTop);
            case UiEffect.ScrollToLastSelected(PackListType type) ->
                    this.visitDeepestList(type, PackList::scrollToLastSelected);
            case UiEffect.FocusList(PackListType type) -> this.setFocused(this.getPackLayout(type).container());
            case UiEffect.Focus(PackListType type, String packId, boolean scroll) when packId == null ->
                    this.applyFocusTarget(type, new FocusTarget.LastSelected(scroll));
            case UiEffect.Focus(PackListType type, String packId, boolean scroll) ->
                    this.applyFocusTarget(type, new FocusTarget.PackEntry(packId, scroll));
        }
    }

    private @Nullable PackLayout getFocusedOrHoveredLayout() {
        return ObjectsUtil.firstNonNull(
                ObjectsUtil.pick(this.availableLayout, this.enabledLayout, pl -> pl.container() == this.method_25399()),
                ObjectsUtil.pick(this.availableLayout, this.enabledLayout, pl -> pl.container().method_49606()),
                ObjectsUtil.pick(this.availableLayout, this.enabledLayout, pl -> pl.container().method_25370())
        );
    }

    private @Nullable PackLayout getFocusedLayout() {
        return ObjectsUtil.firstNonNull(
                ObjectsUtil.pick(this.availableLayout, this.enabledLayout, pl -> pl.container() == this.method_25399()),
                ObjectsUtil.pick(this.availableLayout, this.enabledLayout, pl -> pl.container().method_25370())
        );
    }

    private ToggleableEditBox<Void> focusSearchField(PackLayout packLayout) {
        if (!Config.get().isShowActionBar()) this.toggleActionBar();
        ToggleableEditBox<Void> searchField = packLayout.getSearchField();
        this.method_48267();
        this.method_25395(searchField);
        return searchField;
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (this.viewModel.isDragging()) {
            return true;
        }
        if (super.method_25400(codePoint, modifiers)) {
            return true;
        }
        if (CollectionsUtil.anyMatch(this.dialogs, ToggleableDialog::isOpen)) {
            return false;
        }
        if (codePoint != field_31947 && (noModifiers(modifiers) || shiftOnly(modifiers))) {
            PackLayout packLayout = this.getFocusedOrHoveredLayout();
            if (packLayout != null && !packLayout.getSearchField().method_25370()) {
                return this.focusSearchField(packLayout).method_25400(codePoint, modifiers);
            }
        }
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (this.viewModel.isDragging()) {
            return true;
        }
        this.contextMenu.setOpen(false);
        if (keyCode == field_31958) {
            PackLayout packLayout = this.getFocusedLayout();
            if (packLayout != null) {
                PackListType type = packLayout.key().type();
                if (this.viewModel.closeFolder(type) || this.viewModel.closeFolder(type.other())) {
                    return true;
                }
            } else if (this.viewModel.closeFolder()) {
                return true;
            }
        }
        if (isDeveloperMode(keyCode, modifiers)) {
            this.viewModel.toggleDevMode();
            this.method_41843();
            return true;
        }
        if (isSwitchDefaultProfile(keyCode, modifiers)) {
            this.viewModel.switchDefaultProfile();
            return true;
        }
        if (isRefresh(keyCode, modifiers) && this.viewModel.canRefresh()) {
            this.viewModel.refreshRepository();
            return true;
        }
        if (isOpenProfiles(keyCode, modifiers)) {
            this.profilesSidebar.toggle();
            return true;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (isRedo(keyCode, modifiers)) {
            this.viewModel.redo();
            return true;
        }
        if (isUndo(keyCode, modifiers)) {
            this.viewModel.undo();
            return true;
        }
        if (keyCode == field_31986) {
            PackLayout packLayout = this.getFocusedOrHoveredLayout();
            if (packLayout != null) {
                ToggleableEditBox<Void> searchField = packLayout.getSearchField();
                if (!searchField.method_25370() && !searchField.method_1882().isEmpty()) {
                    return this.focusSearchField(packLayout).method_25404(keyCode, scanCode, modifiers);
                }
            }
        }
        return false;
    }

    private void openContextMenu(int mouseX, int mouseY) {
        if (this.contextMenu.method_25405(mouseX, mouseY)) return;

        var extensions = ContextMenuEventImpl.postScreen(this.context);
        var prefExtensions = ContextMenuEventImpl.postPreferences(this.context);

        new ContextMenuItemBuilder()
                .whenNonNull(extensions.getItems(ContextMenuEvent.Screen.Pos.TOP))
                .ifTrue((items, b) -> b.addAll(items))
                .then(b -> this.buildItems(b, mouseX, mouseY))
                .when(this.context.devMode())
                .ifTrue(dev -> dev
                        .separatorIfNonEmpty()
                        .whenNonNull(this.viewModel.getSelectedProfile())
                        .ifTrue(b -> b.
                                add(devItem(ResourceUtil.getText("profile.save"))
                                        .action(this.viewModel::saveSelectedProfile)
                                        .build())
                                .separator())
                        .parent(children -> devItem(ResourceUtil.getText("preferences"))
                                .addChildren(children)
                                .build(), prefsBuilder -> prefsBuilder
                                .whenNonNull(prefExtensions.getItems(ContextMenuEvent.Preferences.Pos.TOP))
                                .ifTrue((items, b) -> b.addAll(items))
                                .addAll(PreferenceToggle.standardOptions())
                                .whenNonNull(prefExtensions.getItems(ContextMenuEvent.Preferences.Pos.BOTTOM))
                                .ifTrue((items, b) -> b.addAll(items))
                                .add(devItem(ResourceUtil.getText("preferences.reset")).action(Preferences::reset).build())))
                .separatorIfNonEmpty()
                .simpleItem(ResourceUtil.getText("reset_enabled"), this.viewModel::isUnlocked, this.viewModel::resetChanges)
                .simpleItem(ResourceUtil.getText("refresh"), this.viewModel::canRefresh, this.viewModel::refreshRepository)
                .when(this.viewModel.getAdditionalFolders(), List::isEmpty)
                .ifTrue(b -> b.simpleItem(OPEN_FOLDER_TEXT, this.viewModel::openBaseDir))
                .orElse((dirs, b) -> b
                        .parent(OPEN_FOLDER_TEXT, p -> p
                                .add(new DirectoryMenuItem(this.viewModel.getBaseDir()))
                                .separator()
                                .iterate(dirs)
                                .map(DirectoryMenuItem::new)))
                .whenNonNull(extensions.getItems(ContextMenuEvent.Screen.Pos.BOTTOM))
                .ifTrue((items, b) -> b.addAll(items))
                .peek(items -> {
                    boolean hasHeader = !items.isEmpty() && items.getFirst() instanceof PackMenuHeader;
                    int yOffset = hasHeader ? this.contextMenu.getItemHeight() : 0;
                    this.contextMenu.open(mouseX, mouseY - yOffset, items);
                });
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.viewModel.isDragging()) {
            return true;
        }
        if (isClickForward(button)) {
            this.viewModel.redo();
            return true;
        }
        if (isClickBack(button)) {
            this.viewModel.undo();
            return true;
        }

        boolean clicked = ToggleableDialogContainer.super.method_25402(mouseX, mouseY, button);

        if (isRightClick(button) && !this.optionsModal.method_25405(mouseX, mouseY)) {
            this.openContextMenu((int) mouseX, (int) mouseY);
        } else if (clicked && !this.contextMenu.method_25405(mouseX, mouseY)) {
            this.contextMenu.setOpen(false);
        }

        if (!clicked && this.hoveredElement == null) {
            ObjectsUtil.ifPresent(this.method_48218(), path -> path.method_48195(false));
        }

        return clicked;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return this.viewModel.isDragging() || ToggleableDialogContainer.super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        ActiveAction.Dragging dragged = this.viewModel.state().dragging();
        if (isLeftClick(button) && dragged != null) {
            if (this.availableLayout.container().method_49606()) {
                this.availableLayout.container().onDrop(dragged, (int) mouseX, (int) mouseY);
            } else if (this.enabledLayout.container().method_49606()) {
                this.enabledLayout.container().onDrop(dragged, (int) mouseX, (int) mouseY);
            } else {
                this.viewModel.dispatch(new PackListIntent.Drop(dragged.target(), dragged.ctx(), dragged.payload(), null, 0));
            }
            return true;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public List<ToggleableDialog<?>> getDialogs() {
        return this.dialogs;
    }

    @Override
    public @Nullable class_364 getHovered() {
        return this.hoveredElement;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.hoveredElement = this.findHovered(mouseX, mouseY);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        if (this.viewModel.isDragging()) {
            if (this.viewModel.isUnlocked()) {
                this.dragActionRenderer.render(
                        this.availableLayout.container(),
                        this.enabledLayout.container(),
                        this.viewModel.state().dragging(),
                        guiGraphics,
                        mouseX,
                        mouseY,
                        partialTick
                );
            } else {
                MinecraftCursor.get().setNotAllowed();
            }
        }

        if (this.context.devMode()) {
            float scale = 0.5f;
            int y = (int) ((field_22790 - this.field_22793.field_2000 * scale) / scale);

            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_22905(scale, scale, 0);
            guiGraphics.method_27535(this.field_22793, ResourceUtil.getText("dev_mode", DEV_MODE_SHORTCUT), 0, y, Theme.WHITE.getARGB());
            guiGraphics.method_51448().method_22909();
        }
    }
}
