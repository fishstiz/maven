package io.github.fishstiz.packed_packs.gui.components.contextmenu;

import io.github.fishstiz.fidgetz.gui.components.contextmenu.MenuItem;
import java.nio.file.Path;
import net.minecraft.class_156;
import net.minecraft.class_2561;

public record DirectoryMenuItem(Path directory, class_2561 text) implements MenuItem {
    public DirectoryMenuItem(Path directory) {
        this(directory, class_2561.method_43470(directory.getFileName().toString()));
    }

    @Override
    public void run() {
        class_156.method_668().method_60932(this.directory);
    }
}