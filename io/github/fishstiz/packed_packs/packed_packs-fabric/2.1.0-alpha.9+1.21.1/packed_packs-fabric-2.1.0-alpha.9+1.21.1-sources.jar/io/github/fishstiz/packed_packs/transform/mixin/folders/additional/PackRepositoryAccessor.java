package io.github.fishstiz.packed_packs.transform.mixin.folders.additional;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(class_3283.class)
public interface PackRepositoryAccessor {
    @Accessor("sources")
    Set<class_3285> packed_packs$getSources();
}
