package io.github.fishstiz.packed_packs.gui.layouts;

import io.github.fishstiz.fidgetz.gui.components.FidgetzButton;
import io.github.fishstiz.fidgetz.gui.components.ToggleableEditBox;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayoutElement;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.ButtonSprites;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.config.ProfileManager;
import io.github.fishstiz.packed_packs.gui.model.ProfilesViewModel;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_339;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.gui.model.ProfilesViewModel.NO_PROFILE_TEXT;
import static io.github.fishstiz.packed_packs.gui.model.ProfilesViewModel.UNNAMED_TEXT;
import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.*;

public class ProfileHeader implements class_8133, FlexLayoutElement {
    private final FlexLayout layout = FlexLayout.horizontal().spacing(SPACING);
    private final ProfilesViewModel viewModel;
    private final ToggleableEditBox<Void> nameField;
    private final FidgetzButton<Void> toggleNameButton;
    private final ButtonSprites cachedToggleSprites = new ButtonSprites(
            Sprite.of16(ResourceUtil.getIcon("edit")),
            Sprite.of16(ResourceUtil.getIcon("edit_inactive"))
    );

    public ProfileHeader(ProfilesViewModel viewModel, Consumer<String> onRename) {
        this.viewModel = viewModel;
        this.nameField = ToggleableEditBox.<Void>builder()
                .setHint(UNNAMED_TEXT)
                .setMaxLength(ProfileManager.getNameMaxLength())
                .setFilter(value -> value != null && (value.isEmpty() || !value.isBlank()))
                .addListener(this.viewModel::renameSelected)
                .addListener(onRename)
                .build();
        this.toggleNameButton = FidgetzButton.<Void>builder()
                .makeSquare()
                .setTooltip(class_7919.method_47407(ResourceUtil.getText("profile.edit")))
                .setSprite(this.cachedToggleSprites)
                .setOnPress(this.nameField::toggle)
                .build();

        this.layout.addChild(this.toggleNameButton);
        this.layout.addFlexChild(this.nameField);

        this.viewModel.subscribe(ProfilesViewModel.Property.ALL, this::refresh);
    }

    private void refresh() {
        Profile selectedProfile = this.viewModel.selectedProfile();
        boolean hasProfile = selectedProfile != null;
        this.nameField.method_1888(false);
        this.nameField.method_47404(hasProfile ? UNNAMED_TEXT : NO_PROFILE_TEXT);
        this.nameField.setValueSilently(hasProfile ? selectedProfile.getName() : "");
        this.nameField.field_22764 = hasProfile;
        this.nameField.field_22763 = hasProfile;
        this.toggleNameButton.field_22764 = hasProfile;
        this.toggleNameButton.field_22763 = hasProfile && !selectedProfile.isLocked();
        this.toggleNameButton.setSprites(this.resolveToggleSprites(selectedProfile));
    }

    private ButtonSprites resolveToggleSprites(@Nullable Profile profile) {
        if (profile == null || !profile.isLocked()) return this.cachedToggleSprites;
        return Objects.equals(profile, this.viewModel.defaultProfile())
                ? ButtonSprites.of(STAR_SPRITE)
                : ButtonSprites.unclamp(LOCK_SPRITE);
    }

    @Override
    public void setWidth(int width) {
        this.layout.setWidth(width);
    }

    @Override
    public void setHeight(int height) {
        this.layout.setHeight(height);
    }

    @Override
    public void method_46421(int x) {
        this.layout.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        this.layout.method_46419(y);
    }

    @Override
    public int method_46426() {
        return this.layout.method_46426();
    }

    @Override
    public int method_46427() {
        return this.layout.method_46427();
    }

    @Override
    public int method_25368() {
        return this.layout.method_25368();
    }

    @Override
    public int method_25364() {
        return this.layout.method_25364();
    }

    @Override
    public void method_48227(@NotNull Consumer<class_8021> visitor) {
        this.layout.method_48227(visitor);
    }

    @Override
    public void method_48206(@NotNull Consumer<class_339> visitor) {
        this.layout.method_48206(visitor);
    }

    @Override
    public void method_48222() {
        this.layout.method_48222();
    }
}
