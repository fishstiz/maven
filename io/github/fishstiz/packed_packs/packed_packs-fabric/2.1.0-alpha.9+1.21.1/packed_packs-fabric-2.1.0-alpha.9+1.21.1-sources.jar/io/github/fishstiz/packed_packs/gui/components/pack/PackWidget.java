package io.github.fishstiz.packed_packs.gui.components.pack;

import io.github.fishstiz.fidgetz.gui.components.AbstractLayoutElement;
import io.github.fishstiz.fidgetz.gui.components.FidgetzText;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_7940;
import org.jetbrains.annotations.NotNull;

class PackWidget extends AbstractLayoutElement implements class_4068 {
    private static final class_2561 INCOMPATIBLE_TITLE = class_2561.method_43471("pack.incompatible");
    private static final int DESCRIPTION_LINES = 2;
    private final class_310 minecraft;
    private final PackListViewModel.Entry viewModel;
    private final int spacing;
    private final FidgetzText<Void> nameWidget;
    private class_7940 descriptionWidget;
    private int cachedBodyWidth;
    private boolean warningShown;

    PackWidget(class_310 minecraft, PackListViewModel.Entry viewModel, int height, int spacing) {
        this.minecraft = minecraft;
        this.viewModel = viewModel;
        this.nameWidget = FidgetzText.<Void>builder()
                .setMessage(viewModel.pack().method_14457())
                .setHeight(minecraft.field_1772.field_2000)
                .setColor(class_124.field_1068.method_532())
                .setShadow(true)
                .build();
        this.spacing = spacing;
        this.setHeight(height);
        this.updateDescriptionWidget();
    }

    private int getIconSize() {
        return this.method_25364();
    }

    private class_2561 getExtendedDescription() {
        return this.viewModel.pack().method_29483().method_45282(this.viewModel.pack().method_14459());
    }

    private void updateDescriptionWidget() {
        this.descriptionWidget = new class_7940(this.getExtendedDescription(), this.minecraft.field_1772);
        this.descriptionWidget.method_48985(DESCRIPTION_LINES);
        this.descriptionWidget.method_48984(this.cachedBodyWidth);
        this.descriptionWidget.method_48981(false);
        this.warningShown = false;
    }

    @Override
    public void setWidth(int width) {
        if (this.method_25368() == width) return;
        super.setWidth(width);

        int bodyX = this.spacing * 2 + this.method_46426() + this.getIconSize();
        int bodyWidth = this.getRight() - this.spacing * 2 - bodyX;
        this.cachedBodyWidth = bodyWidth;

        this.nameWidget.method_46421(bodyX);
        this.nameWidget.method_25358(bodyWidth);
        this.updateDescriptionWidget();
    }

    public int getContentLeft() {
        return this.nameWidget.method_46426();
    }

    protected void renderSprite(class_332 guiGraphics) {
        int x = this.method_46426() + this.spacing;
        int y = this.method_46427();
        int size = this.getIconSize();
        this.viewModel.sprite().render(guiGraphics, x, y, size, size);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderSprite(guiGraphics);

        int lineHeight = this.minecraft.field_1772.field_2000;
        int totalContentHeight = lineHeight + spacing + (lineHeight * DESCRIPTION_LINES);
        int startY = this.method_46427() + (this.method_25364() - totalContentHeight) / 2;

        this.nameWidget.method_46419(startY);
        this.nameWidget.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        this.descriptionWidget.method_48229(this.nameWidget.method_46426(), startY + lineHeight + this.spacing);
        this.descriptionWidget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    public void checkCompatibility(boolean showWarning) {
        if (showWarning) {
            if (!this.warningShown && !this.viewModel.pack().method_14460().method_14437() && !this.viewModel.incompatibleWarningsHidden()) {
                this.nameWidget.method_25355(INCOMPATIBLE_TITLE);
                this.descriptionWidget.method_25355(this.viewModel.pack().method_14460().method_14439());
                this.warningShown = true;
            }
        } else if (this.warningShown) {
            this.nameWidget.method_25355(this.viewModel.pack().method_14457());
            this.nameWidget.method_25358(this.cachedBodyWidth);
            this.descriptionWidget.method_25355(this.getExtendedDescription());
            this.warningShown = false;
        }
    }
}
