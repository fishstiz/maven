package io.github.fishstiz.packed_packs.config;

import net.minecraft.class_3264;

public record PackConfigs(Config.Packs user, DevConfig.Packs dev, ProfileManager profiles) {
    public static PackConfigs get(class_3264 packType) {
        return new PackConfigs(
                Config.packs(packType),
                DevConfig.packs(packType),
                ProfileManager.get(packType)
        );
    }
}
