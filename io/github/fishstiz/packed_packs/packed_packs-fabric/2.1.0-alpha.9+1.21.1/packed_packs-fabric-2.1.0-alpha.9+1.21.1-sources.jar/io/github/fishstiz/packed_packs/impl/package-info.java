@ApiStatus.Internal
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.packed_packs.impl;

import org.jetbrains.annotations.ApiStatus;