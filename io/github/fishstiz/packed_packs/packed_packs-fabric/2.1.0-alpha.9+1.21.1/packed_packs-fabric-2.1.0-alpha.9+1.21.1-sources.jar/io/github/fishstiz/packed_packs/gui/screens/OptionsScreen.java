package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.gui.components.FidgetzButton;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.layouts.OptionsLayout;
import io.github.fishstiz.packed_packs.util.constants.GuiConstants;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_8132;
import net.minecraft.class_8133;

public class OptionsScreen extends class_437 {
    private final class_8132 layout = new class_8132(this);
    private final class_437 previous;
    private class_8133 body;

    public OptionsScreen(class_437 previous) {
        super(GuiConstants.OPTIONS_TEXT);
        this.previous = previous;
    }

    @Override
    protected void method_25426() {
        this.layout.method_57726(this.field_22785, this.field_22793);
        this.body = this.layout.method_48999(new OptionsLayout(this.field_22787, this.layout::method_57727));
        this.layout.method_48996(FidgetzButton.builder().setMessage(class_5244.field_24334).setOnPress(this::method_25419).build());
        this.layout.method_48206(this::method_37063);
        this.method_48640();
    }

    @Override
    protected void method_48640() {
        this.layout.method_48222();

        if (this.body != null) {
            this.body.method_46419(this.layout.method_48998());
        }
    }

    @Override
    public void method_25419() {
        Config.get().save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.previous);
        }
    }
}
