@ApiStatus.Internal
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.packed_packs.impl.context;

import org.jetbrains.annotations.ApiStatus;