package io.github.fishstiz.packed_packs.transform.mixin.gui;

import net.minecraft.class_350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_350.class)
public interface AbstractSelectionListAccessor {
    @Accessor("scrolling")
    boolean packed_packs$scrolling();
}
