package io.github.fishstiz.packed_packs.transform.mixin;

import io.github.fishstiz.packed_packs.transform.interfaces.ChildScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.nio.file.Path;
import net.minecraft.class_5369;
import net.minecraft.class_5375;

@Mixin(class_5375.class)
public interface PackSelectionScreenAccessor extends ChildScreen {
    @Accessor("model")
    class_5369 getModel();

    @Invoker("reload")
    void invokeReload();

    @Invoker("closeWatcher")
    void invokeCloseWatcher();

    @Accessor("packDir")
    Path packed_packs$getPackDir();
}
