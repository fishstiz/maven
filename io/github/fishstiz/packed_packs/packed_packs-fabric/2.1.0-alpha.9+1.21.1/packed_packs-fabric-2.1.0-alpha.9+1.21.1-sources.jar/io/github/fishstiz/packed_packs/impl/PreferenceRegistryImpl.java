package io.github.fishstiz.packed_packs.impl;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.PreferenceRegistry;
import io.github.fishstiz.packed_packs.config.Preferences;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_2960;

public final class PreferenceRegistryImpl implements PreferenceRegistry {
    private final Map<class_2960, Preferences.Option<?>> options = new Object2ObjectOpenHashMap<>();
    private @Nullable Set<Key<?>> incorrectKeys;

    PreferenceRegistryImpl() {
    }

    @Override
    public <T> Key<T> register(
            class_2960 id,
            Class<T> type,
            T defaultValue,
            @Nullable Function<String, T> deserializer,
            @Nullable Function<T, String> serializer
    ) {
        Preferences.Option<?> option = this.options.get(id);
        if (option != null) {
            PackedPacks.LOGGER.error("Preference already exists for key: {}", id);
            return new KeyImpl<>(id, type);
        }

        String key = id.method_12836().equals(PackedPacks.MOD_ID) ? id.method_12832() : id.method_42094();
        this.options.put(id, deserializer == null || serializer == null
                ? Preferences.register(key, type, defaultValue)
                : Preferences.register(key, type, defaultValue, deserializer, serializer));

        return new KeyImpl<>(id, type);
    }

    @Override
    public <T> Key<T> register(class_2960 id, Class<T> type, T defaultValue) {
        return this.register(id, type, defaultValue, null, null);
    }

    @SuppressWarnings("unchecked")
    private <T> Preferences.@Nullable Option<T> getAndValidate(Key<T> key) {
        Preferences.Option<?> option = this.options.get(key.id());
        if (option == null) {
            return null;
        }
        if (option.type() == key.type()) {
            return (Preferences.Option<T>) option;
        }
        if (this.incorrectKeys == null) {
            this.incorrectKeys = new ReferenceOpenHashSet<>();
        }
        if (this.incorrectKeys.add(key)) {
            PackedPacks.LOGGER.warn("[packed_packs] Unexpected type found for preference key '{}'", key.id());
        }
        return null;
    }

    private <T> void setOrLog(class_2960 id, Preferences.@Nullable Option<T> option, T value) {
        if (option == null) {
            PackedPacks.LOGGER.error("[packed_packs] Cannot set value of unregistered preference '{}'", id);
        } else {
            option.set(value);
        }
    }

    @Override
    public <T> void set(Key<T> key, T value) {
        this.setOrLog(key.id(), this.getAndValidate(key), value);
    }

    @Override
    public @Nullable <T> T get(Key<T> key) {
        Preferences.Option<T> option = this.getAndValidate(key);
        return option == null ? null : option.get();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void setUnsafe(class_2960 id, Object value) {
        this.setOrLog(id, (Preferences.Option<Object>) this.options.get(id), value);
    }

    @Override
    public @Nullable Object getUnsafe(class_2960 key) {
        Preferences.Option<?> option = this.options.get(key);
        return option == null ? null : option.get();
    }

    public <T> Preferences.@Nullable Option<T> getOption(Key<T> key) {
        return this.getAndValidate(key);
    }

    private record KeyImpl<T>(class_2960 id, Class<T> type) implements Key<T> {
    }
}
