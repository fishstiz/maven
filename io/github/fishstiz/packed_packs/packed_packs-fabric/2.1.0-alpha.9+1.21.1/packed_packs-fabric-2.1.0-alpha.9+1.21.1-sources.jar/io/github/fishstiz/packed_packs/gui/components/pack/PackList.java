package io.github.fishstiz.packed_packs.gui.components.pack;

import io.github.fishstiz.fidgetz.gui.components.*;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuItemBuilder;
import io.github.fishstiz.fidgetz.gui.renderables.ColoredRect;
import io.github.fishstiz.fidgetz.gui.renderables.GradientRect;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.GuiSprite;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializePackEntryEvent;
import io.github.fishstiz.packed_packs.compat.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.components.MouseSelectionHandler;
import io.github.fishstiz.packed_packs.gui.components.PreferenceToggle;
import io.github.fishstiz.packed_packs.gui.components.SelectableEntry;
import io.github.fishstiz.packed_packs.gui.components.contextmenu.PackMenuHeader;
import io.github.fishstiz.packed_packs.gui.model.PackListKey;
import io.github.fishstiz.packed_packs.gui.model.PackListUtils;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.events.ContextMenuEventImpl;
import io.github.fishstiz.packed_packs.transform.mixin.gui.AbstractSelectionListAccessor;
import io.github.fishstiz.packed_packs.util.PackUtil;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8028;

import static io.github.fishstiz.packed_packs.util.InputUtil.*;
import static io.github.fishstiz.packed_packs.util.ResourceUtil.getVanilla;
import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.*;
import static io.github.fishstiz.fidgetz.util.lang.ObjectsUtil.*;

public class PackList extends AbstractFixedListWidget<PackList.Entry> implements FocusPathProvider, ContainerEventHandlerPatch, ContextMenuContainer {
    protected static final int Y_OFFSET = 2;
    protected static final int ITEM_HEIGHT = 32;
    protected static final int ROW_GAP = 3;
    private static final double SCROLL_STEP = 10;
    private static final int DROP_INDEX_PADDING = 2;
    private final ScreenContext screenContext;
    private final PackListViewModel viewModel;
    private Theme dropTheme;
    private ColoredRect dropRect;
    private ColoredRect dropIndexRect;
    private GradientRect scrollUpRect;
    private GradientRect scrollDownRect;
    private boolean scrolling;

    public PackList(ScreenContext screenContext, PackListViewModel viewModel) {
        super(ITEM_HEIGHT, DEFAULT_SCROLLBAR_OFFSET, Y_OFFSET, ROW_GAP);
        this.screenContext = screenContext;
        this.viewModel = viewModel;
        this.applyTheme();
        this.refresh();
        this.viewModel.subscribe(PackListViewModel.Property.PACKS, this::refresh);
        this.viewModel.subscribe(PackListViewModel.Property.SELECTION, this::refreshSelected);
    }

    public PackListKey key() {
        return this.viewModel.key();
    }

    private void applyTheme() {
        if (this.viewModel.supportsReordering()) {
            this.dropTheme = Theme.GREEN_500;
            this.dropIndexRect = new ColoredRect(dropTheme.getARGB());
            this.scrollUpRect = GradientRect.fromTop(dropTheme.withAlpha(0.75f), dropTheme.withAlpha(0));
            this.scrollDownRect = this.scrollUpRect.flip();
        } else {
            this.dropTheme = Theme.RED_700;
            this.dropRect = new ColoredRect(dropTheme.withAlpha(0.25f));
        }
    }

    private void refresh() {
        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry focused = this.method_25336();

        this.method_25395(null);
        this.setSelected(null);

        this.method_25339();

        this.viewModel.forEachEntry((entry, i) -> {
            io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry listEntry = new io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry(entry, i);
            this.method_25321(listEntry);

            if (entry.selectedLast()) {
                this.setSelected(listEntry);
            }
            if (focused != null && focused.pack().equals(entry.pack())) {
                this.method_25395(listEntry);
            }
        });

        this.method_60322();
    }

    private void refreshSelected() {
        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry selected = this.field_22751;
        if (selected != null && !selected.viewModel.selectedLast()) {
            this.field_22751 = null;
        }
    }

    @Override
    public void setSelected(@Nullable io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry selected) {
        if (selected == null || selected.viewModel.selectedLast()) {
            this.field_22751 = selected;
        }
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) method_25395(null);
    }

    @Override
    public @Nullable io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry method_25334() {
        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry selected = super.method_25334();
        if (selected == null && !this.viewModel.hasSelection()) {
            return this.field_22751 = null;
        }
        if (selected != null && selected.viewModel.selectedLast()) {
            return selected;
        }
        for (io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry : this.method_25396()) {
            if (entry.viewModel.selectedLast()) {
                return this.field_22751 = entry;
            }
        }
        return selected;
    }

    public void scrollToTop() {
        this.method_25307(0);
    }

    public void scrollToLastSelected() {
        ifPresent(this.method_25334(), this::scrollToEntry);
    }

    private void scrollStep(boolean up, float partialTick) {
        double scrollAmount = this.scrollAmount();
        if (up) {
            scrollAmount -= SCROLL_STEP * partialTick;
        } else {
            scrollAmount += SCROLL_STEP * partialTick;
        }

        this.scrolling = true;
        this.method_60321(scrollAmount);
    }

    private int getDropIndex(double mouseY) {
        if (this.method_25396().isEmpty()) return -1;

        int index = this.getRowIndex(mouseY);
        if (index == -1) return -1;

        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry = this.method_25326(index);
        int centerY = entry.method_46427() + (entry.method_25364() / 2);

        if (mouseY >= centerY) {
            int next = index + 1;
            return next < this.method_25396().size() ? next : -1;
        }
        return index;
    }

    private boolean isMouseOverSelectionEntry(SequencedCollection<class_3288> selection, double mouseX, double mouseY, int index) {
        if (index < 0 || index >= this.method_25396().size()) return false;

        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry = this.method_25396().get(index);
        if (entry == null) return false;

        return entry.method_25405(mouseX, mouseY) && selection.contains(entry.pack());
    }

    private boolean isMouseOverSelection(SequencedCollection<class_3288> selection, double mouseX, double mouseY, int index) {
        return this.isMouseOverSelectionEntry(selection, mouseX, mouseY, index - 1) || this.isMouseOverSelectionEntry(selection, mouseX, mouseY, index);
    }

    private boolean canDropAt(ActiveAction.Dragging dragging, int mouseX, int mouseY, int index) {
        if (this.scrolling || (dragging.target() == this.key() && this.isMouseOverSelection(dragging.payload(), mouseX, mouseY, index))) {
            return false;
        }
        return this.viewModel.canDrop(dragging.target(), dragging.ctx().pack(), dragging.payload(), index);
    }

    private void renderDropIndex(class_332 guiGraphics, int x, int width, int index) {
        int rowTop = Math.clamp(
                this.method_25337(index != -1 ? index : this.method_25396().size()),
                this.method_46427() + this.offsetY + DROP_INDEX_PADDING,
                this.method_55443() - this.rowGap - DROP_INDEX_PADDING
        );
        int indexY = rowTop - this.rowGap - DROP_INDEX_PADDING;

        guiGraphics.method_44379(this.method_46426(), this.method_46427(), this.method_55442(), this.method_55443());
        this.dropIndexRect.render(guiGraphics, x, indexY, width, rowTop - indexY + DROP_INDEX_PADDING);
        guiGraphics.method_44380();
    }

    private void renderDroppableSlots(class_332 guiGraphics, ActiveAction.Dragging dragging, int mouseX, int mouseY, float partialTick) {
        int x = this.method_46426();
        int y = this.method_46427();
        int width = this.method_57717() ? this.method_25368() - this.scrollbarOffset : this.method_25368();
        int height = this.method_25364();
        int bottom = this.method_55443();

        if (this.method_25405(mouseX, mouseY)) {
            double scrollAmount = this.scrollAmount();

            int scrollDownY = bottom - this.getItemHeight();
            if (scrollAmount < this.maxScrollAmount() && mouseY >= scrollDownY) {
                this.scrollDownRect.render(guiGraphics, x, scrollDownY, width, this.getItemHeight());
                this.scrollStep(false, partialTick);
            } else if (scrollAmount > 0 && mouseY <= y + this.getItemHeight()) {
                this.scrollUpRect.render(guiGraphics, x, y, width, this.getItemHeight());
                this.scrollStep(true, partialTick);
            } else {
                this.scrolling = false;
            }

            int index = this.getDropIndex(mouseY);
            if (this.canDropAt(dragging, mouseX, mouseY, index)) {
                this.renderDropIndex(guiGraphics, x, width, index);
            }
        }

        guiGraphics.method_49601(x, y, width, height, dropTheme.getARGB());
    }

    private void renderDroppableRect(class_332 guiGraphics, ActiveAction.Dragging dragging, int mouseX, int mouseY, float partialTick) {
        if (this.canDropAt(dragging, mouseX, mouseY, 0)) {
            if (this.method_25405(mouseX, mouseY)) {
                this.dropRect.render(guiGraphics, this.method_46426(), this.method_46427(), field_22758, this.method_25364(), partialTick);
            }
            guiGraphics.method_49601(this.method_46426(), this.method_46427(), field_22758, this.method_25364(), this.dropTheme.getARGB());
        }
    }

    public void renderDroppableZone(class_332 guiGraphics, ActiveAction.Dragging dragging, int mouseX, int mouseY, float partialTick) {
        if (!this.viewModel.locked() && PackListUtils.canInteract(dragging.target(), this.key())) {
            if (this.viewModel.supportsReordering()) {
                this.renderDroppableSlots(guiGraphics, dragging, mouseX, mouseY, partialTick);
            } else {
                this.renderDroppableRect(guiGraphics, dragging, mouseX, mouseY, partialTick);
            }
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        int index = this.getDropIndex(mouseY);
        if (this.canDropAt(dragging, mouseX, mouseY, index)) {
            this.viewModel.applyDrop(dragging.target(), dragging.ctx(), dragging.payload(), index);
        } else {
            this.viewModel.cancelDrop(dragging.target(), dragging.ctx(), dragging.payload());
        }
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry getEntry(String packId) {
        for (io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry : this.method_25396()) {
            if (entry.pack().method_14463().equals(packId)) {
                return entry;
            }
        }
        return null;
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry getNextEntryAt(class_8028 direction) {
        if (this.method_25396().isEmpty()) return null;

        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry selectedEntry = firstNonNull(this.method_25336(), this.method_25334());
        return switch (direction) {
            case field_41826 -> selectedEntry != null && this.method_25396().getFirst().equals(selectedEntry)
                    ? selectedEntry
                    : this.getPreviousEntry(selectedEntry);
            case field_41827 -> selectedEntry != null && this.method_25396().getLast().equals(selectedEntry)
                    ? selectedEntry
                    : this.getNextEntry(selectedEntry);
            case field_41828 -> this.key().type().available() ? selectedEntry : null;
            case field_41829 -> this.key().type().enabled() ? selectedEntry : null;
        };
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        if (this.children().isEmpty()) return null;

        Entry targetEntry = switch (target) {
            case FocusTarget.LastSelected ignored -> this.getSelected();
            case FocusTarget.PackEntry entry -> this.getEntry(entry.packId());
        };

        return targetEntry == null ? null : new ListPath(this, targetEntry, target.scroll(), false);
    }

    @Override
    public @Nullable class_8016 method_48205(@NotNull class_8023 event) {
        if (this.children().isEmpty()) return null;

        Entry next = switch (event) {
            case FocusNavigationEvent.InitialFocus ignored -> firstNonNull(this.getFocused(), this.getSelected());
            case FocusNavigationEvent.TabNavigation ignored -> this.isFocused()
                    ? null
                    : Objects.requireNonNullElse(this.getSelected(), this.children().getFirst());
            case FocusNavigationEvent.ArrowNavigation(ScreenDirection direction) -> this.isFocused()
                    ? this.getNextEntryAt(direction)
                    : Objects.requireNonNullElse(this.getSelected(), this.children().getFirst());
            default -> null;
        };

        return next == null ? null : ListPath.path(this, next);
    }

    record ListPath(PackList component, io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry child, boolean scroll, boolean select) implements class_8016 {
        static ListPath path(PackList component, io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry child) {
            return new ListPath(component, child, true, true);
        }

        @Override
        public void method_48195(boolean focused) {
            this.child.method_25365(focused);
            if (!focused) {
                this.component.method_25395(null);
                return;
            }
            this.component.method_25395(this.child);
            if (this.scroll) {
                this.component.scrollToEntry(this.child);
            }
            if (this.select && !this.child.viewModel.selectedLast()) {
                this.child.viewModel.select();
            }
        }
    }

    private void selectOnKeyPress(@Nullable io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry) {
        if (entry == null) return;
        if (isRangeModifierActive()) {
            entry.viewModel.selectRange();
        } else {
            entry.viewModel.selectExclusive();
        }
        this.method_25395(entry);
        this.scrollToEntry(entry);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (isSelectAll(keyCode, modifiers)) {
            this.viewModel.selectAll();
            return true;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (isUp(keyCode) || isDown(keyCode)) {
            this.selectOnKeyPress(this.getNextEntryAt(isUp(keyCode) ? class_8028.field_41826 : class_8028.field_41827));
            return true;
        }
        if (isHome(keyCode) || isEnd(keyCode)) {
            if (this.method_25396().isEmpty()) return true;
            this.selectOnKeyPress(isHome(keyCode) ? this.method_25396().getFirst() : this.method_25396().getLast());
            return true;
        }
        if (isPageUp(keyCode) || isPageDown(keyCode)) {
            if (this.method_25396().isEmpty()) return true;
            int pageSize = Math.max(1, this.method_25364() / this.getItemHeight());
            io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry selected = firstNonNull(this.method_25336(), this.method_25334());
            int currentIndex = selected != null ? this.method_25396().indexOf(selected) : 0;
            int targetIndex = isPageUp(keyCode)
                    ? Math.max(0, currentIndex - pageSize)
                    : Math.min(this.method_25396().size() - 1, currentIndex + pageSize);
            io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry = this.method_25396().get(targetIndex);
            this.selectOnKeyPress(entry);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (this.method_53812(button)) this.method_25318(mouseX, mouseY, button - 1); // resets scrolling
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.method_53812(button)) this.method_25318(mouseX, mouseY, button);
        return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) || ((AbstractSelectionListAccessor) this).packed_packs$scrolling();
    }

    @Override
    public @NotNull List<io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry> method_25396() {
        return this.field_22739;
    }

    @Override
    protected void method_25311(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.viewModel.isFolderOpened()) return;

        super.method_25311(guiGraphics, mouseX, mouseY, partialTick);

        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry focused = this.method_25336();
        if (focused != null && this.method_25396().contains(focused)) {
            int outlineTop = focused.method_46427() - io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry.BACKGROUND_MARGIN;
            int outlineHeight = focused.method_25364() + io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry.BACKGROUND_MARGIN * 2;
            guiGraphics.method_49601(focused.method_46426(), outlineTop, focused.method_25368(), outlineHeight, Theme.WHITE.getARGB());
        }
    }

    @Override
    protected void method_44397(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int index, int left, int top, int width, int height) {
        io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry entry = this.method_25326(index);
        entry.ensureInitialized();
        entry.method_25343(guiGraphics, index, top, left, width, height, mouseX, mouseY, Objects.equals(this.method_37019(), entry), partialTick);
    }

    public class Entry extends AbstractFixedListWidget<io.github.fishstiz.packed_packs.gui.components.pack.PackList.Entry>.Entry implements SelectableEntry, ContainerEventHandlerPatch, ContextMenuContainer {
        private static final int BACKGROUND_MARGIN = 1;
        private static final int H_SPACING = 2;
        private static final int ICON_SIZE = ITEM_HEIGHT;
        private static final class_7919 FOLDER_OPEN_INFO = class_7919.method_47407(FolderPack.FOLDER_OPEN_TEXT);
        private static final ColoredRect SELECTED_OVERLAY = new ColoredRect(Theme.BLUE_500.withAlpha(0.25F));
        private static final Sprite SELECT_HIGHLIGHTED_SPRITE = GuiSprite.of32(getVanilla("transferable_list/select_highlighted"));
        private static final Sprite SELECT_SPRITE = GuiSprite.of32(getVanilla("transferable_list/select"));
        private static final Sprite UNSELECT_HIGHLIGHTED_SPRITE = GuiSprite.of32(getVanilla("transferable_list/unselect_highlighted"));
        private static final Sprite UNSELECT_SPRITE = GuiSprite.of32(getVanilla("transferable_list/unselect"));
        private static final Sprite MOVE_UP_HIGHLIGHTED_SPRITE = GuiSprite.of32(getVanilla("transferable_list/move_up_highlighted"));
        private static final Sprite MOVE_UP_SPRITE = GuiSprite.of32(getVanilla("transferable_list/move_up"));
        private static final Sprite MOVE_DOWN_HIGHLIGHTED_SPRITE = GuiSprite.of32(getVanilla("transferable_list/move_down_highlighted"));
        private static final Sprite MOVE_DOWN_SPRITE = GuiSprite.of32(getVanilla("transferable_list/move_down"));
        private final PackListViewModel.Entry viewModel;
        private final MouseSelectionHandler selectionHandler;
        private final List<class_364> children = new ObjectArrayList<>();
        private final List<class_4068> renderables = new ObjectArrayList<>();
        private final List<class_4068> topRenderables = new ObjectArrayList<>();
        private @Nullable PackWidget packWidget;
        private @Nullable FidgetzButton<Void> folderWidget;
        private @Nullable PackListDevMenu devMenu;
        private boolean initialized;

        Entry(PackListViewModel.Entry viewModel, int index) {
            super(index);
            this.viewModel = viewModel;
            this.selectionHandler = new MouseSelectionHandler(this, viewModel::selected, viewModel::selectedLast, viewModel::selectedExclusive);
        }

        private void ensureInitialized() {
            if (!this.initialized) this.init();
        }

        private void init() {
            this.packWidget = this.addRenderableOnly(new PackWidget(PackList.this.field_22740, this.viewModel, ITEM_HEIGHT, H_SPACING));
            this.folderWidget = this.addTopLayer(this.viewModel.folder().flatMap(pack ->
                    PreferenceToggle.bind(Preferences.FOLDER_PACK_WIDGET, FidgetzButton.<Void>builder())
                            .map(bound -> bound.value().setTooltip(FOLDER_OPEN_INFO)
                                    .setHeight(this.packWidget.method_25364() / 3)
                                    .makeSquare()
                                    .setContextMenuBuilder(bound.apply(toggle -> (btn, b) -> toggle.updateBuilder(b)))
                                    .setForeground(bound.toggle())
                                    .setSprite(HAMBURGER_SPRITE)
                                    .setOnPress(this.viewModel::openFolder)
                                    .build())).orElse(null));

            if (PackList.this.screenContext.devMode()) {
                this.devMenu = this.viewModel.devMenu(PackList.this.field_22740);
            }

            this.initialized = true;

            InitializePackEntryEvent event = new InitializePackEntryEvent(PackList.this.screenContext, this.viewModel, this, this::addTopLayer);
            PackedPacksApiImpl.getInstance().eventBus().post(event);
        }

        public class_3288 pack() {
            return this.viewModel.pack();
        }

        public <T extends class_4068> T addRenderableOnly(T renderable) {
            if (renderable == null) return null;
            this.renderables.add(renderable);
            return renderable;
        }

        public <T extends class_364> T prependWidget(T widget) {
            if (widget == null) return null;
            this.children.addFirst(widget);
            return widget;
        }

        public <T extends class_4068> T addTopRenderableOnly(T renderable) {
            if (renderable == null) return null;
            this.topRenderables.add(renderable);
            return renderable;
        }

        public <T extends class_364 & class_4068> T addTopLayer(T widget) {
            if (widget == null) return null;
            return this.addTopRenderableOnly(this.prependWidget(widget));
        }

        private boolean handleMouseAction(MouseSelectionHandler.Action action) {
            if (!action.shouldDispatch()) return false;

            switch (action) {
                case SELECT -> this.viewModel.select();
                case SELECT_TOGGLE -> this.viewModel.selectToggle();
                case SELECT_EXCLUSIVE -> this.viewModel.selectExclusive();
                case SELECT_RANGE -> this.viewModel.selectRange();
                case DRAG -> this.viewModel.drag();
                case TRANSFER -> {
                    this.viewModel.transfer();
                    return false;
                }
            }

            return true;
        }

        private boolean isFocusedOrSelected() {
            return PackList.this.method_25336() == null ? this.viewModel.selectedLast() : this.method_25370();
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return PackList.this.beforeScrollbarX(mouseX) && super.method_25405(mouseX, mouseY);
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) || isRightClick(button)) {
                if (!PackList.this.viewModel.isFolderOpened()) return true;
                // ideally folderWidget should return false on #shouldTakeFocusAfterInteraction,
                // but that does not exist on older versions
                this.method_25395(null);
                return false;
            }

            if (isLeftClick(button)) {
                int relativeX = (int) mouseX - (this.method_46426() + H_SPACING);
                int relativeY = (int) mouseY - (this.method_46427() + BACKGROUND_MARGIN);

                if (this.viewModel.canEnable() && this.mouseOverIcon(relativeX, relativeY, ICON_SIZE)) {
                    this.viewModel.enable();
                    return false;
                }

                if (this.viewModel.canDisable() && this.mouseOverLeftHalf(relativeX, relativeY, ICON_SIZE)) {
                    this.viewModel.disable();
                    return false;
                }

                if (this.viewModel.canMoveUp() && this.mouseOverTopRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    this.viewModel.moveUp();
                    return false;
                }

                if (this.viewModel.canMoveDown() && this.mouseOverBottomRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    this.viewModel.moveDown();
                    return false;
                }
            }

            return this.handleMouseAction(this.selectionHandler.mouseClicked(mouseX, mouseY, button));
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return this.handleMouseAction(this.selectionHandler.mouseReleased(mouseX, mouseY, button));
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            return this.handleMouseAction(this.selectionHandler.mouseDragged(mouseX, mouseY, button, dragX, dragY));
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (super.method_25404(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (isExpandFolder(keyCode, modifiers) && this.viewModel.folder().isPresent() && this.viewModel.selectedExclusive()) {
                this.viewModel.openFolder();
                return true;
            }
            if (isTransfer(keyCode, modifiers) && PackList.this.viewModel.supportsTransferring()) {
                this.viewModel.transfer();
                return true;
            }
            if (isMoveDown(keyCode, modifiers) && PackList.this.viewModel.supportsReordering()) {
                this.viewModel.moveDown();
                return true;
            }
            if (isMoveUp(keyCode, modifiers) && PackList.this.viewModel.supportsReordering()) {
                this.viewModel.moveUp();
                return true;
            }
            if (isOpenFile(keyCode, modifiers)) {
                PackUtil.openPack(this.pack());
                return true;
            }
            if (isOpenFolder(keyCode, modifiers)) {
                PackUtil.openParent(this.pack());
                return true;
            }
            if (isDelete(keyCode, modifiers) && this.viewModel.fileModifiable()) {
                this.viewModel.delete();
                return true;
            }
            if (isRename(keyCode, modifiers) && this.viewModel.fileModifiable()) {
                this.viewModel.openRename();
                return true;
            }
            return false;
        }

        private void renderBack(@NotNull class_332 guiGraphics, int top, int left, int width, int height) {
            if (!this.pack().method_14460().method_14437() && !this.viewModel.incompatibleWarningsHidden()) {
                guiGraphics.method_25294(left, top, left + width, top + height, Theme.RED_900.getARGB());
            }
        }

        private void updateCursor(boolean hovered) {
            if (hovered) {
                MinecraftCursor.get().setPointingHand();
            }
        }

        private void renderForeground(class_332 guiGraphics, int top, int left, int mouseX, int mouseY, boolean hovering) {
            if (!hovering && !this.viewModel.selectedLast()) return;

            int x = left + H_SPACING;
            int relativeX = mouseX - x;
            int relativeY = mouseY - top;

            WHITE_OVERLAY.render(guiGraphics, x, top, ICON_SIZE, ICON_SIZE);

            if (this.viewModel.canEnable()) {
                boolean hovered = hovering && this.mouseOverIcon(relativeX, relativeY, ICON_SIZE);
                pick(hovered, SELECT_HIGHLIGHTED_SPRITE, SELECT_SPRITE).render(guiGraphics, x, top);
                this.updateCursor(hovered);
            }

            if (this.viewModel.canDisable()) {
                boolean hovered = hovering && this.mouseOverLeftHalf(relativeX, relativeY, ICON_SIZE);
                pick(hovered, UNSELECT_HIGHLIGHTED_SPRITE, UNSELECT_SPRITE).render(guiGraphics, x, top);
                this.updateCursor(hovered);
            }

            if (this.viewModel.canMoveUp()) {
                boolean hovered = hovering && this.mouseOverTopRightQuarter(relativeX, relativeY, ICON_SIZE);
                pick(hovered, MOVE_UP_HIGHLIGHTED_SPRITE, MOVE_UP_SPRITE).render(guiGraphics, x, top);
                this.updateCursor(hovered);
            }

            if (this.viewModel.canMoveDown()) {
                boolean hovered = hovering && this.mouseOverBottomRightQuarter(relativeX, relativeY, ICON_SIZE);
                pick(hovered, MOVE_DOWN_HIGHLIGHTED_SPRITE, MOVE_DOWN_SPRITE).render(guiGraphics, x, top);
                this.updateCursor(hovered);
            }
        }

        private void renderSelection(class_332 guiGraphics, int top, int left, int width, int height) {
            if (this.viewModel.selected()) {
                int xtTop = top - BACKGROUND_MARGIN;
                int xtHeight = height + BACKGROUND_MARGIN * 2;
                pick(this.viewModel.selectedLast(), WHITE_OVERLAY, SELECTED_OVERLAY).render(guiGraphics, left, xtTop, width, xtHeight);
                guiGraphics.method_49601(left, xtTop, width, xtHeight, Theme.BLUE_500.getARGB());
            }
        }

        private void renderTop(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
            if (this.folderWidget != null) {
                int folderWidgetY = this.getBottom() - this.folderWidget.method_25364() - BACKGROUND_MARGIN;
                this.folderWidget.method_48229(this.packWidget.getContentLeft(), folderWidgetY);
            }

            if (!this.topRenderables.isEmpty()) {
                guiGraphics.method_51448().method_22903();
                guiGraphics.method_51448().method_46416(0, 0, 1f);
                for (class_4068 renderable : this.topRenderables) {
                    renderable.method_25394(guiGraphics, mouseX, mouseY, partialTick);
                }
                guiGraphics.method_51448().method_22909();
            }
        }

        public void renderContent(@NotNull class_332 guiGraphics, int mouseX, int mouseY, boolean hovering, float partialTick) {
            hovering = hovering && PackList.this.beforeScrollbarX(mouseX) && GuiUtil.isHovered(this, mouseX, mouseY);

            int left = this.method_46426();
            int top = this.method_46427();
            int width = this.method_25368();
            int height = this.method_25364();
            int innerTop = top + BACKGROUND_MARGIN;

            this.packWidget.method_48229(left, innerTop);
            this.packWidget.setWidth(width);

            this.renderBack(guiGraphics, top, left, width, height);

            this.packWidget.checkCompatibility(hovering || this.isFocusedOrSelected());

            for (class_4068 renderable : this.renderables) {
                renderable.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }

            this.renderSelection(guiGraphics, top, left, width, height);
            this.renderForeground(guiGraphics, innerTop, left, mouseX, mouseY, hovering);
            this.renderTop(guiGraphics, mouseX, mouseY, partialTick);

            if (this.devMenu != null) {
                guiGraphics.method_51448().method_22903();
                guiGraphics.method_51448().method_46416(0, 0, 1f);
                this.devMenu.render(guiGraphics, innerTop, left, width, height, partialTick);
                guiGraphics.method_51448().method_22909();
            }
        }

        @Override
        public void method_25343(@NotNull class_332 guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            this.renderContent(guiGraphics, mouseX, mouseY, hovering, partialTick);
        }

        @Override
        public void buildItems(ContextMenuItemBuilder builder, int mouseX, int mouseY) {
            if (!this.initialized) return;

            var extensions = ContextMenuEventImpl.postPackEntry(PackList.this.screenContext, this.viewModel);

            ContextMenuContainer.super.buildItems(builder
                            .whenNonNull(extensions.getItems(ContextMenuEvent.PackEntry.Pos.BEFORE_HEADER))
                            .ifTrue((items, b) -> b.addAll(items))
                            .add(new PackMenuHeader(this.pack(), this.viewModel.sprite()))
                            .whenNonNull(extensions.getItems(ContextMenuEvent.PackEntry.Pos.AFTER_HEADER))
                            .ifTrue((items, b) -> b.addAll(items))
                            .whenNonNull(this.devMenu)
                            .ifTrue((menu, b) -> menu.buildItems(b, mouseX, mouseY))
                            .whenNonNull(extensions.getItems(ContextMenuEvent.PackEntry.Pos.AFTER_DEV))
                            .ifTrue((items, b) -> b.addAll(items))
                            .whenNonNull(this.folderWidget)
                            .ifTrue(b -> b
                                    .simpleItem(FolderPack.FOLDER_OPEN_TEXT, this.viewModel::openFolder)
                                    .separator()
                            )
                            .when(this.viewModel.fileModifiable())
                            .ifTrue(b -> b
                                    .simpleItem(RENAME_FILE_TEXT, this.viewModel::fileModifiable, this.viewModel::openRename)
                                    .simpleItem(DELETE_FILE_TEXT, this.viewModel::fileModifiable, this.viewModel::delete)
                                    .simpleItem(OPEN_FILE_TEXT, () -> PackUtil.openPack(this.pack()))
                                    .simpleItem(OPEN_PARENT_TEXT, () -> PackUtil.openParent(this.pack()))
                            )
                            .whenNonNull(extensions.getItems(ContextMenuEvent.PackEntry.Pos.AFTER_PACK))
                            .ifTrue((items, b) -> b.addAll(items)),
                    mouseX,
                    mouseY
            );
        }

        @Override
        public @NotNull List<class_364> method_25396() {
            return this.children;
        }

        @Override
        public @NotNull List<class_6379> method_37025() {
            return Collections.emptyList();
        }

        @Override
        public int method_46427() {
            return super.method_46427() - BACKGROUND_MARGIN;
        }

        @Override
        public int method_25364() {
            return super.method_25364() + BACKGROUND_MARGIN * 2;
        }
    }
}
