package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.Justification;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.states.PackListKey;
import io.github.fishstiz.packed_packs.gui.states.PackListType;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.states.PackListState;
import io.github.fishstiz.packed_packs.gui.actions.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.states.PackListComputed;
import io.github.fishstiz.packed_packs.pack.PackIconCache;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksContext;
import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.gui.states.ProfileSelection;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8023.class_8024;
import net.minecraft.class_8023.class_8025;
import net.minecraft.class_8023.class_8026;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;
import static net.minecraft.class_8023.*;

public class PackListContainer extends class_339 implements FocusPathProvider, class_8133, ContainerEventHandlerPatch {
    private final @Nullable PackListContainer head;
    private final PackedPacksContext context;
    private final PackList packList;
    private final PackListComputed state;
    private @Nullable Folder folder;
    private @Nullable class_364 focused;
    private boolean dragging;
    private List<class_364> children;
    private boolean entriesDirty;

    private PackListContainer(@Nullable PackListContainer head, PackedPacksContext context, PackListComputed state) {
        super(0, 0, 0, 0, class_5244.field_39003);
        this.head = head;
        this.context = context;
        this.state = state;
        this.packList = new PackList(context, state);
        this.children = List.of(this.packList);
    }

    private PackListContainer(PackListContainer head, PackListKey key) {
        this(head, head.context, new PackListComputed(key));
    }

    public static PackListContainer createHead(PackedPacksContext context, PackListType type) {
        PackListKey key = PackListKey.head(type);
        PackListComputed computed = new PackListComputed(
                key,
                context.state().value().getHeadList(type),
                context.state().value().profiles()
        );

        PackListContainer root = new PackListContainer(null, context, computed);

        context.state().subscribe(
                "PackListContainer@" + key,
                value -> {
                    root.onStateChanged(value.getHeadList(type), value.profiles(), type.available());
                    root.onStateChanged(value.dragging());
                }
        );

        return root;
    }

    private void updateChild(class_364 target) {
        this.children = List.of(target);
        if (method_25399() != null) {
            method_25395(target);
        }
    }

    private void onStateChanged(ActiveAction.@Nullable Dragging dragging) {
        state.onDrag(dragging);

        if (folder != null) {
            folder.listContainer.onStateChanged(dragging);
        }
    }

    private void onStateChanged(PackListState newState, ProfileSelection newProfiles, boolean folderUnlockable) {
        PackListState prev = this.state.state();
        ProfileSelection prevProfiles = this.state.profiles();

        if (prev == newState && newProfiles == prevProfiles) {
            return;
        }

        this.state.onStateChanged(newState, newProfiles);

        PackListState folderState = newState.folder();

        if ((folderState == null) != (this.folder == null)) {
            if (folderState != null) {
                Folder newFolder = new Folder(head == null ? this : head, this.state.key().nest(), folderState);
                this.folder = newFolder;
                updateChild(newFolder);
                class_8016 path = newFolder.method_48205(new class_8025());
                if (path != null) path.method_48195(true);
            } else {
                this.folder.onClose();
                this.folder = null;
                updateChild(packList);
            }
        }

        if (this.folder != null && folderState != null) {
            this.folder.onStateChanged(folderState, newProfiles, folderUnlockable && !newState.module());
            entriesDirty = entriesDirty || prev.visiblePacks() != newState.visiblePacks() || prevProfiles != newProfiles;
        } else if (entriesDirty || prev.visiblePacks() != newState.visiblePacks() || prevProfiles != newProfiles) {
            packList.rebuildEntries();
            entriesDirty = false;
        }
    }

    public boolean extractDropCandidateRenderState(
            class_332 graphics,
            ActiveAction.Dragging dragging,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        PackListContainer leafContainer = this;

        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if ((leafContainer.packList.extractDropCandidateRenderState(graphics, dragging, mouseX, mouseY, partialTick)
             || dragging.src().equals(leafContainer.state.key()))
            && leafContainer.packList.method_49606()) {
            return true;
        }

        PackListContainer root = this.head == null ? this : this.head;
        if (state.key().type().available() && !state.isLocked() && state.canDrop(0)) {
            renderDropToDisabledZone(root, graphics);
            return root.method_49606();
        }

        return false;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        packList.method_25394(graphics, mouseX, mouseY, partialTick);
        if (this.folder != null) {
            this.folder.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
        if (this.folder != null) {
            this.folder.listContainer.method_37020(output.method_37031());
        } else {
            packList.method_37020(output.method_37031());
        }
    }

    public void visitLeafList(Consumer<PackList> visitor) {
        if (state.state().folder() != null && this.folder != null) {
            this.folder.listContainer.visitLeafList(visitor);
        } else {
            visitor.accept(packList);
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        if (state.isLocked()) {
            context.dispatch(new PackListIntent.Drop(dragging.src()));
            return;
        }

        PackListContainer leafContainer = this;
        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if (state.key().type().enabled()) {
            leafContainer.packList.onDrop(dragging, mouseX, mouseY);
            return;
        }

        boolean dropCandidate = leafContainer.state.isDropCandidate() || dragging.src().equals(leafContainer.state.key());
        if (leafContainer.packList.method_49606() && dropCandidate) {
            leafContainer.packList.onDrop(dragging, mouseX, mouseY);
            return;
        }

        context.dispatch(new PackListIntent.Drop(dragging.src(), state.key(), 0));
    }

    @Override
    public List<class_364> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean isDragging) {
        this.dragging = isDragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        } else {
            method_25395(this.folder == null ? packList : this.folder);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }
            if (focused != null) {
                focused.method_25365(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        FocusPathProvider child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.getFocusPath(target));
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        class_364 child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.method_48205(event));
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        if (head == null) {
            packList.method_53533(height);
        }
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        if (head == null) {
            packList.method_25358(width);
        }
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        if (head == null) {
            packList.method_46421(x);
        }
        repositionFolder();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        if (head == null) {
            packList.method_46419(y);
        }
        repositionFolder();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        method_25358(width);
        method_53533(height);
    }

    @Override
    public void method_48229(int x, int y) {
        super.method_48229(x, y);
        method_46421(x);
        method_46419(y);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public void method_48227(Consumer<class_8021> visitor) {
        visitor.accept(this);
    }

    @Override
    public void method_48222() {
        packList.initializeEntries();
        if (this.folder != null) this.folder.arrangeElements();
    }

    private void repositionFolder() {
        if (this.folder != null) this.folder.repositionElements();
    }

    public void rebuildEntries() {
        packList.rebuildEntries();
        if (folder != null) {
            folder.listContainer.rebuildEntries();
        }
    }

    static class Folder extends class_362 implements FocusPathProvider, FZContextMenu.Source, ContainerEventHandlerPatch, class_4068, FZComponent {
        private static final int HEADER_SIZE = 16;
        private static final int LAYOUT_SPACING = SPACING / 2;
        private final PackListContainer root;
        private final FZIcon background;
        private final PackListContainer listContainer;
        private final FZText folderTitle;
        private final FZButton recallButton;
        private final FZIconButton lockButton;
        private final WrappedLayout<FZFlexLayout> header;
        private final FZLayout layout;
        private PackListState folderState;
        private PackNode.Parent parent;
        private List<class_364> children = Collections.emptyList();
        private List<class_4068> renderables = Collections.emptyList();
        private boolean childOpened;
        private boolean closed;

        Folder(PackListContainer head, PackListKey key, PackListState state) {
            this.root = head;
            this.folderState = state;
            this.parent = Objects.requireNonNull(state.parent(), "folder parent cannot be null");
            this.listContainer = new PackListContainer(head, key);
            this.background = FZIcon.builder(class_2960.method_60656("popup/background")).build();
            FZIconButton closeButton = FZIconButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .icon(new WidgetElements(key.depth() > 1 ? ARROW_UP_SPRITE : CROSS_SPRITE, 16, 16))
                    .onPress(() -> head.context.dispatch(new PackListIntent.CloseFolder(key.unnest())))
                    .focusOnInteraction(false)
                    .build();
            PackIconCache iconCache = head.context.iconCache();
            FZIcon folderIcon = FZIcon.builder(GuiUtils.lazyTexture(() -> iconCache.get(this.parent), 16, 16))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .build();
            this.folderTitle = FZText.builder(parent.title())
                    .height(HEADER_SIZE)
                    .build();
            this.recallButton = FZButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .message(class_2561.method_43470("<<"))
                    .tooltip(class_2561.method_43471("packed_packs.folder.recall"))
                    .visible(key.type().available())
                    .onPress(() -> head.context.dispatch(new PackListIntent.Recall(key, this.parent)))
                    .build();
            this.lockButton = FZIconButton.builder()
                    .icon(new WidgetElements(
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL),
                            Renderables.sprite(LOCK_SPRITE_SMALL),
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL),
                            16,
                            16
                    ))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .onPress(() -> head.context.dispatch(
                            new PackListIntent.UpdateModule(key, this.parent, !this.folderState.module())
                    ))
                    .build();

            FZFlexLayout section = FZFlexLayout.vertical(head).spacing(LAYOUT_SPACING);
            {
                FZFlexLayout header = section.child(FZFlexLayout.horizontal(), section.flexChildHorizontalSettings());
                {
                    FZFlexLayout wrapped = FZFlexLayout.horizontal();
                    wrapped.spacing(LAYOUT_SPACING).alignContents(Justification.CENTER);
                    wrapped.child(closeButton);
                    wrapped.child(folderIcon);
                    wrapped.child(folderTitle, wrapped.flexChildHorizontalSettings());
                    wrapped.child(recallButton);
                    wrapped.child(lockButton);

                    this.header = header.child(WrappedLayout.wrap(wrapped), header.flexChildHorizontalSettings());
                }
                section.child(listContainer.packList, section.flexChildSettings());
            }

            this.layout = FZComposedLayout.compose(section).padding(SPACING).clamp(head::method_48202);

            arrangeElements();
            updateChildren();
        }

        private void updateChildren() {
            if (folderState.folder() == null) {
                this.renderables = List.of(background, header, listContainer);
                this.children = List.of(header, listContainer);
                this.childOpened = false;
            } else {
                this.renderables = List.of(listContainer);
                this.children = List.of(listContainer);
                this.childOpened = true;
            }
        }

        private void onStateChanged(PackListState folderState, ProfileSelection profiles, boolean unlockable) {
            PackListState prevFolderState = this.folderState;
            this.folderState = folderState;

            lockButton.field_22763 = unlockable && !profiles.isLocked();
            recallButton.field_22763 = !folderState.module() && !profiles.isLocked();

            if (prevFolderState.parent() != folderState.parent()) { // I don't think this will ever be true, but just in case
                this.parent = Objects.requireNonNull(folderState.parent(), "folder parent cannot be null");
                folderTitle.method_25355(parent.title());
            }
            if ((prevFolderState.folder() == null) != (folderState.folder() == null)) {
                updateChildren();
            }

            listContainer.onStateChanged(folderState, profiles, unlockable);
        }

        private void onClose() {
            this.closed = true;

            listContainer.context.resources().saveFolderMetadata(this.parent);

            if (listContainer.folder != null) {
                listContainer.folder.onClose();
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            for (class_4068 renderable : this.renderables) {
                renderable.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            PackNode.Parent pack = this.parent;

            if (this.childOpened) {
                FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
                return;
            }

            collector.addEntry(builder -> builder
                    .message(pack.title())
                    .icon(padded16Rect(Renderables.texture(listContainer.context.iconCache().get(pack), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false));

            collector.addEntry(builder -> builder
                    .message(class_5244.field_24339.method_27661().method_10852(class_5244.field_39678))
                    .onPress(() -> root.context.dispatch(new PackListIntent.CloseFolder(listContainer.state.key().unnest()))));

            if (!listContainer.packList.method_49606()) {
                if (listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack)) {
                    collector.addEntry(builder -> builder
                            .message(RENAME_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.OpenRenameModal(listContainer.state.key(), pack))));
                    collector.addEntry(builder -> builder
                            .message(DELETE_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.Delete(listContainer.state.key(), pack))));
                }

                collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(pack.path())));
                collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(pack.path())));
            }

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        void repositionElements() {
            if (root.method_46426() != 0 && (layout.method_46426() != root.method_46426())
                || root.method_46427() != 0 && (layout.method_46427() != root.method_46427())) {
                listContainer.method_48229(root.method_46426(), root.method_46427());
                layout.method_48229(root.method_46426(), root.method_46427());
                background.method_48229(root.method_46426(), root.method_46427());
            }
        }

        void arrangeElements() {
            if ((root.method_25368() != 0 && layout.method_25368() != root.method_25368())
                || (root.method_25364() != 0 && layout.method_25364() != root.method_25364())) {
                listContainer.method_55445(root.method_25368(), root.method_25364());
                layout.fidgetz$setSize(root.method_25368(), root.method_25364());
                background.method_55445(root.method_25368(), root.method_25364());
            }

            repositionElements();
        }

        @Override
        public @Nullable class_8016 getFocusPath(FocusTarget target) {
            return class_8016.method_48192(this, listContainer.getFocusPath(target));
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 event) {
            if (this.childOpened) {
                return class_8016.method_48192(this, listContainer.method_48205(event));
            }

            if (event instanceof class_8025) {
                class_8016 path = listContainer.method_48205(event);
                return path == null ? class_8016.method_48192(this, NavigationUtils.initialFocus(header)) : class_8016.method_48192(this, path);
            }

            class_364 focused = this.method_25399();
            if (focused != null) {
                if (event instanceof class_8024 arrowNavigation && (focused == this.header || focused == this.listContainer)) {
                    class_8028 direction = arrowNavigation.comp_1191();
                    class_8016 inner = focused.method_48205(event);
                    if (inner != null) {
                        return class_8016.method_48192(this, inner);
                    }

                    if (focused == this.header ? direction == class_8028.field_41827 : direction == class_8028.field_41826) {
                        class_364 target = focused == this.header ? this.listContainer : this.header;
                        class_8016 path = target.method_48205(arrowNavigation);
                        if (path != null) {
                            return class_8016.method_48192(this, path);
                        }
                    }

                    return class_8016.method_48192(this, focused.method_48205(event));
                } else if (event instanceof class_8026) {
                    return super.method_48205(event);
                } else {
                    return class_8016.method_48192(this, focused.method_48205(event));
                }
            }

            if (!(event instanceof class_8024(class_8028 direction))) {
                return super.method_48205(event);
            }

            boolean headerFirst = direction == class_8028.field_41827;
            class_364 first = headerFirst ? this.header : this.listContainer;
            class_364 second = headerFirst ? this.listContainer : this.header;

            class_8016 path = first.method_48205(event);
            if (path == null) {
                path = second.method_48205(event);
            }
            if (path != null) {
                return class_8016.method_48192(this, path);
            }

            return super.method_48205(event);
        }

        @Override
        public boolean fidgetz$shouldTakeFocusAfterInteraction() {
            return !closed;
        }

        @Override
        public void method_25365(boolean isFocused) {
            if (!isFocused) {
                method_25395(null);
            }
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (method_25399() != focused) {
                super.method_25395(focused);
            }
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) && !closed;
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return method_48202().method_58137((int) mouseX, (int) mouseY);
        }

        @Override
        public List<class_364> method_25396() {
            return children;
        }

        @Override
        public class_8030 method_48202() {
            return layout.method_48202();
        }
    }
}
