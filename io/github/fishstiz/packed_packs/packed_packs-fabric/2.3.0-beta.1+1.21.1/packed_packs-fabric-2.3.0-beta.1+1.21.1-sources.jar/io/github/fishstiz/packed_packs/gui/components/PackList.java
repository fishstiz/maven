package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.packed_packs.api.context.PackContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializePackEntryEvent;
import io.github.fishstiz.packed_packs.api.gui.ElementSink;
import io.github.fishstiz.packed_packs.compat.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.states.PackListKey;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.actions.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.states.PackListComputed;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksContext;
import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.events.ContextMenuEventImpl;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.PackUtil;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5352;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8028;

import static io.github.fishstiz.packed_packs.util.PackListComputedUtils.sortByOrderOf;
import static io.github.fishstiz.packed_packs.util.GuiUtils.*;
import static io.github.fishstiz.packed_packs.util.InputUtil.*;

public class PackList extends FZAbstractListWidget<PackList.Entry> implements FocusPathProvider, ContainerEventHandlerPatch {
    private static final int INNER_ITEM_PADDING = 2;
    private static final int INNER_ITEM_HEIGHT = 32;
    private static final int ITEM_HEIGHT = INNER_ITEM_HEIGHT + INNER_ITEM_PADDING * 2;
    private static final int DROP_INDEX_PADDING = 3;
    private static final double SCROLL_RATE = (double) ITEM_HEIGHT / 2;
    private final Map<String, io.github.fishstiz.packed_packs.gui.components.PackList.Entry> entries = new Object2ObjectOpenHashMap<>();
    private final PackedPacksContext context;
    private final PackListComputed state;
    private boolean scrolling;
    private boolean initialized;

    public PackList(PackedPacksContext context, PackListComputed state) {
        this.context = context;
        this.state = state;
        setScrollRate(SCROLL_RATE);
    }

    PackListKey key() {
        return state.key();
    }

    boolean module() {
        return state.state().module();
    }

    @Override
    protected int maxContentWidth() {
        return 0;
    }

    @Override
    protected int rowSpacing() {
        return -1;
    }

    void initializeEntries() {
        if (!this.initialized) {
            rebuildEntries();
            this.initialized = true;
        }
    }

    void rebuildEntries() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry previousFocused = this.method_25399();
        double previousScrollAmount = scrollAmount();

        method_25339();
        entries.clear();

        state.forEachEntry((entryState, i) -> {
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = entryState.pack() instanceof PackNode.Leaf leaf
                    ? new LeafEntry(entryState, leaf.pack(), i)
                    : new io.github.fishstiz.packed_packs.gui.components.PackList.Entry(entryState, i);

            addEntry(entry);
            entries.put(entryState.pack().id(), entry);
            if (previousFocused != null && previousFocused.pack.equals(entryState.pack())) {
                method_25395(entry);
            }
        });

        repositionEntries();
        method_25307(previousScrollAmount);
    }

    public void scrollToTop() {
        this.method_25307(0);
    }

    public void scrollToLastSelected() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry selected = getLastSelected();
        if (selected != null) scrollToEntry(selected);
    }

    public void transferAll() {
        if (!state.isLocked()) {
            List<PackNode> packs = state.state().visiblePacks();
            List<PackNode> payload = new ObjectArrayList<>(packs.size());
            for (PackNode pack : packs) {
                io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = entries.get(pack.id());
                if (entry != null && entry.state.canTransfer()) {
                    payload.add(pack);
                }
            }
            if (!payload.isEmpty()) {
                List<PackNode> orderedPayload = sortByOrderOf(packs, payload).reversed();
                context.dispatch(switch (key().type()) {
                    case AVAILABLE -> new PackListIntent.Enable(key(), orderedPayload.getFirst(), orderedPayload);
                    case ENABLED -> new PackListIntent.Disable(key(), orderedPayload.getFirst(), orderedPayload);
                });
            }
        }
    }

    private int getDropIndex(double mouseY) {
        if (method_25396().isEmpty()) return -1;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = method_37019();
        if (entry == null) return -1;

        int index = entry.index;

        int centerY = entry.getY() + (entry.getHeight() / 2);
        if (mouseY >= centerY) {
            int next = index + 1;
            return next < method_25396().size() ? next : -1;
        }

        return index;
    }

    private boolean isMouseOverSelectionEntry(SequencedCollection<PackNode> selection, double mouseX, double mouseY, int index) {
        if (index < 0 || index >= method_25396().size()) return false;
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = method_25396().get(index);
        return entry.method_25405(mouseX, mouseY) && selection.contains(entry.pack);
    }

    private boolean isMouseOverSelection(SequencedCollection<PackNode> selection, double mouseX, double mouseY, int index) {
        return isMouseOverSelectionEntry(selection, mouseX, mouseY, index - 1) || isMouseOverSelectionEntry(selection, mouseX, mouseY, index);
    }

    private boolean canDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY, int index) {
        if (this.scrolling || (dragging.src().equals(key()) && isMouseOverSelection(dragging.packs(), mouseX, mouseY, index))) {
            return false;
        }
        return state.canDrop(index);
    }

    private void renderDroppableSlots(
            class_332 graphics,
            ActiveAction.Dragging dragging,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        int x = method_46426();
        int y = method_46427();
        int width = method_57717() ? method_25368() - scrollbarWidth() : method_25368();
        int height = method_25364();
        int bottom = method_55443();

        if (method_49606()) {
            double scrollAmount = scrollAmount();

            int scrollDownY = bottom - INNER_ITEM_HEIGHT;
            if (scrollAmount < maxScrollAmount() && mouseY >= scrollDownY) {
                graphics.method_25296(x, scrollDownY, x + width, scrollDownY + INNER_ITEM_HEIGHT, DROP_ENABLED_TO_COLOR, DROP_ENABLED_FROM_COLOR);
                scroll(scrollRate() * partialTick);
                this.scrolling = true;
            } else if (scrollAmount > 0 && mouseY <= y + INNER_ITEM_HEIGHT) {
                graphics.method_25296(x, y, x + width, y + INNER_ITEM_HEIGHT, DROP_ENABLED_FROM_COLOR, DROP_ENABLED_TO_COLOR);
                scroll(-(scrollRate() * partialTick));
                this.scrolling = true;
            } else {
                this.scrolling = false;
            }

            int index = getDropIndex(mouseY);
            if (canDrop(dragging, mouseX, mouseY, index)) {
                int rowTop;
                if (index != -1) {
                    rowTop = method_25396().get(index).getY();
                } else {
                    io.github.fishstiz.packed_packs.gui.components.PackList.Entry last = method_25396().isEmpty() ? null : method_25396().getLast();
                    rowTop = last == null ? method_55443() : last.getY() + last.getHeight();
                }

                rowTop = Math.clamp(rowTop, method_46427() + DROP_INDEX_PADDING, method_55443() - DROP_INDEX_PADDING);
                int indexY = rowTop - DROP_INDEX_PADDING;

                graphics.method_44379(method_46426(), method_46427(), method_55442(), method_55443());
                graphics.method_25294(x, indexY, x + width, indexY + (rowTop - indexY + DROP_INDEX_PADDING), DROP_ENABLED_COLOR);
                graphics.method_44380();
            }
        }

        graphics.method_49601(x, y, width, height, DROP_ENABLED_COLOR);
    }

    private void renderDroppableRect(class_332 graphics) {
        if (state.isDropCandidate() && state.canDrop(0)) {
            renderDropToDisabledZone(this, graphics);
        }
    }

    boolean extractDropCandidateRenderState(
            class_332 graphics,
            ActiveAction.Dragging dragging,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        if (!state.isLocked() && state.isDropCandidate()) {
            if (state.canReorder()) {
                renderDroppableSlots(graphics, dragging, mouseX, mouseY, partialTick);
            } else {
                renderDroppableRect(graphics);
            }
            return true;
        }
        return false;
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        int index = getDropIndex(mouseY);
        if (canDrop(dragging, mouseX, mouseY, index)) {
            context.dispatch(new PackListIntent.Drop(dragging.src(), key(), index));
        } else {
            context.dispatch(new PackListIntent.Drop(dragging.src(), null, 0));
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry previous = method_25399();
        if (previous != focused) {
            super.method_25395(focused);
            if (previous != null && previous.packWidget != null) {
                previous.packWidget.checkCompatibility(false);
            }
            if (focused instanceof io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry && entry.packWidget != null) {
                entry.packWidget.checkCompatibility(true);
            }
        }
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getLastSelected() {
        PackNode selected = state.getSelected();
        return selected == null ? null : entries.get(selected.id());
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getFocusedOrSelected() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry focused = method_25399();
        return focused == null ? getLastSelected() : focused;
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getEntry(String packId) {
        return entries.get(packId);
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getNextEntryAt(class_8028 direction) {
        if (method_25396().isEmpty()) return null;
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry selectedEntry = getFocusedOrSelected();
        return switch (direction) {
            case field_41826 -> Objects.equals(selectedEntry, method_25396().getFirst())
                    ? null
                    : getPreviousEntry(selectedEntry);
            case field_41827 -> Objects.equals(selectedEntry, method_25396().getLast())
                    ? null
                    : getNextEntry(selectedEntry);
            case field_41828 -> key().type().available() ? selectedEntry : null;
            case field_41829 -> key().type().enabled() ? selectedEntry : null;
        };
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        if (this.method_25396().isEmpty()) return null;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry targetEntry = switch (target) {
            case FocusTarget.LastSelected ignored -> getLastSelected();
            case FocusTarget.PackEntry entry -> getEntry(entry.packId());
        };

        return targetEntry == null ? null : new ListPath(this, targetEntry, target.scroll(), false);
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        if (method_25396().isEmpty()) return null;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry next = switch (event) {
            case class_8023.class_8025 ignored -> getFocusedOrSelected();
            case class_8023.class_8026 ignored -> method_25370()
                    ? null
                    : Objects.requireNonNullElse(getLastSelected(), method_25396().getFirst());
            case class_8023.class_8024(class_8028 direction) -> method_25370()
                    ? getNextEntryAt(direction)
                    : Objects.requireNonNullElse(getLastSelected(), method_25396().getFirst());
            default -> null;
        };

        return next == null ? null : ListPath.path(this, next);
    }

    record ListPath(PackList component, io.github.fishstiz.packed_packs.gui.components.PackList.Entry child, boolean scroll, boolean select) implements class_8016 {
        static ListPath path(PackList component, io.github.fishstiz.packed_packs.gui.components.PackList.Entry child) {
            return new ListPath(component, child, true, true);
        }

        @Override
        public void method_48195(boolean focused) {
            this.child.method_25365(focused);
            if (!focused) {
                this.component.method_25395(null);
                return;
            }
            this.component.method_25395(this.child);
            if (this.scroll) {
                this.component.scrollToEntry(this.child);
            }
            if (this.select && !this.child.state.isSelectedLast()) {
                this.child.selectPackExclusively();
            }
        }
    }

    private void selectOnKeyPress(@Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry) {
        if (entry == null) return;
        if (isRangeModifierActive()) {
            context.dispatch(new PackListIntent.SelectRange(key(), entry.pack));
        } else {
            context.dispatch(new PackListIntent.SelectExclusive(key(), entry.pack));
        }
        method_25395(entry);
        scrollToEntry(entry);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (isSelectAll(keyCode, modifiers)) {
            context.dispatch(new PackListIntent.SelectAll(key(), state.getSelected()));
            return true;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (isUp(keyCode) || isDown(keyCode)) {
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry nextEntry = getNextEntryAt(isUp(keyCode) ? class_8028.field_41826 : class_8028.field_41827);
            selectOnKeyPress(nextEntry);
            return nextEntry != null;
        }
        if (isHome(keyCode) || isEnd(keyCode)) {
            if (method_25396().isEmpty()) return true;
            selectOnKeyPress(isHome(keyCode) ? method_25396().getFirst() : method_25396().getLast());
            return true;
        }
        if (isPageUp(keyCode) || isPageDown(keyCode)) {
            if (method_25396().isEmpty()) return true;
            int pageSize = Math.max(1, method_25364() / ITEM_HEIGHT);
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry selected = getFocusedOrSelected();
            int currentIndex = selected != null ? method_25396().indexOf(selected) : 0;
            int targetIndex = isPageUp(keyCode)
                    ? Math.max(0, currentIndex - pageSize)
                    : Math.min(method_25396().size() - 1, currentIndex + pageSize);
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = method_25396().get(targetIndex);
            selectOnKeyPress(entry);
            return true;
        }
        return false;
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (!state.isFolderOpened()) {
            super.extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
        }
    }

    class Entry extends FZAbstractListWidget.Entry<io.github.fishstiz.packed_packs.gui.components.PackList.Entry> implements SelectableEntry, ContainerEventHandlerPatch, FZContextMenu.Source, FZComponent, ElementSink {
        private static final int ICON_SIZE = 32;
        private static final class_7919 FOLDER_OPEN_INFO = class_7919.method_47407(FOLDER_OPEN_TEXT);
        private static final RenderableRectangle SELECTED_OVERLAY = Renderables.fill(Colors.alpha(Colors.BLUE_500, 0.25f));
        private static final WidgetRenderables SELECT_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/select")),
                Renderables.sprite(class_2960.method_60656("transferable_list/select_highlighted"))
        );
        private static final WidgetRenderables UNSELECT_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/unselect")),
                Renderables.sprite(class_2960.method_60656("transferable_list/unselect_highlighted"))
        );
        private static final WidgetRenderables MOVE_UP_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/move_up")),
                Renderables.sprite(class_2960.method_60656("transferable_list/move_up_highlighted"))
        );
        private static final WidgetRenderables MOVE_DOWN_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/move_down")),
                Renderables.sprite(class_2960.method_60656("transferable_list/move_down_highlighted"))
        );
        private final int index;
        protected final PackNode pack;
        protected final PackListComputed.Entry state;
        private final MouseStateHandler mouseStateHandler;
        private final List<class_364> children = new ObjectArrayList<>();
        private final List<class_4068> renderables = new ObjectArrayList<>();
        private List<class_8021> rightElements = Collections.emptyList();
        protected @Nullable PackWidget packWidget;
        private @Nullable class_339 folderWidget;
        private @Nullable PackDevMenu devMenu;
        private boolean initialized;

        Entry(PackListComputed.Entry state, int index) {
            super(ITEM_HEIGHT);
            this.index = index;
            this.pack = state.pack();
            this.state = state;
            this.mouseStateHandler = new MouseStateHandler(this);
        }

        @Override
        public int getIndex() {
            return index;
        }

        protected PackListKey key() {
            return PackList.this.state.key();
        }

        protected boolean moduleParent() {
            return module();
        }

        protected boolean isIncompatibleWarningsHidden() {
            return context.configs().user().isIncompatibleWarningsHidden();
        }

        protected boolean isFileModifiable() {
            return context.resources().isModifiable(PackList.this.state.profiles(), pack);
        }

        protected class_2960 getPackIcon() {
            return context.iconCache().get(pack);
        }

        protected void buildWidgets() {
            this.packWidget = new PackWidget(this, INNER_ITEM_HEIGHT);
            repositionPackWidget();

            if (pack instanceof PackNode.Parent) {
                PreferenceHelper.wrap(Preferences.FOLDER_PACK_WIDGET, FZIconButton.builder()
                                .size(INNER_ITEM_HEIGHT / 3, INNER_ITEM_HEIGHT / 3)
                                .icon(new WidgetElements(HAMBURGER_RECT, 8, 8))
                                .tooltip(FOLDER_OPEN_INFO)
                                .focusOnInteraction(false)
                                .onPress(this::expandFolder)
                                .build())
                        .ifPresent(widget -> {
                            int x = method_46426() + PackWidget.ICON_SIZE + INNER_ITEM_PADDING * 2;
                            int y = method_46427() + method_25364() - widget.method_25364() - INNER_ITEM_PADDING;
                            widget.method_48229(x, y);
                            acceptWidget(widget);
                            acceptRenderable(widget);
                            this.folderWidget = widget;
                        });
            }

            if (context.devMode()) {
                this.devMenu = new PackDevMenu(context, PackList.this.state.profiles(), this);
            }
        }

        private void init() {
            if (!this.initialized) {
                this.initialized = true;
                buildWidgets();
            }
        }
        // todo add widgets to navigation path
        @Override
        public void acceptWidget(class_364 widget) {
            if (widget instanceof FZHoverableElement hoverable && widget instanceof class_339 abstractWidget) {
                hoverable.fidgetz$setHovered(abstractWidget.method_49606());
            }
            children.addFirst(widget);
        }

        @Override
        public void acceptRenderable(class_4068 renderable) {
            renderables.add(renderable);
        }

        @Override
        public void acceptElement(class_8021 element) {
            this.rightElements = CollectionUtils.addLast(rightElements, element);
        }

        public void selectPack() {
            if (PackList.this.state.isLocked()) return;
            context.dispatch(new PackListIntent.Select(key(), pack));
        }

        public void selectToggle() {
            if (PackList.this.state.isLocked()) return;
            context.dispatch(new PackListIntent.SelectToggle(key(), pack));
        }

        public void selectTowardsPack() {
            if (PackList.this.state.isLocked()) return;
            context.dispatch(new PackListIntent.SelectRange(key(), pack));
        }

        public void selectPackExclusively() {
            if (PackList.this.state.isLocked()) return;
            context.dispatch(new PackListIntent.SelectExclusive(key(), pack));
        }

        protected List<PackNode> createPayload(BooleanSupplier filter) {
            SequencedCollection<PackNode> selection = PackList.this.state.state().selectedPacks();
            if (!selection.contains(pack)) {
                return filter.getAsBoolean() ? List.of(pack) : Collections.emptyList();
            }

            return CollectionUtils.addIf(new ObjectArrayList<>(selection.size()), selection, ignored -> filter.getAsBoolean());
        }

        protected List<PackNode> createPayload() {
            return state.isSelected() ? List.copyOf(PackList.this.state.state().selectedPacks()) : List.of(pack);
        }

        protected void transferPack() {
            if (!PackList.this.state.isLocked()) {
                List<PackNode> payload = createPayload(state::canTransfer);
                if (!payload.isEmpty()) {
                    List<PackNode> orderedPayload = sortByOrderOf(PackList.this.state.state().visiblePacks(), payload).reversed();
                    context.dispatch(key().type().available()
                            ? new PackListIntent.Enable(key(), pack, orderedPayload)
                            : new PackListIntent.Disable(key(), pack, orderedPayload));
                }
            }
        }

        protected void movePack(boolean upwards) {
            if (!PackList.this.state.isLocked()) {
                List<PackNode> payload = createPayload();
                if (!payload.isEmpty()) {
                    context.dispatch(new PackListIntent.MoveOnce(key(), pack, payload, upwards));
                }
            }
        }

        protected void openRenameModal() {
            context.dispatch(new PackListIntent.OpenRenameModal(key(), pack));
        }

        protected void deletePack() {
            context.dispatch(new PackListIntent.Delete(key(), pack));
        }

        protected void expandFolder() {
            if (pack instanceof PackNode.Parent parent) {
                context.dispatch(new PackListIntent.OpenFolder(key(), parent));
            }
        }

        protected void dragPack() {
            if (!state.canDrag() || PackList.this.state.isLocked()) return;
            List<PackNode> payload = createPayload();
            if (!payload.isEmpty()) {
                List<PackNode> orderedPayload = sortByOrderOf(PackList.this.state.state().visiblePacks(), payload);
                context.dispatch(new PackListIntent.Drag(key(), pack, new ObjectLinkedOpenHashSet<>(orderedPayload)));
            }
        }

        @Override
        public void method_25365(boolean focused) {
            super.setFocused(focused);
            if (!focused && method_25399() != null) {
                method_25399().method_25365(false);
            }
        }

        private boolean isFocusedOrSelected() {
            return PackList.this.method_25399() == null ? state.isSelectedLast() : method_25370();
        }

        @Override
        public boolean fidgetz$shouldTakeFocusAfterInteraction() {
            return !PackList.this.state.isFolderOpened();
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (super.mouseClicked(mouseX, mouseY, button) || isRightClick(button)) {
                if (!PackList.this.state.isFolderOpened()) return true;
                // ideally folderWidget should return false on #shouldTakeFocusAfterInteraction,
                // #shouldTakeFocusAfterInteraction also does not bubble up,
                // we want to return false regardless so that the folder can be focused
                this.method_25395(null);
                return false;
            }

            if (isLeftClick(button) && fidgetz$getHovered() == null) {
                int relativeX = (int) mouseX - (method_46426() + INNER_ITEM_PADDING);
                int relativeY = (int) mouseY - (method_46427() + INNER_ITEM_PADDING);

                if (state.canEnable() && mouseOverIcon(relativeX, relativeY, ICON_SIZE)) {
                    transferPack();
                    return false;
                }
                if (state.canDisable() && mouseOverLeftHalf(relativeX, relativeY, ICON_SIZE)) {
                    transferPack();
                    return false;
                }
                if (state.canMoveUp() && mouseOverTopRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    movePack(true);
                    return false;
                }
                if (state.canMoveDown() && mouseOverBottomRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    movePack(false);
                    return false;
                }
            }

            return mouseStateHandler.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return mouseStateHandler.mouseReleased(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            return mouseStateHandler.mouseDragged(mouseX, mouseY, button, dragX, dragY);
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (super.keyPressed(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (isExpandFolder(keyCode, modifiers) && pack instanceof PackNode.Parent && state.isSelectedExclusively()) {
                expandFolder();
                return true;
            }
            if (isTransfer(keyCode, modifiers) && state.canTransfer()) {
                transferPack();
                return true;
            }
            if (isMoveDown(keyCode, modifiers) && PackList.this.state.canReorder()) {
                movePack(false);
                return true;
            }
            if (isMoveUp(keyCode, modifiers) && PackList.this.state.canReorder()) {
                movePack(true);
                return true;
            }
            if (isOpenFile(keyCode, modifiers)) {
                PackUtil.openPack(pack.path());
                return true;
            }
            if (isOpenFolder(keyCode, modifiers)) {
                PackUtil.openParent(pack.path());
                return true;
            }
            if (isDelete(keyCode, modifiers) && context.resources().isModifiable(PackList.this.state.profiles(), pack)) {
                deletePack();
                return true;
            }
            if (isRename(keyCode, modifiers) && context.resources().isModifiable(PackList.this.state.profiles(), pack)) {
                openRenameModal();
                return true;
            }
            return false;
        }

        public void renderBack(class_332 graphics, int top, int left, int width, int height) {
            if (!pack.compatibility().method_14437() && !isIncompatibleWarningsHidden()) {
                int margin = INNER_ITEM_PADDING / 2;
                int backgroundLeft = left + margin;
                int backgroundTop = top + margin;
                int backgroundRight = (left + width) - margin;
                int backgroundBottom = (top + height) - margin;
                graphics.method_25294(backgroundLeft, backgroundTop, backgroundRight, backgroundBottom, Colors.RED_900);
            }
        }

        private void renderWidgetSprites(class_332 graphics, WidgetRenderables sprites, int left, int top, boolean hovered) {
            RenderableRectangle sprite = hovered ? sprites.enabledFocused() : sprites.enabled();
            sprite.extractRenderState(graphics, left, top, ICON_SIZE, ICON_SIZE, 0, 0, 0);
            if (hovered) {
                MinecraftCursor.get().setPointingHand();
            }
        }

        private void renderWidgetSprites(class_332 graphics, int top, int left, int mouseX, int mouseY) {
            boolean hovered = isHovered() && fidgetz$getHovered() == null;
            if ((!hovered && !state.isSelectedLast()) || PackList.this.state.isDragging()) return;

            int relX = mouseX - left;
            int relY = mouseY - top;

            WHITE_OVERLAY.extractRenderState(graphics, left, top, ICON_SIZE, ICON_SIZE, 0, 0, 0);

            if (state.canEnable()) {
                renderWidgetSprites(graphics, SELECT_SPRITES, left, top, hovered && mouseOverIcon(relX, relY, ICON_SIZE));
            }
            if (state.canDisable()) {
                renderWidgetSprites(graphics, UNSELECT_SPRITES, left, top, hovered && mouseOverLeftHalf(relX, relY, ICON_SIZE));
            }
            if (state.canMoveUp()) {
                renderWidgetSprites(graphics, MOVE_UP_SPRITES, left, top, hovered && mouseOverTopRightQuarter(relX, relY, ICON_SIZE));
            }
            if (state.canMoveDown()) {
                renderWidgetSprites(graphics, MOVE_DOWN_SPRITES, left, top, hovered && mouseOverBottomRightQuarter(relX, relY, ICON_SIZE));
            }
        }

        private void renderSelection(class_332 graphics, int top, int left, int width, int height) {
            if (state.isSelected()) {
                RenderableRectangle overlay = state.isSelectedLast() ? WHITE_OVERLAY : SELECTED_OVERLAY;
                overlay.extractRenderState(graphics, left, top, width, height, 0, 0, 0);
                graphics.method_49601(left, top, width, height, Colors.BLUE_500);
            }
        }

        @Override
        public void render(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            init();
            int left = method_46426();
            int top = method_46427();
            int width = method_25368();
            int height = method_25364();
            int innerTop = top + INNER_ITEM_PADDING;
            int innerLeft = left + INNER_ITEM_PADDING;

            renderBack(graphics, top, left, width, height);

            Objects.requireNonNull(packWidget).checkCompatibility(isHovered() || isFocusedOrSelected());
            packWidget.method_25394(graphics, mouseX, mouseY, partialTick);

            renderSelection(graphics, top, left, width, height);
            renderWidgetSprites(graphics, innerTop, innerLeft, mouseX, mouseY);

            if (!renderables.isEmpty()) {
                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(0f, 0f, 0.1f);
                for (class_4068 renderable : this.renderables) {
                    renderable.method_25394(graphics, mouseX, mouseY, partialTick);
                }
                graphics.method_51448().method_22909();
            }

            if (devMenu != null) {
                devMenu.render(graphics, innerTop, left, width);
            }
        }

        protected void updateContextEntries(
                Function<ContextMenuEvent.PackEntry.Pos, Collection<FZPopoverMenuItem>> entryFactory,
                FZContextMenu.Collector collector,
                double x,
                double y
        ) {
            entryFactory.apply(ContextMenuEvent.PackEntry.Pos.BEFORE_HEADER).forEach(collector::addEntry);

            collector.addEntry(builder -> builder
                    .message(pack.title())
                    .icon(padded16Rect(Renderables.texture(getPackIcon(), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false));

            collector.nextSection();

            entryFactory.apply(ContextMenuEvent.PackEntry.Pos.AFTER_HEADER).forEach(collector::addEntry);

            if (devMenu != null) {
                devMenu.updateContextEntries(collector);
                collector.nextSection();
            }

            entryFactory.apply(ContextMenuEvent.PackEntry.Pos.AFTER_DEV).forEach(collector::addEntry);

            if (pack instanceof PackNode.Parent) {
                collector.addEntry(builder -> builder
                        .message(FOLDER_OPEN_TEXT)
                        .onPress(this::expandFolder));
                collector.nextSection();
            }

            if (isFileModifiable()) {
                collector.addEntry(builder -> builder
                        .message(RENAME_FILE_TEXT)
                        .active(this::isFileModifiable)
                        .onPress(this::openRenameModal));
                collector.addEntry(builder -> builder
                        .message(DELETE_FILE_TEXT)
                        .active(this::isFileModifiable)
                        .onPress(this::deletePack));
            }

            if (pack.path() != null) {
                collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(pack.path())));
                collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(pack.path())));
            }

            entryFactory.apply(ContextMenuEvent.PackEntry.Pos.AFTER_PACK).forEach(collector::addEntry);

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        protected void updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            updateContextEntries(ignored -> Collections.emptyList(), collector, x, y);
        }

        @Override
        public final void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            if (this.initialized) {
                updateContextEntries(x, y, collector);
            }
        }

        @Override
        public List<class_364> method_25396() {
            return this.children;
        }

        @Override
        public boolean isHovered() {
            return super.isHovered() && fidgetz$isHovered();
        }

        private void repositionPackWidget() {
            if (packWidget != null) {
                packWidget.method_48229(method_46426(), method_46427() + INNER_ITEM_PADDING);
                packWidget.setWidth(method_25368());
            }
        }

        @Override
        public void setX(int x) {
            rightElements.forEach(child -> child.method_46421(child.method_46426() + x - method_46426()));
            if (folderWidget != null) folderWidget.method_46421(folderWidget.method_46426() + x - method_46426());
            super.setX(x);
            repositionPackWidget();
        }

        @Override
        public void setY(int y) {
            rightElements.forEach(child -> child.method_46419(child.method_46427() + y - method_46427()));
            if (folderWidget != null) folderWidget.method_46419(folderWidget.method_46427() + y - method_46427());
            super.setY(y);
            repositionPackWidget();
        }

        @Override
        protected void setWidth(int width) {
            rightElements.forEach(child -> child.method_46421(child.method_46426() + width - method_25368()));
            super.setWidth(width);
            repositionPackWidget();
        }

        @Override
        protected void setHeight(int height) {
            super.setHeight(height);
            repositionPackWidget();
        }

        @Override
        protected void setBounds(int x, int y, int width, int height) {
            rightElements.forEach(child -> child.method_48229((child.method_46426() + x - method_46426()) + width - method_25368(), child.method_46427() + y - method_46427()));
            if (folderWidget != null) {
                folderWidget.method_48229(folderWidget.method_46426() + x - method_46426(), folderWidget.method_46427() + y - method_46427());
            }
            super.setBounds(x, y, width, height);
            repositionPackWidget();
        }
    }

    class LeafEntry extends io.github.fishstiz.packed_packs.gui.components.PackList.Entry implements PackContext {
        private final class_3288 exposed;

        LeafEntry(PackListComputed.Entry state, class_3288 pack, int index) {
            super(state, index);
            this.exposed = pack;
        }

        @Override
        public class_3288 pack() {
            return exposed;
        }

        @Override
        public class_2960 icon() {
            return getPackIcon();
        }

        @Override
        public boolean fileModifiable() {
            return isFileModifiable();
        }

        @Override
        protected void buildWidgets() {
            super.buildWidgets();

            PackedPacksApiImpl.getInstance().eventBus().post(new InitializePackEntryEvent(
                    context,
                    this,
                    Objects.requireNonNull(packWidget),
                    this
            ));
        }

        @Override
        public void updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            var extensions = ContextMenuEventImpl.postPackEntry(context, this);
            updateContextEntries(extensions::entries, collector, x, y);
        }

        // PackSelectionModel.Entry overrides

        @Override
        @Deprecated
        public class_2960 method_30286() {
            return getPackIcon();
        }

        @Override
        @Deprecated
        public class_3281 method_29648() {
            return pack.compatibility();
        }

        @Override
        @Deprecated
        public String method_48276() {
            return pack.id();
        }

        @Override
        @Deprecated
        public class_2561 method_29650() {
            return pack.title();
        }

        @Override
        @Deprecated
        public class_2561 method_29651() {
            return pack.metadata().comp_999();
        }

        @Override
        @Deprecated
        public class_5352 method_29652() {
            return pack.packSource();
        }

        @Override
        @Deprecated
        public boolean method_29654() {
            return PackList.this.state.profiles().isPackFixed(pack);
        }

        @Override
        @Deprecated
        public boolean method_29655() {
            return PackList.this.state.profiles().isPackRequired(pack);
        }

        @Override
        @Deprecated
        public void method_29656() {
            if (state.canEnable()) {
                transferPack();
            }
        }

        @Override
        @Deprecated
        public void method_29657() {
            if (state.canDisable()) {
                transferPack();
            }
        }

        @Override
        @Deprecated
        public void method_29658() {
            movePack(true);
        }

        @Override
        @Deprecated
        public void method_29659() {
            movePack(false);
        }

        @Override
        @Deprecated
        public boolean method_29660() {
            return key().type().enabled();
        }

        @Override
        @Deprecated
        public boolean method_29663() {
            return state.canMoveUp();
        }

        @Override
        @Deprecated
        public boolean method_29664() {
            return state.canMoveDown();
        }
    }
}
