package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.FZPopoverMenuItem;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.util.PackUtil;
import it.unimi.dsi.fastutil.objects.Object2LongLinkedOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5352;

import static io.github.fishstiz.packed_packs.util.GuiUtils.padded16Sprite;

public enum SortOptions implements SortOption {
    VANILLA("packed_packs.sort.vanilla", "icon/sort_vanilla") {
        @Override
        public Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
            return folderFirst((first, second) -> {
                class_5352 firstPackSource = first.packSource();
                class_5352 secondPackSource = second.packSource();

                boolean builtInFirst = PackUtil.isBuiltIn(firstPackSource);
                boolean builtInSecond = PackUtil.isBuiltIn(secondPackSource);

                if (builtInFirst != builtInSecond) return builtInFirst ? 1 : -1;

                boolean featureFirst = PackUtil.isFeature(firstPackSource);
                boolean featureSecond = PackUtil.isFeature(secondPackSource);

                if (featureFirst != featureSecond) return featureFirst ? 1 : -1;

                return first.title().getString().compareTo(second.title().getString());
            });
        }
    },
    A_Z("packed_packs.sort.a_z", "icon/sort_a_z") {
        @Override
        public Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
            return folderFirst(Comparator.comparing(
                    pack -> class_124.method_539(pack.title().getString()),
                    String.CASE_INSENSITIVE_ORDER
            ));
        }
    },
    Z_A("packed_packs.sort.z_a", "icon/sort_z_a") {
        @Override
        public Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
            return A_Z.comparator(packs).reversed();
        }
    },
    RECENT("packed_packs.sort.recent", "icon/sort_recent") {
        @Override
        public Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
            Map<PackNode, Long> cache = buildTimestampCache(packs);
            return folderFirst(Comparator.<PackNode, Long>comparing(cache::get).reversed());
        }
    },
    OLDEST("packed_packs.sort.oldest", "icon/sort_oldest") {
        @Override
        public Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
            return RECENT.comparator(packs).reversed();
        }
    };

    private final String translationKey;
    private final String spritePath;

    SortOptions(String key, String icon) {
        this.translationKey = key;
        this.spritePath = icon;
    }

    public abstract Comparator<PackNode> comparator(SequencedCollection<PackNode> packs);

    public class_2960 icon() {
        return PackedPacks.id(spritePath);
    }

    public class_2561 text() {
        return class_2561.method_43471(translationKey);
    }

    static Comparator<PackNode> folderFirst(Comparator<PackNode> base) {
        return Comparator.comparing((PackNode pack) -> !(pack instanceof PackNode.Parent)).thenComparing(base);
    }

    public static SortOption getOrDefault(@Nullable String name) {
        if (name == null) {
            return VANILLA;
        }

        try {
            return valueOf(name);
        } catch (IllegalArgumentException e) {
            return VANILLA;
        }
    }

    public static List<FZPopoverMenuItem> menuItems(Consumer<SortOptions> clickHandler) {
        List<FZPopoverMenuItem> items = new ArrayList<>();

        for (SortOptions option : SortOptions.values()) {
            items.add(FZPopoverMenuItem.builder()
                    .message(option.text())
                    .icon(padded16Sprite(option.icon()))
                    .onPress(() -> clickHandler.accept(option))
                    .build());
        }

        return items;
    }

    private static Map<PackNode, Long> buildTimestampCache(SequencedCollection<PackNode> packs) {
        Map<PackNode, Long> cache = new Object2LongLinkedOpenHashMap<>(packs.size());
        for (PackNode pack : packs) cache.put(pack, getLastUpdatedEpochMs(pack));
        return cache;
    }

    private static long getLastUpdatedEpochMs(PackNode pack) {
        Path path = pack.path();
        if (path == null) {
            return -1;
        }
        try {
            return Files.getLastModifiedTime(path).toInstant().toEpochMilli();
        } catch (IOException e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to get age of pack '{}'", pack.id());
            return -1;
        }
    }
}
