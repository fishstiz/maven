package io.github.fishstiz.packed_packs.pack;

import com.google.common.hash.Hashing;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jetbrains.annotations.Nullable;

import java.io.InputStream;
import java.nio.file.NoSuchFileException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_7367;

public class PackIconCache {
    private final Map<String, class_2960> cachedIcons = new ConcurrentHashMap<>();
    private final Executor mainThreadExecutor;
    private final class_1060 textureManager;
    private Map<String, class_2960> staleIcons;

    public PackIconCache(Executor mainThreadExecutor, class_1060 textureManager) {
        this.mainThreadExecutor = mainThreadExecutor;
        this.textureManager = textureManager;
    }

    public class_2960 get(PackNode pack) {
        if (!cachedIcons.containsKey(pack.id())) {
            class_2960 fallback = (this.staleIcons != null) ? this.staleIcons.get(pack.id()) : null;
            if (fallback == null) {
                fallback = pack.defaultIcon();
            }

            cachedIcons.put(pack.id(), fallback);

            loadPackIcon(pack).thenAcceptAsync(icon -> {
                if (icon != null) {
                    cachedIcons.put(pack.id(), icon);
                }
            }, mainThreadExecutor);
        }

        return cachedIcons.getOrDefault(pack.id(), pack.defaultIcon());
    }

    public void clear() {
        this.staleIcons = Map.copyOf(cachedIcons);
        cachedIcons.clear();
    }

    /**
     * Refer to {@code PackSelectionScreen#loadPackIcon(TextureManager, Pack)}
     */
    private CompletableFuture<@Nullable class_2960> loadPackIcon(PackNode pack) {
        return CompletableFuture.supplyAsync(() -> {
            try (class_3262 packResources = pack.open()) {
                class_7367<InputStream> iconIoSupplier = packResources.method_14410(PackUtil.ICON_FILENAME);
                if (iconIoSupplier == null) return null;

                try (InputStream iconStream = iconIoSupplier.get()) {
                    return class_1011.method_4309(iconStream);
                }
            } catch (Exception e) {
                if (!(e instanceof NoSuchFileException)) {
                    PackedPacks.LOGGER.warn("[packed_packs] Failed to load icon from pack '{}'", pack.id(), e);
                }
                return null;
            }
        }, class_156.method_18349()).thenApplyAsync(nativeImage -> {
            if (nativeImage == null) return null;
            class_2960 icon = class_2960.method_60656(hashIconName(pack.id()));
            this.textureManager.method_4616(icon, new class_1043(nativeImage));
            return icon;
        }, this.mainThreadExecutor);
    }

    @SuppressWarnings("deprecation")
    private static String hashIconName(String id) {
        return "pack/" + class_156.method_30309(id, class_2960::method_29184) + "/" + Hashing.sha1().hashUnencodedChars(id) + "/icon";
    }
}
