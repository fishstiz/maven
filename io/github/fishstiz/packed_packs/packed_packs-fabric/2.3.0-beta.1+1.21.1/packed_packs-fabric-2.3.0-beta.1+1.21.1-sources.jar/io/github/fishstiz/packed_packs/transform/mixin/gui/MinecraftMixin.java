package io.github.fishstiz.packed_packs.transform.mixin.gui;

import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.screens.PackSelectionScreenArgs;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.concurrent.Executor;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5375;

@Mixin(class_310.class)
public abstract class MinecraftMixin implements Executor {
    @Shadow
    @Nullable
    public class_437 screen;

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private class_437 replacePackScreen(class_437 original) {
        if (original instanceof class_5375 packScreen &&
            (((PackSelectionScreenAccessor) packScreen).packed_packs$getPrevious() == null) &&
            !(this.screen instanceof PackedPacksScreen)) {

            PackSelectionScreenArgs args = PackSelectionScreenArgs.extract(packScreen);

            if (Config.packs(args.packType()).isReplaceOriginal()) {
                ((PackSelectionScreenAccessor) packScreen).packed_packs$closeWatcher();
                return new PackedPacksScreen((class_310) (Object) this, this.screen, args);
            }
        }

        return original;
    }
}
