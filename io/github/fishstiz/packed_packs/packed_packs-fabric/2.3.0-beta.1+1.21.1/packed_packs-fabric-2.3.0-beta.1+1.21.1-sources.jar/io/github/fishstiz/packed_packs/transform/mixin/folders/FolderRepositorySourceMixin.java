package io.github.fishstiz.packed_packs.transform.mixin.folders;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.FolderPackMeta;
import io.github.fishstiz.packed_packs.pack.FolderLocationInfo;
import io.github.fishstiz.packed_packs.transform.interfaces.FilePack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_3279;
import net.minecraft.class_3288;
import net.minecraft.class_8580;
import net.minecraft.class_8581;
import net.minecraft.class_8621;
import net.minecraft.class_9224;

@Mixin(class_3279.class)
public abstract class FolderRepositorySourceMixin {
    @Shadow
    @Final
    static Logger LOGGER;

    @Unique
    private static final ThreadLocal<@Nullable FolderLocationInfo> PARENT_CONTEXT = new ThreadLocal<>();

    @Shadow
    @Final
    private Path folder;

    @Inject(method = "loadPacks", at = @At("RETURN"))
    private void ensureRemoveThreadLocals(Consumer<class_3288> result, CallbackInfo ci) {
        PARENT_CONTEXT.remove();
    }

    @WrapOperation(method = "discoverPacks", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/packs/repository/FolderRepositorySource$FolderPackDetector;detectPackResources(Ljava/nio/file/Path;Ljava/util/List;)Ljava/lang/Object;"
    ))
    private static Object discoverNestedPacks(
            @Coerce class_8621<class_3288.class_7680> instance,
            Path path,
            List<class_8581> list,
            Operation<class_3288.class_7680> original,
            @Local(argsOnly = true) class_8580 validator,
            @Local(argsOnly = true) BiConsumer<Path, class_3288.class_7680> output,
            @Share("suppressLog") LocalBooleanRef suppressLogRef
    ) {
        class_3288.class_7680 resourcesSupplier = null;
        try {
            resourcesSupplier = original.call(instance, path, list);
        } catch (Exception e) {
            LOGGER.warn("Failed to read properties of '{}', ignoring", path, e);
        }

        if (resourcesSupplier == null && PackUtil.isNonPackDirectory(path)) {
            suppressLogRef.set(true);

            FolderLocationInfo parent = PARENT_CONTEXT.get();

            try {
                FolderLocationInfo parentInfo = FolderLocationInfo.fromPath(path.toAbsolutePath().normalize(), parent);
                PARENT_CONTEXT.set(parentInfo);
                discoverPacks(path, validator, output);
            } catch (IOException e) {
                PackedPacks.LOGGER.warn("[packed_packs] Failed to list packs in {}", path, e);
            } finally {
                if (parent == null) {
                    PARENT_CONTEXT.remove();
                } else {
                    PARENT_CONTEXT.set(parent);
                }
            }
        }

        return resourcesSupplier;
    }

    @WrapOperation(method = "discoverPacks", at = @At(
            value = "INVOKE",
            target = "Lorg/slf4j/Logger;info(Ljava/lang/String;Ljava/lang/Object;)V",
            remap = false
    ))
    private static void suppressLogOnFolderDiscovery(
            Logger instance,
            String s,
            Object o,
            Operation<Void> original,
            @Share("suppressLog") LocalBooleanRef suppressLogRef
    ) {
        if (!suppressLogRef.get() &&
            !(o instanceof Path p && (p.endsWith(FolderPackMeta.FILENAME) || p.endsWith(PackUtil.ICON_FILENAME)))) {
            original.call(instance, s, o);
        }
        suppressLogRef.set(false);
    }

    @SuppressWarnings("UnresolvedMixinReference")
    @ModifyArg(method = {"method_45272", "lambda$loadPacks$0"}, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/packs/repository/Pack;readMetaAndCreate(Lnet/minecraft/server/packs/PackLocationInfo;Lnet/minecraft/server/packs/repository/Pack$ResourcesSupplier;Lnet/minecraft/server/packs/PackType;Lnet/minecraft/server/packs/PackSelectionConfig;)Lnet/minecraft/server/packs/repository/Pack;"
    ))
    private class_9224 relativizePackId(class_9224 location, @Local(argsOnly = true) Path path) {
        FolderLocationInfo parent = PARENT_CONTEXT.get();
        if (parent == null) return location;

        String relativePath = this.folder.relativize(path).toString().replace('\\', '/');
        String newId = "file/" + relativePath;

        return new class_9224(newId, location.comp_2330(), location.comp_2331(), location.comp_2332());
    }

    @SuppressWarnings("UnresolvedMixinReference")
    @ModifyArg(method = {"method_45272", "lambda$loadPacks$0"}, at = @At(
            value = "INVOKE",
            target = "Ljava/util/function/Consumer;accept(Ljava/lang/Object;)V"
    ))
    private Object bindDirToNestedPack(Object arg, @Local(argsOnly = true) Path path) {
        if (arg instanceof FilePack pack) {
            pack.packed_packs$setPath(path);
            FolderLocationInfo parent = PARENT_CONTEXT.get();
            if (parent != null) {
                pack.packed_packs$setParent(parent);
            }
        }
        return arg;
    }

    @Shadow
    public static void discoverPacks(Path folder, class_8580 validator, BiConsumer<Path, class_3288.class_7680> output) throws IOException {
        throw new AssertionError();
    }

    @Shadow
    private static String nameFromPath(Path content) {
        throw new UnsupportedOperationException("Implemented via mixin");
    }
}
