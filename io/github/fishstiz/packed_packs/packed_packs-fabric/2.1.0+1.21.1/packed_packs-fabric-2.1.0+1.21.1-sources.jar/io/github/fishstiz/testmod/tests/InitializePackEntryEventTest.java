package io.github.fishstiz.testmod.tests;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.events.InitializePackEntryEvent;
import io.github.fishstiz.testmod.TestFeature;
import io.github.fishstiz.testmod.TestMod;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

public final class InitializePackEntryEventTest {
    private static class_4185 createButton(String message) {
        return class_4185.method_46430(class_2561.method_43470(message), btn -> TestMod.LOGGER.info(message))
                .method_46437(30, 20)
                .method_46431();
    }

    public static void initialize(PackedPacksApi api, List<class_2960> dependencies) {
        TestFeature feature = TestFeature.builder(api.preferences(), "init_entry", "Initialize Pack Entry")
                .rebuildOnChange()
                .after(dependencies)
                .register(api.eventBus());

        api.eventBus().register(InitializePackEntryEvent.class, feature.id(), event -> {
            if (!feature.isEnabled()) return;

            String packId = event.packContext().pack().method_14463();

            switch (packId) {
                case "vanilla" -> event.addDetachedWidget(container -> new class_4264(0, 0, 60, 16, class_2561.method_43470("DETACHED WIDGET")) {
                    @Override
                    protected void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
                        int height = method_25364();
                        int x = container.method_46426() + 36;
                        int y = (container.method_46427() + container.method_25364()) - height;
                        method_48229(x, y);
                        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
                    }

                    @Override
                    protected void method_47399(@NotNull class_6382 narrationElementOutput) {
                        method_37021(narrationElementOutput);
                    }

                    @Override
                    public void method_25306() {
                        TestMod.LOGGER.info(this.method_25369().getString());
                    }
                });
                case "programmer_art" -> {
                    event.addCenterRight(createButton("CR 1"));
                    event.addCenterRight(createButton("CR 2"));
                }
                case "high_contrast" -> {
                    event.addTopRight(createButton("TR 1"));
                    event.addTopRight(createButton("TR 2"));
                }
                case "fabric", "mod_resources" -> {
                    event.anchorCenterRight(8, createButton("CRA 1"));
                    event.anchorCenterRight(20, createButton("CRA 2"));
                }
            }
        });

        dependencies.add(feature.id());
    }

    private InitializePackEntryEventTest() {
    }
}
