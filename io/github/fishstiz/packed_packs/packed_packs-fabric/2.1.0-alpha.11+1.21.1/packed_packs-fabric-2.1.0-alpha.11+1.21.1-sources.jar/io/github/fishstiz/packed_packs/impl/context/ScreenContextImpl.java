package io.github.fishstiz.packed_packs.impl.context;

import io.github.fishstiz.packed_packs.api.PreferenceRegistry;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.gui.components.PreferenceToggle;
import io.github.fishstiz.packed_packs.gui.metadata.PackSelectionScreenArgs;
import io.github.fishstiz.packed_packs.gui.model.PackedPacksViewModel;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_5375;

public record ScreenContextImpl(
        class_437 previousScreen,
        class_437 screen,
        PackedPacksViewModel viewModel,
        PackSelectionScreenArgs originalArgs,
        class_3264 packType,
        boolean devMode
) implements ScreenContext {
    public ScreenContextImpl(
            class_437 previousScreen,
            class_437 screen,
            PackedPacksViewModel viewModel,
            PackSelectionScreenArgs originalArgs,
            boolean devMode
    ) {
        this(previousScreen, screen, viewModel, originalArgs, originalArgs.packType(), devMode);
    }

    @Override
    public class_5375 originalScreen() {
        return this.previousScreen instanceof class_5375 packSelectionScreen
                ? packSelectionScreen
                : this.originalArgs.createDummy();
    }

    @Override
    public class_3283 packRepository() {
        return this.originalArgs.repository();
    }

    @Override
    public List<class_3288> getAvailablePacks() {
        return Collections.unmodifiableList(this.viewModel.getAvailablePacks());
    }

    @Override
    public List<class_3288> getSelectedPacks() {
        return Collections.unmodifiableList(this.viewModel.getEnabledPacks());
    }

    @Override
    public void reload() {
        this.viewModel.refreshRepository();
    }

    @Override
    public void commit() {
        this.viewModel.commit();
    }

    @Override
    public @Nullable class_339 wrapWidget(PreferenceRegistry.Key<Boolean> key, @Nullable class_339 widget) {
        return PreferenceToggle.wrap(key, widget);
    }
}
