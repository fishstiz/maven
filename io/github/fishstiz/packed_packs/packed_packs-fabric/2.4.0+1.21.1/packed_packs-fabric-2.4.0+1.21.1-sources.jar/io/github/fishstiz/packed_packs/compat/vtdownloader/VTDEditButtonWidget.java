package io.github.fishstiz.packed_packs.compat.vtdownloader;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.PackContext;
import io.github.fishstiz.packed_packs.compat.ModIntegration;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.components.PreferenceHelper;
import org.jetbrains.annotations.Nullable;

import java.util.function.BooleanSupplier;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6382;

/**
 * Copied from VTDownloader
 * <p>
 * Original work Copyright (c) 2020-2023 IotaBread
 * <p>
 * Licensed under the MIT License.
 *
 * @see <a href="https://github.com/IotaBread/VTDownloader/blob/1.21/src/main/java/me/bymartrixx/vtd/mixin/PackEntryListWidgetMixin.java">Github</a>
 */
public class VTDEditButtonWidget extends class_4264 implements FZContextMenu.Source {
    private static final String VT_DESCRIPTION_MARKER = "vanillatweaks.net";
    private static final class_2960 PENCIL_TEXTURE = class_2960.method_60655("vt_downloader", "textures/pencil.png");
    private static final int PENCIL_TEXTURE_SIZE = 32;
    private static final int PENCIL_SIZE = 16;
    private final class_437 previous;
    private final PackContext pack;
    private final BooleanSupplier editable;
    private final Preference<Boolean> preference;

    private VTDEditButtonWidget(Preference<Boolean> prefKey, class_437 previous, PackContext pack, BooleanSupplier editable) {
        super(0, 0, PENCIL_SIZE, PENCIL_SIZE, class_5244.field_39003);
        this.preference = prefKey;
        this.previous = previous;
        this.pack = pack;
        this.editable = editable;
        this.field_22763 = this.editable.getAsBoolean();
    }

    public static @Nullable VTDEditButtonWidget create(Preference<Boolean> prefKey, class_437 previous, PackContext pack, BooleanSupplier editable) {
        return pack.method_29651().getString().contains(VT_DESCRIPTION_MARKER) ? new VTDEditButtonWidget(prefKey, previous, pack, editable) : null;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.field_22763 = this.editable.getAsBoolean();

        int x = this.method_46426();
        int y = this.method_46427();

        float u = 0.0F;
        float v = 0.0F;
        if (!this.field_22763) {
            v = PENCIL_SIZE;
        } else if (method_25367()) {
            u = PENCIL_SIZE;
        }

        graphics.method_25290(
                PENCIL_TEXTURE,
                x, y,
                u, v,
                PENCIL_SIZE, PENCIL_SIZE,
                PENCIL_TEXTURE_SIZE, PENCIL_TEXTURE_SIZE
        );

        if (Config.get().isDevMode()) {
            PreferenceHelper.extractOverlay(graphics, preference, x, y, method_25368(), method_25364());
        }
    }

    @Override
    public void method_25306() {
        if (this.field_22763) {
            VTDIntegration.createVTDScreenSetter(this.previous, pack).run();
        }
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        this.method_37021(narrationElementOutput);
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        collector.addEntry(PreferenceHelper.createEntry(preference, ModIntegration.getWidgetPrefText(preference)));
    }
}
