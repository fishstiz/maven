package io.github.fishstiz.packed_packs.platform.services;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import net.fabricmc.fabric.impl.resource.loader.BuiltinModResourcePackSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_5352;
import java.nio.file.Path;
import java.util.List;

public class FabricPlatformHelper implements PlatformHelper {
    @Override
    public String getPlatform() {
        return "fabric";
    }

    @Override
    public Path getConfigDir() {
        return FabricLoader.getInstance().getConfigDir();
    }

    @Override
    public boolean isModLoaded(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }

    @Override
    public boolean isDev() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    @Override
    public List<PackedPacksInitializer> getModExtensions() {
        return FabricLoader.getInstance().getEntrypoints(PackedPacks.MOD_ID, PackedPacksInitializer.class);
    }

    @Override
    public boolean isBuiltInPack(class_5352 packSource) {
        return packSource instanceof BuiltinModResourcePackSource;
    }
}
