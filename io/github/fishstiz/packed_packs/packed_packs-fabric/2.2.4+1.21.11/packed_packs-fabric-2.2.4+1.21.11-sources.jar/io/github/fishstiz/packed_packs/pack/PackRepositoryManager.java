package io.github.fishstiz.packed_packs.pack;

import com.google.common.collect.ImmutableList;
import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.PackOptions;
import io.github.fishstiz.packed_packs.pack.folder.FolderLocationInfo;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.transform.interfaces.FilePack;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionModelAccessor;
import io.github.fishstiz.packed_packs.transform.mixin.folders.additional.FolderRepositorySourceAccessor;
import io.github.fishstiz.packed_packs.transform.mixin.folders.additional.PackRepositoryAccessor;
import io.github.fishstiz.packed_packs.util.PackUtil;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.*;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_5369;
import net.minecraft.class_7172;

public class PackRepositoryManager {
    private final class_3283 repository;
    private final Path packDir;
    private class_5369 model;
    private Map<String, class_3288> availablePacks = Collections.emptyMap();
    private Set<String> selectedPacksCache = Collections.emptySet();

    public PackRepositoryManager(class_3283 repository, Path packDir) {
        this.repository = repository;
        this.packDir = packDir;
        this.refreshModel();
        this.regenerateAvailablePacks();
    }

    public class_3283 getRepository() {
        return this.repository;
    }

    private List<class_3288> getSelectedPacks() {
        return ((PackSelectionModelAccessor) this.model).getSelectedPacks();
    }

    private List<class_3288> getUnselectedPacks() {
        return ((PackSelectionModelAccessor) this.model).getUnselectedPacks();
    }

    private void refreshModel() {
        this.model = new class_5369(
                FunctionUtils.nopConsumer(),
                PackIconManager::getDefault,
                this.repository,
                FunctionUtils.nopConsumer()
        );
        ((PackSelectionModelAccessor) this.model).packed_packs$filterHidden(false);
    }

    public List<class_3288> getPacks() {
        return List.copyOf(this.availablePacks.values());
    }

    public PackGroup getPacksBySelected(PackOptions options) {
        return this.validatePacks(this.groupByFolders(this.getUnselectedPacks()), this.groupByFolders(this.getSelectedPacks()), options);
    }

    public void removePack(class_3288 pack) {
        if (pack instanceof FolderPack folderPack) {
            folderPack.contents().forEach(this::removePack);
        }

        this.repository.method_49428(pack.method_14463());

        if (!this.availablePacks.isEmpty()) {
            // available packs is immutable until populated
            // ideally should keep being immutable but probably not worth it when you have to rebuild the map on delete
            this.availablePacks.remove(pack.method_14463());
        }

        try {
            // PackSelectionModel#selected and PackSelectionModel#unselected are mutable in vanilla
            this.getSelectedPacks().remove(pack);
            this.getUnselectedPacks().remove(pack);
        } catch (UnsupportedOperationException e) {
            // just in case
            PackedPacks.LOGGER.warn("[packed_packs] Failed to mutate PackSelectionModel lists. Report this issue to mod author.");
        }
    }

    /**
     * @param unselected grouped list of unselected packs
     * @param selected   grouped list of selected packs
     * @return validated and grouped list of packs
     */
    public PackGroup validatePacks(List<class_3288> unselected, List<class_3288> selected, PackOptions options) {
        return PackUtil.syncPackSelection(new ObjectOpenHashSet<>(this.availablePacks.values()), unselected, selected, options);
    }

    /**
     * @param packIds grouped pack ids
     * @param source  grouped packs
     * @return grouped packs by id
     */
    public List<class_3288> getPacksById(Collection<String> packIds, Map<String, class_3288> source) {
        return CollectionUtils.lookup(packIds, source);
    }

    /**
     * @param packIds grouped pack ids
     * @param source  grouped packs
     * @return grouped packs by id
     */
    public List<class_3288> getPacksById(Collection<String> packIds, Collection<class_3288> source) {
        return CollectionUtils.lookup(packIds, CollectionUtils.toMap(source, class_3288::method_14463));
    }

    /**
     * @param packIds grouped pack ids
     * @return grouped packs by id
     */
    public List<class_3288> getPacksById(Collection<String> packIds) {
        return this.getPacksById(packIds, this.availablePacks);
    }

    public @Nullable class_3288 getPackById(String id) {
        return this.availablePacks.get(id);
    }

    public List<class_3288> getPacksByFlattenedIds(Collection<String> packIds) {
        List<class_3288> folderPacks = CollectionUtils.filter(this.availablePacks.values(), FolderPack.class::isInstance);
        List<class_3288> available = CollectionUtils.addAll(folderPacks, this.repository.method_14441());
        return this.groupByFolders(this.getPacksById(packIds, available));
    }

    /**
     * @param packs ungrouped collection of packs
     */
    private void populateAvailablePacks(
            Collection<class_3288> packs,
            Map<String, class_3288> currentAvailable,
            Map<FolderLocationInfo, List<class_3288>> folders
    ) {
        for (class_3288 pack : packs) {
            FolderLocationInfo folderLocationInfo = ((FilePack) pack).packed_packs$getFolderLocationInfo();
            if (folderLocationInfo != null) {
                folders.computeIfAbsent(folderLocationInfo, k -> new ObjectArrayList<>()).add(pack);
            } else {
                currentAvailable.put(pack.method_14463(), pack);
            }
        }
    }

    private void regenerateAvailablePacks() {
        this.selectedPacksCache = Set.copyOf(this.repository.method_29210());

        Map<String, class_3288> newAvailablePacks = new Object2ObjectLinkedOpenHashMap<>();
        Map<FolderLocationInfo, List<class_3288>> folders = new Object2ObjectLinkedOpenHashMap<>();

        this.populateAvailablePacks(this.getSelectedPacks(), newAvailablePacks, folders);
        this.populateAvailablePacks(this.getUnselectedPacks(), newAvailablePacks, folders);

        for (Map.Entry<FolderLocationInfo, List<class_3288>> folderEntry : folders.entrySet()) {
            FolderPack folderPack = FolderPack.createAndPreloadMetadata(folderEntry.getKey(), folderEntry.getValue());
            newAvailablePacks.putIfAbsent(folderPack.method_14463(), folderPack);
        }

        this.availablePacks = newAvailablePacks;
    }

    public void refresh() {
        this.refreshModel();
        this.model.method_29981();
        this.regenerateAvailablePacks();
    }

    /**
     * @param selected grouped list of selected packs
     */
    public void selectPacks(List<class_3288> selected) {
        boolean hasHighContrast = false;
        List<String> packIds = new ObjectArrayList<>();

        for (class_3288 pack : PackUtil.flattenPacks(selected).reversed()) {
            String packId = pack.method_14463();

            packIds.add(packId);
            if (!hasHighContrast && packId.equals(PackUtil.HIGH_CONTRAST_ID)) {
                hasHighContrast = true;
            }
        }

        this.repository.method_14447(ImmutableList.copyOf(packIds));

        class_7172<@NonNull Boolean> highContrastOption = class_310.method_1551().field_1690.method_49600();
        if (highContrastOption.method_41753() != hasHighContrast) {
            highContrastOption.method_41748(hasHighContrast);
        }

        this.refreshModel();
        this.selectedPacksCache = Set.copyOf(this.repository.method_29210());
    }

    /**
     * @param flatPacks ungrouped list of packs
     * @return grouped list of packs
     */
    private List<class_3288> groupByFolders(List<class_3288> flatPacks) {
        Set<String> seenFolders = new ObjectOpenHashSet<>();
        List<class_3288> grouped = new ObjectArrayList<>(flatPacks.size());

        for (class_3288 pack : flatPacks) {
            FolderLocationInfo folderLocationInfo = ((FilePack) pack).packed_packs$getFolderLocationInfo();
            if (folderLocationInfo != null) {
                class_3288 folder = this.availablePacks.get(folderLocationInfo.id());
                if (folder instanceof FolderPack valid && seenFolders.add(valid.method_14463())) {
                    grouped.add(this.availablePacks.get(valid.method_14463()));
                }
            } else {
                grouped.add(pack);
            }
        }

        return grouped;
    }

    public boolean isEnabled(class_3288 pack) {
        if (pack instanceof FolderPack folderPack) {
            for (class_3288 nestedPack : folderPack.contents()) {
                if (this.selectedPacksCache.contains(nestedPack.method_14463())) {
                    return true;
                }
            }
            return false;
        }

        return this.selectedPacksCache.contains(pack.method_14463());
    }

    public Path getBaseDir() {
        return this.packDir;
    }

    public List<Path> getAdditionalDirs() {
        Path normalizedBaseDir = this.getBaseDir().toAbsolutePath().normalize();

        return ((PackRepositoryAccessor) this.repository).packed_packs$getSources().stream()
                .filter(FolderRepositorySourceAccessor.class::isInstance)
                .map(source -> ((FolderRepositorySourceAccessor) source).packed_packs$getFolder().toAbsolutePath().normalize())
                .filter(path -> !path.equals(normalizedBaseDir))
                .distinct()
                .toList();
    }
}
