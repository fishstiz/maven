package io.github.fishstiz.packed_packs.util;

import io.github.fishstiz.packed_packs.PackedPacks;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_370;
import net.minecraft.class_5244;

public class ToastUtil {
    private static final class_370.class_9037 FILE_OPS_FAIL_ID = new class_370.class_9037();
    private static final class_370.class_9037 DEV_MODE_ID = new class_370.class_9037(750);

    private ToastUtil() {
    }

    public static void onDevModeToggleToast(boolean enabled) {
        class_2561 enableText = enabled ? class_5244.field_24332 : class_5244.field_24333;
        class_370.method_1990(
                class_310.method_1551().method_1566(),
                DEV_MODE_ID,
                class_2561.method_43470(PackedPacks.MOD_NAME),
                class_2561.method_43469("packed_packs.dev_mode", enableText)
        );
    }

    public static void onFileFailToast(class_2561 message) {
        class_370.method_1990(
                class_310.method_1551().method_1566(),
                FILE_OPS_FAIL_ID,
                class_2561.method_43471("packed_packs.file.fail"),
                message
        );
    }

    public static class_2561 getRenameFailText(String from, String to) {
        return class_2561.method_43469("packed_packs.file.rename.fail", from, to);
    }

    public static class_2561 getDeleteFailText(String fileName) {
        return class_2561.method_43469("packed_packs.file.delete.fail", fileName);
    }

    public static void onDeleteFailToast(class_2561 fileName) {
        onFileFailToast(getDeleteFailText(fileName.getString()));
    }

    public static void onRenameFailToast(class_2561 from, String to) {
        onFileFailToast(getRenameFailText(from.getString(), to));
    }
}
