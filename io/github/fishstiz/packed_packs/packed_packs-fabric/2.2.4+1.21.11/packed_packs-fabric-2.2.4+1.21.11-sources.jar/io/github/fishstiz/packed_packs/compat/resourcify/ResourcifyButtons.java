package io.github.fishstiz.packed_packs.compat.resourcify;

import dev.dediamondpro.resourcify.gui.injections.PackScreensAddition;
import dev.dediamondpro.resourcify.services.ProjectType;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2588;
import net.minecraft.class_4185;
import net.minecraft.class_5375;
import net.minecraft.class_7417;

public class ResourcifyButtons {
    private ResourcifyButtons() {
    }

    public static @Nullable List<? extends class_4185> getButtons(class_5375 packScreen) {
        class_7417 contents = packScreen.method_25440().method_10851();

        if (contents instanceof class_2588 translatable) {
            ProjectType type = PackScreensAddition.INSTANCE.getType(translatable.method_11022());
            if (type != null) {
                return PackScreensAddition.INSTANCE.getButtons(packScreen, type);
            }
        }

        return null;
    }
}
