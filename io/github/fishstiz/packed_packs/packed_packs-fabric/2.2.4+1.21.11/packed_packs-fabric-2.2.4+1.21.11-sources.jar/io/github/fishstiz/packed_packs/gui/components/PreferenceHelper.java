package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.fidgetz.v0.gui.components.FZPopoverMenuItem;
import io.github.fishstiz.fidgetz.v0.gui.components.WrappedComponent;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;

public class PreferenceHelper extends WrappedComponent implements FZContextMenu.Source {
    private static final int ENABLED_COLOR = Colors.alpha(Colors.GREEN_500, 0.5f);
    private static final int DISABLED_COLOR = Colors.alpha(Colors.RED_700, 0.5f);
    private static final int ENABLED_BORDER = Colors.GREEN_500;
    private static final int DISABLED_BORDER = Colors.RED_700;
    private final Preference<Boolean> preference;
    private final class_2561 label;

    private PreferenceHelper(class_339 widget, Preference<Boolean> preference, class_2561 label) {
        super(widget);
        this.preference = preference;
        this.label = label;
    }

    private PreferenceHelper(class_339 widget, Preferences.Option<Boolean> preference) {
        super(widget);
        this.preference = preference;
        this.label = getOptionLabel(preference);
    }

    public static class_2561 getOptionLabel(Preferences.Option<Boolean> preference) {
        return class_2561.method_43471("packed_packs.preferences.widgets." + preference.getKey());
    }

    public static Optional<class_339> wrap(Preferences.Option<Boolean> option, class_339 widget) {
        if (Config.get().isDevMode()) {
            return Optional.of(new PreferenceHelper(widget, option));
        }
        return option.get() ? Optional.of(widget) : Optional.empty();
    }

    public static class_339 wrapNonNull(Preferences.Option<Boolean> option, class_339 widget) {
        if (Config.get().isDevMode()) {
            return new PreferenceHelper(widget, option);
        }
        return widget;
    }

    public static @Nullable class_339 wrap(@Nullable class_339 widget, Preference<Boolean> preference, class_2561 label) {
        if (widget == null) {
            return null;
        }
        if (Config.get().isDevMode()) {
            return new PreferenceHelper(widget, preference, label);
        }
        return preference.get() ? widget : null;
    }

    public static FZPopoverMenuItem createEntry(Preference<Boolean> preference, class_2561 label) {
        return GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                .message(label)
                .icon(GuiUtils.toggleRect(preference::get))
                .onPress(() -> preference.set(!preference.get()))
                .closeOnInteraction(false)
                .build();
    }

    public static FZPopoverMenuItem createEntry(Preferences.Option<Boolean> preference) {
        return createEntry(preference, getOptionLabel(preference));
    }

    public static void extractOverlay(class_332 graphics, Preference<Boolean> preference, int x, int y, int width, int height) {
        boolean enabled = preference.get();
        int color = enabled ? ENABLED_COLOR : DISABLED_COLOR;
        int border = enabled ? ENABLED_BORDER : DISABLED_BORDER;
        graphics.method_25294(x, y, x + width, y + height, color);
        graphics.method_73198(x, y, width, height, border);
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(graphics, mouseX, mouseY, partialTick);
        if (get().field_22764) {
            extractOverlay(graphics, preference, method_46426(), method_46427(), method_25368(), method_25364());
        }
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        if (get().method_37303()) {
            collector.addEntry(createEntry(preference, label));
        }
    }
}
