package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.v0.gui.components.FZButton;
import io.github.fishstiz.fidgetz.v0.gui.components.FZText;
import io.github.fishstiz.fidgetz.v0.gui.components.GuiComponentCollector;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.screens.FZScreen;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.layouts.OptionsLayout;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.jspecify.annotations.Nullable;

public class OptionsScreen extends FZScreen {
    private final class_437 previous;
    private @Nullable FZLayout root;

    public OptionsScreen(class_437 previous) {
        super(GuiUtils.OPTIONS_TEXT);
        this.previous = previous;
    }

    @Override
    protected void collectChildren(GuiComponentCollector collector) {
        root = FZComposedLayout.contain(this, FZFlexLayout.vertical(this).spacing(GuiUtils.SPACING).also(root -> {
            root.defaultChildSettings().method_46467();
            root.child(FZText.builder(field_22785).build());
            root.child(OptionsLayout.create(this, Config.get().getResourcepacks(), Config.get().getDatapacks()), root.flexChildVerticalSettings());
            root.child(FZButton.builder().bigWidth().message(class_5244.field_24334).onPress(this::method_25419).build());
        })).padding(GuiUtils.SPACING).center().clamp().arrange().visitWidgets(collector::renderableWidget).get();
    }

    @Override
    protected void method_48640() {
        if (root == null) {
            super.method_48640();
        } else {
            root.fidgetz$setSize(field_22789, field_22790);
            root.method_48222();
        }
    }

    @Override
    public void method_25419() {
        Config.get().save();
        this.field_22787.method_1507(this.previous);
    }
}
