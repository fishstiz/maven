package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.config.DevConfig;
import io.github.fishstiz.packed_packs.config.DevConfig.ResourcePacks.LoadDefaultCondition;
import io.github.fishstiz.packed_packs.gui.model.ProfilesViewModel;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8133;
import net.minecraft.class_8666;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class ProfileList extends FZAbstractListWidget<ProfileList.Entry> implements class_8133 {
    private static final class_2561 EMPTY_TEXT = class_2561.method_43471("packed_packs.profile.empty");
    private final ScreenContext context;
    private final ProfilesViewModel model;

    public ProfileList(ScreenContext context, ProfilesViewModel model) {
        this.context = context;
        this.model = model;
        refreshEntries();
        model.subscribe(ProfilesViewModel.Property.ALL, this::refreshEntries);
    }

    @Override
    protected int maxContentWidth() {
        return 0;
    }

    private void refreshEntries() {
        io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused = method_25399();
        String focusedId = focused == null ? null : focused.model.id();
        double scrollAmount = method_44387();

        clearEntries();

        model.forEachEntry((entryModel, ignored) -> {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = new io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry(context, entryModel);
            addEntry(entry);
            if (entryModel.id().equals(focusedId)) {
                method_25395(entry);
            }
        });

        repositionEntries();
        method_44382(scrollAmount);
    }

    @Override
    public void method_53533(int height) {
        int previousHeight = method_25364();
        super.method_53533(height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    public void method_55445(int width, int height) {
        int previousHeight = method_25364();
        super.method_55445(width, height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);

        if (method_25396().isEmpty()) {
            method_75799(
                    graphics.method_75787(this, class_332.class_12228.field_63850),
                    EMPTY_TEXT,
                    0
            );
        }
    }

    @Override
    protected void extractFocusedRenderState(class_332 graphics, io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused) {
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void method_48222() {
        repositionEntries();
    }

    protected static final class Entry extends FZAbstractListWidget.Entry implements FZContextMenu.Source {
        private static final class_2960 STAR_OUTLINE_SPRITE = PackedPacks.id("icon/star_outline");
        private static final class_8666 LOCK_SPRITES = new class_8666(
                LOCK_SPRITE,
                class_2960.method_60656("widget/locked_button_highlighted")
        );
        private static final class_8666 UNLOCK_SPRITES = new class_8666(
                class_2960.method_60656("widget/unlocked_button"),
                class_2960.method_60656("widget/unlocked_button_highlighted")
        );
        private final List<class_339> children = new ArrayList<>();
        private final FZFlexLayout layout;
        private final ProfilesViewModel.Entry model;
        private final ScreenContext context;

        private Entry(ScreenContext context, ProfilesViewModel.Entry model) {
            this.model = model;
            this.context = context;
            this.layout = FZFlexLayout.horizontal();

            boolean deleteActive = !model.isLocked() && !model.isDefault();
            FZIconButton delete = layout.child(FZIconButton.builder()
                    .square()
                    .message(class_2561.method_43471("packed_packs.profile.delete"))
                    .tooltip(deleteActive ? class_2561.method_43471("packed_packs.profile.delete.info") : null)
                    .icon(getDeleteIcon(model))
                    .onPress(model::delete)
                    .active(deleteActive)
                    .build());

            FZButton select = layout.child(FZButton.builder()
                    .message(model.name())
                    .onPress(model::select)
                    .active(!model.isSelected())
                    .build(), layout.flexChildHorizontalSettings());

            children.add(select);
            children.add(delete);

            if (Config.get().isDevMode()) {
                children.add(layout.child(FZIconButton.builder()
                        .square()
                        .icon(new WidgetElements(model.isDefault() ? STAR_SPRITE : STAR_OUTLINE_SPRITE, 16, 16))
                        .tooltip(model.isDefault()
                                ? class_2561.method_43471("packed_packs.profile.default.unset")
                                : class_2561.method_43471("packed_packs.profile.default.set"))
                        .onPress(model::toggleDefault)
                        .build()));

                children.add(layout.child(FZIconButton.builder(model.isLocked() ? LOCK_SPRITES : UNLOCK_SPRITES)
                        .square()
                        .tooltip(model.isLocked()
                                ? class_2561.method_43471("packed_packs.profile.unlock")
                                : class_2561.method_43471("packed_packs.profile.lock"))
                        .onPress(model::toggleLock)
                        .build()));
            }

            for (class_339 child : children) {
                if (child instanceof FZHoverableElement hoverableElement) {
                    hoverableElement.fidgetz$setHovered(fidgetz$isHovered());
                }
            }

            layout.method_48222();
        }

        private static WidgetElements getDeleteIcon(ProfilesViewModel.Entry entry) {
            if (entry.isDefault()) {
                return new WidgetElements(STAR_SPRITE, 16, 16);
            } else if (entry.isLocked()) {
                return new WidgetElements(LOCK_SPRITE_DISABLED, 20, 20);
            } else {
                return new WidgetElements(TRASH_SPRITE, 16, 16);
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            for (class_339 child : children) {
                child.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        private static WidgetElements createIcon(Supplier<class_2960> sprite) {
            return padded16Rect(GuiUtils.createRect(sprite));
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            if (!Config.get().isDevMode()) return;

            collector.nextSection();

            collector.addEntry(builder -> buildDevEntry(builder)
                    .message(class_2561.method_43471("packed_packs.profile.default." + (model.isDefault() ? "unset" : "set")))
                    .icon(createIcon(() -> model.isDefault() ? STAR_SPRITE : STAR_OUTLINE_SPRITE))
                    .onPress(model::toggleDefault));

            collector.addEntry(builder -> buildDevEntry(builder
                    .message(class_2561.method_43471("packed_packs.profile." + (model.isLocked() ? "unlock" : "lock")))
                    .icon(createIcon(() -> model.isLocked() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL))
                    .onPress(model::toggleLock)));

            if (!model.isDefault() || context.isServerData()) {
                return;
            }

            DevConfig.ResourcePacks config = DevConfig.get().getResourcepacks();

            FZPopoverMenuItem.Builder loadConditionEntry = buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.info")));

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .closeOnInteraction(false)
                    .build());

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_FILE))
                    .closeOnInteraction(false)
                    .build());

            collector.addEntry(loadConditionEntry.build());
        }

        @Override
        public void method_46421(int x) {
            super.method_46421(x);
            layout.method_46421(x);
        }

        @Override
        public void method_46419(int y) {
            super.method_46419(y);
            layout.method_46419(y);
        }

        @Override
        protected void setWidth(int width) {
            super.setWidth(width);
            layout.fidgetz$setWidth(method_25368());
        }

        @Override
        protected void setBounds(int x, int y, int width, int height) {
            super.setBounds(x, y, width, height);
            layout.method_48229(x, y);
            layout.fidgetz$setWidth(width);
        }

        @Override
        public int method_25364() {
            return layout.method_25364();
        }

        @Override
        public List<class_339> method_25396() {
            return children;
        }
    }
}
