package io.github.fishstiz.packed_packs.gui.model;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import it.unimi.dsi.fastutil.objects.Object2LongLinkedOpenHashMap;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3288;

public record Query(
        boolean hideIncompatible,
        @Nullable SortOption sort,
        @Nullable String search,
        @Nullable String unmodifiedSearch
) implements Predicate<class_3288> {
    private static final Query EMPTY = new Query(false, null, null, null);

    public Query {
        search = search != null ? search.toLowerCase(Locale.ROOT) : null;
    }

    public static Query empty() {
        return EMPTY;
    }

    public Query withHideIncompatible(boolean hideIncompatible) {
        if (this.hideIncompatible == hideIncompatible) return this;
        return new Query(hideIncompatible, this.sort, this.search, this.unmodifiedSearch);
    }

    public Query withSort(SortOption sort) {
        if (Objects.equals(this.sort, sort)) return this;
        return new Query(this.hideIncompatible, sort, this.search, this.unmodifiedSearch);
    }

    public Query withSearch(String search) {
        String searchLower = search != null ? search.toLowerCase(Locale.ROOT) : null;
        if (Objects.equals(this.search, searchLower)) return this;
        return new Query(this.hideIncompatible, this.sort, searchLower, search);
    }

    @Override
    public boolean test(class_3288 pack) {
        if (pack == null) {
            return false;
        }
        if (this.hideIncompatible && !pack.method_14460().method_14437()) {
            return false;
        }
        return this.search == null || normalizeTitle(pack.method_14457().getString()).toLowerCase(Locale.ROOT).contains(this.search);
    }

    public boolean hasQuery() {
        return this.hideIncompatible || (this.search != null && !this.search.isEmpty()) || this.sort != null;
    }

    private static String normalizeTitle(String title) {
        return title.replaceAll("§.", "").trim();
    }

    public enum SortOption {
        VANILLA("packed_packs.sort.vanilla", "icon/sort_vanilla") {
            @Override
            public Comparator<class_3288> comparator(SequencedCollection<class_3288> packs) {
                return folderFirst((first, second) -> {
                    boolean builtInFirst = PackUtil.isBuiltIn(first);
                    boolean builtInSecond = PackUtil.isBuiltIn(second);

                    if (builtInFirst != builtInSecond) return builtInFirst ? 1 : -1;

                    boolean featureFirst = PackUtil.isFeature(first);
                    boolean featureSecond = PackUtil.isFeature(second);

                    if (featureFirst != featureSecond) return featureFirst ? 1 : -1;

                    return first.method_14457().getString().compareTo(second.method_14457().getString());
                });
            }
        },
        A_Z("packed_packs.sort.a_z", "icon/sort_a_z") {
            @Override
            public Comparator<class_3288> comparator(SequencedCollection<class_3288> packs) {
                return folderFirst(Comparator.comparing(
                        pack -> normalizeTitle(pack.method_14457().getString()),
                        String.CASE_INSENSITIVE_ORDER
                ));
            }
        },
        Z_A("packed_packs.sort.z_a", "icon/sort_z_a") {
            @Override
            public Comparator<class_3288> comparator(SequencedCollection<class_3288> packs) {
                return A_Z.comparator(packs).reversed();
            }
        },
        RECENT("packed_packs.sort.recent", "icon/sort_recent") {
            @Override
            public Comparator<class_3288> comparator(SequencedCollection<class_3288> packs) {
                Map<class_3288, Long> cache = buildTimestampCache(packs);
                return folderFirst(Comparator.<class_3288, Long>comparing(cache::get).reversed());
            }
        },
        OLDEST("packed_packs.sort.oldest", "icon/sort_oldest") {
            @Override
            public Comparator<class_3288> comparator(SequencedCollection<class_3288> packs) {
                return RECENT.comparator(packs).reversed();
            }
        };

        private final String translationKey;
        private final String spritePath;

        SortOption(String key, String icon) {
            this.translationKey = key;
            this.spritePath = icon;
        }

        public abstract Comparator<class_3288> comparator(SequencedCollection<class_3288> packs);

        public class_2960 icon() {
            return PackedPacks.id(spritePath);
        }

        public @NonNull class_2561 text() {
            return class_2561.method_43471(translationKey);
        }

        static Comparator<class_3288> folderFirst(Comparator<class_3288> base) {
            return Comparator.comparing((class_3288 pack) -> !(pack instanceof FolderPack)).thenComparing(base);
        }

        public static SortOption getOrDefault(String name) {
            if (name == null) {
                return VANILLA;
            }

            try {
                return valueOf(name);
            } catch (IllegalArgumentException e) {
                return VANILLA;
            }
        }

        private static Map<class_3288, Long> buildTimestampCache(SequencedCollection<class_3288> packs) {
            Map<class_3288, Long> cache = new Object2LongLinkedOpenHashMap<>(packs.size());
            for (class_3288 pack : packs) cache.put(pack, PackUtil.getLastUpdatedEpochMs(pack));
            return cache;
        }
    }
}
