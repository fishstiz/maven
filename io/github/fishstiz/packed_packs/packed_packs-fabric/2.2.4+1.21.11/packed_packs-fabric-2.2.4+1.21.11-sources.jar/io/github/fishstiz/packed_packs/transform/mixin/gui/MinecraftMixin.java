package io.github.fishstiz.packed_packs.transform.mixin.gui;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.screens.PackSelectionScreenArgs;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.concurrent.Executor;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5375;

@Mixin(class_310.class)
public abstract class MinecraftMixin implements Executor {
    @Shadow
    @Nullable
    public class_437 screen;

    @WrapMethod(method = "setScreen")
    private void replacePackScreen(class_437 guiScreen, Operation<Void> original) {
        if (guiScreen instanceof class_5375 packScreen &&
            (((PackSelectionScreenAccessor) packScreen).packed_packs$getPrevious() == null) &&
            !(this.screen instanceof PackedPacksScreen)) {

            PackSelectionScreenArgs args = PackSelectionScreenArgs.extract(packScreen);

            if (Config.packs(args.packType()).isReplaceOriginal()) {
                ((PackSelectionScreenAccessor) packScreen).packed_packs$closeWatcher();
                guiScreen = new PackedPacksScreen(this.screen, args);
            }
        }
        original.call(guiScreen);
    }
}
