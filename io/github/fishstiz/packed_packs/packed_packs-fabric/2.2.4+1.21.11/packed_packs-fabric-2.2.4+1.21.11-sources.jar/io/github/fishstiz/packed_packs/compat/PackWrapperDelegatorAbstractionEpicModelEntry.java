package io.github.fishstiz.packed_packs.compat;

import io.github.fishstiz.packed_packs.pack.PackIconManager;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_5369;
import org.jspecify.annotations.NullMarked;

@NullMarked
public record PackWrapperDelegatorAbstractionEpicModelEntry(class_3288 pack) implements class_5369.class_5371 {
    @Override
    public class_2960 method_30286() {
        return PackIconManager.getDefault(pack);
    }

    @Override
    public class_3281 method_29648() {
        return pack.method_14460();
    }

    @Override
    public String method_48276() {
        return pack.method_14463();
    }

    @Override
    public class_2561 method_29650() {
        return pack.method_14457();
    }

    @Override
    public class_2561 method_29651() {
        return pack.method_14459();
    }

    @Override
    public class_5352 method_29652() {
        return pack.method_29483();
    }

    @Override
    public boolean method_29654() {
        return pack.method_14465();
    }

    @Override
    public boolean method_29655() {
        return pack.method_14464();
    }

    @Override
    public void method_29656() {
        // no-op
    }

    @Override
    public void method_29657() {
        // no-op
    }

    @Override
    public void method_29658() {
        // no-op
    }

    @Override
    public void method_29659() {
        // no-op
    }

    @Override
    public boolean method_29660() {
        return false;
    }

    @Override
    public boolean method_29663() {
        return false;
    }

    @Override
    public boolean method_29664() {
        return false;
    }
}