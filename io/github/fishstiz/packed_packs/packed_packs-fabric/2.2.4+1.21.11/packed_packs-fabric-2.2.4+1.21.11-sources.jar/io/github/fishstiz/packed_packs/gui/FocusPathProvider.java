package io.github.fishstiz.packed_packs.gui;

import net.minecraft.class_364;
import net.minecraft.class_8016;
import org.jspecify.annotations.Nullable;

public interface FocusPathProvider extends class_364 {
    @Nullable class_8016 getFocusPath(FocusTarget target);
}
