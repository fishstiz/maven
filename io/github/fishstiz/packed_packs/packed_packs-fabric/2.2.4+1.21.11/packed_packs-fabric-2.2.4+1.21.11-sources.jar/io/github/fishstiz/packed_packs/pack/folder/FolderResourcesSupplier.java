package io.github.fishstiz.packed_packs.pack.folder;

import org.jspecify.annotations.NullMarked;

import java.nio.file.Path;
import net.minecraft.class_3288;
import net.minecraft.class_9224;

@NullMarked
public record FolderResourcesSupplier(Path path) implements class_3288.class_7680 {
    @Override
    public FolderResources method_52424(class_9224 location) {
        return new FolderResources(location, this.path);
    }

    @Override
    public FolderResources method_52425(class_9224 location, class_3288.class_7679 metadata) {
        return this.method_52424(location);
    }
}