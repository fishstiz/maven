package io.github.fishstiz.packed_packs.compat.vtdownloader;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.compat.ModIntegration;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.components.PreferenceHelper;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.function.BooleanSupplier;
import net.minecraft.class_10799;
import net.minecraft.class_11876;
import net.minecraft.class_11907;
import net.minecraft.class_2960;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6382;

/**
 * Copied from VTDownloader
 * <p>
 * Original work Copyright (c) 2020-2023 IotaBread
 * <p>
 * Licensed under the MIT License.
 *
 * @see <a href="https://github.com/IotaBread/VTDownloader/blob/1.21/src/main/java/me/bymartrixx/vtd/mixin/PackEntryListWidgetMixin.java">Github</a>
 */
public class VTDEditButtonWidget extends class_4264 implements FZContextMenu.Source {
    private static final String VT_DESCRIPTION_MARKER = "vanillatweaks.net";
    private static final class_2960 PENCIL_TEXTURE = class_2960.method_60655("vt_downloader", "textures/pencil.png");
    private static final int PENCIL_TEXTURE_SIZE = 32;
    private static final int PENCIL_SIZE = 16;
    private final class_437 previous;
    private final class_3288 pack;
    private final BooleanSupplier editable;
    private final Preference<Boolean> preference;

    private VTDEditButtonWidget(Preference<Boolean> prefKey, class_437 previous, class_3288 pack, BooleanSupplier editable) {
        super(0, 0, PENCIL_SIZE, PENCIL_SIZE, class_5244.field_39003);
        this.preference = prefKey;
        this.previous = previous;
        this.pack = pack;
        this.editable = editable;
        this.field_22763 = this.editable.getAsBoolean();
    }

    public static @Nullable VTDEditButtonWidget create(Preference<Boolean> prefKey, class_437 previous, class_3288 pack, BooleanSupplier editable) {
        return pack.method_14459().getString().contains(VT_DESCRIPTION_MARKER) ? new VTDEditButtonWidget(prefKey, previous, pack, editable) : null;
    }

    @Override
    protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.field_22763 = this.editable.getAsBoolean();

        int x = this.method_46426();
        int y = this.method_46427();

        float u = 0.0F;
        float v = 0.0F;
        if (!this.field_22763) {
            v = PENCIL_SIZE;
        } else if (method_49606()) {
            u = PENCIL_SIZE;
        }

        graphics.method_25290(
                class_10799.field_56883,
                PENCIL_TEXTURE,
                x, y,
                u, v,
                PENCIL_SIZE, PENCIL_SIZE,
                PENCIL_TEXTURE_SIZE, PENCIL_TEXTURE_SIZE
        );

        if (Config.get().isDevMode()) {
            PreferenceHelper.extractOverlay(graphics, preference, x, y, method_25368(), method_25364());
        }

        if (method_49606() && field_22763) {
            graphics.method_74037(class_11876.field_62455);
        }
    }

    @Override
    public void method_25306(@NonNull class_11907 inputWithModifiers) {
        if (this.field_22763) {
            VTDIntegration.createVTDScreenSetter(this.previous, this.pack).run();
        }
    }

    @Override
    protected void method_47399(@NonNull class_6382 narrationElementOutput) {
        this.method_37021(narrationElementOutput);
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        collector.addEntry(PreferenceHelper.createEntry(preference, ModIntegration.getWidgetPrefText(preference)));
    }
}
