package io.github.fishstiz.packed_packs.transform.mixin.gui;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreenPreloader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_429.class)
public abstract class OptionsScreenMixin extends class_437 {
    @Shadow
    @Final
    private static class_2561 RESOURCEPACK;

    protected OptionsScreenMixin(class_2561 title) {
        super(title);
    }

    @WrapWithCondition(method = "applyPacks", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/Minecraft;setScreen(Lnet/minecraft/client/gui/screens/Screen;)V"
    ))
    public boolean shouldCloseOnApplyPacks(class_310 instance, class_437 guiScreen) {
        // apply packs without closing the screen
        return !(this.field_22787.field_1755 instanceof PackedPacksScreen);
    }

    @ModifyReturnValue(method = "openScreenButton", at = @At("RETURN"))
    private class_4185 preloadPackedPacksScreen(class_4185 original, class_2561 message) {
        if (message == RESOURCEPACK) {
            PackedPacksScreenPreloader.attach(this, original);
        }
        return original;
    }
}
