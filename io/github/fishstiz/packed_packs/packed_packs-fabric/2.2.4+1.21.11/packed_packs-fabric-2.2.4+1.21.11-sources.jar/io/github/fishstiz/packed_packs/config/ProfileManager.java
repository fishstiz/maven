package io.github.fishstiz.packed_packs.config;

import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_3264;
import net.minecraft.class_4239;

import static io.github.fishstiz.packed_packs.config.JsonLoader.loadOrDefault;
import static io.github.fishstiz.packed_packs.config.JsonLoader.saveJson;

public final class ProfileManager {
    private static final ProfileManager RESOURCE_PACK_PROFILES = new ProfileManager(class_3264.field_14188);
    private static final ProfileManager DATA_PACK_PROFILES = new ProfileManager(class_3264.field_14190);
    private static final class_2561 DEFAULT_NAME_COMPONENT = class_2561.method_43471("packed_packs.profile.unnamed");
    private static final String PROFILE_EXTENSION = ".profile.json";
    private static final String PROFILE_EXTENSION_QUOTE = Pattern.quote(PROFILE_EXTENSION);
    private static final String PROFILE_DIR = "profiles";
    private static final String RESOURCE_PACK_DIR = "resourcepacks";
    private static final String DATA_PACK_DIR = "datapacks";
    private static final int NAME_MAX_LENGTH = 32;
    private final class_3264 packType;
    private SequencedMap<String, Profile> profiles;
    private Profile defaultProfile;
    private Profile lastViewed;

    private ProfileManager(class_3264 packType) {
        this.packType = packType;
    }

    public static ProfileManager get(class_3264 type) {
        return switch (type) {
            case field_14188 -> RESOURCE_PACK_PROFILES;
            case field_14190 -> DATA_PACK_PROFILES;
        };
    }

    public static ProfileManager clientResources() {
        return RESOURCE_PACK_PROFILES;
    }

    public static ProfileManager serverData() {
        return DATA_PACK_PROFILES;
    }

    private static Path getProfileDir(class_3264 packType) {
        return PackedPacks.getConfigDir().resolve(PROFILE_DIR).resolve(switch (packType) {
            case field_14188 -> RESOURCE_PACK_DIR;
            case field_14190 -> DATA_PACK_DIR;
        });
    }

    private static String removeExtension(String id) {
        return id.replaceFirst(PROFILE_EXTENSION_QUOTE + "$", "");
    }

    private static Path getFile(Path saveFolder, String id) {
        return saveFolder.resolve(id + PROFILE_EXTENSION);
    }

    private static Path getFile(class_3264 packType, String id) {
        return getFile(getProfileDir(packType), id);
    }

    private static ObjectArrayList<Profile> getAllProfiles(class_3264 type) {
        Path dir = getProfileDir(type);
        if (!Files.isDirectory(dir)) {
            return new ObjectArrayList<>();
        }

        List<CompletableFuture<Profile>> futures = new ObjectArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path file : stream) {
                if (file.getFileName().toString().endsWith(PROFILE_EXTENSION)) {
                    futures.add(CompletableFuture.supplyAsync(() -> {
                        String id = removeExtension(file.getFileName().toString());
                        Profile profile = loadOrDefault(file, Profile.class, () -> new Profile(id));
                        profile.id = id;
                        return profile;
                    }, class_156.method_18349()));
                }
            }
        } catch (IOException e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to fetch profiles at {}. ", dir, e);
        }

        if (futures.isEmpty()) {
            return new ObjectArrayList<>();
        }

        CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new)).join();
        return CollectionUtils.map(futures, CompletableFuture::join, ObjectArrayList::new);
    }

    private static @Nullable Profile getProfile(String id, class_3264 type) {
        Profile profile = loadOrDefault(getFile(getProfileDir(type), id), Profile.class, FunctionUtils.nullSupplier());
        if (profile != null) profile.id = id;
        return profile;
    }

    private static String findAvailableId(Path saveFolder, String name) {
        if (!Files.isDirectory(saveFolder)) {
            try {
                Files.createDirectories(saveFolder);
            } catch (IOException e) {
                PackedPacks.LOGGER.warn("[packed_packs] Failed to create profile directory at {}. ", saveFolder, e);
            }
        }

        try {
            return removeExtension(class_4239.method_19773(saveFolder, name, PROFILE_EXTENSION));
        } catch (IOException e) {
            return name + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss.SSS"));
        }
    }

    private static String trimName(String name) {
        if (name == null) return "";
        return name.length() <= NAME_MAX_LENGTH ? name : name.substring(0, NAME_MAX_LENGTH);
    }

    private static String sanitizeName(String name) {
        String trimmed = trimName(name);
        return trimmed.isBlank() ? DEFAULT_NAME_COMPONENT.getString() : name;
    }

    public static int getNameMaxLength() {
        return NAME_MAX_LENGTH;
    }

    public static class_2561 getDefaultNameComponent() {
        return DEFAULT_NAME_COMPONENT;
    }

    public @Nullable Profile get(String id) {
        if (this.profiles != null) {
            Profile cached = this.profiles.get(id);
            if (cached != null) return cached;
        }

        Profile profile = getProfile(id, this.packType);
        if (profile != null) {
            profile.id = id;
            if (this.profiles != null) this.profiles.put(id, profile);
        }

        return profile;
    }

    public @Nullable Profile getDefault() {
        Profile localDefault = this.defaultProfile;
        if (localDefault != null) return localDefault;

        String id = DevConfig.packs(this.packType).getDefaultProfile();
        if (id == null) return null;

        Profile fetched = this.get(id);
        if (fetched == null) {
            DevConfig.packs(this.packType).setDefaultProfile(null);
        } else {
            this.defaultProfile = fetched;
        }

        return fetched;
    }

    public @Nullable Profile getLastViewed() {
        Profile localLast = this.lastViewed;
        if (localLast != null) return localLast;

        String id = Config.packs(this.packType).getLastViewedProfile();
        if (id == null) return null;

        Profile fetched = this.get(id);
        if (fetched == null) {
            Config.packs(this.packType).setLastViewedProfile(null);
        } else {
            this.lastViewed = fetched;
        }

        return fetched;
    }

    public Profile create(String name) {
        String trimmed = sanitizeName(name);
        String id = findAvailableId(getProfileDir(this.packType), trimmed);
        Profile profile = new Profile(id);
        profile.temp = true;
        return profile;
    }

    public Profile copy(Profile profile) {
        if (profile.temp) this.save(profile);
        String cleanName = sanitizeName(profile.getName().replaceAll("\\s\\(\\d+\\)$", ""));
        String id = findAvailableId(getProfileDir(this.packType), cleanName);
        Profile copy = profile.copy(id);
        copy.temp = true;
        return copy;
    }

    public boolean save(Profile profile) {
        if (profile.getName().isBlank()) {
            rename(profile, sanitizeName(profile.getId()));
        }
        if (profile.temp) {
            profile.id = findAvailableId(getProfileDir(this.packType), sanitizeName(profile.getName()));
        }
        if (saveJson(profile, getFile(this.packType, profile.getId()))) {
            profile.temp = false;
            Map<String, Profile> map = this.profiles;
            if (map != null) map.putIfAbsent(profile.getId(), profile);
            return true;
        }
        return false;
    }

    public void setOrder(List<Profile> profiles) {
        Config.packs(this.packType).setProfileOrder(CollectionUtils.map(profiles, Profile::getId));
    }

    public void setDefault(@Nullable Profile profile) {
        DevConfig.packs(this.packType).setDefaultProfile(profile);
        this.defaultProfile = profile;
    }

    public void setLastViewed(@Nullable Profile profile) {
        Config.packs(this.packType).setLastViewedProfile(profile);
        this.lastViewed = profile;
    }

    public boolean delete(Profile profile) {
        Path file = getFile(this.packType, profile.getId());
        try {
            Files.deleteIfExists(file);

            Config.Packs config = Config.packs(this.packType);
            DevConfig.Packs metaConfig = DevConfig.packs(this.packType);

            if (Objects.equals(profile.getId(), metaConfig.getDefaultProfile())) {
                metaConfig.setDefaultProfile(null);
                this.defaultProfile = null;
            }
            if (Objects.equals(profile.getId(), config.getLastViewedProfile())) {
                config.setLastViewedProfile(null);
                this.lastViewed = null;
            }

            Map<String, Profile> map = this.profiles;
            if (map != null) {
                map.remove(profile.getId());
            }

            return true;
        } catch (IOException e) {
            PackedPacks.LOGGER.error("[packed_packs] Failed to delete profile at {}", file, e);
            return false;
        }
    }

    public void rename(Profile profile, String name) {
        if (profile.isLocked()) return;
        String trimmed = trimName(name);
        profile.setName(trimmed);
    }

    public List<Profile> getProfiles() {
        if (this.profiles != null) return List.copyOf(this.profiles.sequencedValues());

        ObjectArrayList<Profile> profiles = getAllProfiles(this.packType);
        List<String> order = Config.packs(this.packType).getProfileOrder();
        Map<String, Integer> orderMap = new Object2IntOpenHashMap<>(order.size());
        for (int i = 0; i < order.size(); i++) {
            orderMap.put(order.get(i), i);
        }

        profiles.sort(Comparator.<Profile>comparingInt(profile ->
                orderMap.containsKey(profile.getId()) ? orderMap.get(profile.getId()) + orderMap.size() : 0
        ).thenComparing(Profile::getName));

        SortedMap<String, Profile> profileMap = new Object2ObjectLinkedOpenHashMap<>(profiles.size());

        Profile lastViewed = this.lastViewed;
        Profile defaultProfile = this.defaultProfile;

        for (Profile profile : profiles) {
            if (Objects.equals(profile, defaultProfile)) {
                profileMap.put(profile.getId(), defaultProfile);
            } else if (Objects.equals(profile, lastViewed)) {
                profileMap.put(profile.getId(), lastViewed);
            } else {
                profileMap.put(profile.getId(), profile);
            }
        }

        this.profiles = profileMap;
        return List.copyOf(profileMap.sequencedValues());
    }

    public void remapAndSavePackIds(String oldPackId, String newPackId) {
        Profile defaultProfile = this.getDefault();
        if (defaultProfile != null && defaultProfile.remapPackId(oldPackId, newPackId)) {
            this.save(defaultProfile);
        }
        for (Profile profile : this.getProfiles()) {
            if (!Objects.equals(profile, defaultProfile) && profile.remapPackId(oldPackId, newPackId)) {
                this.save(profile);
            }
        }
    }
}
