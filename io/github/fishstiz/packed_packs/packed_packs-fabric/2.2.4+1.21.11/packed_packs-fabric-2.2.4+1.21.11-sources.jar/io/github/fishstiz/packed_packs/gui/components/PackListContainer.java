package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.*;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.gui.ContainerEventHandlerPatch;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.model.PackListUtils;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import io.github.fishstiz.packed_packs.util.Colors;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_11875;
import net.minecraft.class_11909;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8027;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class PackListContainer extends class_339 implements FocusPathProvider, class_8133, ContainerEventHandlerPatch {
    private final @Nullable PackListContainer root;
    private final ScreenContext screenContext;
    private final PackListViewModel viewModel;
    private final PackList packList;
    private PackListContainer.@Nullable Folder folder;
    private @Nullable class_364 focused;
    private boolean dragging;
    private List<class_364> children;

    private PackListContainer(@Nullable PackListContainer root, ScreenContext screenContext, PackListViewModel viewModel) {
        super(0, 0, 0, 0, class_5244.field_39003);
        this.root = root;
        this.screenContext = screenContext;
        this.viewModel = viewModel;
        this.packList = new PackList(screenContext, viewModel);
        this.children = List.of(this.packList);
        this.viewModel.subscribe(PackListViewModel.Property.FOLDER, this::refresh);
    }

    private PackListContainer(PackListContainer root, PackListViewModel.Module viewModel) {
        this(root, root.screenContext, viewModel);
    }

    public PackListContainer(ScreenContext screenContext, PackListViewModel viewModel) {
        this(null, screenContext, viewModel);
    }

    private void updateState(class_364 target) {
        this.children = List.of(target);
        method_25395(target);
    }

    private void refresh() {
        boolean isOpened = viewModel.isFolderOpened();
        if (isOpened == (this.folder != null)) {
            return;
        }

        if (isOpened) {
            Folder newFolder = new Folder(root == null ? this : root, viewModel.createFolderSlice());
            this.folder = newFolder;
            updateState(newFolder);
            class_8016 path = newFolder.method_48205(new class_8023.class_8025());
            if (path != null) path.method_48195(true);
        } else {
            this.folder = null;
            updateState(packList);
        }
    }

    public boolean renderDroppableZone(ActiveAction.Dragging dragging, class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.folder != null) {
            return this.folder.listContainer.renderDroppableZone(dragging, guiGraphics, mouseX, mouseY, partialTick);
        }
        packList.renderDroppableZone(guiGraphics, dragging, mouseX, mouseY, partialTick);
        if (packList.method_25405(mouseX, mouseY)) {
            return dragging.target() == viewModel.key() || PackListUtils.canInteract(dragging.target(), viewModel.key());
        }
        return false;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        packList.method_25394(graphics, mouseX, mouseY, partialTick);
        if (this.folder != null) {
            this.folder.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
        if (this.folder != null) {
            this.folder.listContainer.method_37020(output.method_37031());
        } else {
            packList.method_37020(output.method_37031());
        }
    }

    public void visitDeepestList(Consumer<PackList> visitor) {
        if (viewModel.isFolderOpened() && this.folder != null) {
            this.folder.listContainer.visitDeepestList(visitor);
        } else {
            visitor.accept(packList);
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        this.visitDeepestList(list -> list.onDrop(dragging, mouseX, mouseY));
    }

    public PackListViewModel model() {
        return viewModel;
    }

    @Override
    public List<class_364> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean isDragging) {
        this.dragging = isDragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        } else {
            method_25395(this.folder == null ? packList : this.folder);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }
            if (focused != null) {
                focused.method_25365(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        FocusPathProvider child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.getFocusPath(target));
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        class_364 child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.method_48205(event));
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        packList.method_53533(height);
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        packList.method_25358(width);
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        packList.method_46421(x);
        repositionFolder();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        packList.method_46419(y);
        repositionFolder();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        method_25358(width);
        method_53533(height);
    }

    @Override
    public void method_48229(int x, int y) {
        super.method_48229(x, y);
        method_46421(x);
        method_46419(y);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        if (root != null && viewModel.isFolderOpened() && this.folder != null) {
            return root.method_25405(mouseX, mouseY);
        }
        return super.method_25405(mouseX, mouseY);
    }

    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
        return ContainerEventHandlerPatch.super.method_25402(mouseButtonEvent, doubleClicked);
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        return ContainerEventHandlerPatch.super.method_25406(mouseButtonEvent);
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.method_25403(mouseButtonEvent, dragX, dragY);
    }

    @Override
    public void method_48227(Consumer<class_8021> visitor) {
        visitor.accept(this);
    }

    @Override
    public void method_48222() {
        packList.initializeEntries();
        if (this.folder != null) this.folder.arrangeElements();
    }

    private void repositionFolder() {
        if (this.folder != null) this.folder.repositionElements();
    }

    static class Folder extends class_362 implements FocusPathProvider, FZContextMenu.Source, ContainerEventHandlerPatch, class_4068 {
        private static final int HEADER_SIZE = 16;
        private static final int LAYOUT_SPACING = SPACING / 2;
        private final PackListContainer root;
        private final PackListViewModel.Module moduleModel;
        private final FZIcon background;
        private final PackListContainer listContainer;
        private final FZIconButton closeButton;
        private final FZIcon folderIcon;
        private final FZText folderTitle;
        private final FZLayout layout;
        private final Runnable unsubscribe;
        private List<class_364> children = Collections.emptyList();
        private List<class_4068> renderables = Collections.emptyList();

        Folder(PackListContainer root, PackListViewModel.Module moduleModel) {
            this.root = root;
            this.moduleModel = moduleModel;
            this.listContainer = new PackListContainer(root, moduleModel);
            this.background = FZIcon.builder(class_2960.method_60656("popup/background")).build();
            this.closeButton = FZIconButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .icon(new WidgetElements(PackedPacks.id("icon/cross"), 16, 16))
                    .onPress(moduleModel::close)
                    .build();
            this.folderIcon = FZIcon.builder(Renderables.texture(moduleModel.icon(), 16, 16))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .build();
            this.folderTitle = FZText.builder(Objects.requireNonNull(moduleModel.currentFolder()).method_14457())
                    .height(HEADER_SIZE)
                    .build();

            FZFlexLayout section = FZFlexLayout.vertical(root).spacing(LAYOUT_SPACING);
            {
                FZFlexLayout header = section.child(FZFlexLayout.horizontal(), section.flexChildHorizontalSettings());
                {
                    header.spacing(LAYOUT_SPACING).alignContents(Justification.CENTER);
                    header.child(closeButton);
                    header.child(folderIcon);
                    header.child(folderTitle, header.flexChildHorizontalSettings());
                }
                section.child(listContainer, section.flexChildSettings());
            }

            this.layout = FZComposedLayout.compose(section).padding(SPACING).clamp((class_8021) root);

            Runnable unsubscribeCurrentFolder = moduleModel.subscribeToCurrentFolder(this::refresh);
            Runnable unsubscribeChildFolder = moduleModel.subscribe(PackListViewModel.Property.FOLDER, this::refreshChild);

            this.unsubscribe = () -> {
                unsubscribeCurrentFolder.run();
                unsubscribeChildFolder.run();
            };

            refresh();
            arrangeElements();
            refreshChild();
        }

        private void refresh() {
            FolderPack folderPack = moduleModel.currentFolder();
            if (folderPack == null) {
                unsubscribe.run();
                children = Collections.emptyList();
                renderables = Collections.emptyList();
            }
        }

        private void refreshChild() {
            if (!moduleModel.isFolderOpened()) {
                this.renderables = List.of(background, folderIcon, folderTitle, closeButton, listContainer);
                this.children = List.of(closeButton, listContainer);
            } else {
                this.renderables = List.of(listContainer);
                this.children = List.of(listContainer);
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            if (method_25405(mouseX, mouseY)) {
                graphics.method_74037(class_11875.field_62449);
            }
            for (class_4068 renderable : this.renderables) {
                renderable.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            FolderPack folderPack = moduleModel.currentFolder();
            if (folderPack == null) {
                FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
                return;
            }

            collector.addEntry(builder -> builder
                    .message(folderPack.method_14457())
                    .icon(padded16Rect(Renderables.texture(moduleModel.icon(), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false)
                    .applyCursorChangeWhenActive(false));

            collector.addEntry(builder -> builder
                    .message(class_5244.field_24339.method_27661().method_10852(class_5244.field_39678))
                    .onPress(moduleModel::close));

            if (!listContainer.packList.method_49606()) {
                if (moduleModel.fileModifiable()) {
                    collector.addEntry(builder -> builder
                            .message(RENAME_FILE_TEXT)
                            .active(moduleModel::fileModifiable)
                            .onPress(moduleModel::openRename));
                    collector.addEntry(builder -> builder
                            .message(DELETE_FILE_TEXT)
                            .active(moduleModel::fileModifiable)
                            .onPress(moduleModel::delete));
                }
                if (PackUtil.validatePackPath(folderPack) != null) {
                    collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(folderPack)));
                    collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(folderPack)));
                }
            }

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        void repositionElements() {
            layout.method_48229(root.method_46426(), root.method_46427());
            background.method_48229(root.method_46426(), root.method_46427());
        }

        void arrangeElements() {
            if (layout.method_25368() != root.method_25368() || layout.method_25364() != root.method_25364()) {
                layout.method_48222();
                layout.fidgetz$setSize(root.method_25368(), root.method_25364());
                background.method_55445(root.method_25368(), root.method_25364());
                repositionElements();
            }
        }

        @Override
        public @Nullable class_8016 getFocusPath(FocusTarget target) {
            return class_8016.method_48192(this, listContainer.getFocusPath(target));
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 event) {
            if (moduleModel.isFolderOpened()) {
                return class_8016.method_48192(this, listContainer.method_48205(event));
            }

            if (event instanceof class_8023.class_8025) {
                class_8016 path = listContainer.method_48205(event);
                return path == null ? class_8016.method_48194(closeButton, this) : class_8016.method_48192(this, path);
            }

            if (!method_25370() &&
                event instanceof class_8023.class_8024(class_8028 direction) &&
                direction.method_48237() == class_8027.field_41822) {
                class_8016 path = listContainer.method_48205(event);
                if (path != null) {
                    return class_8016.method_48192(this, path);
                }
            }

            return super.method_48205(event);
        }

        @Override
        public void method_25365(boolean isFocused) {
            if (!isFocused) {
                method_25395(null);
            }
        }

        @Override
        public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
            return ContainerEventHandlerPatch.super.method_25402(mouseButtonEvent, doubleClicked) && moduleModel.isOpened();
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return method_48202().method_58137((int) mouseX, (int) mouseY);
        }

        @Override
        public List<class_364> method_25396() {
            return children;
        }

        @Override
        public class_8030 method_48202() {
            return layout.method_48202();
        }
    }
}
