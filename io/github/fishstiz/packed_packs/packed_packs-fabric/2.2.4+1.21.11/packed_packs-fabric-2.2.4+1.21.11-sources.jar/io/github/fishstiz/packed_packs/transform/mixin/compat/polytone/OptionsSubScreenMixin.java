package io.github.fishstiz.packed_packs.transform.mixin.compat.polytone;

import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_4667.class)
public abstract class OptionsSubScreenMixin {
    // polytone's screen factory only accepts PackSelectionScreen as parent.
    @ModifyVariable(method = "<init>", at = @At("HEAD"), argsOnly = true)
    private static class_437 replacePackScreen(class_437 parent) {
        if (parent instanceof PackSelectionScreenAccessor packScreen) {
            class_437 screen = packScreen.packed_packs$getActualScreen();
            if (screen instanceof PackedPacksScreen packedPacksScreen) {
                return packedPacksScreen;
            }
        }
        return parent;
    }
}
