package io.github.fishstiz.packed_packs.transform.mixin.compat.vtd;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.fishstiz.packed_packs.api.context.PackContext;
import net.minecraft.class_2561;
import net.minecraft.class_3288;
import net.minecraft.class_437;
import net.minecraft.class_5369;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Slice;

@Pseudo
@Mixin(targets = "me.bymartrixx.vtd.gui.VTDownloadScreen", remap = false)
public abstract class VTDownloaderScreenMixin extends class_437 {
    protected VTDownloaderScreenMixin(class_2561 title) {
        super(title);
    }

    @Dynamic
    @Shadow(aliases = "pack")
    private class_5369.class_5371 packEntry;

    @Dynamic
    @WrapOperation(
            method = "readResourcePack",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/lang/Class;isNestmateOf(Ljava/lang/Class;)Z"
            ),
            require = 0
    )
    private boolean hasPack(Class<?> instance, Class<?> clazz, Operation<Boolean> original) {
        return original.call(instance, clazz) || this.packEntry instanceof PackContext;
    }

    @Dynamic
    @WrapOperation(
            method = "readResourcePack",
            slice = @Slice(from = @At(value = "INVOKE", target = "Ljava/lang/Class;isNestmateOf(Ljava/lang/Class;)Z")),
            at = @At(
                    value = "FIELD:FIRST",
                    target = "Lme/bymartrixx/vtd/gui/VTDownloadScreen;pack:Lnet/minecraft/client/gui/screens/packs/PackSelectionModel$Entry;",
                    ordinal = 0,
                    remap = true,
                    opcode = Opcodes.GETFIELD
            ),
            require = 0
    )
    private class_5369.class_5371 getPackEntry(@Coerce class_437 instance, Operation<class_5369.class_5371> original) {
        return this.packEntry instanceof PackContext ? null : original.call(instance);
    }

    @Dynamic
    @WrapOperation(
            method = "readResourcePack",
            at = @At(
                    value = "INVOKE",
                    target = "Lme/bymartrixx/vtd/access/AbstractPackAccess;vtdownloader$getProfile()Lnet/minecraft/server/packs/repository/Pack;",
                    remap = true
            ),
            require = 0
    )
    private class_3288 getPack(@Coerce Object instance, Operation<class_3288> original) {
        return this.packEntry instanceof PackContext ctx ? ctx.pack() : original.call(instance);
    }
}
