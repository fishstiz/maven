package io.github.fishstiz.packed_packs;

import io.github.fishstiz.packed_packs.platform.Services;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_2960;

public class PackedPacks {
    public static final String MOD_ID = "packed_packs";
    public static final String MOD_NAME = "Packed Packs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final boolean DEBUG = System.getProperty("packed_packs.debug") != null;

    private PackedPacks() {
    }

    public static Path getConfigDir() {
        return Services.PLATFORM.getConfigDir().resolve(MOD_ID);
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    public static void openPath(Path path) {
        class_156.method_668().method_60932(path);
    }

    public static long duration(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    public static <T, R> R mapOrElse(T obj, R defaultValue, Function<T, R> mapper) {
        return obj != null ? mapper.apply(obj) : defaultValue;
    }

    public static void runInParallel(Runnable... tasks) {
        @SuppressWarnings("unchecked")
        CompletableFuture<Void>[] futures = (CompletableFuture<Void>[]) new CompletableFuture<?>[tasks.length];
        for (int i = 0; i < tasks.length; i++) {
            futures[i] = CompletableFuture.runAsync(tasks[i], class_156.method_18349());
        }
        CompletableFuture.allOf(futures).join();
    }
}
