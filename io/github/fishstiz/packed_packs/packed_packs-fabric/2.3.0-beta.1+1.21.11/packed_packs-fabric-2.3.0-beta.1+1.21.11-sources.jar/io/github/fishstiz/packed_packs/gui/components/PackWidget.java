package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.FZText;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_7940;
import net.minecraft.class_8012;
import net.minecraft.class_8021;

class PackWidget implements class_4068, class_8021 {
    static final int ICON_SIZE = 32;
    private static final class_2561 INCOMPATIBLE_TITLE = class_2561.method_43471("pack.incompatible");
    private static final int DESCRIPTION_LINES = 2;
    private static final int SPACING = 2;
    private final class_327 font;
    private final PackList.Entry entry;
    private final FZText nameWidget;
    private final class_7940 descriptionWidget;
    private int cachedBodyWidth;
    private boolean warningShown;
    private int x;
    private int y;
    private int width;
    private int height;

    PackWidget(PackList.Entry entry, int height) {
        this.entry = entry;
        this.font = class_310.method_1551().field_1772;
        this.nameWidget = FZText.builder(entry.pack.title()).build();
        this.height = height;
        this.descriptionWidget = new class_7940(getExtendedDescription(), font);
        repositionElements();
    }

    private class_2561 getExtendedDescription() {
        return class_2564.method_75859(entry.pack.decoratedDescription(), class_2583.field_24360.method_36139(class_8012.field_44941));
    }

    private void repositionHorizontal() {
        int bodyX = x + ICON_SIZE + SPACING * 2;
        int bodyWidth = (x + width) - SPACING * 2 - bodyX;

        nameWidget.method_46421(bodyX);
        nameWidget.method_25358(bodyWidth);

        descriptionWidget.method_48985(DESCRIPTION_LINES);
        descriptionWidget.method_48981(false);
        descriptionWidget.method_46421(nameWidget.method_46426());
        descriptionWidget.method_48984(bodyWidth);

        this.cachedBodyWidth = bodyWidth;
    }

    private void repositionVertical() {
        int lineHeight = font.field_2000;
        int totalContentHeight = lineHeight + SPACING + (lineHeight * DESCRIPTION_LINES);
        int startY = y + (height - totalContentHeight) / 2;
        nameWidget.method_46419(startY);
        this.descriptionWidget.method_46419(startY + lineHeight + SPACING);
    }

    private void repositionElements() {
        repositionHorizontal();
        repositionVertical();
    }

    public void setWidth(int width) {
        this.width = width;
        repositionElements();
    }

    public void setHeight(int height) {
        this.height = height;
        repositionVertical();
    }

    @Override
    public void method_46421(int x) {
        this.x = x;
        repositionHorizontal();
    }

    @Override
    public void method_46419(int y) {
        this.y = y;
        repositionVertical();
    }

    @Override
    public int method_46426() {
        return x;
    }

    @Override
    public int method_46427() {
        return y;
    }

    @Override
    public int method_25368() {
        return width;
    }

    @Override
    public int method_25364() {
        return height;
    }

    @Override
    public void method_48206(Consumer<class_339> widgetVisitor) {
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        GuiGraphicsUtils.texture(graphics, entry.getPackIcon(), x + SPACING, y, ICON_SIZE, ICON_SIZE);
        nameWidget.method_25394(graphics, mouseX, mouseY, partialTick);
        this.descriptionWidget.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    void checkCompatibility(boolean showWarning) {
        if (showWarning) {
            if (!this.warningShown && !entry.pack.compatibility().method_14437() && !entry.isIncompatibleWarningsHidden()) {
                nameWidget.method_25355(INCOMPATIBLE_TITLE);
                this.descriptionWidget.method_25355(entry.pack.compatibility().method_14439());
                this.warningShown = true;
            }
        } else if (this.warningShown) {
            nameWidget.method_25355(entry.pack.title());
            nameWidget.method_25358(this.cachedBodyWidth);
            this.descriptionWidget.method_25355(getExtendedDescription());
            this.warningShown = false;
        }
    }
}
