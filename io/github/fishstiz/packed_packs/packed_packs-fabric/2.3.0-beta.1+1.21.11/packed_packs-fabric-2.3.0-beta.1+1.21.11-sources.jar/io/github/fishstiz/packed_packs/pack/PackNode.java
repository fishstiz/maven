package io.github.fishstiz.packed_packs.pack;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.transform.interfaces.ConfiguredPack;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7699;
import net.minecraft.class_9224;
import net.minecraft.class_9225;

public sealed interface PackNode {
    String id();

    @Nullable String parentId();

    class_2561 title();

    class_3288.class_7679 metadata();

    class_3281 compatibility();

    class_9225 selectionConfig();

    class_5352 packSource();

    @Nullable Path path();

    default class_2561 decoratedDescription() {
        return packSource().method_45282(metadata().comp_999());
    }

    class_2960 defaultIcon();

    class_3262 open();

    void visitNodes(Consumer<PackNode> visitor);

    void visitPacks(Consumer<class_3288> visitor);

    Stream<PackNode> stream();

    record Parent(
            @Nullable String parentId,
            Path path,
            class_9224 location,
            class_3288.class_7680 resourcesSupplier,
            List<PackNode> children
    ) implements PackNode {
        public static final class_2960 DEFAULT_ICON = PackedPacks.id("textures/misc/unknown_folder.png");
        public static final class_2561 DESCRIPTION = class_2561.method_43471("packed_packs.folder");
        public static final class_9225 SELECTION_CONFIG = new class_9225(false, class_3288.class_3289.field_14280, false);
        public static final class_3288.class_7679 METADATA = new class_3288.class_7679(
                DESCRIPTION,
                class_3281.field_14224,
                class_7699.method_45397(),
                Collections.emptyList()
        );

        public Parent {
            Objects.requireNonNull(path, "path cannot be null");
            children = List.copyOf(children);
        }

        @Override
        public String id() {
            return location.comp_2329();
        }

        @Override
        public class_2561 title() {
            return location.comp_2330();
        }

        @Override
        public class_3288.class_7679 metadata() {
            return METADATA;
        }

        @Override
        public class_3281 compatibility() {
            return METADATA.comp_1583();
        }

        @Override
        public class_9225 selectionConfig() {
            return SELECTION_CONFIG;
        }

        @Override
        public class_5352 packSource() {
            return location.comp_2331();
        }

        @Override
        public class_2960 defaultIcon() {
            return DEFAULT_ICON;
        }

        @Override
        public class_3262 open() {
            return resourcesSupplier.method_52425(location, metadata());
        }

        @Override
        public void visitNodes(Consumer<PackNode> visitor) {
            visitor.accept(this);
            children.forEach(child -> child.visitNodes(visitor));
        }

        @Override
        public void visitPacks(Consumer<class_3288> visitor) {
            children.forEach(child -> child.visitPacks(visitor));
        }

        @Override
        public Stream<PackNode> stream() {
            return Stream.concat(
                    Stream.of(this),
                    children.stream().flatMap(PackNode::stream)
            );
        }

        @Override
        public int hashCode() {
            return location.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            return obj == this || (obj instanceof Parent other && location.equals(other.location));
        }

        @Override
        public String toString() {
            return "Parent{" +
                   "id='" + location.comp_2329() + '\'' +
                   ", parentId=" + parentId +
                   '}';
        }
    }

    record Leaf(class_3288 pack, @Nullable Path path, @Nullable String parentId) implements PackNode {
        public static final class_2960 DEFAULT_ICON = class_2960.method_60656("textures/misc/unknown_pack.png");

        @Override
        public String id() {
            return pack.method_14463();
        }

        @Override
        public class_2561 title() {
            return pack.method_14457();
        }

        @Override
        public class_3288.class_7679 metadata() {
            return ((ConfiguredPack) pack).packed_packs$getMetadata();
        }

        @Override
        public class_3281 compatibility() {
            return pack.method_14460();
        }

        @Override
        public class_9225 selectionConfig() {
            return ((ConfiguredPack) pack).packed_packs$originalConfig();
        }

        @Override
        public class_5352 packSource() {
            return pack.method_29483();
        }

        @Override
        public class_2960 defaultIcon() {
            return DEFAULT_ICON;
        }

        @Override
        public class_3262 open() {
            return pack.method_14458();
        }

        @Override
        public void visitNodes(Consumer<PackNode> visitor) {
            visitor.accept(this);
        }

        @Override
        public void visitPacks(Consumer<class_3288> visitor) {
            visitor.accept(pack);
        }

        @Override
        public Stream<PackNode> stream() {
            return Stream.of(this);
        }

        @Override
        public int hashCode() {
            return pack.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            return obj == this || (obj instanceof Leaf other && pack.equals(other.pack));
        }

        @Override
        public String toString() {
            return "Leaf{" +
                   "id='" + pack.method_14463() + '\'' +
                   ", parentId=" + parentId +
                   '}';
        }
    }
}
