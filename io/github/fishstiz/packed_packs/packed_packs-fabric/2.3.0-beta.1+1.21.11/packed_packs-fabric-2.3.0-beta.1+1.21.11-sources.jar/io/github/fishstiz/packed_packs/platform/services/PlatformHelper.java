package io.github.fishstiz.packed_packs.platform.services;

import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_5352;

public interface PlatformHelper {
    String getPlatform();

    Path getConfigDir();

    boolean isModLoaded(String id);

    boolean isDev();

    default List<PackedPacksInitializer> getModExtensions() {
        return Collections.emptyList();
    }

    default boolean isBuiltInPack(class_5352 packSource) {
        return false;
    }
}
