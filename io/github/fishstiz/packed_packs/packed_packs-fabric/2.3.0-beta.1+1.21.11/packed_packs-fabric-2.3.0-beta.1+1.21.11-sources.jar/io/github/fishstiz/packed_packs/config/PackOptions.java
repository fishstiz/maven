package io.github.fishstiz.packed_packs.config;

import net.minecraft.class_3288;
import net.minecraft.class_9225;

public interface PackOptions {
    boolean isHidden(String packId);

    boolean isRequired(String packId);

    boolean isFixed(String packId);

    class_3288.class_3289 getPosition(String packId);

    class_9225 getSelectionConfig(String packId);
}
