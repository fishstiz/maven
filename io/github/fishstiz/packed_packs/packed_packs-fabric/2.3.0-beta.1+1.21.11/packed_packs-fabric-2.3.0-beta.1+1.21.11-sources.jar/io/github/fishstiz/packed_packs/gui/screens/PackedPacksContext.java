package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.GuiHooks;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuSink;
import io.github.fishstiz.packed_packs.config.PackConfigs;
import io.github.fishstiz.packed_packs.gui.UiEffect;
import io.github.fishstiz.packed_packs.gui.components.PreferenceHelper;
import io.github.fishstiz.packed_packs.gui.Store;
import io.github.fishstiz.packed_packs.gui.actions.intents.Intent;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.gui.ContextMenuItemSpecImpl;
import io.github.fishstiz.packed_packs.pack.PackIconCache;
import io.github.fishstiz.packed_packs.pack.PackNodeRepository;
import io.github.fishstiz.packed_packs.pack.PackResourcesService;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5375;
import net.minecraft.class_6379;

import static io.github.fishstiz.packed_packs.util.PackUtil.mapValidDirectories;

public final class PackedPacksContext implements ScreenContext {
    private final class_310 minecraft;
    private final @Nullable class_437 previousScreen;
    private final class_437 screen;
    private final PackSelectionScreenArgs args;
    private final Path packDir;
    private final class_3264 packType;
    private final PackConfigs configs;
    private final class_3283 packRepository;
    private final PackNodeRepository nodeRepository;
    private final PackResourcesService resources;
    private final PackIconCache iconCache;
    private final Store store;
    private @Nullable List<Path> otherDirectories = null;

    public PackedPacksContext(
            class_310 minecraft,
            @Nullable class_437 previousScreen,
            PackedPacksScreen screen,
            PackSelectionScreenArgs args
    ) {
        this.minecraft = minecraft;
        this.previousScreen = previousScreen;
        this.screen = screen;
        this.args = args;
        this.packDir = args.packDir();
        this.packType = args.packType();
        this.packRepository = args.repository();
        this.configs = PackConfigs.get(packType);
        this.nodeRepository = new PackNodeRepository(packRepository, configs.user(), packDir);
        this.resources = new PackResourcesService(packType, nodeRepository);
        this.iconCache = new PackIconCache(minecraft, minecraft.method_1531());
        this.store = new Store(minecraft, configs, iconCache, resources(), nodeRepository);
    }

    public FZRef<PackedPacksState> state() {
        return store;
    }

    public void dispatch(Intent intent) {
        store.dispatch(intent);
    }

    void initializeState() {
        store.initializeState();
        this.otherDirectories = null;
    }

    Path packDir() {
        return packDir;
    }

    List<Path> otherDirectories() {
        if (this.otherDirectories == null) {
            Set<Path> additionalFolders = new LinkedHashSet<>(mapValidDirectories(configs.user().getAdditionalFolders()));
            additionalFolders.addAll(nodeRepository.otherDirectorySources());
            this.otherDirectories = List.copyOf(additionalFolders);
        }
        return this.otherDirectories;
    }

    void setEffectHandler(Consumer<UiEffect> effect) {
        store.setEffectHandler(effect);
    }

    @Override
    public class_310 getMinecraft() {
        return minecraft;
    }

    @Override
    public class_437 screen() {
        return screen;
    }

    public PackConfigs configs() {
        return configs;
    }

    @Override
    public class_3283 packRepository() {
        return packRepository;
    }

    @Override
    public class_5375 originalScreen() {
        return previousScreen instanceof class_5375 packScreen ? packScreen : args.createDummy();
    }

    @Override
    public class_3264 packType() {
        return packType;
    }

    @Override
    public List<class_3288> getAvailablePacks() {
        return store.getDisabledPacks();
    }

    @Override
    public List<class_3288> getSelectedPacks() {
        return store.getEnabledPacks();
    }

    void startWatcher() {
        List<Path> otherSources = otherDirectories();
        List<Path> directories = new ArrayList<>(otherSources.size() + 1);
        directories.add(packDir);
        directories.addAll(otherSources);
        store.startWatcher(this, directories);
    }

    void stopWatcher() {
        store.stopWatcher();
    }

    void pollWatcher() {
        store.pollWatcher();
    }

    @Override
    public void reload() {
        store.refreshRepository();
    }

    public boolean canReload() {
        return store.canRefresh();
    }

    void cancelReload() {
        store.cancelRefresh();
    }

    void undo() {
        store.undo();
    }

    void redo() {
        store.redo();
    }

    @Override
    public void commit() {
        store.savePacksToRepository();
        args.output().accept(packRepository);
    }

    public void saveSelectedProfile() {
        store.saveSelectedProfile();
    }

    void saveState() {
        store.saveState();
    }

    public PackIconCache iconCache() {
        return iconCache;
    }

    public PackResourcesService resources() {
        return resources;
    }

    @Override
    public boolean devMode() {
        return store.value().devMode();
    }

    @Override
    public void rebuild() {
        GuiHooks.rebuildWidgets(screen);
    }

    @Override
    public <T extends class_364 & class_6379> T addWidget(T widget) {
        return GuiHooks.addWidget(screen, widget);
    }

    @Override
    public <T extends class_4068> T addRenderableOnly(T renderable) {
        return GuiHooks.addRenderableOnly(screen, renderable);
    }

    @Override
    public <T extends class_364 & class_6379 & class_4068> T addRenderableWidget(T widget) {
        return GuiHooks.addRenderableWidget(screen, widget);
    }

    @Override
    public void removeWidget(class_364 widget) {
        GuiHooks.removeWidget(screen, widget);
    }

    @Override
    public @Nullable class_339 wrapWidget(Preference<Boolean> key, class_2561 text, @Nullable class_339 widget) {
        return PackedPacksApiImpl.getInstance().preferences()
                .find(key.id(), key.type())
                .map(p -> PreferenceHelper.wrap(widget, p, text))
                .orElse(null);
    }

    @Override
    public <T extends class_339> class_339 wrapWithContextMenu(T widget, BiConsumer<T, ContextMenuSink> configurator) {
        GuiHooks.supplyContextMenuEntries(widget, collector -> configurator.accept(widget, itemConfigurator -> {
            ContextMenuItemSpecImpl itemSpec = new ContextMenuItemSpecImpl(false);
            itemConfigurator.accept(itemSpec);
            itemSpec.apply(collector);
        }));
        return widget;
    }
}
