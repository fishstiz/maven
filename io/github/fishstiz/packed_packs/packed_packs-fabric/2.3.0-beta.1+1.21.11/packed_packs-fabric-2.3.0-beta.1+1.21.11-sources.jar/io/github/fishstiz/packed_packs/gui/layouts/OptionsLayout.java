package io.github.fishstiz.packed_packs.gui.layouts;

import io.github.fishstiz.fidgetz.v0.gui.components.FZButton;
import io.github.fishstiz.fidgetz.v0.gui.components.FZText;
import io.github.fishstiz.fidgetz.v0.gui.layouts.*;
import io.github.fishstiz.packed_packs.config.Config;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_4069;
import net.minecraft.class_5244;

import static io.github.fishstiz.packed_packs.util.GuiUtils.SPACING;

public class OptionsLayout extends WrappedLayout {
    private OptionsLayout(FZLayout layout) {
        super(layout);
    }

    public static OptionsLayout create(class_4069 container, Config.Packs... configs) {
        FZFlexLayout root = FZFlexLayout.horizontal().spacing(SPACING);

        for (Config.Packs config : configs) {
            FZFlexLayout body = root.child(FZFlexLayout.vertical().spacing(SPACING), root.flexChildSettings());
            body.defaultChildSettings().flexCross();

            switch (config) {
                case Config.DataPacks dataPacks -> {
                    body.child(FZText.builder(class_2561.method_43471("selectWorld.dataPacks")).build());

                    FZFlexLayout contents = FZFlexLayout.vertical().spacing(SPACING);
                    contents.defaultChildSettings().flexCross();
                    commonOptions(contents, dataPacks);

                    body.child(FZScrollableLayout.from(container, contents), body.flexChildSettings()).method_48222();
                }
                case Config.ResourcePacks resourcePacks -> {
                    body.child(FZText.builder(class_2561.method_43471("packed_packs.resource_packs")).build());

                    FZFlexLayout contents = FZFlexLayout.vertical().spacing(SPACING);
                    contents.defaultChildSettings().flexCross();
                    commonOptions(contents, resourcePacks);
                    contents.child(toggle(
                            class_2561.method_43471("packed_packs.options.apply_on_close"),
                            resourcePacks::setApplyOnClose,
                            resourcePacks::isApplyOnClose
                    ).build());

                    contents.method_48222();
                    body.child(FZScrollableLayout.from(container, contents), body.flexChildSettings()).method_48222();
                }
            }
        }

        return new OptionsLayout(root);
    }

    private static void commonOptions(FZFlexLayout layout, Config.Packs config) {
        layout.child(toggle(
                class_2561.method_43471("packed_packs.options.replace_screen"),
                config::setReplaceOriginal,
                config::isReplaceOriginal
        ).build());

        layout.child(toggle(
                class_2561.method_43471("packed_packs.options.hide_incompatible_warnings"),
                config::setHideIncompatibleWarnings,
                config::isIncompatibleWarningsHidden
        ).tooltip(class_2561.method_43471("packed_packs.options.hide_incompatible_warnings.info")).build());

        layout.child(toggle(
                class_2561.method_43471("packed_packs.options.folders_module_by_default"),
                config::setFoldersModuleByDefault,
                config::areFoldersModuleByDefault
        ).build());

        layout.child(toggle(
                class_2561.method_43471("packed_packs.options.remember_last_viewed_profile"),
                config::setRememberLastViewedProfile,
                config::isLastViewedProfileRemembered
        ).build());
    }

    private static FZButton.Builder toggle(class_2561 name, BooleanConsumer setter, BooleanSupplier getter) {
        return FZButton.builder()
                .bigWidth()
                .message(class_5244.method_30619(name, getter.getAsBoolean()))
                .onPress(e -> {
                    setter.accept(!getter.getAsBoolean());
                    e.target().method_25355(class_5244.method_30619(name, getter.getAsBoolean()));
                });
    }
}
