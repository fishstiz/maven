package io.github.fishstiz.packed_packs.compat.respackopts;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.PackContext;
import io.github.fishstiz.packed_packs.compat.Mod;
import io.github.fishstiz.packed_packs.compat.ModIntegration;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.components.PreferenceHelper;
import io.gitlab.jfronny.libjf.entrywidgets.api.v0.ResourcePackEntryWidget;
import net.minecraft.class_11876;
import net.minecraft.class_11907;
import net.minecraft.class_2561;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_5369;
import net.minecraft.class_6382;
import net.minecraft.class_8021;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

public class RespackoptsWidget extends class_4264 implements FZContextMenu.Source {
    private final ResourcePackEntryWidget wrapped;
    private final class_5369.class_5371 model;
    private final class_8021 container;
    private final Preference<Boolean> preference;

    private RespackoptsWidget(Preference<Boolean> prefKey, class_8021 container, ResourcePackEntryWidget wrapped, class_5369.class_5371 model) {
        super(0, 0, 0, 0, class_2561.method_43470(Mod.RESPACKOPTS.getId()));
        this.preference = prefKey;
        this.container = container;
        this.wrapped = wrapped;
        this.model = model;
    }

    public static @Nullable RespackoptsWidget create(Preference<Boolean> preference, class_8021 container, PackContext pack) {
        var widgets = ResourcePackEntryWidget.WIDGETS;
        if (!widgets.isEmpty()) {
            for (ResourcePackEntryWidget widget : widgets) {
                if (widget.isVisible(pack, isSelectable(pack.pack()))) {
                    return new RespackoptsWidget(preference, container, widget, pack);
                }
            }
        }
        return null;
    }

    @Override
    public void method_25306(@NonNull class_11907 inputWithModifiers) {
        this.wrapped.onClick(this.model);
    }

    @Override
    protected void method_75752(@NonNull class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int width = this.wrapped.getWidth(this.model);
        int height = this.wrapped.getHeight(this.model, this.container.method_25364());
        int marginRight = this.wrapped.getXMargin(this.model);

        this.method_25358(width);
        this.method_53533(height);
        this.method_46421((this.container.method_46426() + this.container.method_25368()) - width - marginRight);
        this.method_46419(this.container.method_46427() + (this.container.method_25364() - height) / 2);

        this.wrapped.render(this.model, graphics, this.method_46426(), this.method_46427(), method_49606(), partialTick);

        if (Config.get().isDevMode()) {
            PreferenceHelper.extractOverlay(graphics, preference, method_46426(), method_46427(), method_25368(), method_25364());
        }

        if (this.method_49606()) {
            graphics.method_74037(class_11876.field_62455);
        }
    }

    @Override
    protected void method_47399(@NonNull class_6382 narrationElementOutput) {
        this.method_37021(narrationElementOutput);
    }

    /**
     * Copied from {@code TransferableSelectionList.Entry#showHoverOverlay()}
     */
    private static boolean isSelectable(class_3288 pack) {
        return !pack.method_14465() || !pack.method_14464();
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        collector.addEntry(PreferenceHelper.createEntry(preference, ModIntegration.getWidgetPrefText(preference)));
    }
}
