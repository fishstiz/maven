package io.github.fishstiz.packed_packs.transform.interfaces;

import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_9225;

public interface ConfiguredPack {
    default void packed_packs$setPackType(class_3264 packType) {
    }

    default boolean packed_packs$isHidden() {
        return false;
    }

    default boolean packed_packs$isConfigured() {
        return false;
    }

    class_9225 packed_packs$originalConfig();

    class_3288.class_7679 packed_packs$getMetadata();
}
