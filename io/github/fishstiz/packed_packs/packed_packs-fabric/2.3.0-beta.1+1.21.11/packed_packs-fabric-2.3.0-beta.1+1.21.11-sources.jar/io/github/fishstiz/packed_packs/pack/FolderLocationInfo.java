package io.github.fishstiz.packed_packs.pack;

import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_9224;

public record FolderLocationInfo(Path path, class_9224 location, @Nullable FolderLocationInfo parent) {
    public static FolderLocationInfo fromPath(Path path, @Nullable FolderLocationInfo parent) {
        String name = path.getFileName().toString();
        String id = parent == null ? "file/" + name : parent.location().comp_2329() + '/' + name;
        class_9224 info = new class_9224(id, class_2561.method_43470(name), PackUtil.PACK_SOURCE, Optional.empty());
        return new FolderLocationInfo(path, info, parent);
    }
}
