package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.Justification;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.packed_packs.config.FolderPackMeta;
import io.github.fishstiz.packed_packs.gui.ContainerEventHandlerPatch;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.states.PackListKey;
import io.github.fishstiz.packed_packs.gui.states.PackListType;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.states.PackListState;
import io.github.fishstiz.packed_packs.gui.actions.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.states.PackListComputed;
import io.github.fishstiz.packed_packs.pack.PackIconCache;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksContext;
import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.gui.states.ProfileSelection;
import io.github.fishstiz.packed_packs.pack.PackResourcesService;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_11875;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8027;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class PackListContainer extends class_339 implements FocusPathProvider, class_8133, ContainerEventHandlerPatch {
    private final @Nullable PackListContainer head;
    private final PackedPacksContext context;
    private final PackList packList;
    private final PackListComputed state;
    private @Nullable Folder folder;
    private @Nullable class_364 focused;
    private boolean dragging;
    private List<class_364> children;

    private PackListContainer(@Nullable PackListContainer head, PackedPacksContext context, PackListComputed state) {
        super(0, 0, 0, 0, class_5244.field_39003);
        this.head = head;
        this.context = context;
        this.state = state;
        this.packList = new PackList(context, state);
        this.children = List.of(this.packList);
    }

    private PackListContainer(PackListContainer head, PackListState state, PackListKey key) {
        this(head, head.context, new PackListComputed(key, state, head.state.profiles()));
    }

    public static PackListContainer createHead(PackedPacksContext context, PackListType type) {
        PackListKey key = PackListKey.head(type);
        PackListComputed computed = new PackListComputed(
                key,
                context.state().value().getHeadList(type),
                context.state().value().profiles()
        );

        PackListContainer root = new PackListContainer(null, context, computed);

        context.state().subscribe(
                "PackListContainer@" + key,
                value -> {
                    root.onStateChanged(value.getHeadList(type), value.profiles(), type.available());
                    root.onStateChanged(value.dragging());
                }
        );

        return root;
    }

    private void updateChild(class_364 target) {
        this.children = List.of(target);
        if (method_25399() != null) {
            method_25395(target);
        }
    }

    private void onStateChanged(ActiveAction.@Nullable Dragging dragging) {
        state.onDrag(dragging);

        if (folder != null) {
            folder.listContainer.onStateChanged(dragging);
        }
    }

    private void onStateChanged(PackListState newState, ProfileSelection newProfiles, boolean folderUnlockable) {
        PackListState prev = this.state.state();
        ProfileSelection prevProfiles = this.state.profiles();

        if (prev == newState && newProfiles == prevProfiles) {
            return;
        }

        this.state.onStateChanged(newState, newProfiles);

        PackListState folderState = newState.folder();

        if ((folderState == null) != (this.folder == null)) {
            if (folderState != null) {
                Folder newFolder = new Folder(head == null ? this : head, this.state.key().nest(), folderState);
                this.folder = newFolder;
                updateChild(newFolder);
                class_8016 path = newFolder.method_48205(new class_8023.class_8025());
                if (path != null) path.method_48195(true);
            } else {
                this.folder.onClose();
                this.folder = null;
                updateChild(packList);
            }
        }

        if (this.folder != null && folderState != null) {
            this.folder.onStateChanged(folderState, newProfiles, folderUnlockable && !newState.module());
        } else if (prev.visiblePacks() != newState.visiblePacks() || prevProfiles != newProfiles) {
            packList.rebuildEntries();
        }
    }

    public boolean extractDropCandidateRenderState(
            class_332 graphics,
            ActiveAction.Dragging dragging,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        PackListContainer leafContainer = this;

        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if ((leafContainer.packList.extractDropCandidateRenderState(graphics, dragging, mouseX, mouseY, partialTick)
             || dragging.src().equals(leafContainer.state.key()))
            && leafContainer.packList.method_49606()) {
            return true;
        }

        PackListContainer root = this.head == null ? this : this.head;
        if (state.key().type().available() && !state.isLocked() && state.canDrop(0)) {
            renderDropToDisabledZone(root, graphics);
            return root.method_49606();
        }

        return false;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        packList.method_25394(graphics, mouseX, mouseY, partialTick);
        if (this.folder != null) {
            this.folder.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
        if (this.folder != null) {
            this.folder.listContainer.method_37020(output.method_37031());
        } else {
            packList.method_37020(output.method_37031());
        }
    }

    public void visitLeafList(Consumer<PackList> visitor) {
        if (state.state().folder() != null && this.folder != null) {
            this.folder.listContainer.visitLeafList(visitor);
        } else {
            visitor.accept(packList);
        }
    }

    public void visitLists(Consumer<PackList> visitor) {
        visitor.accept(packList);
        if (state.state().folder() != null && this.folder != null) {
            this.folder.listContainer.visitLists(visitor);
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        if (state.isLocked()) {
            context.dispatch(new PackListIntent.Drop(dragging.src()));
            return;
        }

        if (state.key().type().enabled()) {
            visitLeafList(list -> list.onDrop(dragging, mouseX, mouseY));
            return;
        }

        PackListContainer leafContainer = this;
        while (leafContainer.folder != null) {
            leafContainer = leafContainer.folder.listContainer;
        }

        if (leafContainer.packList.method_49606() && (leafContainer.state.isDropCandidate() || dragging.src().equals(leafContainer.state.key()))) {
            leafContainer.packList.onDrop(dragging, mouseX, mouseY);
            return;
        }

        context.dispatch(new PackListIntent.Drop(dragging.src(), state.key(), 0));
    }

    @Override
    public List<class_364> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean isDragging) {
        this.dragging = isDragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        } else {
            method_25395(this.folder == null ? packList : this.folder);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }
            if (focused != null) {
                focused.method_25365(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        FocusPathProvider child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.getFocusPath(target));
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        class_364 child = this.folder != null ? this.folder : packList;
        return class_8016.method_48192(this, child.method_48205(event));
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        packList.method_53533(height);
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        packList.method_25358(width);
        if (folder != null) {
            folder.arrangeElements();
        }
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        packList.method_46421(x);
        repositionFolder();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        packList.method_46419(y);
        repositionFolder();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        method_25358(width);
        method_53533(height);
    }

    @Override
    public void method_48229(int x, int y) {
        super.method_48229(x, y);
        method_46421(x);
        method_46419(y);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        if (head != null && state.state().folder() != null && this.folder != null) {
            return head.method_25405(mouseX, mouseY);
        }
        return super.method_25405(mouseX, mouseY);
    }

    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
        return ContainerEventHandlerPatch.super.method_25402(mouseButtonEvent, doubleClicked);
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        return ContainerEventHandlerPatch.super.method_25406(mouseButtonEvent);
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.method_25403(mouseButtonEvent, dragX, dragY);
    }

    @Override
    public void method_48227(Consumer<class_8021> visitor) {
        visitor.accept(this);
    }

    @Override
    public void method_48222() {
        packList.initializeEntries();
        if (this.folder != null) this.folder.arrangeElements();
    }

    private void repositionFolder() {
        if (this.folder != null) this.folder.repositionElements();
    }

    public void rebuildEntries() {
        visitLists(PackList::rebuildEntries);
    }

    static class Folder extends class_362 implements FocusPathProvider, FZContextMenu.Source, ContainerEventHandlerPatch, class_4068 {
        private static final int HEADER_SIZE = 16;
        private static final int LAYOUT_SPACING = SPACING / 2;
        private final PackListContainer root;
        private final FZIcon background;
        private final PackListContainer listContainer;
        private final FZIconButton closeButton;
        private final FZIcon folderIcon;
        private final FZText folderTitle;
        private final FZButton recallButton;
        private final FZIconButton lockButton;
        private final FZLayout layout;
        private PackListState folderState;
        private PackNode.Parent parent;
        private List<class_364> children = Collections.emptyList();
        private List<class_4068> renderables = Collections.emptyList();
        private boolean childOpened;
        private boolean closed;

        Folder(PackListContainer head, PackListKey key, PackListState state) {
            this.root = head;
            this.folderState = state;
            this.parent = Objects.requireNonNull(state.parent(), "folder parent cannot be null");
            this.listContainer = new PackListContainer(head, state, key);
            this.background = FZIcon.builder(class_2960.method_60656("popup/background")).build();
            this.closeButton = FZIconButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .icon(new WidgetElements(key.depth() > 1 ? ARROW_UP_SPRITE : CROSS_SPRITE, 16, 16))
                    .onPress(() -> head.context.dispatch(new PackListIntent.CloseFolder(key.unnest())))
                    .focusOnInteraction(false)
                    .build();
            PackIconCache iconCache = head.context.iconCache();
            this.folderIcon = FZIcon.builder(GuiUtils.lazyTexture(() -> iconCache.get(this.parent), 16, 16))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .build();
            this.folderTitle = FZText.builder(parent.title())
                    .height(HEADER_SIZE)
                    .build();
            this.recallButton = FZButton.builder()
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .message(class_2561.method_43470("<<"))
                    .tooltip(class_2561.method_43471("packed_packs.folder.recall"))
                    .visible(key.type().available())
                    .onPress(() -> head.context.dispatch(new PackListIntent.Recall(key, this.parent)))
                    .build();
            this.lockButton = FZIconButton.builder(new WidgetRenderables(
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE : UNLOCK_SPRITE),
                            Renderables.sprite(LOCK_SPRITE_DISABLED),
                            GuiUtils.lazySprite(() -> folderState.module() ? LOCK_SPRITE_HIGHLIGHTED : UNLOCK_SPRITE_HIGHLIGHTED)
                    ))
                    .size(HEADER_SIZE, HEADER_SIZE)
                    .onPress(() -> head.context.dispatch(
                            new PackListIntent.UpdateModule(key, this.parent, !this.folderState.module())
                    ))
                    .build();

            FZFlexLayout section = FZFlexLayout.vertical(head).spacing(LAYOUT_SPACING);
            {
                FZFlexLayout header = section.child(FZFlexLayout.horizontal(), section.flexChildHorizontalSettings());
                {
                    header.spacing(LAYOUT_SPACING).alignContents(Justification.CENTER);
                    header.child(closeButton);
                    header.child(folderIcon);
                    header.child(folderTitle, header.flexChildHorizontalSettings());
                    header.child(recallButton);
                    header.child(lockButton);
                }
                section.child(listContainer, section.flexChildSettings());
            }

            this.layout = FZComposedLayout.compose(section).padding(SPACING).clamp(head::method_48202);

            arrangeElements();
            updateChildren();
        }

        private void updateChildren() {
            if (folderState.folder() == null) {
                this.renderables = List.of(
                        background,
                        folderIcon,
                        folderTitle,
                        closeButton,
                        recallButton,
                        lockButton,
                        listContainer
                );
                this.children = List.of(closeButton, recallButton, lockButton, listContainer);
                this.childOpened = false;
            } else {
                this.renderables = List.of(listContainer);
                this.children = List.of(listContainer);
                this.childOpened = true;
            }
        }

        private void onStateChanged(PackListState folderState, ProfileSelection profiles, boolean unlockable) {
            PackListState prevFolderState = this.folderState;
            this.folderState = folderState;

            lockButton.field_22763 = unlockable && !profiles.isLocked();
            recallButton.field_22763 = !folderState.module() && !profiles.isLocked();

            if (prevFolderState.parent() != folderState.parent()) { // I don't think this will ever be true, but just in case
                this.parent = Objects.requireNonNull(folderState.parent(), "folder parent cannot be null");
                folderIcon.method_25355(parent.title());
            }
            if ((prevFolderState.folder() == null) != (folderState.folder() == null)) {
                updateChildren();
            }
            if (listContainer.state.state() != folderState || listContainer.state.profiles() != profiles) {
                listContainer.onStateChanged(folderState, profiles, unlockable);
            }
        }

        private void onClose() {
            this.closed = true;

            listContainer.context.resources().saveFolderMetadata(this.parent, new FolderPackMeta(
                    folderState.module(),
                    PackResourcesService.replaceDirsWithRelative(folderState.packs())
            ));

            if (listContainer.folder != null) {
                listContainer.folder.onClose();
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            if (method_25405(mouseX, mouseY)) {
                graphics.method_74037(class_11875.field_62449);
            }
            for (class_4068 renderable : this.renderables) {
                renderable.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            PackNode.Parent pack = this.parent;

            if (this.childOpened) {
                FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
                return;
            }

            collector.addEntry(builder -> builder
                    .message(pack.title())
                    .icon(padded16Rect(Renderables.texture(listContainer.context.iconCache().get(pack), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false)
                    .applyCursorChangeWhenActive(false));

            collector.addEntry(builder -> builder
                    .message(class_5244.field_24339.method_27661().method_10852(class_5244.field_39678))
                    .onPress(() -> root.context.dispatch(new PackListIntent.CloseFolder(listContainer.state.key().unnest()))));

            if (!listContainer.packList.method_49606()) {
                if (listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack)) {
                    collector.addEntry(builder -> builder
                            .message(RENAME_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.OpenRenameModal(listContainer.state.key(), pack))));
                    collector.addEntry(builder -> builder
                            .message(DELETE_FILE_TEXT)
                            .active(() -> listContainer.context.resources().isModifiable(listContainer.state.profiles(), pack))
                            .onPress(() -> root.context.dispatch(new PackListIntent.Delete(listContainer.state.key(), pack))));
                }

                collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(pack.path())));
                collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(pack.path())));
            }

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        void repositionElements() {
            layout.method_48229(root.method_46426(), root.method_46427());
            background.method_48229(root.method_46426(), root.method_46427());
        }

        void arrangeElements() {
            if ((root.method_25368() != 0 && layout.method_25368() != root.method_25368())
                || (root.method_25364() != 0 && layout.method_25364() != root.method_25364())) {
                layout.fidgetz$setSize(root.method_25368(), root.method_25364());
                background.method_55445(root.method_25368(), root.method_25364());
                repositionElements();
            }
        }

        @Override
        public @Nullable class_8016 getFocusPath(FocusTarget target) {
            return class_8016.method_48192(this, listContainer.getFocusPath(target));
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 event) {
            if (this.childOpened) {
                return class_8016.method_48192(this, listContainer.method_48205(event));
            }

            if (event instanceof class_8023.class_8025) {
                class_8016 path = listContainer.method_48205(event);
                return path == null ? class_8016.method_48194(closeButton, this) : class_8016.method_48192(this, path);
            }

            if (!method_25370() &&
                event instanceof class_8023.class_8024(class_8028 direction) &&
                direction.method_48237() == class_8027.field_41822) {
                class_8016 path = listContainer.method_48205(event);
                if (path != null) {
                    return class_8016.method_48192(this, path);
                }
            }

            return super.method_48205(event);
        }

        @Override
        public boolean method_72784() {
            return !closed;
        }

        @Override
        public void method_25365(boolean isFocused) {
            if (!isFocused) {
                method_25395(null);
            }
        }

        @Override
        public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
            return ContainerEventHandlerPatch.super.method_25402(mouseButtonEvent, doubleClicked) && !closed;
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return method_48202().method_58137((int) mouseX, (int) mouseY);
        }

        @Override
        public List<class_364> method_25396() {
            return children;
        }

        @Override
        public class_8030 method_48202() {
            return layout.method_48202();
        }
    }
}
