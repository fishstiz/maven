package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.screens.FZScreen;
import io.github.fishstiz.fidgetz.v0.gui.state.FZMutableRef;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.api.Event;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.events.ClosingEvent;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializeEvent;
import io.github.fishstiz.packed_packs.api.events.InitializeLayoutEvent;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.UiEffect;
import io.github.fishstiz.packed_packs.gui.components.*;
import io.github.fishstiz.packed_packs.gui.layouts.*;
import io.github.fishstiz.packed_packs.gui.states.*;
import io.github.fishstiz.packed_packs.gui.actions.intents.Intent;
import io.github.fishstiz.packed_packs.gui.actions.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.actions.intents.ProfileIntent;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.events.ContextMenuEventImpl;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionModelAccessor;
import io.github.fishstiz.packed_packs.transform.mixin.PackSelectionScreenAccessor;
import io.github.fishstiz.packed_packs.util.Colors;
import io.github.fishstiz.packed_packs.util.PackUtil;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11876;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_403;
import net.minecraft.class_410;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5375;
import net.minecraft.class_8016;
import net.minecraft.class_8669;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;
import static io.github.fishstiz.packed_packs.util.InputUtil.*;

public class PackedPacksScreen extends FZScreen {
    private static final class_2561 DEV_MODE_TEXT = class_2561.method_43469("packed_packs.dev_mode", DEV_MODE_SHORTCUT);
    private static final class_2561 SEARCH_TEXT = class_2561.method_43471("gui.packSelection.search").method_27696(class_342.field_62466);
    private final @Nullable class_437 parent;
    private final PackSelectionScreenArgs original;
    private final PackedPacksContext context;
    private final FZMutableRef<Boolean> ribbonOpen = new FZMutableRef<>(Config.get().isShowActionBar());
    private final FZMutableRef<Boolean> sidebarOpen = new FZMutableRef<>(false);
    private final PackListContainer availableList;
    private final PackListContainer enabledList;
    private final DragActionRenderer dragActionRenderer;
    private @Nullable FZLayout layout;
    private @Nullable FZTextField availableSearch;
    private @Nullable FZTextField enabledSearch;
    private boolean initialized = false;
    private boolean preloading;

    public PackedPacksScreen(@Nullable class_437 parent, PackSelectionScreenArgs args) {
        super(class_2561.method_43470(PackedPacks.MOD_NAME));
        this.parent = parent;
        this.original = args;

        this.context = new PackedPacksContext(field_22787, parent, this, args);

        this.availableList = PackListContainer.createHead(context, PackListType.AVAILABLE);
        this.enabledList = PackListContainer.createHead(context, PackListType.ENABLED);
        this.dragActionRenderer = new DragActionRenderer(context.iconCache(), field_22793, availableList, enabledList);

        context.setEffectHandler(this::onUiEffect);
        context.state().subscribe("RenameModal", PackedPacksState::renamingPack, this::initRenameModal);
        context.state().subscribe("AliasModal", PackedPacksState::editingAliases, this::initAliasModal);
        sidebarOpen.subscribe("ProfilesSidebar", this::initSidebar);
    }

    // In v2.1.2, all components used to be initialized in the ctor parallelly due to slow loading.
    // Dialogs are now loaded lazily, but the initial screen load time got ~100% slower with the updated fidgetz components,
    // so now we preload the components and avoid initializing the API.
    static void preload(class_310 minecraft) {
        PackedPacksScreen screen = new PackedPacksScreen(null, PackSelectionScreenArgs.dummy(minecraft));
        screen.context.stopWatcher();
        screen.preloading = true;
        screen.method_25426();
    }

    private <T extends Event> T postEvent(T event) {
        if (!this.preloading) {
            PackedPacksApiImpl.getInstance().eventBus().post(event);
        }
        return event;
    }

    @Override
    public void method_49589() {
        if (this.initialized) {
            context.initializeState();
            context.reload();
            context.startWatcher();
        }
    }

    @Override
    public void method_25432() {
        Config.get().setShowActionBar(ribbonOpen.value());
        context.cancelReload();
        context.stopWatcher();
        context.saveState();
    }

    @Override
    protected void method_25426() {
        if (this.initialized) return;

        List<Consumer<InitializeEvent.Post>> postActions = new ArrayList<>();
        postEvent(new InitializeEvent.Pre(context, postActions::add));

        super.method_25426();
        context.initializeState();

        this.initialized = true;

        InitializeEvent.Post postInit = new InitializeEvent.Post(context);
        postActions.forEach(listener -> listener.accept(postInit));
        postEvent(postInit);

        context.startWatcher();
    }

    private FZRef<PackedPacksState> state() {
        return context.state();
    }

    private FZTextField createSearchField(PackListType type) {
        return FZTextField.bind("SearchField@" + type, state()
                .map(s -> s.getTailList(type).query().search())
                .map(value -> FZTextField.builder()
                        .text(value == null ? "" : value)
                        .onChange(e -> context.dispatch(new PackListIntent.Search(
                                state().value().getTailKey(type),
                                e.value()
                        )))
                        .hint(SEARCH_TEXT)
                        .toProps()
                )
        );
    }

    private FZButton createTransferAllButton(PackListType type) {
        PackListContainer container = type.available() ? availableList : enabledList;
        class_2561 message = class_2561.method_43470(type.available() ? ">>" : "<<");

        return FZButton.bind("TransferAllButton@" + type, state()
                .map(s -> s.profiles().isLocked()
                          || s.getTailList(PackListType.AVAILABLE).module()
                          || s.getTailList(PackListType.ENABLED).module()
                )
                .map(locked -> FZButton.builder()
                        .message(message)
                        .tooltip(class_2561.method_43471("packed_packs.transfer_all.info"))
                        .onPress(() -> container.visitLeafList(PackList::transferAll))
                        .square()
                        .active(!locked)
                        .toProps()
                )
        );
    }

    @Override
    protected void collectChildren(GuiComponentCollector collector) {
        InitializeLayoutEvent event = postEvent(new InitializeLayoutEvent(context));

        FZFlexLayout root = FZFlexLayout.vertical(this).spacing(SPACING);
        {
            FZFlexLayout header = root.child(horizontal(), root.flexChildHorizontalSettings());

            header.child(FZIconButton.builder()
                    .square()
                    .tooltip(PROFILE_TITLE_TEXT)
                    .focusOnInteraction(false)
                    .icon(new WidgetElements(HAMBURGER_RECT, 16, 16))
                    .onPress(() -> sidebarOpen.set(prev -> !prev))
                    .build());

            PreferenceHelper.wrap(Preferences.ACTION_BAR_WIDGET, FZIconButton.builder()
                    .square()
                    .tooltip(class_2561.method_43471("packed_packs.toggle_actionbar.info"))
                    .icon(new WidgetElements(PackedPacks.id("icon/filter"), 16, 16))
                    .onPress(() -> ribbonOpen.set(prev -> !prev))
                    .build()).ifPresent(header::child);

            header.child(
                    ProfileTitleLayout.create(state().map(PackedPacksState::profiles), context::dispatch),
                    header.flexChildHorizontalSettings()
            );

            event.getPendingWidgets(InitializeLayoutEvent.Pos.AFTER_TITLE).forEach(header::child);

            PreferenceHelper.wrap(Preferences.OPTIONS_WIDGET, FZIconButton.builder()
                    .square()
                    .message(OPTIONS_TEXT)
                    .tooltip(OPTIONS_TEXT)
                    .icon(new WidgetElements(PackedPacks.id("icon/gear"), 16, 16))
                    .onPress(this::openOptions)
                    .build()).ifPresent(header::child);

            PreferenceHelper.wrap(Preferences.ORIGINAL_SCREEN_WIDGET, FZIconButton.builder()
                    .square()
                    .tooltip(class_2561.method_43471("packed_packs.original_screen.info"))
                    .icon(new WidgetElements(PackedPacks.id("icon/exit"), 16, 16))
                    .onPress(() -> {
                        if (parent instanceof class_5375 screen) {
                            field_22787.method_1507(screen);
                        } else {
                            field_22787.method_1507(original.createScreen(parent));
                        }
                    })
                    .build()).ifPresent(header::child);
        }

        {
            FZFlexLayout body = root.child(vertical(), root.flexChildSettings());
            {
                FZFlexLayout ribbon = body.child(horizontal(), body.flexChildHorizontalSettings()).visible(ribbonOpen.value());
                {
                    FZFlexLayout leftRibbon = ribbon.child(horizontal(), ribbon.flexChildHorizontalSettings());

                    this.availableSearch = leftRibbon.child(
                            createSearchField(PackListType.AVAILABLE),
                            leftRibbon.flexChildHorizontalSettings()
                    );

                    leftRibbon.child(FZDropdown.bind("AvailableSortDropdown", state()
                            .map(s -> s.getTailList(PackListType.AVAILABLE).query().sort())
                            .map(sort -> {
                                boolean active = sort != null && !(sort instanceof SortOption.Locked);
                                class_2561 valueText = sort != null && active ? sort.text() : class_5244.field_39003;
                                class_2561 sortText = class_2561.method_43471("packed_packs.sort");

                                return FZDropdown.builder(this)
                                        .width(40)
                                        .minContainerWidth(175)
                                        .hideMessage(true)
                                        .message(sortText)
                                        .active(active)
                                        .tooltip(active ? class_5244.method_32700(sortText, valueText) : sortText)
                                        .leftIcon(sort == null ? null : padded16Sprite(sort.icon()))
                                        .entryDivider(null)
                                        .entries(SortOptions.menuItems(option -> context.dispatch(new PackListIntent.Sort(
                                                state().value().getTailKey(PackListType.AVAILABLE),
                                                option
                                        ))))
                                        .toProps();
                            })));

                    if (Preferences.INCOMPATIBLE_TOGGLE_WIDGET.get() || Config.get().isDevMode()) {
                        leftRibbon.child(PreferenceHelper.wrapNonNull(
                                Preferences.INCOMPATIBLE_TOGGLE_WIDGET,
                                FZIconButton.bind("AvailableIncompatibleButton", state()
                                        .map(s -> s.getTailList(PackListType.AVAILABLE).query().hideIncompatible())
                                        .map(value -> {
                                            class_2960 icon = value
                                                    ? PackedPacks.id("icon/incompatible_hidden")
                                                    : PackedPacks.id("icon/incompatible");

                                            return FZIconButton.builder()
                                                    .square()
                                                    .message(class_2561.method_43471("packed_packs.hide_incompatible"))
                                                    .tooltip(class_2561.method_43471("packed_packs.hide_incompatible.info"))
                                                    .icon(new WidgetElements(icon, 16, 16))
                                                    .onPress(() -> context.dispatch(new PackListIntent.HideIncompatible(
                                                            state().value().getTailKey(PackListType.AVAILABLE),
                                                            !value
                                                    )))
                                                    .toProps();
                                        })))
                        );
                    }

                    leftRibbon.child(createTransferAllButton(PackListType.AVAILABLE));
                }

                {
                    FZFlexLayout rightRibbon = ribbon.child(horizontal(), ribbon.flexChildHorizontalSettings());

                    rightRibbon.child(createTransferAllButton(PackListType.ENABLED));

                    this.enabledSearch = rightRibbon.child(
                            createSearchField(PackListType.ENABLED),
                            rightRibbon.flexChildHorizontalSettings()
                    );
                }

                ribbon.method_48206(widget -> widget.field_22764 = ribbonOpen.value());

                ribbonOpen.subscribe("Ribbon", value -> {
                    ribbon.visible(value);
                    ribbon.method_48206(widgets -> widgets.field_22764 = value);
                    body.method_48222();
                });
            }
            {
                FZFlexLayout content = body.child(horizontal(), body.flexChildSettings());
                content.child(availableList, content.flexChildSettings());
                content.child(enabledList, content.flexChildSettings());
            }
        }
        {
            FZFlexLayout footer = root.child(horizontal(), root.flexChildHorizontalSettings());
            {
                FZFlexLayout leftFooter = footer.child(horizontal(), footer.flexChildHorizontalSettings());

                event.getPendingWidgets(InitializeLayoutEvent.Pos.BEFORE_FOOTER).forEach(leftFooter::child);

                {
                    FZFlexLayout folders = leftFooter.child(FZFlexLayout.horizontal(), leftFooter.flexChildHorizontalSettings());

                    folders.child(FZButton.builder()
                            .message(class_2561.method_43471("pack.openFolder"))
                            .tooltip(class_2561.method_43471("pack.folderInfo"))
                            .onPress(() -> PackedPacks.openPath(context.packDir()))
                            .build(), folders.flexChildHorizontalSettings());

                    List<Path> paths = context.otherDirectories();
                    if (!paths.isEmpty()) {
                        FZDropdown.Builder dropdown = FZDropdown.builder(this)
                                .hideMessage()
                                .size(20, 20)
                                .minContainerWidth(150, HorizontalDirection.LEFT)
                                .entryDivider(null);

                        for (Path path : paths) {
                            dropdown.entry(class_2561.method_43470(path.getFileName().toString()), () -> PackedPacks.openPath(path));
                        }

                        folders.child(dropdown.build());
                    }
                }

                event.getPendingWidgets(InitializeLayoutEvent.Pos.AFTER_LEFT_FOOTER).forEach(leftFooter::child);
            }
            {
                FZFlexLayout rightFooter = footer.child(horizontal(), footer.flexChildHorizontalSettings());

                event.getPendingWidgets(InitializeLayoutEvent.Pos.BEFORE_RIGHT_FOOTER).forEach(rightFooter::child);

                if (context.isClientResources()) {
                    rightFooter.child(FZButton.builder()
                            .message(class_2561.method_43471("packed_packs.apply"))
                            .onPress(context::commit)
                            .build(), rightFooter.flexChildHorizontalSettings());
                }

                event.getPendingWidgets(InitializeLayoutEvent.Pos.BETWEEN_RIGHT_FOOTER).forEach(rightFooter::child);

                rightFooter.child(FZButton.builder()
                        .message(class_5244.field_24334)
                        .onPress(this::method_25419)
                        .build(), rightFooter.flexChildHorizontalSettings());

                event.getPendingWidgets(InitializeLayoutEvent.Pos.AFTER_FOOTER).forEach(rightFooter::child);
            }
        }

        layout = FZComposedLayout.contain(this, root)
                .padding(SPACING)
                .center()
                .clamp()
                .get();

        if (!this.preloading) {
            layout.method_48222();
            layout.method_48206(collector::renderableWidget);
        }
    }

    @Override
    protected void method_48640() {
        if (layout == null) {
            super.method_48640();
        } else {
            layout.fidgetz$setSize(field_22789, field_22790);
        }

        dialogManager.remove(GLOBAL_CONTEXT_MENU_ID);
        fidgetz$Dialogs().forEach(FZDialog::repositionElements);
    }

    private void openOptions() {
        dialogManager.put(FZModal.builder(this, OptionsLayout.create(this, Config.packs(original.packType())))
                .id("OptionsModal")
                .popoverOrder(0)
                .padding(SPACING, SPACING + 2, SPACING, SPACING)
                .margin(SPACING)
                .centered()
                .buildAndOpen());
    }

    @Override
    protected void openContextMenu(double x, double y, boolean focus) {
        if (fidgetz$Dialogs().stream().noneMatch(dialog -> dialog.isOpen() && dialog.fidgetz$popoverOrder() < 1)) {
            dialogManager.put(FZContextMenu.builder(this)
                    .id(GLOBAL_CONTEXT_MENU_ID)
                    .maxHeight((int) Math.max((field_22790 * .8), 240))
                    .popoverOrder(1)
                    .sectionDivider(FZPopoverMenuItem.createDivider(PackedPacks.id("widget/contextmenu_section_divider"), 1))
                    .noEntryDivider()
                    .rowSpacing(0)
                    .padding(1)
                    .focusOnOpen(focus)
                    .buildAndOpen(x, y, fidgetz$collectContextEntries(x, y)));
        }
    }

    private void initRenameModal() {
        FZRef<ActiveAction.@Nullable RenamingPack> ref = state().map(PackedPacksState::renamingPack);

        dialogManager.put(FZModal.bind("RenameModal", ref.map(rename -> {
            PackRenameLayout layout = PackRenameLayout.create(ref, context::dispatch, context.iconCache());
            return FZModal.builder(this, layout)
                    .id("RenameModal")
                    .popoverOrder(2)
                    .padding(SPACING)
                    .centered()
                    .captureClick()
                    .captureFocus()
                    .closeAfterClickOutOfBounds()
                    .open(rename != null)
                    .onClose(layout::onClose)
                    .toProps();
        })));
    }

    private void initAliasModal() {
        FZRef<ActiveAction.@Nullable EditingAliases> ref = state().map(PackedPacksState::editingAliases);
        dialogManager.put(FZModal.bind("AliasModal", ref.map(editingAliases -> {
            PackAliasLayout layout = PackAliasLayout.create(ref, context::dispatch, context.iconCache());
            return FZModal.builder(this, layout)
                    .id("AliasModal")
                    .popoverOrder(2)
                    .backdrop(null)
                    .padding(SPACING)
                    .centered()
                    .captureClick(false)
                    .open(editingAliases != null)
                    .onClose(layout::onClose)
                    .toProps();
        })));
    }

    private void initSidebar() {
        SidebarLayout sidebar = SidebarLayout.create(state(), context::dispatch, context.packType(), () -> sidebarOpen.set(false));
        dialogManager.put(FZModal.bind("ProfilesSidebar", sidebarOpen.map(open -> FZModal.builder(this, sidebar)
                .id("ProfilesSidebar")
                .popoverOrder(100)
                .alignTopLeft()
                .flexHeight()
                .padding(SPACING)
                .backdrop(null)
                .captureClick(false)
                .open(open)
                .onClose(() -> sidebarOpen.set(false))
                .toProps())));
    }

    @Override
    public void method_41843() {
        if (!this.initialized) return;
        context.cancelReload();
        method_37067();
        context.saveState();
        this.initialized = false;
        method_25426();
        availableList.rebuildEntries();
        enabledList.rebuildEntries();
        dialogManager.refreshDialogs();
    }

    @Override
    public void method_29638(List<Path> files) {
        field_22787.method_1507(new class_410(
                confirmed -> {
                    if (!confirmed) {
                        field_22787.method_1507(this);
                        return;
                    }
                    PackUtil.PathValidationResults results = PackUtil.validatePaths(files);
                    if (!results.symlinkWarnings().isEmpty()) {
                        field_22787.method_1507(class_8669.method_52750(() -> field_22787.method_1507(this)));
                        return;
                    }
                    if (!results.valid().isEmpty()) {
                        PackSelectionScreenAccessor.packed_packs$copyPacks(field_22787, results.valid(), context.packDir());
                        context.reload();
                    }
                    if (!results.rejected().isEmpty()) {
                        String rejectedNames = PackUtil.joinPackNames(results.rejected());
                        field_22787.method_1507(new class_403(
                                () -> field_22787.method_1507(this),
                                class_2561.method_43471("pack.dropRejected.title"),
                                class_2561.method_43469("pack.dropRejected.message", rejectedNames)
                        ));
                        return;
                    }
                    field_22787.method_1507(this);
                },
                class_2561.method_43471("pack.dropConfirm"),
                class_2561.method_43470(PackUtil.joinPackNames(files))
        ));
    }

    @Override
    public void method_25419() {
        ClosingEvent closingEvent = postEvent(new ClosingEvent(context));
        if (closingEvent.isCommitted() || !(context.configs().user() instanceof Config.ResourcePacks config) || config.isApplyOnClose()) {
            context.commit();
        }
        if (context.isServerData() && !(parent instanceof class_5375)) {
            return;
        }
        if (parent instanceof PackSelectionScreenAccessor packScreen) {
            ((PackSelectionModelAccessor) packScreen.packed_packs$model()).packed_packs$reset();
            packScreen.packed_packs$reload();
        }
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25393() {
        context.pollWatcher();
    }

    private PackListContainer getPackList(PackListType type) {
        return switch (type) {
            case AVAILABLE -> availableList;
            case ENABLED -> enabledList;
        };
    }

    private void visitDeepestList(PackListType type, Consumer<PackList> visitor) {
        this.getPackList(type).visitLeafList(visitor);
    }

    private void applyFocusTarget(PackListType type, FocusTarget target) {
        method_48267();
        PackListContainer list = getPackList(type);
        method_25395(list);
        class_8016 targetPath = list.getFocusPath(target);
        if (targetPath != null) targetPath.method_48195(true);
    }

    private void onUiEffect(UiEffect effect) {
        switch (effect) {
            case UiEffect.ScrollToTop(PackListType type) -> visitDeepestList(type, PackList::scrollToTop);
            case UiEffect.ScrollToLastSelected(PackListType type) ->
                    visitDeepestList(type, PackList::scrollToLastSelected);
            case UiEffect.FocusList(PackListType type) -> method_25395(getPackList(type));
            case UiEffect.Focus(PackListType type, String packId, boolean scroll) when packId == null ->
                    applyFocusTarget(type, new FocusTarget.LastSelected(scroll));
            case UiEffect.Focus(PackListType type, String packId, boolean scroll) ->
                    applyFocusTarget(type, new FocusTarget.PackEntry(packId, scroll));
        }
    }

    private PackListType getClosestListType() {
        class_364 focused = method_25399();
        if (focused == availableList) {
            return PackListType.AVAILABLE;
        } else if (focused == enabledList) {
            return PackListType.ENABLED;
        }

        class_364 hovered = fidgetz$getHovered();
        if (hovered == availableList) {
            return PackListType.AVAILABLE;
        } else if (hovered == enabledList) {
            return PackListType.ENABLED;
        }

        return PackListType.AVAILABLE;
    }

    private @Nullable FZTextField getClosestSearchField() {
        if (availableSearch == null || enabledSearch == null) return null;

        class_364 focused = method_25399();
        if (focused == availableList) {
            return availableSearch;
        } else if (focused == enabledList) {
            return enabledSearch;
        }

        class_364 hovered = fidgetz$getHovered();
        if (hovered == availableList || hovered == availableSearch) {
            return availableSearch;
        } else if (hovered == enabledList || hovered == enabledSearch) {
            return enabledSearch;
        }

        return null;
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (state().value().dragging() != null) {
            return true;
        }
        if (super.method_25400(event)) {
            return true;
        }
        if (fidgetz$Dialogs().stream().anyMatch(FZDialog::isOpen)) {
            return false;
        }
        if (canAutoFocusSearchField(event)) {
            FZTextField searchField = getClosestSearchField();
            if (searchField != null && !searchField.method_25370()) {
                ribbonOpen.set(true);
                method_25395(searchField);
                return searchField.method_25400(event);
            }
        }
        return false;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (state().value().dragging() != null) {
            return true;
        }
        dialogManager.remove(GLOBAL_CONTEXT_MENU_ID);
        if (event.method_74231() && dialogManager.dialogs().stream().noneMatch(FZDialog::isOpen)) {
            PackListType type = getClosestListType();
            PackListKey key = null;

            for (int i = 0; i < 2; i++) {
                key = state().value().getTailKey(type);
                if (key.depth() > 0) break;
                type = type.other();
            }

            if (key.depth() > 0) {
                context.dispatch(new PackListIntent.CloseFolder(key.unnest()));
                return true;
            }
        }
        if (isDeveloperMode(event)) {
            context.dispatch(new Intent.ToggleDevMode());
            method_41843();
            return true;
        }
        if (isSwitchDefaultProfile(event)) {
            context.dispatch(new ProfileIntent.Select(state().value().profiles().isSelectedDefault()
                    ? null
                    : state().value().profiles().defaultProfile())
            );
            return true;
        }
        if (isRefresh(event)) {
            if (context.canReload()) {
                context.reload();
            }
            return true;
        }
        if (isOpenProfiles(event)) {
            sidebarOpen.set(prev -> !prev);
            return true;
        }
        if (super.method_25404(event)) {
            return true;
        }
        if (isRedo(event)) {
            context.redo();
            return true;
        }
        if (isUndo(event)) {
            context.undo();
            return true;
        }
        if (event.comp_4795() == class_3675.field_31986) {
            FZTextField searchField = getClosestSearchField();
            if (searchField != null && !searchField.method_25370() && !searchField.method_1882().isEmpty()) {
                ribbonOpen.set(true);
                method_25395(searchField);
                return searchField.method_25404(event);
            }
        }
        if (isSearch(event)) {
            FZTextField searchField = getClosestSearchField();
            if (searchField != null && !searchField.method_25370()) {
                ribbonOpen.set(true);
                method_25395(searchField);
                return true;
            }
        }
        return false;
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        ContextMenuEventImpl<ContextMenuEvent.Screen.Pos> screenExtensions = ContextMenuEventImpl.postScreen(context);

        screenExtensions.entries(ContextMenuEvent.Screen.Pos.TOP).forEach(collector::addEntry);

        super.fidgetz$updateContextEntries(x, y, collector);
        collector.nextSection();

        if (context.devMode()) {
            collector.nextSection();

            if (state().value().profiles().selectedProfile() != null) {
                collector.addEntry(builder -> buildDevEntry(builder)
                        .message(class_2561.method_43471("packed_packs.profile.save"))
                        .onPress(context::saveSelectedProfile));
                collector.nextSection();
            }

            FZPopoverMenuItem.Builder preferences = buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.preferences"));

            ContextMenuEventImpl<ContextMenuEvent.Preferences.Pos> prefExtensions = ContextMenuEventImpl.postPreferences(context);

            prefExtensions.entries(ContextMenuEvent.Preferences.Pos.TOP).forEach(preferences::child);

            List<Preferences.Option<Boolean>> standardOptions = Preferences.standardBooleanOptions();
            standardOptions.forEach(standardOption -> preferences.child(PreferenceHelper.createEntry(standardOption)));

            prefExtensions.entries(ContextMenuEvent.Preferences.Pos.BOTTOM).forEach(preferences::child);

            preferences.nextSection();
            preferences.child(builder -> buildDevEntry(builder
                    .message(class_2561.method_43471("packed_packs.preferences.reset"))
                    .closeOnInteraction(false)
                    .onPress(() -> {
                        standardOptions.forEach(Preference::reset);
                        prefExtensions.getPreferences().forEach(Preference::reset);
                    })));

            collector.addEntry(preferences.build());
            collector.nextSection();
        }

        collector.addEntry(builder -> builder
                .message(class_2561.method_43471("packed_packs.reset_enabled"))
                .active(() -> !state().value().profiles().isLocked())
                .onPress(() -> context.dispatch(new Intent.Reset())));

        collector.addEntry(builder -> builder
                .message(class_2561.method_43471("packed_packs.refresh"))
                .active(context::canReload)
                .onPress(context::reload));

        List<Path> folders = context.otherDirectories();
        if (folders.isEmpty()) {
            collector.addEntry(builder -> builder
                    .message(class_2561.method_43471("pack.openFolder"))
                    .onPress(() -> PackedPacks.openPath(context.packDir())));
        } else {
            FZPopoverMenuItem.Builder parent = FZPopoverMenuItem.builder().message(class_2561.method_43471("pack.openFolder"));
            parent.child(builder -> builder
                    .message(class_2561.method_43470(context.packDir().getFileName().toString()))
                    .onPress(() -> PackedPacks.openPath(context.packDir())));
            parent.nextSection();

            for (Path folder : folders) {
                parent.child(FZPopoverMenuItem.builder()
                        .message(class_2561.method_43470(folder.getFileName().toString()))
                        .onPress(() -> PackedPacks.openPath(folder))
                        .build());
            }

            collector.addEntry(parent.build());
        }

        screenExtensions.entries(ContextMenuEvent.Screen.Pos.BOTTOM).forEach(collector::addEntry);
    }

    @Override
    public boolean method_25402(class_11909 mouseEvent, boolean doubleClicked) {
        if (state().value().dragging() != null) {
            return true;
        }
        if (isClickForward(mouseEvent)) {
            context.redo();
            return true;
        }
        if (isClickBack(mouseEvent)) {
            context.undo();
            return true;
        }

        boolean clicked = super.method_25402(mouseEvent, doubleClicked);
        if (!clicked && fidgetz$getHovered() == null) {
            class_8016 path = method_48218();
            if (path != null) path.method_48195(false);
        }

        return clicked;
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dragX, double dragY) {
        return state().value().dragging() != null || super.method_25403(mouseButtonEvent, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        ActiveAction.Dragging dragged = state().value().dragging();
        if (isLeftClick(mouseButtonEvent) && dragged != null) {
            if (availableList.method_49606()) {
                availableList.onDrop(dragged, (int) mouseButtonEvent.comp_4798(), (int) mouseButtonEvent.comp_4799());
            } else if (enabledList.method_49606()) {
                enabledList.onDrop(dragged, (int) mouseButtonEvent.comp_4798(), (int) mouseButtonEvent.comp_4799());
            } else {
                context.dispatch(new PackListIntent.Drop(dragged.src(), null, 0));
            }
            return true;
        }
        return super.method_25406(mouseButtonEvent);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        ActiveAction.Dragging dragging = state().value().dragging();
        if (dragging != null) {
            if (!state().value().profiles().isLocked()) {
                dragActionRenderer.render(dragging, graphics, mouseX, mouseY, partialTick);
            } else {
                graphics.method_74037(class_11876.field_62459);
            }
        }

        if (context.devMode()) {
            float scale = 0.5f;
            int y = (int) ((field_22790 - field_22793.field_2000 * scale) / scale);
            graphics.method_51448().pushMatrix();
            graphics.method_51448().scale(scale);
            graphics.method_27535(field_22793, DEV_MODE_TEXT, 0, y, Colors.WHITE);
            graphics.method_51448().popMatrix();
        }
    }
}
