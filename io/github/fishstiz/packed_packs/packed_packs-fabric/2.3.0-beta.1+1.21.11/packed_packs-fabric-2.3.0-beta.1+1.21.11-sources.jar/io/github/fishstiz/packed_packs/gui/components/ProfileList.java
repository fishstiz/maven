package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.DevConfig;
import io.github.fishstiz.packed_packs.config.DevConfig.ResourcePacks.LoadDefaultCondition;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.gui.actions.intents.Intent;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.gui.states.ProfilesState;
import io.github.fishstiz.packed_packs.gui.actions.intents.ProfileIntent;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class ProfileList extends FZAbstractListWidget<ProfileList.Entry> implements class_8133 {
    private static final class_2561 EMPTY_TEXT = class_2561.method_43471("packed_packs.profile.empty");
    private final Consumer<? super Intent> dispatcher;
    private final class_3264 packType;
    private ProfilesState state = ProfilesState.empty();
    private boolean devMode;

    public ProfileList(FZRef<PackedPacksState> state, Consumer<? super Intent> dispatcher, class_3264 packType) {
        this.dispatcher = dispatcher;
        this.packType = packType;
        onStateChanged(state.value());
        state.subscribe("ProfileList", this::onStateChanged);
    }

    @Override
    protected int maxContentWidth() {
        return 0;
    }

    private void onStateChanged(PackedPacksState newState) {
        ProfilesState prev = this.state;
        boolean devModeChanged = devMode != newState.devMode();

        if (prev == newState.profiles() && !devModeChanged) {
            return;
        }

        this.state = newState.profiles();
        this.devMode = newState.devMode();

        if (prev.profiles() != this.state.profiles() || prev.defaultProfile() != this.state.defaultProfile()) {
            rebuildEntries();
        } else {
            for (io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry : method_25396()) {
                entry.onStateChanged(devModeChanged);
            }
        }
    }

    private void rebuildEntries() {
        io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused = method_25399();
        Profile previousFocused = focused == null ? null : focused.profile;
        double scrollAmount = method_44387();

        clearEntries();

        Profile defaultProfile = state.defaultProfile();
        List<Profile> profiles = new ObjectArrayList<>(state.profiles());

        int i = 0;
        if (defaultProfile != null) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = new io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry(defaultProfile, i++);
            addEntry(entry);
            profiles.remove(defaultProfile);
            if (previousFocused != null
                && (previousFocused == defaultProfile || previousFocused.getId().equals(defaultProfile.getId()))) {
                method_25395(entry);
            }
        }

        for (Profile profile : profiles) {
            io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry entry = new io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry(profile, i++);
            addEntry(entry);
            if (previousFocused != null && previousFocused.getId().equals(profile.getId())) {
                method_25395(entry);
            }
        }

        repositionEntries();
        method_44382(scrollAmount);
    }

    @Override
    public void method_53533(int height) {
        int previousHeight = method_25364();
        super.method_53533(height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    public void method_55445(int width, int height) {
        int previousHeight = method_25364();
        super.method_55445(width, height);
        if (previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);

        if (method_25396().isEmpty()) {
            method_75799(
                    graphics.method_75787(this, class_332.class_12228.field_63850),
                    EMPTY_TEXT,
                    0
            );
        }
    }

    @Override
    protected void extractFocusedRenderState(class_332 graphics, io.github.fishstiz.packed_packs.gui.components.ProfileList.Entry focused) {
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void method_48222() {
        repositionEntries();
    }

    protected final class Entry extends FZAbstractListWidget.Entry implements FZContextMenu.Source {
        private static final class_2960 STAR_OUTLINE_SPRITE = PackedPacks.id("icon/star_outline");
        private final List<class_339> children = new ArrayList<>();
        private final FZFlexLayout layout;
        private final Profile profile;
        private final int index;
        private FZButton selectButton;
        private boolean prevDefault;
        private boolean prevLocked;

        private Entry(Profile profile, int index) {
            this.index = index;
            this.profile = profile;
            this.layout = FZFlexLayout.horizontal();

            buildWidgets(state.defaultProfile() == profile, profile.isLocked());

            layout.method_48222();
        }

        private <T extends class_339> T addChild(T widget) {
            children.add(widget);
            if (widget instanceof FZHoverableElement hoverableElement) {
                hoverableElement.fidgetz$setHovered(fidgetz$isHovered());
            }
            return widget;
        }

        private void buildWidgets(boolean isDefault, boolean isLocked) {
            boolean deleteActive = !isLocked && !isDefault;

            addChild(layout.child(FZIconButton.builder()
                    .square()
                    .id("DeleteButton")
                    .message(class_2561.method_43471("packed_packs.profile.delete"))
                    .tooltip(deleteActive ? class_2561.method_43471("packed_packs.profile.delete.info") : null)
                    .icon(getDeleteIcon(isDefault, isLocked))
                    .onPress(() -> dispatcher.accept(new ProfileIntent.Delete(profile)))
                    .active(deleteActive)
                    .build()));

            this.selectButton = addChild(layout.child(FZButton.builder()
                    .id("SelectButton")
                    .message(class_2561.method_43470(profile.getName()))
                    .onPress(() -> dispatcher.accept(new ProfileIntent.Select(profile)))
                    .active(state.selectedProfile() != profile)
                    .build(), layout.flexChildHorizontalSettings()));

            if (devMode) {
                addChild(layout.child(FZIconButton.builder()
                        .id("DefaultButton")
                        .square()
                        .icon(new WidgetElements(isDefault ? STAR_SPRITE : STAR_OUTLINE_SPRITE, 16, 16))
                        .tooltip(isDefault
                                ? class_2561.method_43471("packed_packs.profile.default.unset")
                                : class_2561.method_43471("packed_packs.profile.default.set"))
                        .onPress(this::toggleDefault)
                        .build()));

                addChild(layout.child(FZIconButton.builder(isLocked ? LOCK_SPRITES : UNLOCK_SPRITES)
                        .id("LockButton")
                        .square()
                        .tooltip(isLocked
                                ? class_2561.method_43471("packed_packs.profile.unlock")
                                : class_2561.method_43471("packed_packs.profile.lock"))
                        .onPress(this::toggleLock)
                        .build()));
            }

            this.prevDefault = isDefault;
            this.prevLocked = isLocked;
        }

        private void rebuildWidgets(boolean isDefault, boolean isLocked) {
            children.clear();
            layout.removeChildren();

            class_364 focused = method_25399();
            method_25395(null);
            buildWidgets(isDefault, isLocked);

            if (focused instanceof FZComponent previousFocusedComponent) {
                String id = previousFocusedComponent.fidgetz$componentId();
                for (class_339 child : children) {
                    if (child instanceof FZComponent component && Objects.equals(id, component.fidgetz$componentId())) {
                        method_25395(child);
                    }
                }
            }

            layout.method_48222();
            layout.fidgetz$setWidth(method_25368());
            layout.method_48229(method_46426(), method_46427());
        }

        private void onStateChanged(boolean devModeChanged) {
            boolean isDefault = isDefault();
            boolean isLocked = profile.isLocked();

            if (devModeChanged || isDefault != prevDefault || isLocked != prevLocked) {
                rebuildWidgets(isDefault, isLocked);
                return;
            }

            String name = profile.getName();
            if (!name.equals(this.selectButton.method_25369().getString())) {
                this.selectButton.method_25355(class_2561.method_43470(name));
            }

            this.selectButton.field_22763 = state.selectedProfile() != profile;
        }

        @Override
        public int getIndex() {
            return index;
        }

        private boolean isDefault() {
            return state.defaultProfile() == profile;
        }

        private void toggleDefault() {
            dispatcher.accept(new ProfileIntent.SetDefault(isDefault() ? null : profile));
        }

        private void toggleLock() {
            dispatcher.accept(new ProfileIntent.ToggleLock(profile));
        }

        private static WidgetElements getDeleteIcon(boolean isDefault, boolean isLocked) {
            if (isDefault) {
                return new WidgetElements(STAR_SPRITE, 16, 16);
            } else if (isLocked) {
                return new WidgetElements(LOCK_SPRITE_DISABLED, 20, 20);
            } else {
                return new WidgetElements(TRASH_SPRITE, 16, 16);
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            for (class_339 child : children) {
                child.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        private static WidgetElements createIcon(Supplier<class_2960> sprite) {
            return padded16Rect(GuiUtils.lazySprite(sprite));
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            if (!devMode) return;

            collector.nextSection();

            collector.addEntry(builder -> buildDevEntry(builder)
                    .message(class_2561.method_43471("packed_packs.profile.default." + (isDefault() ? "unset" : "set")))
                    .icon(createIcon(() -> isDefault() ? STAR_SPRITE : STAR_OUTLINE_SPRITE))
                    .onPress(this::toggleDefault));

            collector.addEntry(builder -> buildDevEntry(builder
                    .message(class_2561.method_43471("packed_packs.profile." + (state.isLocked() ? "unlock" : "lock")))
                    .icon(createIcon(() -> state.isLocked() ? LOCK_SPRITE_SMALL : UNLOCK_SPRITE_SMALL))
                    .onPress(this::toggleLock)));

            if (!isDefault() || packType == class_3264.field_14190) {
                return;
            }

            DevConfig.ResourcePacks config = DevConfig.get().getResourcepacks();

            FZPopoverMenuItem.Builder loadConditionEntry = buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.info")));

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options_or_version.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_OR_VERSION_FILE))
                    .closeOnInteraction(false)
                    .build());

            loadConditionEntry.child(GuiUtils.buildDevEntry(FZPopoverMenuItem.builder())
                    .message(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options"))
                    .tooltip(class_7919.method_47407(class_2561.method_43471("packed_packs.profile.default.resource_pack.load.no_options.info")))
                    .icon(GuiUtils.toggleRect(() -> config.getLoadDefaultCondition() == LoadDefaultCondition.NO_OPTIONS_FILE))
                    .onPress(() -> DevConfig.get().getResourcepacks().setLoadDefaultCondition(LoadDefaultCondition.NO_OPTIONS_FILE))
                    .closeOnInteraction(false)
                    .build());

            collector.addEntry(loadConditionEntry.build());
        }

        @Override
        public void method_46421(int x) {
            super.method_46421(x);
            layout.method_46421(x);
        }

        @Override
        public void method_46419(int y) {
            super.method_46419(y);
            layout.method_46419(y);
        }

        @Override
        protected void setWidth(int width) {
            super.setWidth(width);
            layout.fidgetz$setWidth(method_25368());
        }

        @Override
        protected void setBounds(int x, int y, int width, int height) {
            super.setBounds(x, y, width, height);
            layout.method_48229(x, y);
            layout.fidgetz$setWidth(width);
        }

        @Override
        public int method_25364() {
            return layout.method_25364();
        }

        @Override
        public List<class_339> method_25396() {
            return children;
        }
    }
}
