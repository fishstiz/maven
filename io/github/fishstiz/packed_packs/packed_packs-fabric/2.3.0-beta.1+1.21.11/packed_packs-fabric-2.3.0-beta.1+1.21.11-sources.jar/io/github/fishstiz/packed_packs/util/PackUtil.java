package io.github.fishstiz.packed_packs.util;

import com.sun.jna.platform.FileUtils;
import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.FolderPackMeta;
import io.github.fishstiz.packed_packs.platform.Services;
import io.github.fishstiz.packed_packs.transform.mixin.UtilAccess;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3262;
import net.minecraft.class_5352;
import net.minecraft.class_8581;
import net.minecraft.class_8621;

public class PackUtil {
    public static final String HIGH_CONTRAST_ID = "high_contrast";
    public static final String VANILLA_ID = "vanilla";
    public static final String FABRIC_ID = "fabric";
    public static final String NEOFORGE_ID = "mod_resources";
    public static final String ZIP_PACK_EXTENSION = ".zip";
    public static final String ICON_FILENAME = "pack.png";
    public static final class_5352 PACK_SOURCE = class_5352.method_45281(name ->
            class_2561.method_43469(
                    "pack.nameAndSource",
                    name,
                    class_2561.method_43470(PackedPacks.MOD_NAME).method_27692(class_124.field_1054)
            ).method_27692(class_124.field_1080), false);

    private PackUtil() {
    }

    public static String replaceDirsWithRelative(String packId) {
        return packId.replaceFirst("^file/.*(?=/[^/]+$)", "relative");
    }

    public static String joinPackNames(Collection<Path> paths) {
        return String.join(", ", CollectionUtils.map(paths, path -> path.getFileName().toString()));
    }

    public static boolean hasMcmeta(Path path) {
        return Files.isRegularFile(path.resolve(class_3262.field_29781), LinkOption.NOFOLLOW_LINKS);
    }

    public static boolean hasFolderConfig(Path path) {
        return Files.isRegularFile(path.resolve(FolderPackMeta.FILENAME), LinkOption.NOFOLLOW_LINKS);
    }

    public static boolean isBuiltIn(class_5352 packSource) {
        return packSource == class_5352.field_25348 || Services.PLATFORM.isBuiltInPack(packSource);
    }

    public static boolean isEssential(String packId) {
        return packId.equals(VANILLA_ID) || packId.equals(FABRIC_ID) || packId.equals(NEOFORGE_ID);
    }

    public static boolean isFeature(class_5352 packSource) {
        return packSource == class_5352.field_40048;
    }

    public static boolean isNonPackDirectory(Path path) {
        return Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS) && !hasMcmeta(path);
    }

    public static boolean isZipPath(@Nullable Path path) {
        return path != null && Files.isRegularFile(path) && path.getFileName().toString().endsWith(ZIP_PACK_EXTENSION);
    }

    public static List<Path> mapValidDirectories(Collection<String> paths) {
        if (paths == null || paths.isEmpty()) return Collections.emptyList();

        List<Path> validPaths = new ObjectArrayList<>(paths.size());
        for (String path : paths) {
            if (path == null || path.isBlank()) continue;

            try {
                Path resolved = Paths.get(path);
                if (Files.isDirectory(resolved, LinkOption.NOFOLLOW_LINKS)) {
                    validPaths.add(resolved.toAbsolutePath().normalize());
                } else {
                    PackedPacks.LOGGER.error("[packed_packs] Path is not a valid directory: '{}', ignoring.", path);
                }
            } catch (Exception e) {
                PackedPacks.LOGGER.error("[packed_packs] Failed to resolve path: '{}', ignoring.", path, e);
            }
        }

        return validPaths;
    }

    public static void openPack(@Nullable Path path) {
        if (path != null) {
            class_156.method_668().method_60932(path);
        }
    }

    public static void openParent(@Nullable Path path) {
        if (path == null) return;

        File file = path.toFile();
        if (!file.exists()) return;

        try {
            switch (class_156.method_668()) {
                case field_1133 -> new ProcessBuilder("explorer.exe", "/select,", file.getAbsolutePath()).start();
                case field_1137 -> new ProcessBuilder("open", "-R", file.getAbsolutePath()).start();
                case field_1135 -> {
                    File parentFile = file.getParentFile();
                    if (parentFile != null) new ProcessBuilder("xdg-open", parentFile.getAbsolutePath()).start();
                }
                default -> {
                    Path parent = path.getParent();
                    if (parent != null) class_156.method_668().method_60932(parent);
                }
            }
        } catch (IOException e) {
            Path parent = path.getParent();
            if (parent != null) class_156.method_668().method_60932(parent);
        }
    }

    public static boolean deletePath(Path path) {
        FileUtils fileUtils = FileUtils.getInstance();

        if (fileUtils.hasTrash()) {
            try {
                fileUtils.moveToTrash(path.toFile());
                return true;
            } catch (IOException e) {
                PackedPacks.LOGGER.warn("[packed_packs] Failed to move to trash: '{}'", path, e);
            }
        }

        if (Files.isDirectory(path)) {
            try {
                org.apache.commons.io.FileUtils.deleteDirectory(path.toFile());
                return true;
            } catch (IOException e) {
                PackedPacks.LOGGER.error("[packed_packs] Failed to delete path: '{}'", path, e);
                return false;
            }
        }

        return UtilAccess.packed_packs$createDeleter(path).getAsBoolean();
    }

    public static boolean renamePath(Path path, Path newName) {
        return UtilAccess.packed_packs$createRenamer(path, newName).getAsBoolean();
    }

    public static String getNewIdOnRename(String previousId, String newName) {
        return previousId.replaceFirst("([^/]+?)(?=\\.[^./]+$|$)", newName);
    }

    public static PathValidationResults validatePaths(List<Path> packs) {
        class_8621<@NonNull Path> packDetector = new class_8621<>(class_310.method_1551().method_52702()) {
            @Override
            protected Path method_52439(@NonNull Path path) {
                return path;
            }

            @Override
            protected Path method_52438(@NonNull Path path) {
                return path;
            }
        };

        PathValidationResults results = new PathValidationResults(packs);
        for (Path path : packs) {
            try {
                if (!isNonPackDirectory(path)) {
                    if (validatePath(path, packDetector, results.symlinkWarnings)) {
                        results.addValid(path);
                    }
                    continue;
                }

                try (DirectoryStream<Path> paths = Files.newDirectoryStream(path)) {
                    for (Path child : paths) {
                        if (validatePath(child, packDetector, results.symlinkWarnings)) {
                            results.addValid(path);
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                PackedPacks.LOGGER.warn("Failed to check {} for packs", path, e);
            }
        }

        return results;
    }

    private static boolean validatePath(Path path, class_8621<@NonNull Path> packDetector, List<class_8581> symlinkWarnings) throws IOException {
        Path detectedPack = packDetector.method_52441(path, symlinkWarnings);
        if (detectedPack == null) {
            PackedPacks.LOGGER.warn("Path {} does not seem like pack", path);
            return false;
        }
        return true;
    }

    public record PathValidationResults(
            List<Path> valid,
            Set<Path> rejected,
            List<class_8581> symlinkWarnings
    ) {
        private PathValidationResults(Collection<Path> packs) {
            this(new ArrayList<>(packs.size()), new ObjectOpenHashSet<>(packs), new ArrayList<>());
        }

        private void addValid(Path path) {
            this.valid.add(path);
            this.rejected.remove(path);
        }
    }
}
