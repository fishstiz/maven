package io.github.fishstiz.packed_packs.transform.mixin.overrides;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.fishstiz.packed_packs.config.PackOverride;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.config.ProfileManager;
import io.github.fishstiz.packed_packs.transform.interfaces.ConfiguredPack;
import net.minecraft.class_3264;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_9225;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_3288.class)
public abstract class PackMixin implements ConfiguredPack {
    @Shadow
    @Final
    private class_3288.class_7679 metadata;

    @Shadow
    @Final
    private class_9225 selectionConfig;

    @Shadow
    public abstract String getId();

    @Shadow
    public abstract boolean isRequired();

    @Shadow
    public abstract class_3288.class_3289 getDefaultPosition();

    @Shadow
    public abstract boolean isFixedPosition();

    @Unique
    @Nullable
    private class_3264 packed_packs$packType;

    @Override
    public void packed_packs$setPackType(class_3264 packType) {
        this.packed_packs$packType = packType;
    }

    @Unique
    private @Nullable Profile packed_packs$getDefaultProfile() {
        return this.packed_packs$packType == null ? null : ProfileManager.get(this.packed_packs$packType).getDefault();
    }

    @Override
    public boolean packed_packs$isHidden() {
        Profile profile = packed_packs$getDefaultProfile();
        return profile != null && profile.isHidden(getId());
    }

    @WrapMethod(method = "isRequired")
    private boolean resolveRequired(Operation<Boolean> original) {
        Profile profile = packed_packs$getDefaultProfile();
        if (profile != null && profile.overridesRequired(getId())) {
            return profile.isRequired(getId());
        }
        return original.call();
    }

    @WrapMethod(method = "isFixedPosition")
    private boolean resolveFixed(Operation<Boolean> original) {
        Profile profile = packed_packs$getDefaultProfile();
        if (profile != null && profile.overridesPosition(getId())) {
            return profile.isFixed(getId());
        }
        return original.call();
    }

    @WrapMethod(method = "getDefaultPosition")
    private class_3288.class_3289 resolvePosition(Operation<class_3288.class_3289> original) {
        Profile profile = packed_packs$getDefaultProfile();
        if (profile != null) {
            class_3288.class_3289 position = profile.getPosition(getId());
            if (position != null) {
                return position;
            }
        }
        return original.call();
    }

    @WrapMethod(method = "selectionConfig")
    private class_9225 resolveSelectionConfig(Operation<class_9225> original) {
        Profile profile = packed_packs$getDefaultProfile();

        if (profile != null) {
            PackOverride override = profile.getOverrides(getId());
            if (override != null) {
                Boolean required = override.required();
                PackOverride.Position position = override.position();
                if (required != null || position != null) {
                    return new class_9225(isRequired(), getDefaultPosition(), isFixedPosition());
                }
            }
        }

        return original.call();
    }

    @WrapMethod(method = "getCompatibility")
    private class_3281 resolveCompatibility(Operation<class_3281> original) {
        Profile profile = packed_packs$getDefaultProfile();
        if (profile != null && profile.includes(getId())) {
            return class_3281.field_14224;
        }
        return original.call();
    }

    @Override
    public boolean packed_packs$isConfigured() {
        Profile profile = packed_packs$getDefaultProfile();
        if (profile != null) {
            return profile.includes(getId());
        }
        return false;
    }

    @Override
    public class_3288.class_7679 packed_packs$getMetadata() {
        return this.metadata;
    }

    @Override
    public class_9225 packed_packs$originalConfig() {
        return this.selectionConfig;
    }
}
