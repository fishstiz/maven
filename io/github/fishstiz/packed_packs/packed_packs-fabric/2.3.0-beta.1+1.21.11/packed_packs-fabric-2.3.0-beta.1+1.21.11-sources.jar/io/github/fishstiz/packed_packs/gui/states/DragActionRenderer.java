package io.github.fishstiz.packed_packs.gui.states;

import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import io.github.fishstiz.packed_packs.gui.components.PackListContainer;
import io.github.fishstiz.packed_packs.pack.PackIconCache;
import io.github.fishstiz.packed_packs.util.Colors;
import net.minecraft.class_11876;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class DragActionRenderer {
    private static final int OFFSET_Y = 4;
    private static final int ICON_SIZE = 48;
    private static final int NUM_SIZE = 16;
    private static final int ICON_OFFSET_X = ICON_SIZE / 2;
    private static final int ICON_OFFSET_Y = ICON_SIZE - OFFSET_Y;
    private static final int NUM_OFFSET_Y = NUM_SIZE - OFFSET_Y + (ICON_SIZE - NUM_SIZE) / 2;
    private final PackIconCache iconCache;
    private final class_327 font;
    private final PackListContainer[] lists;

    public DragActionRenderer(PackIconCache iconCache, class_327 font, PackListContainer... lists) {
        this.iconCache = iconCache;
        this.font = font;
        this.lists = lists;
    }

    public void render(
            ActiveAction.Dragging dragging,
            class_332 graphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        boolean validDrop = false;
        for (PackListContainer list : lists) {
            validDrop |= list.extractDropCandidateRenderState(graphics, dragging, mouseX, mouseY, partialTick);
        }

        renderDragging(dragging, graphics, mouseX, mouseY);
        graphics.method_74037(validDrop ? class_11876.field_62458 : class_11876.field_62459);
    }

    private void renderDragging(ActiveAction.Dragging dragging, class_332 graphics, int mouseX, int mouseY) {
        String sizeString = Integer.toString(dragging.packs().size());
        int sizeStringWidth = this.font.method_1727(sizeString);
        int iconX = mouseX - ICON_OFFSET_X;
        int iconY = mouseY - ICON_OFFSET_Y;
        int numWidth = NUM_SIZE > sizeStringWidth ? NUM_SIZE : (sizeStringWidth + NUM_SIZE - font.field_2000);
        int numX = mouseX - numWidth / 2;
        int numY = mouseY - NUM_OFFSET_Y;

        int iconRight = iconX + ICON_SIZE;
        int iconBottom = iconY + ICON_SIZE;

        graphics.method_25294(iconX, iconY, iconRight, iconBottom, Colors.GRAY_800);
        GuiGraphicsUtils.texture(graphics, iconCache.get(dragging.srcPack()), iconX, iconY, ICON_SIZE, ICON_SIZE);
        graphics.method_25294(iconX, iconY, iconRight, iconBottom, Colors.alpha(Colors.BLACK, 0.5f));

        int numRight = numX + numWidth;
        int numBottom = numY + NUM_SIZE;

        graphics.method_25294(numX, numY, numRight, numBottom, Colors.BLUE_500);
        graphics.method_25303(this.font, sizeString, numX + numWidth / 2 - sizeStringWidth / 2, numY + NUM_SIZE / 2 - font.field_2000 / 2, Colors.WHITE);

        graphics.method_73198(iconX, iconY, ICON_SIZE, ICON_SIZE, Colors.WHITE);
        graphics.method_73198(numX, numY, numWidth, NUM_SIZE, Colors.WHITE);
    }
}
