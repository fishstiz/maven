package io.github.fishstiz.packed_packs.impl.context;

import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuSink;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.gui.components.PreferenceToggle;
import io.github.fishstiz.packed_packs.gui.metadata.PackSelectionScreenArgs;
import io.github.fishstiz.packed_packs.gui.model.PackedPacksViewModel;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import io.github.fishstiz.packed_packs.impl.gui.ContextMenuWrappedWidget;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5375;
import net.minecraft.class_6379;

public record ScreenContextImpl(
        class_437 previousScreen,
        PackedPacksScreen screen,
        PackedPacksViewModel viewModel,
        PackSelectionScreenArgs originalArgs,
        class_3264 packType
) implements ScreenContext {
    public ScreenContextImpl(
            class_437 previousScreen,
            PackedPacksScreen screen,
            PackedPacksViewModel viewModel,
            PackSelectionScreenArgs originalArgs
    ) {
        this(previousScreen, screen, viewModel, originalArgs, originalArgs.packType());
    }

    @Override
    public class_5375 originalScreen() {
        return this.previousScreen instanceof class_5375 packSelectionScreen
                ? packSelectionScreen
                : this.originalArgs.createDummy();
    }

    @Override
    public class_3283 packRepository() {
        return this.originalArgs.repository();
    }

    @Override
    public List<class_3288> getAvailablePacks() {
        return Collections.unmodifiableList(this.viewModel.getAvailablePacks());
    }

    @Override
    public List<class_3288> getSelectedPacks() {
        return Collections.unmodifiableList(this.viewModel.getEnabledPacks());
    }

    @Override
    public void reload() {
        this.viewModel.refreshRepository();
    }

    @Override
    public void commit() {
        this.viewModel.commit();
    }

    @Override
    public boolean devMode() {
        return Config.get().isDevMode();
    }

    @Override
    public void rebuild() {
        this.screen.method_41843();
    }

    @Override
    public <T extends class_364 & class_6379> T addWidget(T widget) {
        return this.screen.method_25429(widget);
    }

    @Override
    public <T extends class_4068> T addRenderableOnly(T renderable) {
        return this.screen.method_37060(renderable);
    }

    @Override
    public <T extends class_364 & class_6379 & class_4068> T addRenderableWidget(T widget) {
        return this.screen.method_37063(widget);
    }

    @Override
    public void removeWidget(class_364 widget) {
        this.screen.method_37066(widget);
    }

    @Override
    public @Nullable class_339 wrapWidget(Preference<Boolean> key, @Nullable class_2561 text, @Nullable class_339 widget) {
        return PreferenceToggle.wrap(key, text, widget);
    }

    @Override
    public <T extends class_339> class_339 wrapWithContextMenu(T widget, BiConsumer<T, ContextMenuSink> configurator) {
        return new ContextMenuWrappedWidget<>(widget, configurator);
    }
}
