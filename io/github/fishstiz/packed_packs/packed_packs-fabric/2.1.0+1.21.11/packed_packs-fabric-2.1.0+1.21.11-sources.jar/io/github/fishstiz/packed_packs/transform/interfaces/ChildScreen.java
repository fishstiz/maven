package io.github.fishstiz.packed_packs.transform.interfaces;

import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

public interface ChildScreen {
    void packed_packs$setPrevious(class_437 previous);

    @Nullable class_437 packed_packs$getPrevious();

    void packed_packs$setActualScreen(class_437 screen);

    @Nullable class_437 packed_packs$getActualScreen();
}
