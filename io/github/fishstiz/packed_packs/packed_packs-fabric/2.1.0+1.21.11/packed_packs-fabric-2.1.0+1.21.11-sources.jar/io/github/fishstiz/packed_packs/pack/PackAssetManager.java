package io.github.fishstiz.packed_packs.pack;

import com.google.common.hash.Hashing;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.io.InputStream;
import java.nio.file.NoSuchFileException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3288;
import net.minecraft.class_5375;
import net.minecraft.class_7367;

public class PackAssetManager {
    public static final Sprite DEFAULT_FOLDER_ICON = Sprite.of16(ResourceUtil.id("textures/misc/unknown_folder.png"));
    public static final Sprite DEFAULT_ICON = Sprite.of16(class_2960.method_60656("textures/misc/unknown_pack.png"));
    private final Map<String, Sprite> cachedIcons = new Object2ObjectOpenHashMap<>();
    private final Executor mainThreadExecutor;
    private final class_1060 textureManager;
    private Map<String, Sprite> staleIcons;

    public PackAssetManager(Executor mainThreadExecutor, class_1060 textureManager) {
        this.mainThreadExecutor = mainThreadExecutor;
        this.textureManager = textureManager;
    }

    public Sprite getIcon(class_3288 pack) {
        if (!this.cachedIcons.containsKey(pack.method_14463())) {
            Sprite fallback = (this.staleIcons != null) ? this.staleIcons.get(pack.method_14463()) : null;
            if (fallback == null) {
                fallback = getDefaultIcon(pack);
            }
            this.cachedIcons.put(pack.method_14463(), fallback);
            this.loadPackIcon(pack).thenAcceptAsync(icon -> {
                if (icon != null) {
                    this.cachedIcons.put(pack.method_14463(), Sprite.of16(icon));
                }
            }, this.mainThreadExecutor);
        }

        return this.cachedIcons.getOrDefault(pack.method_14463(), getDefaultIcon(pack));
    }

    public void clearIconCache() {
        this.staleIcons = new Object2ObjectOpenHashMap<>(this.cachedIcons);
        this.cachedIcons.clear();
    }

    public static Sprite getDefaultIcon(class_3288 pack) {
        return pack instanceof FolderPack ? DEFAULT_FOLDER_ICON : DEFAULT_ICON;
    }

    public static class_2960 getDefaultLocation(class_3288 pack) {
        return getDefaultIcon(pack).location;
    }

    /**
     * Copied from {@link class_5375#method_30289(class_1060, class_3288)}
     */
    private CompletableFuture<@Nullable class_2960> loadPackIcon(class_3288 pack) {
        return CompletableFuture.supplyAsync(() -> {
            try (class_3262 packResources = pack.method_14458()) {
                class_7367<@NonNull InputStream> iconIoSupplier = packResources.method_14410(PackUtil.ICON_FILENAME);
                if (iconIoSupplier == null) return null;

                try (InputStream iconStream = iconIoSupplier.get()) {
                    return class_1011.method_4309(iconStream);
                }
            } catch (Exception e) {
                if (!(e instanceof NoSuchFileException)) {
                    PackedPacks.LOGGER.warn("Failed to load icon from pack '{}'", pack.method_14463(), e);
                }
                return null;
            }
        }, class_156.method_18349()).thenApplyAsync(nativeImage -> {
            if (nativeImage == null) return null;
            class_2960 icon = class_2960.method_60656(hashIconName(pack.method_14463()));
            this.textureManager.method_4616(icon, new class_1043(icon::toString, nativeImage));
            return icon;
        }, this.mainThreadExecutor);
    }

    @SuppressWarnings("deprecation")
    private static String hashIconName(String id) {
        return "pack/" + class_156.method_30309(id, class_2960::method_29184) + "/" + Hashing.sha1().hashUnencodedChars(id) + "/icon";
    }
}
