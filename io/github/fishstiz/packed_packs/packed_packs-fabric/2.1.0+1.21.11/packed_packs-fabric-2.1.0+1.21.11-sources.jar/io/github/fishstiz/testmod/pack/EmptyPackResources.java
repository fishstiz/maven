package io.github.fishstiz.testmod.pack;

import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_7367;
import net.minecraft.class_7677;
import net.minecraft.class_9224;

public record EmptyPackResources(class_9224 location) implements class_3262 {
    @Override
    public @Nullable class_7367<InputStream> method_14410(String... elements) {
        return null;
    }

    @Override
    public @Nullable class_7367<InputStream> method_14405(class_3264 packType, class_2960 location) {
        return null;
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String path, class_7664 resourceOutput) {
    }

    @Override
    public Set<String> method_14406(class_3264 type) {
        return Collections.emptySet();
    }

    @Override
    public @Nullable <T> T method_14407(class_7677<T> metadataSectionType) throws IOException {
        return null;
    }

    @Override
    public void close() {
    }
}
