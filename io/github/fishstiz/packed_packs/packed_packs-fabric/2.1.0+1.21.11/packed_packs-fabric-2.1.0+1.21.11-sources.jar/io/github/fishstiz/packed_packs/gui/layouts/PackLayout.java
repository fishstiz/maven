package io.github.fishstiz.packed_packs.gui.layouts;

import io.github.fishstiz.fidgetz.gui.components.CyclicButton;
import io.github.fishstiz.fidgetz.gui.components.FidgetzButton;
import io.github.fishstiz.fidgetz.gui.components.ToggleButton;
import io.github.fishstiz.fidgetz.gui.components.ToggleableEditBox;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayoutElement;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.fidgetz.gui.shapes.Size;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.config.Config;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.gui.components.PreferenceToggle;
import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import io.github.fishstiz.packed_packs.gui.components.pack.PackListContainer;
import io.github.fishstiz.packed_packs.gui.components.pack.Query;
import io.github.fishstiz.packed_packs.gui.model.PackListKey;
import io.github.fishstiz.packed_packs.gui.model.PackListType;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import io.github.fishstiz.packed_packs.gui.model.PackedPacksViewModel;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.gui.states.ProfilesState;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.SPACING;

public class PackLayout implements FlexLayoutElement, class_8133 {
    private final FlexLayout layout = FlexLayout.vertical().spacing(SPACING);
    private final FlexLayout headerLayout;
    private final PackListViewModel viewModel;
    private final PackListContainer root;
    private final ToggleableEditBox<Void> searchField;
    private final FidgetzButton<Void> transferButton;
    private @Nullable CyclicButton<Query.SortOption, Void> sortButton;
    private @Nullable ToggleButton<Void> compatButton;

    public PackLayout(ScreenContext screenContext, PackedPacksViewModel viewModel, PackListType type) {
        this.viewModel = viewModel.createPackListSlice(type);
        this.root = new PackListContainer(screenContext, this.viewModel);
        this.headerLayout = FlexLayout.horizontal(this.root::method_25368).spacing(SPACING);

        this.searchField = ToggleableEditBox.<Void>builder()
                .setHint(ResourceUtil.getText("search").method_10852(class_5244.field_39678))
                .setEditable(true)
                .addListener(this.viewModel::search)
                .build();
        this.transferButton = FidgetzButton.<Void>builder()
                .makeSquare()
                .setOnPress(this.viewModel::transferAll)
                .setTooltip(class_7919.method_47407(ResourceUtil.getText("transfer_all.info")))
                .build();
        this.transferButton.field_22763 = !this.viewModel.locked();

        switch (type) {
            case ENABLED -> {
                this.transferButton.method_25355(class_2561.method_43470("<<"));
                this.headerLayout.addChild(transferButton);
                this.headerLayout.addFlexChild(this.searchField);
            }
            case AVAILABLE -> {
                this.transferButton.method_25355(class_2561.method_43470(">>"));

                this.sortButton = CyclicButton.<Query.SortOption, Void>builder(Query.SortOption.values())
                        .setPrefix(ResourceUtil.getText("sort"))
                        .makeSquare()
                        .addListener(this.viewModel::sort)
                        .addListener(Config.get()::setSort)
                        .setValue(Config.get().getSort())
                        .build();
                this.compatButton = PreferenceToggle.bind(Preferences.INCOMPATIBLE_TOGGLE_WIDGET, ToggleButton.<Void>builder()).map(
                        bound -> bound.value()
                                .setMessage(ResourceUtil.getText("hide_incompatible"))
                                .setTooltip(class_7919.method_47407(ResourceUtil.getText("hide_incompatible.info")))
                                .setSprite(ToggleButton.Sprites.of(
                                        new Sprite(ResourceUtil.getIcon("incompatible_hidden"), Size.of16()),
                                        new Sprite(ResourceUtil.getIcon("incompatible"), Size.of16())
                                ))
                                .setContextMenuBuilder(bound.apply(toggle -> (btn, b) -> toggle.updateBuilder(b)))
                                .setForeground(bound.toggle())
                                .makeSquare()
                                .addListener(this.viewModel::hideIncompatible)
                                .addListener(Config.get()::setHideIncompatible)
                                .setValue(Config.get().isHideIncompatible())
                                .build()).orElse(null);

                this.headerLayout.addFlexChild(this.searchField);
                this.headerLayout.addChild(sortButton);
                this.headerLayout.addChild(compatButton);
                this.headerLayout.addChild(transferButton);
            }
        }

        this.layout.addChild(this.headerLayout);
        this.layout.addFlexChild(this.root, true);

        viewModel.subscribe(PackedPacksState::profiles, this::refreshTransferButton);
        this.viewModel.subscribe(PackListViewModel.Property.QUERY, this::refresh);
    }

    private void refreshTransferButton(ProfilesState profilesState) {
        this.transferButton.field_22763 = !this.viewModel.locked();
    }

    private void refresh() {
        Query query = this.viewModel.query();

        this.searchField.setValueSilently(query.unmodifiedSearch());

        if (this.sortButton != null && query.sort() != null) {
            this.sortButton.setValueSilently(query.sort());
        }
        if (this.compatButton != null) {
            this.compatButton.setValueSilently(query.hideIncompatible());
        }
    }

    public PackListKey key() {
        return this.viewModel.key();
    }

    public PackListContainer container() {
        return this.root;
    }

    public ToggleableEditBox<Void> getSearchField() {
        return this.searchField;
    }

    public void setHeaderVisibility(boolean visible) {
        this.headerLayout.method_48206(widget -> widget.field_22764 = visible);
        class_8030 headerRect = this.headerLayout.method_48202();
        int y = visible ? headerRect.method_49619() + SPACING : headerRect.method_49618();
        int height = visible ? this.layout.method_25364() - headerRect.comp_1197() - SPACING : this.layout.method_25364();

        this.root.method_46419(y);
        this.root.method_53533(height);
        this.root.visitPackLists(PackList::clampScrollAmount);
    }

    @Override
    public void method_46421(int x) {
        this.layout.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        this.layout.method_46419(y);
    }

    @Override
    public int method_46426() {
        return this.layout.method_46426();
    }

    @Override
    public int method_46427() {
        return this.layout.method_46427();
    }

    @Override
    public int method_25368() {
        return this.layout.method_25368();
    }

    @Override
    public int method_25364() {
        return this.layout.method_25364();
    }

    @Override
    public void setWidth(int width) {
        this.layout.setWidth(width);
    }

    @Override
    public void setHeight(int height) {
        this.layout.setHeight(height);
    }

    @Override
    public void method_48227(@NonNull Consumer<class_8021> visitor) {
        this.layout.method_48227(visitor);
    }

    @Override
    public void method_48206(@NonNull Consumer<class_339> visitor) {
        this.layout.method_48206(visitor);
    }

    @Override
    public void method_48222() {
        this.layout.method_48222();
    }
}
