package io.github.fishstiz.packed_packs.compat.vtdownloader;

import io.github.fishstiz.fidgetz.gui.components.FidgetzButton;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializeLayoutEvent;
import io.github.fishstiz.packed_packs.api.events.InitializePackEntryEvent;
import io.github.fishstiz.packed_packs.compat.*;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3288;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5369;
import net.minecraft.class_7919;

public class VTDIntegration extends ModIntegration {
    private static final int PENCIL_MARGIN_RIGHT = 1;

    @Override
    public ModContext mod() {
        return FabricMod.VTD;
    }

    @Override
    protected void onInitLoaded(PackedPacksApi api) {
        Preference<Boolean> vtdButton = api.preferences().register(ResourceUtil.id("vtd_button"), true);
        Preference<Boolean> vtdEditButton = api.preferences().register(ResourceUtil.id("vtd_edit_button"), true);

        api.eventBus().register(InitializeLayoutEvent.class, this.id(), ModIntegration.id(Mod.ETF), event -> {
            ScreenContext ctx = event.screenContext();
            if (ctx.isClientResources()) {
                var button = ctx.wrapWidget(vtdButton, null, this.createButton(ctx.screen()));
                if (button != null) event.addWidget(InitializeLayoutEvent.Pos.AFTER_TITLE, button);
            }
        });

        api.eventBus().register(InitializePackEntryEvent.class, this.id(), event -> {
            ScreenContext ctx = event.screenContext();
            if (ctx.isClientResources()) {
                var button = ctx.wrapWidget(vtdEditButton, null, VTDEditButtonWidget.create(
                        vtdEditButton,
                        ctx.screen(),
                        event.packContext().pack(),
                        event.packContext()::fileModifiable
                ));
                if (button != null) event.addBottomRight(PENCIL_MARGIN_RIGHT, button);
            }
        });

        api.eventBus().register(ContextMenuEvent.Preferences.class, this.id(), List.of(id(Mod.RESPACKOPTS), id(Mod.ETF)), event -> {
            if (event.screenContext().isClientResources()) {
                event.addToggle(vtdButton, getWidgetPrefText(vtdButton));
                event.addToggle(vtdEditButton, getWidgetPrefText(vtdEditButton));
            }
        });
    }

    private class_4185 createButton(class_437 parent) {
        return FidgetzButton.<Void>builder()
                .makeSquare()
                .setTooltip(class_7919.method_47407(class_2561.method_43471("vtd.resourcePack.button")))
                .setSprite(Sprite.of32(class_2960.method_60655("vt_downloader", "icon.png")))
                .setFocusedBorder(Theme.WHITE.getARGB())
                .setOnPress(createVTDScreenSetter(parent, null))
                .build();
    }

    static Runnable createVTDScreenSetter(class_437 parent, @Nullable class_3288 pack) {
        String screenName = "me.bymartrixx.vtd.gui.VTDownloadScreen";
        ScreenArg<class_437> parentArg = ScreenArg.parent(parent);
        ScreenArg<class_2561> subtitleArg = new ScreenArg<>(class_2561.class, class_2561.method_43471("vtd.resourcePack.subtitle"));

        if (pack == null) {
            return createScreenSetter(screenName, parentArg, subtitleArg);
        }

        return createScreenSetter(screenName, parentArg, subtitleArg, new ScreenArg<>(
                class_5369.class_5371.class,
                new PackWrapperDelegatorAbstractionEpicModelEntry(pack)
        ));
    }
}
