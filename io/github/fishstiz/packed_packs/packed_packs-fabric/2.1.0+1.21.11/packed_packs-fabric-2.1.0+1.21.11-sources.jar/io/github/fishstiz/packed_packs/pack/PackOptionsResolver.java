package io.github.fishstiz.packed_packs.pack;

import io.github.fishstiz.fidgetz.util.lang.FunctionsUtil;
import io.github.fishstiz.packed_packs.config.PackOptions;
import io.github.fishstiz.packed_packs.config.Profile;
import io.github.fishstiz.packed_packs.config.ProfileManager;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.function.*;
import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_9225;

/**
 * Checks the default profile first, then the selected profile, then pack defaults.
 */
public record PackOptionsResolver(
        Supplier<@Nullable Profile> profileSupplier,
        Supplier<@Nullable Profile> defaultProfileSupplier
) implements PackOptions {
    public static final PackOptionsResolver DATA_PACKS = new PackOptionsResolver(ProfileManager.get(class_3264.field_14190));
    public static final PackOptionsResolver RESOURCE_PACKS = new PackOptionsResolver(ProfileManager.get(class_3264.field_14188));

    public PackOptionsResolver(ProfileManager manager) {
        this(FunctionsUtil.nullSupplier(), manager::getDefault);
    }

    @Override
    public boolean isHidden(class_3288 pack) {
        return Boolean.TRUE.equals(this.inDefaultOrSelected(pack, Profile::isHidden, Profile::isHidden));
    }

    public boolean isRequired(class_3288 pack) {
        return Boolean.TRUE.equals(this.inDefaultOrSelected(pack, Profile::overridesRequired, Profile::isRequired));
    }

    @Override
    public boolean isFixed(class_3288 pack) {
        return Boolean.TRUE.equals(this.inDefaultOrSelected(pack, Profile::overridesPosition, Profile::isFixed));
    }

    @Override
    public class_3288.@Nullable class_3289 getPosition(class_3288 pack) {
        return this.inDefaultOrSelected(pack, Profile::overridesPosition, Profile::getPosition);
    }

    @Override
    public @Nullable class_9225 getSelectionConfig(class_3288 pack) {
        return this.inDefaultOrSelected(pack, (profile, p) -> profile.overridesPosition(p) || profile.overridesRequired(p), Profile::getSelectionConfig);
    }

    public boolean isRequiredOrDefault(class_3288 pack) {
        return this.inDefaultOrSelected(pack, Profile::overridesRequired, Profile::isRequired, class_3288::method_14464);
    }

    public boolean isFixedOrDefault(class_3288 pack) {
        return this.inDefaultOrSelected(pack, Profile::overridesPosition, Profile::isFixed, class_3288::method_14465);
    }

    public class_3288.@NonNull class_3289 getPositionOrDefault(class_3288 pack) {
        return Objects.requireNonNull(this.inDefaultOrSelected(pack, Profile::overridesPosition, Profile::getPosition, class_3288::method_14466));
    }

    public @NonNull class_9225 getSelectionConfigOrDefault(class_3288 pack) {
        return Objects.requireNonNull(this.getOrDefault(pack, PackOptions::getSelectionConfig, Objects::nonNull, class_3288::method_56934));
    }

    public boolean overridesRequired(class_3288 pack) {
        return this.hasOverride(pack, Profile::overridesRequired);
    }

    public boolean overridesPosition(class_3288 pack) {
        return this.hasOverride(pack, Profile::overridesPosition);
    }

    private boolean hasOverride(class_3288 pack, BiPredicate<Profile, class_3288> option) {
        Profile defaultProfile = this.defaultProfileSupplier.get();
        Profile selected = this.profileSupplier.get();

        if (defaultProfile != null && option.test(defaultProfile, pack)) {
            return true;
        }
        return selected != null && option.test(selected, pack);
    }

    private <T> T getOrDefault(class_3288 pack, BiFunction<PackOptions, class_3288, T> option, Predicate<T> predicate, Function<class_3288, T> defaultValue) {
        T value = option.apply(this, pack);
        return predicate.test(value) ? value : defaultValue.apply(pack);
    }

    private <T> T inDefaultOrSelected(class_3288 pack, BiPredicate<Profile, class_3288> shouldApply, BiFunction<Profile, class_3288, T> option, Function<class_3288, T> defaultValue) {
        Profile defaultProfile = this.defaultProfileSupplier.get();
        if (defaultProfile != null && shouldApply.test(defaultProfile, pack)) {
            return option.apply(defaultProfile, pack);
        }
        Profile selected = this.profileSupplier.get();
        if (selected != null && shouldApply.test(selected, pack)) {
            return option.apply(selected, pack);
        }
        return defaultValue.apply(pack);
    }

    private <T> @Nullable T inDefaultOrSelected(class_3288 pack, BiPredicate<Profile, class_3288> shouldApply, BiFunction<Profile, class_3288, T> option) {
        return this.inDefaultOrSelected(pack, shouldApply, option, p -> null);
    }
}
