package io.github.fishstiz.testmod.gui;

import io.github.fishstiz.testmod.TestFeature;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

public class FocusPathRenderer extends TestFeatureRenderer {
    private static final String LABEL = "Focus Path: ";
    private final class_310 minecraft;

    public FocusPathRenderer(TestFeature feature) {
        super(feature);
        this.minecraft = class_310.method_1551();
    }

    @Override
    protected int renderFeature(class_332 guiGraphics, int mouseX, int mouseY, int y, float partialTick) {
        class_437 screen = minecraft.field_1755;
        if (screen == null) return y;

        guiGraphics.method_25294(0, y, minecraft.field_1772.method_1727(LABEL), y + minecraft.field_1772.field_2000, 0x7FFF0000);
        guiGraphics.method_25303(minecraft.field_1772, "Focus Path: ", 0, y, 0xFFFFFFFF);
        return renderFocusPath(guiGraphics, screen.method_25399(), y + minecraft.field_1772.field_2000, minecraft.field_1772);
    }

    private static int renderFocusPath(class_332 guiGraphics, @Nullable class_364 listener, int y, class_327 font) {
        if (listener == null) return y;

        String name = listener.getClass().getName();
        guiGraphics.method_25294(0, y, font.method_1727(name), y + font.field_2000, 0x7FFF0000);
        guiGraphics.method_25303(font, name, 0, y, 0xFFFFFFFF);

        if (listener instanceof class_4069 container) {
            return renderFocusPath(guiGraphics, container.method_25399(), y + font.field_2000, font);
        }

        return y + font.field_2000;
    }
}