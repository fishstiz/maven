package io.github.fishstiz.packed_packs.transform.mixin.compat.cursors_extended;

import net.minecraft.class_11875;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_11875.class)
public interface CursorTypeAccess {
    @Invoker("<init>")
    static class_11875 packed_packs$createCursorType(String name, long handle) {
        throw new AssertionError();
    }
}
