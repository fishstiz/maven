package io.github.fishstiz.packed_packs.compat.controlify;

import dev.isxander.controlify.api.bind.InputBinding;
import dev.isxander.controlify.bindings.ControlifyBindings;
import dev.isxander.controlify.controller.ControllerEntity;
import dev.isxander.controlify.controller.input.ControllerStateView;
import dev.isxander.controlify.controller.input.GamepadInputs;
import dev.isxander.controlify.controller.input.InputComponent;
import dev.isxander.controlify.screenop.ScreenProcessor;
import dev.isxander.controlify.utils.HoldRepeatHelper;
import io.github.fishstiz.packed_packs.gui.components.PackList;
import io.github.fishstiz.packed_packs.gui.screens.PackedPacksScreen;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.function.Supplier;
import net.minecraft.class_11908;
import net.minecraft.class_2960;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import net.minecraft.class_8030;

class PackedPacksScreenProcessor extends ScreenProcessor<PackedPacksScreen> {
    public PackedPacksScreenProcessor(PackedPacksScreen screen) {
        super(screen);
    }

    @Override
    protected boolean handleComponentButtonOverride(ControllerEntity controller) {
        if (ControlifyBindings.GUI_BACK.on(controller).guiPressed().get()) {
            screen.method_25404(new class_11908(class_3675.field_31958, GLFW.glfwGetKeyScancode(GLFW.GLFW_KEY_ESCAPE), 0));
            return true;
        }

        InputComponent input = controller.input().orElse(null);
        if (input != null) {
            ControllerStateView state = input.stateNow();
            ControllerStateView prevState = input.stateThen();

            if (justPressed(GamepadInputs.LEFT_SHOULDER_BUTTON, state, prevState)) {
                screen.toggleSidebar();
                return true;
            } else if (justPressed(GamepadInputs.START_BUTTON, state, prevState)) {
                screen.openOptions();
                return true;
            } else if (justPressed(GamepadInputs.RIGHT_SHOULDER_BUTTON, state, prevState)) {
                class_364 leaf = leafComponent(screen.method_48218());
                if (leaf == null) {
                    screen.openContextMenu(0, 0, true);
                } else {
                    class_8030 rect = leaf.method_48202();
                    screen.openContextMenu(rect.method_49621() - 1, rect.method_49618(), true);
                }
                return true;
            }
        }

        return super.handleComponentButtonOverride(controller);
    }

    @Override
    protected @Nullable Supplier<Boolean> createScreenNavigationFunc(class_8028 direction) {
        class_8016 path = screen.method_48205(new class_8023.class_8024(direction));
        if (path == null) return null;

        return () -> {
            screen.method_48263(unselectListPath(path));
            return true;
        };
    }

    HoldRepeatHelper holdRepeatHelper() {
        return holdRepeatHelper;
    }

    private static class_8016 unselectListPath(class_8016 path) {
        if (path instanceof class_8016.class_8018(class_4069 component, class_8016 childPath)) {
            return class_8016.method_48192(component, unselectListPath(childPath));
        } else if (path instanceof PackList.ListPath listPath) {
            return new PackList.ListPath(listPath.comp_1188(), listPath.child(), listPath.scroll(), false);
        } else {
            return path;
        }
    }

    private static class_364 leafComponent(@Nullable class_8016 path) {
        if (path instanceof class_8016.class_8018 containerPath) {
            return leafComponent(containerPath.comp_1190());
        } else if (path instanceof PackList.ListPath listPath) {
            return listPath.child();
        } else if (path != null) {
            return path.comp_1188();
        } else {
            return null;
        }
    }

    static @Nullable class_8028 getVerticalDirection(
            PackedPacksScreenProcessor screen,
            ControllerEntity controller
    ) {
        InputComponent input = controller.input().orElse(null);
        if (input == null) return null;

        HoldRepeatHelper holdRepeatHelper = screen.holdRepeatHelper();
        boolean canRepeat = holdRepeatHelper.canNavigate();

        ControllerStateView state = input.stateNow();
        ControllerStateView prevState = input.stateThen();

        class_8028 direction = null;

        if (canNavigate(ControlifyBindings.GUI_NAVI_UP.on(controller), canRepeat, holdRepeatHelper)) {
            direction = class_8028.field_41826;
        } else if (canNavigate(ControlifyBindings.GUI_NAVI_DOWN.on(controller), canRepeat, holdRepeatHelper)) {
            direction = class_8028.field_41827;
        } else if (canPress(GamepadInputs.DPAD_UP_BUTTON, state, prevState, canRepeat, holdRepeatHelper)) {
            direction = class_8028.field_41826;
        } else if (canPress(GamepadInputs.DPAD_DOWN_BUTTON, state, prevState, canRepeat, holdRepeatHelper)) {
            direction = class_8028.field_41827;
        }

        return direction;
    }

    static boolean canNavigate(InputBinding binding, boolean canRepeat, HoldRepeatHelper holdRepeatHelper) {
        if (binding.digitalNow() && (canRepeat || !binding.digitalPrev())) {
            if (!binding.digitalPrev()) {
                holdRepeatHelper.reset();
            }
            return true;
        }
        return false;
    }

    static boolean canPress(
            class_2960 input,
            ControllerStateView state,
            ControllerStateView prevState,
            boolean canRepeat,
            HoldRepeatHelper holdRepeatHelper
    ) {
        if (state.isButtonDown(input) && (canRepeat || !prevState.isButtonDown(input))) {
            if (!prevState.isButtonDown(input)) {
                holdRepeatHelper.reset();
            }
            return true;
        }
        return false;
    }

    static boolean justPressed(
            class_2960 input,
            ControllerStateView state,
            ControllerStateView prevState
    ) {
        return state.isButtonDown(input) && !prevState.isButtonDown(input);
    }

    static boolean justReleased(
            class_2960 input,
            ControllerStateView state,
            ControllerStateView prevState
    ) {
        return !state.isButtonDown(input) && prevState.isButtonDown(input);
    }
}
