package io.github.fishstiz.packed_packs.compat.controlify;

import dev.isxander.controlify.controller.ControllerEntity;
import dev.isxander.controlify.controller.input.GamepadInputs;
import dev.isxander.controlify.screenop.ComponentProcessor;
import dev.isxander.controlify.screenop.ScreenProcessor;
import io.github.fishstiz.packed_packs.gui.components.PackList;
import net.minecraft.class_8028;

public record PackListProcessor(PackList packList) implements ComponentProcessor {
    @Override
    public boolean overrideControllerNavigation(ScreenProcessor<?> screen, ControllerEntity controller) {
        if (!packList.method_25370() || !(screen instanceof PackedPacksScreenProcessor screenProcessor)) {
            return false;
        }

        if (controller.input().filter(input -> input.stateNow().isButtonDown(GamepadInputs.NORTH_BUTTON)).isPresent()) {
            class_8028 direction = PackedPacksScreenProcessor.getVerticalDirection(screenProcessor, controller);
            if (direction != null) {
                PackList.Entry focused = packList.method_25399();
                screenProcessor.holdRepeatHelper().onNavigate();
                if (focused != null) focused.selectPack();
                packList.selectRangeAtDirection(direction, true);
                return true;
            }
        }

        return false;
    }
}
