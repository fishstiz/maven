package io.github.fishstiz.packed_packs.pack;

import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.config.DevConfig;
import io.github.fishstiz.packed_packs.config.ProfileManager;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.minecraft.class_3288;

// TreeMap in vanilla and fabric, LinkedHashMap in NeoForge
public class PackAliasMap implements Map<String, class_3288> {
    private final DevConfig.Packs config;
    private final Map<String, class_3288> map;
    private Set<String> unresolvedIds;

    public PackAliasMap(DevConfig.Packs config, Map<String, class_3288> map) {
        this.config = config;
        this.map = map;
    }

    @Override
    public int size() {
        return this.map.size();
    }

    @Override
    public boolean isEmpty() {
        return this.map.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        return this.map.containsKey(key) || this.resolvePackId(key) != null;
    }

    @Override
    public boolean containsValue(Object value) {
        return this.map.containsValue(value);
    }

    /**
     * Called when rebuilding selected ids, so hopefully the resolved map is also built immediately.
     */
    @Override
    public class_3288 get(Object key) {
        class_3288 pack = this.map.get(key);
        if (pack != null) {
            return pack;
        }
        return this.resolvePackId(key);
    }

    @Override
    public @Nullable class_3288 put(String key, class_3288 value) {
        return this.map.put(key, value);
    }

    @Override
    public class_3288 remove(Object key) {
        return this.map.remove(key);
    }

    @Override
    public void putAll(@NotNull Map<? extends String, ? extends class_3288> m) {
        this.map.putAll(m);
    }

    @Override
    public void clear() {
        this.map.clear();
    }

    @Override
    public @NotNull Set<String> keySet() {
        return this.map.keySet();
    }

    @Override
    public @NotNull Collection<class_3288> values() {
        return this.map.values();
    }

    @Override
    public @NotNull Set<Entry<String, class_3288>> entrySet() {
        return this.map.entrySet();
    }

    @Override
    @SuppressWarnings("SuspiciousMethodCalls")
    public class_3288 getOrDefault(Object key, class_3288 defaultValue) {
        return this.map.getOrDefault(key, defaultValue);
    }

    @Override
    public void forEach(BiConsumer<? super String, ? super class_3288> action) {
        this.map.forEach(action);
    }

    @Override
    public void replaceAll(BiFunction<? super String, ? super class_3288, ? extends class_3288> function) {
        this.map.replaceAll(function);
    }

    @Override
    public @Nullable class_3288 putIfAbsent(String key, class_3288 value) {
        return this.map.putIfAbsent(key, value);
    }

    @Override
    public boolean remove(Object key, Object value) {
        return this.map.remove(key, value);
    }

    @Override
    public boolean replace(String key, class_3288 oldValue, class_3288 newValue) {
        return this.map.replace(key, oldValue, newValue);
    }

    @Override
    public @Nullable class_3288 replace(String key, class_3288 value) {
        return this.map.replace(key, value);
    }

    @Override
    public class_3288 computeIfAbsent(String key, @NotNull Function<? super String, ? extends class_3288> mappingFunction) {
        return this.map.computeIfAbsent(key, mappingFunction);
    }

    @Override
    public class_3288 computeIfPresent(String key, @NotNull BiFunction<? super String, ? super class_3288, ? extends class_3288> remappingFunction) {
        return this.map.computeIfPresent(key, remappingFunction);
    }

    @Override
    public class_3288 compute(String key, @NotNull BiFunction<? super String, ? super class_3288, ? extends class_3288> remappingFunction) {
        return this.map.compute(key, remappingFunction);
    }

    @Override
    public class_3288 merge(String key, @NotNull class_3288 value, @NotNull BiFunction<? super class_3288, ? super class_3288, ? extends class_3288> remappingFunction) {
        return this.map.merge(key, value, remappingFunction);
    }

    @Override
    @SuppressWarnings("EqualsDoesntCheckParameterClass")
    public boolean equals(Object obj) {
        return this.map.equals(obj);
    }

    @Override
    public int hashCode() {
        return this.map.hashCode();
    }

    private @Nullable class_3288 resolvePackId(Object key) {
        if (!(key instanceof String packId)) {
            return null;
        }

        if (this.unresolvedIds != null && this.unresolvedIds.contains(key)) {
            return null;
        }

        String mappedPackId = this.config.resolveCanonicalId(packId);
        if (mappedPackId == null) {
            this.setUnresolved(packId);
            return null;
        }

        class_3288 resolvedPack = null;

        if (DevConfig.Packs.isRegexPrefixed(mappedPackId)) {
            try {
                Pattern pattern = Pattern.compile(mappedPackId.replaceFirst(DevConfig.Packs.getRegexPrefixPattern().pattern(), ""));
                for (class_3288 availablePack : this.map.values()) {
                    if (pattern.matcher(availablePack.method_14463()).matches()) {
                        resolvedPack = availablePack;

                        if (!this.config.isExactAlias(packId)) {
                            // cache result of regex matched id
                            this.config.putAlias(packId, resolvedPack.method_14463());
                            DevConfig.get().save();
                        }
                        break;
                    }
                }
            } catch (PatternSyntaxException e) {
                PackedPacks.LOGGER.error("[packed_packs] Invalid regex syntax '{}' for key '{}'. ", mappedPackId, key, e);
            }
        } else {
            resolvedPack = this.get(mappedPackId);

            if (!this.config.isExactAlias(packId)) {
                // cache anyway even if unresolved for faster subsequent launches.
                this.config.putAlias(packId, mappedPackId);
                DevConfig.get().save();
            }
        }

        if (resolvedPack != null) {
            PackedPacks.LOGGER.info("[packed_packs] Resolved unknown pack '{}' to '{}', remapping profiles.",
                    packId,
                    resolvedPack.method_14463()
            );

            ProfileManager.get(this.config.packType()).remapAndSavePackIds(packId, resolvedPack.method_14463());

            this.put(packId, resolvedPack);
        } else {
            PackedPacks.LOGGER.warn(
                    "[packed_packs] Unknown pack '{}' mapped to '{}', but no such pack is available.",
                    packId,
                    mappedPackId
            );
            this.setUnresolved(packId);
        }

        return resolvedPack;
    }

    private void setUnresolved(String packId) {
        if (this.unresolvedIds == null) {
            this.unresolvedIds = new ObjectOpenHashSet<>();
        }
        this.unresolvedIds.add(packId);
    }
}
