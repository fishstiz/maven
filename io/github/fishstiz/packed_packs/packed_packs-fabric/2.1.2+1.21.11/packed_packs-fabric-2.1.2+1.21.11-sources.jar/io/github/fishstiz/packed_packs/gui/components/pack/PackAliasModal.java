package io.github.fishstiz.packed_packs.gui.components.pack;

import io.github.fishstiz.fidgetz.gui.components.*;
import io.github.fishstiz.fidgetz.gui.layouts.FlexLayout;
import io.github.fishstiz.fidgetz.util.lang.ObjectsUtil;
import io.github.fishstiz.fidgetz.util.text.PatternStylizer;
import io.github.fishstiz.fidgetz.util.text.TextStylizer;
import io.github.fishstiz.packed_packs.config.DevConfig;
import io.github.fishstiz.packed_packs.gui.intents.PackListIntent;
import io.github.fishstiz.packed_packs.gui.model.PackedPacksViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.gui.states.PackedPacksState;
import io.github.fishstiz.packed_packs.util.constants.GuiConstants;
import io.github.fishstiz.packed_packs.util.constants.Theme;
import io.github.fishstiz.packed_packs.util.text.GroupCloseStylizer;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8133;
import net.minecraft.class_8667;

import static io.github.fishstiz.packed_packs.util.constants.GuiConstants.SPACING;

public class PackAliasModal extends Modal<PackAliasModal.DelegatedLayout> {
    private final PackedPacksViewModel viewModel;

    public <S extends class_437 & ToggleableDialogContainer> PackAliasModal(S screen, PackedPacksViewModel viewModel) {
        super(Modal.builder(screen, new DelegatedLayout(viewModel::dispatch)).padding(SPACING).setFocusOnOpen(true));
        this.viewModel = viewModel;
        this.viewModel.subscribe(PackedPacksState::editingAliases, this::refresh);
    }

    private void refresh(ActiveAction.@Nullable EditingAliases editContext) {
        if (editContext == null) {
            super.setOpen(false);
            this.root().layout().clear();
            this.clearWidgets();
            ObjectsUtil.ifPresent(this.method_48218(), p -> p.method_48195(false));
            this.method_25395(null);
            return;
        }

        this.root().layout().init();
        this.root().layout().refresh(editContext, this::addRenderableWidget, this::addRenderableOnly);
        this.repositionElements();
        super.setOpen(true);
    }

    @Override
    public void setOpen(boolean open) {
        var editContext = this.viewModel.state().editingAliases();
        if (!open && editContext != null) {
            List<String> aliases = ObjectsUtil.mapOrNull(this.root().layout().aliases, EditableList::extractItems);
            if (aliases != null) {
                this.viewModel.dispatch(new PackListIntent.CloseAliases(editContext.target(), editContext.ctx(), aliases));
            }
        }
    }

    @Override
    public @Nullable class_8016 method_48205(@NonNull class_8023 event) {
        return super.method_48205(event);
    }

    static class DelegatedLayout implements class_8133 {
        private static final int LIST_WIDTH = 296;
        private static final int LIST_HEIGHT = 128;
        private static final int MAX_ALIAS_LENGTH = 255;
        private Pattern unescapedForwardSlash;
        private Pattern unclosedParenthesis;
        private Pattern unclosedBracket;
        private Pattern danglingBackslash;
        private Pattern boundary;
        private Pattern anyChar;
        private Pattern escapedChar;
        private Pattern quantifier;
        private Pattern openCharSet;
        private Pattern openCaptureGroup;
        private Pattern alternation;
        private final Consumer<PackListIntent.CloseAliases> onClose;
        private final class_8667 stubLayout = class_8667.method_52741();
        private class_8667 layout = this.stubLayout;
        private @Nullable EditableList<String> aliases;
        private boolean initialized;

        DelegatedLayout(Consumer<PackListIntent.CloseAliases> onClose) {
            this.onClose = onClose;
        }

        void init() {
            if (this.initialized) return;
            this.unescapedForwardSlash = Pattern.compile("(?<!\\\\)/");
            this.unclosedParenthesis = Pattern.compile("(?<!\\\\)\\((?=[^)]*$)");
            this.unclosedBracket = Pattern.compile("(?<!\\\\)\\[(?![^]\\[]*])");
            this.danglingBackslash = Pattern.compile("(?<=(?<!\\\\)(\\\\\\\\){0,128})\\\\$");
            this.boundary = Pattern.compile("(?<!(?<!\\\\)(\\\\\\\\){0,128}\\[[^]]{0,255})(?<=(?<!\\\\)(\\\\\\\\){0,128})(?<=(?<!\\\\)(\\\\\\\\){0,128})[$^]|(\\\\[bB])");
            this.anyChar = Pattern.compile("\\\\[wWdDsS]|(?<!(?<!\\\\)(\\\\\\\\){0,128}\\[[^]]{0,255})(?<=(?<!\\\\)(\\\\\\\\){0,128})(?<=(?<!\\\\)(\\\\\\\\){0,128})\\.");
            this.escapedChar = Pattern.compile("(\\\\u[0-9a-fA-F]{4})|(\\\\([0-3][0-7]{2}|[0-7]{1,2}))|(\\\\[^wWdDsS])");
            this.quantifier = Pattern.compile("(?<!(?<!\\\\)(\\\\\\\\){0,128}\\[[^]]{0,255})(?<=(?<!\\\\)(\\\\\\\\){0,128})(?<=(?<!\\\\)(\\\\\\\\){0,128})(\\{\\d+,?\\d*}|[+*?])");
            this.openCharSet = Pattern.compile("(?<=(?<!\\\\)(\\\\\\\\){0,128})\\[\\^?(?=[^]]*(?<=(?<!\\\\)(\\\\\\\\){0,128})])");
            this.openCaptureGroup = Pattern.compile("(?<=(?<!\\\\)(\\\\\\\\){0,128})\\((\\?(<\\w+>|:|!|=|<!|<=))?(?=.*(?<=(?<!\\\\)(\\\\\\\\){0,128})\\))");
            this.alternation = Pattern.compile("(?<!(?<!\\\\)(\\\\\\\\){0,128}\\[[^]]{0,255})(?<=(?<!\\\\)(\\\\\\\\){0,128})\\|");
            this.initialized = true;
        }

        void clear() {
            this.aliases = null;
            this.layout = this.stubLayout;
        }

        void refresh(
                ActiveAction.EditingAliases editAction,
                UnaryOperator<class_339> widgetAdder,
                UnaryOperator<class_339> renderableAdder
        ) {
            if (!this.initialized) return;
            this.aliases = EditableList.builder(editAction.aliases())
                    .setDimensions(LIST_WIDTH, LIST_HEIGHT)
                    .setMaxTextLength(MAX_ALIAS_LENGTH)
                    .setSaveValidator(value -> !Objects.equals(value, editAction.ctx().pack().method_14463()))
                    .addTextStylizer(createStylizer(this.unescapedForwardSlash, Theme.RED_700.getARGB()))
                    .addTextStylizer(createStylizer(this.unclosedParenthesis, Theme.RED_700.getARGB()))
                    .addTextStylizer(createStylizer(this.unclosedBracket, Theme.RED_700.getARGB()))
                    .addTextStylizer(createStylizer(this.danglingBackslash, Theme.RED_700.getARGB()))
                    .addTextStylizer(createStylizer(this.anyChar, Theme.ORANGE_500.getARGB()))
                    .addTextStylizer(createStylizer(this.escapedChar, Theme.MAGENTA_500.getARGB()))
                    .addTextStylizer(createStylizer(this.boundary, Theme.BROWN_500.getARGB()))
                    .addTextStylizer(createStylizer(this.quantifier, Theme.BLUE_500.getARGB()))
                    .addTextStylizer(createStylizer(this.openCharSet, Theme.YELLOW_500.getARGB()))
                    .addTextStylizer(createClosingStylizer('[', ']', Theme.YELLOW_500.getARGB()))
                    .addTextStylizer(createStylizer(this.openCaptureGroup, Theme.GREEN_500.getARGB()))
                    .addTextStylizer(createClosingStylizer('(', ')', Theme.GREEN_500.getARGB()))
                    .addTextStylizer(createStylizer(this.alternation, Theme.GREEN_500.getARGB()))
                    .addTextStylizer(createStylizer(DevConfig.Packs.getRegexPrefixPattern(), Theme.GRAY_500.getARGB()))
                    .build();
            FidgetzText<Void> name = FidgetzText.<Void>builder()
                    .setMessage(editAction.ctx().pack().method_14457())
                    .setOffsetY(1)
                    .build();
            RenderableRectWidget<Void> icon = RenderableRectWidget.<Void>builder(editAction.ctx().sprite())
                    .makeSquare()
                    .build();
            FidgetzButton<Void> closeButton = FidgetzButton.<Void>builder()
                    .makeSquare()
                    .setSprite(GuiConstants.CROSS_SPRITE)
                    .setOnPress(() -> {
                        if (this.aliases != null) {
                            this.onClose.accept(new PackListIntent.CloseAliases(editAction.target(), editAction.ctx(), this.aliases.extractItems()));
                        }
                    })
                    .build();

            final FlexLayout titleLayout = FlexLayout.horizontal(this.aliases::method_25368).spacing(GuiConstants.SPACING);
            titleLayout.addChild(renderableAdder.apply(icon));
            titleLayout.addFlexChild(renderableAdder.apply(name));
            titleLayout.addChild(widgetAdder.apply(closeButton));

            this.layout = class_8667.method_52741().method_52735(GuiConstants.SPACING);
            this.layout.method_52736(titleLayout);
            this.layout.method_52736(widgetAdder.apply(this.aliases));
        }

        @Override
        public void method_46421(int x) {
            this.layout.method_46421(x);
        }

        @Override
        public void method_46419(int y) {
            this.layout.method_46419(y);
        }

        @Override
        public int method_46426() {
            return this.layout.method_46426();
        }

        @Override
        public int method_46427() {
            return this.layout.method_46427();
        }

        @Override
        public int method_25368() {
            return this.layout.method_25368();
        }

        @Override
        public int method_25364() {
            return this.layout.method_25364();
        }

        @Override
        public void method_48227(@NonNull Consumer<class_8021> visitor) {
            this.layout.method_48227(visitor);
        }

        @Override
        public void method_48222() {
            this.layout.method_48222();
        }

        private static TextStylizer createStylizer(Pattern pattern, int color) {
            return new PatternStylizer(DevConfig.Packs::isRegexPrefixed, pattern, color);
        }

        private static TextStylizer createClosingStylizer(char open, char close, int color) {
            return new GroupCloseStylizer(DevConfig.Packs::isRegexPrefixed, open, close, color);
        }
    }
}
