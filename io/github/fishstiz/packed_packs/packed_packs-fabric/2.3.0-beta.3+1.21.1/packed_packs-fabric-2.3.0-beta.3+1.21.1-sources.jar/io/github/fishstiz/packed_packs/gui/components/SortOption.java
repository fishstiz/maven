package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.packed_packs.pack.PackNode;
import io.github.fishstiz.packed_packs.util.GuiUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.SequencedCollection;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5244;

public interface SortOption {
    String name();

    class_2960 icon();

    class_2561 text();

    default @Nullable Comparator<PackNode> comparator(SequencedCollection<PackNode> packs) {
        return null;
    }

    default boolean canSort() {
        return true;
    }

    record Locked(@Nullable SortOption sort) implements SortOption {
        @Override
        public String name() {
            return "LOCKED";
        }

        @Override
        public class_2960 icon() {
            return GuiUtils.LOCK_SPRITE_SMALL;
        }

        @Override
        public class_2561 text() {
            return class_5244.field_39003;
        }

        @Override
        public boolean canSort() {
            return false;
        }
    }
}
