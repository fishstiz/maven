package io.github.fishstiz.packed_packs.impl;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import net.minecraft.class_2561;

public class TestImpl implements PackedPacksInitializer {
    @Override
    public void onInitialize(PackedPacksApi api) {
        api.eventBus().register(ContextMenuEvent.Screen.class, ResourceUtil.id("test"), event -> {
            event.addItem(item -> item.setLabel(class_2561.method_43470("SEPARATOR TESTS")).addSeparatorAbove().applyDevStyle());

            event.addItem(item -> item.setLabel(class_2561.method_43470("SEP BELOW")).addSeparatorBelow());
            event.addItem(item -> item.setLabel(class_2561.method_43470("SEP ABOVE")));
            event.addItem(item -> item.setLabel(class_2561.method_43470("NO SEP")));
            event.addItem(item -> item.setLabel(class_2561.method_43470("SEP BELOW")));
            event.addItem(item -> item.setLabel(class_2561.method_43470("SEP ABOVE AND BELOW")).addSeparatorAbove().addSeparatorBelow());

            event.addItem(item -> item.setLabel(class_2561.method_43470("SEP ABOVE PARENT"))
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEP BELOW")).addSeparatorBelow())
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEP ABOVE")))
                    .addChild(child -> child.setLabel(class_2561.method_43470("NO SEP")))
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEB BELOW")).addSeparatorBelow())
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEP ABOVE AND BELOW")).addSeparatorBelow().addSeparatorAbove())
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEP ABOVE")).addSeparatorAbove())
                    .addChild(child -> child.setLabel(class_2561.method_43470("NO SEP")))
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEP BELOW")))
                    .addChild(child -> child.setLabel(class_2561.method_43470("SEB ABOVE")).addSeparatorAbove()));
        });
    }
}
