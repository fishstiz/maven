package io.github.fishstiz.packed_packs.gui.screens;

import io.github.fishstiz.fidgetz.v0.utils.GuiHooks;
import io.github.fishstiz.packed_packs.PackedPacks;
import io.github.fishstiz.packed_packs.platform.Services;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_437;

public class PackedPacksScreenPreloader implements class_4068 {
    private static boolean preloaded;
    private final class_310 minecraft;
    private final class_437 screen;
    private final class_339 widget;

    private PackedPacksScreenPreloader(class_310 minecraft, class_437 screen, class_339 widget) {
        this.minecraft = minecraft;
        this.screen = screen;
        this.widget = widget;
    }

    public static void attach(class_437 screen, class_339 widget) {
        if (!preloaded) {
            GuiHooks.modifyRenderables(screen, renderables -> {
                renderables.add(new PackedPacksScreenPreloader(class_310.method_1551(), screen, widget));
                return renderables;
            });
        }
    }

    private void detach() {
        GuiHooks.modifyRenderables(screen, renderables -> {
            renderables.remove(this);
            return renderables;
        });
    }

    private void preload() {
        if (preloaded) return;

        CompletableFuture.runAsync(() -> {
            long start = 0;
            boolean debug = System.getProperty("packed_packs.debug") != null;

            if (debug) {
                start = System.nanoTime();
                PackedPacks.LOGGER.info("[packed_packs] ======== Preloading PackedPacksScreen ========");
            }

            PackedPacksScreen.preload(minecraft);

            if (debug) {
                long duration = (System.nanoTime() - start) / 1_000_000;
                PackedPacks.LOGGER.info("[packed_packs] ======== Preloaded PackedPacksScreen in {}ms ========", duration);
            }
        }, class_156.method_18349()).thenRunAsync(() -> {
            if (minecraft.field_1755 == screen) {
                detach();
            }
        }, minecraft);

        preloaded = true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (!preloaded && widget.method_25367()) {
            preload();
        }
    }
}
