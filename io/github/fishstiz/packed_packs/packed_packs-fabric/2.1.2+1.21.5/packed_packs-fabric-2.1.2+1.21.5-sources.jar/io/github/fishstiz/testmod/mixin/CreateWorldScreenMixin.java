package io.github.fishstiz.testmod.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.fishstiz.testmod.pack.TestPackRegistry;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import net.minecraft.class_525;
import org.apache.commons.lang3.ArrayUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_525.class)
public abstract class CreateWorldScreenMixin {
    @WrapOperation(method = "openFresh", at = @At(
            value = "NEW",
            target = "([Lnet/minecraft/server/packs/repository/RepositorySource;)Lnet/minecraft/server/packs/repository/PackRepository;"
    ))
    private static class_3283 addTestPacks(class_3285[] sources, Operation<class_3283> original) {
        return original.call((Object) ArrayUtils.add(sources, TestPackRegistry.asRepositorySource()));
    }
}
