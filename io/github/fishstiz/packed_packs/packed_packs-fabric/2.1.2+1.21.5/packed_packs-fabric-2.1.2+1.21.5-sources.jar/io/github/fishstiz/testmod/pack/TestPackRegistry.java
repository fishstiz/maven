package io.github.fishstiz.testmod.pack;

import io.github.fishstiz.testmod.config.Configuration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3285;
import net.minecraft.class_3288;

public final class TestPackRegistry {
    private static final int PACK_COUNT = 200;
    private static final List<class_3288> PACKS;

    static {
        List<class_3288> packs = new ArrayList<>(PACK_COUNT);
        for (int i = 1; i <= PACK_COUNT; i++) {
            String id = id(i);
            boolean compatible = Math.floorMod(id.hashCode(), 20) != 0;
            packs.add(TestPackFactory.createPack(id, title(i), description(i), compatible));
        }
        PACKS = Collections.unmodifiableList(packs);
    }

    public static String id(int number) {
        return String.format("file/test_pack_%03d", number);
    }

    public static class_2561 title(int number) {
        return class_2561.method_43470(String.format("Pack %03d", number));
    }

    public static class_2561 description(int number) {
        return class_2561.method_43470(String.format("Test Pack No. %03d", number)).method_27692(class_124.field_1080);
    }

    public static class_3288 get(int number) {
        if (number < 1 || number > PACK_COUNT) {
            throw new IndexOutOfBoundsException("Pack number must be between 1 and " + PACK_COUNT);
        }
        return PACKS.get(number - 1);
    }

    public static int size() {
        return PACK_COUNT;
    }

    public static class_3285 asRepositorySource() {
        return repository -> {
            if (Configuration.getInstance().shouldAddTestPacks()) {
                for (class_3288 pack : PACKS) {
                    repository.accept(pack);
                }
            }
        };
    }

    private TestPackRegistry() {
    }
}