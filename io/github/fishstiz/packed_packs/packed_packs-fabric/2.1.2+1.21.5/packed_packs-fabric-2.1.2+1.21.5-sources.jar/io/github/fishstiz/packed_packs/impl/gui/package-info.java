@ApiStatus.Internal
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.packed_packs.impl.gui;

import org.jetbrains.annotations.ApiStatus;