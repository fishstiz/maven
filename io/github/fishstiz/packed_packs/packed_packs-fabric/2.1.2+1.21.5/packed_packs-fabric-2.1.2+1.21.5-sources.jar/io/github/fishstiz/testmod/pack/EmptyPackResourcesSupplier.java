package io.github.fishstiz.testmod.pack;

import net.minecraft.class_3262;
import net.minecraft.class_3288;
import net.minecraft.class_9224;

public final class EmptyPackResourcesSupplier implements class_3288.class_7680 {
    @Override
    public class_3262 method_52424(class_9224 location) {
        return new EmptyPackResources(location);
    }

    @Override
    public class_3262 method_52425(class_9224 location, class_3288.class_7679 metadata) {
        return method_52424(location);
    }
}
