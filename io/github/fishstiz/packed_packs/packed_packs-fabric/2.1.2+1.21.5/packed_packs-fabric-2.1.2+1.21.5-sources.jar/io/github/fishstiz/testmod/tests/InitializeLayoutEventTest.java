package io.github.fishstiz.testmod.tests;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.events.InitializeLayoutEvent;
import io.github.fishstiz.testmod.TestFeature;
import io.github.fishstiz.testmod.TestMod;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_339;
import net.minecraft.class_4185;

public final class InitializeLayoutEventTest {
    private InitializeLayoutEventTest() {
    }

    private static class_339 btn(class_2561 message) {
        return class_4185.method_46430(message, btn -> TestMod.LOGGER.info(message.getString())).method_46437(30, 20).method_46431();
    }

    private static void addFeatureButton(String message, TestFeature feature, InitializeLayoutEvent event, InitializeLayoutEvent.Pos pos) {
        class_2561 component = class_2561.method_43470(message);
        class_339 btn = event.screenContext().wrapWidget(feature.preference(), feature.label(), btn(component));
        if (btn != null) event.addWidget(pos, btn);
    }

    public static void initialize(PackedPacksApi api, List<class_2960> dependencies) {
        TestFeature feature = TestFeature.builder(api.preferences(), "init_layout", "Initialize Layout")
                .rebuildOnChange()
                .after(dependencies)
                .register(api.eventBus());

        TestFeature afterTitle = feature.registerSubFeature("after_title", "After Title");
        TestFeature beforeFooter = feature.registerSubFeature("before_footer", "Before Footer");
        TestFeature afterLeftFooter = feature.registerSubFeature("after_left_footer", "After Left Footer");
        TestFeature beforeRightFooter = feature.registerSubFeature("before_right_footer", "Before Right Footer");
        TestFeature betweenRightFooter = feature.registerSubFeature("between_right_footer", "Between Right Footer");
        TestFeature afterFooter = feature.registerSubFeature("after_footer", "After Footer");

        api.eventBus().register(InitializeLayoutEvent.class, feature.id(), dependencies, event -> {
            if (!feature.isEnabled()) return;

            addFeatureButton("AT", afterTitle, event, InitializeLayoutEvent.Pos.AFTER_TITLE);
            addFeatureButton("BF", beforeFooter, event, InitializeLayoutEvent.Pos.BEFORE_FOOTER);
            addFeatureButton("ALF", afterLeftFooter, event, InitializeLayoutEvent.Pos.AFTER_LEFT_FOOTER);
            addFeatureButton("BRF", beforeRightFooter, event, InitializeLayoutEvent.Pos.BEFORE_RIGHT_FOOTER);
            addFeatureButton("BWRF", betweenRightFooter, event, InitializeLayoutEvent.Pos.BETWEEN_RIGHT_FOOTER);
            addFeatureButton("AF", afterFooter, event, InitializeLayoutEvent.Pos.AFTER_FOOTER);
        });

        dependencies.add(feature.id());
    }
}
