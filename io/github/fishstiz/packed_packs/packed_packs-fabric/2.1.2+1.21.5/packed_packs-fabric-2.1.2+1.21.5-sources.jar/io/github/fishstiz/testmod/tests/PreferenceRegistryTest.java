package io.github.fishstiz.testmod.tests;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.events.InitializeLayoutEvent;
import io.github.fishstiz.testmod.TestFeature;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.UnaryOperator;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4264;
import net.minecraft.class_5244;
import net.minecraft.class_6382;

public final class PreferenceRegistryTest {
    private enum OptionKey {
        BOOL, INT, FLOAT, DOUBLE, STRING
    }

    private static class_2960 appendPath(class_2960 parentId, String path) {
        return parentId.method_45134(p -> p + "." + path);
    }

    public static void initialize(PackedPacksApi api, List<class_2960> dependencies) {
        TestFeature feature = TestFeature.builder(api.preferences(), "preference_registry", "Preference Registry")
                .after(dependencies)
                .register(api.eventBus());

        class_2960 visibleOptionId = appendPath(feature.id(), "visible_option");
        Preference<OptionKey> visibleOptions = api.preferences().register(visibleOptionId, OptionKey.class, OptionKey.BOOL);
        Map<OptionKey, Option<?>> optionMap = Map.of(
                OptionKey.BOOL, new Option<>(OptionKey.BOOL, api.preferences().register(appendPath(visibleOptionId, "pref_bool"), true), v -> !v),
                OptionKey.INT, new Option<>(OptionKey.INT, api.preferences().register(appendPath(visibleOptionId, "pref_int"), 0), v -> v + 1),
                OptionKey.FLOAT, new Option<>(OptionKey.FLOAT, api.preferences().register(appendPath(visibleOptionId, "pref_float"), 3.14f), v -> v + 0.1f),
                OptionKey.DOUBLE, new Option<>(OptionKey.DOUBLE, api.preferences().register(appendPath(visibleOptionId, "pref_double"), 1.618), v -> v + 0.1),
                OptionKey.STRING, new Option<>(OptionKey.STRING, api.preferences().register(appendPath(visibleOptionId, "pref_string"), "hello world"), v -> v + "!")
        );

        api.eventBus().register(InitializeLayoutEvent.class, feature.id(), dependencies, event -> {
            if (!feature.isEnabled()) return;

            PreferenceWidget widget = new PreferenceWidget(visibleOptions, optionMap);
            event.addWidget(
                    InitializeLayoutEvent.Pos.AFTER_TITLE,
                    event.screenContext().wrapWithContextMenu(widget, (w, sink) -> {
                        sink.addItem(item -> item
                                .label(class_2561.method_43470("Visible Options"))
                                .applyDevStyle()
                                .separatorAbove()
                                .children(widget.options.values(), (option, child) -> child
                                        .label(class_2561.method_43470(option.optionKey().name()))
                                        .action(() -> w.setVisible(option.optionKey())))
                                .applyDevStyle()
                                .closeOnInteract(false)
                                .child(reset -> reset
                                        .label(class_2561.method_43470("Reset All"))
                                        .action(() -> widget.options.values().forEach(Option::reset))
                                        .closeOnInteract(false)
                                        .applyDevStyle()));
                        sink.addItem(item -> item
                                .label(class_2561.method_43470("Reset Option"))
                                .applyDevStyle()
                                .separatorBelow()
                                .closeOnInteract(false)
                                .action(widget::resetCurrent));
                    })
            );
        });

        dependencies.add(feature.id());
    }

    private record Option<T>(OptionKey optionKey, Preference<T> preference, UnaryOperator<T> cycler) {
        T getValue() {
            return preference.get();
        }

        void cycle() {
            preference.set(cycler.apply(getValue()));
        }

        void reset() {
            preference.reset();
        }
    }

    private static final class PreferenceWidget extends class_4264 {
        private final Preference<OptionKey> visibleOption;
        private final Map<OptionKey, Option<?>> options;

        private PreferenceWidget(Preference<OptionKey> visibleOption, Map<OptionKey, Option<?>> options) {
            super(0, 0, 150, 20, class_5244.field_39003);
            this.visibleOption = visibleOption;
            this.options = options;
            this.updateMessage();
        }

        private Option<?> getCurrent() {
            return Objects.requireNonNull(options.get(visibleOption.get()));
        }

        public void setVisible(OptionKey optionKey) {
            visibleOption.set(optionKey);
            updateMessage();
        }

        public void resetCurrent() {
            getCurrent().reset();
            updateMessage();
        }

        private void updateMessage() {
            Option<?> current = getCurrent();
            method_25355(class_5244.method_32700(
                    class_2561.method_43470(current.optionKey().name()),
                    class_2561.method_43470(String.valueOf(current.getValue()))));
        }

        @Override
        public void method_25306() {
            getCurrent().cycle();
            updateMessage();
        }

        @Override
        protected void method_47399(@NotNull class_6382 narrationElementOutput) {
            method_37021(narrationElementOutput);
        }
    }
}
