package io.github.fishstiz.packed_packs.impl.gui;

import io.github.fishstiz.fidgetz.gui.components.ContainedWidget;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuItemBuilder;
import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuSink;
import java.util.function.BiConsumer;
import net.minecraft.class_339;

public class ContextMenuWrappedWidget<T extends class_339> extends ContainedWidget implements ContextMenuContainer {
    private final BiConsumer<T, ContextMenuSink> configurator;

    public ContextMenuWrappedWidget(T widget, BiConsumer<T, ContextMenuSink> configurator) {
        super(widget);
        this.configurator = configurator;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void buildItems(ContextMenuItemBuilder builder, int mouseX, int mouseY) {
        this.configurator.accept((T) this.widget, itemConfigurator -> {
            ContextMenuItemSpecImpl itemSpec = new ContextMenuItemSpecImpl(false);
            itemConfigurator.accept(itemSpec);
            itemSpec.apply(builder);
        });
        ContextMenuContainer.super.buildItems(builder, mouseX, mouseY);
    }
}
