package io.github.fishstiz.testmod.pack;

import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2561;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7699;
import net.minecraft.class_9224;
import net.minecraft.class_9225;

public final class TestPackFactory {
    public static final class_3288.class_7680 DEFAULT_RESOURCES_SUPPLIER = new EmptyPackResourcesSupplier();
    public static final class_9225 DEFAULT_SELECTION_CONFIG = new class_9225(false, class_3288.class_3289.field_14280, false);

    public static class_9224 createPackLocationInfo(String id, class_2561 title) {
        return new class_9224(id, title, class_5352.field_25347, Optional.empty());
    }

    public static class_3288.class_7679 createPackMetadata(class_2561 description, boolean compatible) {
        class_3281 compatibility;
        if (compatible) {
            compatibility = class_3281.field_14224;
        } else {
            compatibility = ThreadLocalRandom.current().nextBoolean() ? class_3281.field_14223 : class_3281.field_14220;
        }
        return new class_3288.class_7679(description, compatibility, class_7699.method_45397(), Collections.emptyList());
    }

    public static class_3288 createPack(String id, class_2561 title, class_2561 description, boolean compatible) {
        return new class_3288(createPackLocationInfo(id, title), DEFAULT_RESOURCES_SUPPLIER, createPackMetadata(description, compatible), DEFAULT_SELECTION_CONFIG);
    }

    private TestPackFactory() {
    }
}
