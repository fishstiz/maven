package io.github.fishstiz.testmod.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.fishstiz.testmod.pack.TestPackRegistry;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import org.apache.commons.lang3.ArrayUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @WrapOperation(method = "<init>", at = @At(
            value = "NEW",
            target = "([Lnet/minecraft/server/packs/repository/RepositorySource;)Lnet/minecraft/server/packs/repository/PackRepository;")
    )
    private class_3283 addTestPacks(class_3285[] sources, Operation<class_3283> original) {
        return original.call((Object) ArrayUtils.add(sources, TestPackRegistry.asRepositorySource()));
    }
}
