package io.github.fishstiz.testmod.tests;

import io.github.fishstiz.packed_packs.api.Event;
import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuItemSpec;
import io.github.fishstiz.testmod.TestFeature;
import io.github.fishstiz.testmod.TestMod;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class ContextMenuEventTest {
    private ContextMenuEventTest() {
    }

    static class TestEvent extends ContextMenuEvent implements Event {
        private final ContextMenuItemSpec parent;

        public TestEvent(ScreenContext context, ContextMenuItemSpec parent) {
            super(context);
            this.parent = parent;
        }

        @Override
        public void addItem(Consumer<ContextMenuItemSpec> configurator) {
            this.parent.child(configurator);
        }
    }

    public static void initialize(PackedPacksApi api, List<class_2960> dependencies) {
        TestFeature feature = TestFeature.builder(api.preferences(), "context_menu", "Context Menu")
                .after(dependencies)
                .register(api.eventBus());

        TestFeature separators = feature.registerSubFeature("separators", "Separators");
        TestFeature nested = feature.registerSubFeature("nested", "Nested Items");
        TestFeature icons = feature.registerSubFeature("icons", "Icons");
        TestFeature preferences = feature.registerSubFeature("preferences", "Preferences");
        TestFeature packEntry = feature.registerSubFeature("pack_entry", "Pack Entry");


        api.eventBus().register(ContextMenuEvent.Screen.class, feature.id(), dependencies, event -> {
            if (!feature.isEnabled()) return;

            event.addItem(item -> {
                item.label(class_2561.method_43470("Context Menu Tests")).applyDevStyle().separatorAbove();
                api.eventBus().post(new TestEvent(event.screenContext(), item));
            });
        });

        api.eventBus().register(TestEvent.class, separators.id(), event -> {
            if (!separators.isEnabled()) return;

            event.addItem(item -> item.label(class_2561.method_43470("BEGIN SEPARATORS")).separatorAbove().applyDevStyle());

            event.addItem(item -> item.label(class_2561.method_43470("SEP BELOW")).separatorBelow());
            event.addItem(item -> item.label(class_2561.method_43470("SEP ABOVE")));
            event.addItem(item -> item.label(class_2561.method_43470("NO SEP")));
            event.addItem(item -> item.label(class_2561.method_43470("SEP BELOW")));
            event.addItem(item -> item.label(class_2561.method_43470("SEP ABOVE AND BELOW")).separatorAbove().separatorBelow());

            event.addItem(item -> item.label(class_2561.method_43470("SEP ABOVE PARENT"))
                    .child(child -> child.label(class_2561.method_43470("SEP BELOW")).separatorBelow())
                    .child(child -> child.label(class_2561.method_43470("SEP ABOVE")))
                    .child(child -> child.label(class_2561.method_43470("NO SEP")))
                    .child(child -> child.label(class_2561.method_43470("SEB BELOW")).separatorBelow())
                    .child(child -> child.label(class_2561.method_43470("SEP ABOVE AND BELOW")).separatorBelow().separatorAbove())
                    .child(child -> child.label(class_2561.method_43470("SEP ABOVE")).separatorAbove())
                    .child(child -> child.label(class_2561.method_43470("NO SEP")))
                    .child(child -> child.label(class_2561.method_43470("SEP BELOW")))
                    .child(child -> child.label(class_2561.method_43470("SEB ABOVE")).separatorAbove()));

            event.addItem(item -> item.label(class_2561.method_43470("END SEPARATORS")).separatorAbove().applyDevStyle());
        });

        api.eventBus().register(TestEvent.class, nested.id(), event -> {
            if (!nested.isEnabled()) return;

            event.addItem(item -> item.label(class_2561.method_43470("BEGIN NESTED")).separatorAbove().applyDevStyle());
            event.addItem(item -> item
                    .label(class_2561.method_43470("GRANDPARENT"))
                    .child(parent -> parent
                            .label(class_2561.method_43470("PARENT 1"))
                            .child(child -> child.label(class_2561.method_43470("CHILD 1")))
                            .child(child -> child.label(class_2561.method_43470("CHILD 2"))))
                    .child(parent -> parent
                            .label(class_2561.method_43470("PARENT 2"))
                            .child(child -> child.label(class_2561.method_43470("CHILD 1")))));
            event.addItem(item -> item.label(class_2561.method_43470("SUPER LONG NAME CONTEXT MENU ITEM PARENT"))
                    .child(child -> child.label(class_2561.method_43470("SUPER LONG NAME CONTEXT MENU ITEM NODE"))));

            event.addItem(item -> item.label(class_2561.method_43470("END NESTED")).separatorAbove().applyDevStyle());
        });

        api.eventBus().register(TestEvent.class, icons.id(), event -> {
            if (!icons.isEnabled()) return;

            event.addItem(item -> item.label(class_2561.method_43470("BEGIN ICONS")).separatorAbove().applyDevStyle());
            event.addItem(item -> item.label(class_2561.method_43470("ICON: LANGUAGE"))
                    .icon(class_2960.method_60656("icon/language")));
            event.addItem(item -> item.label(class_2561.method_43470("ICON: ACCESSIBILITY"))
                    .icon(class_2960.method_60656("icon/accessibility")));
            event.addItem(item -> item.label(class_2561.method_43470("ICON WITH CHILD"))
                    .icon(class_2960.method_60656("icon/language"))
                    .child(child -> child.label(class_2561.method_43470("CHILD WITH ICON"))
                            .icon(class_2960.method_60656("icon/accessibility"))));
            event.addItem(item -> item.label(class_2561.method_43470("END ICONS")).separatorAbove().applyDevStyle());
        });

        Preference<Boolean> boolPref = api.preferences().register(TestMod.id("context_menu_bool_pref"), true);
        Preference<Boolean> boolPref2 = api.preferences().register(TestMod.id("context_menu_bool_pref_2"), false);
        api.eventBus().register(ContextMenuEvent.Preferences.class, preferences.id(), dependencies, event -> {
            if (!preferences.isEnabled()) return;

            event.addToggle(boolPref, class_2561.method_43470("BOOL PREF 1"));
            event.addToggle(ContextMenuEvent.Preferences.Pos.TOP, boolPref2, class_2561.method_43470("BOOL PREF 2 (TOP)"));
            event.addItem(item -> event.applyToggle(item, boolPref)
                    .label(class_2561.method_43470("APPLY TOGGLE ON CHILD PARENT"))
                    .child(child -> event.applyToggle(child, boolPref2)
                            .label(class_2561.method_43470("APPLY TOGGLE ON CHILD"))));
        });

        api.eventBus().register(ContextMenuEvent.PackEntry.class, packEntry.id(), dependencies, event -> {
            if (!packEntry.isEnabled()) return;

            event.addItem(ContextMenuEvent.PackEntry.Pos.BEFORE_HEADER, item -> item
                    .label(class_2561.method_43470("BEFORE HEADER")));
            event.addItem(ContextMenuEvent.PackEntry.Pos.AFTER_HEADER, item -> item
                    .label(class_2561.method_43470("AFTER HEADER")));
            event.addItem(ContextMenuEvent.PackEntry.Pos.AFTER_DEV, item -> item
                    .label(class_2561.method_43470("AFTER DEV"))
                    .applyDevStyle());
            event.addItem(ContextMenuEvent.PackEntry.Pos.AFTER_PACK, item -> item
                    .label(class_2561.method_43470("AFTER PACK"))
                    .child(child -> child.label(class_2561.method_43470("CHILD"))));
        });

        dependencies.add(feature.id());
        dependencies.add(preferences.id());
        dependencies.add(packEntry.id());
    }
}
