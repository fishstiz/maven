package io.github.fishstiz.testmod.gui;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_4068;

public class TestFeatureRendererCoordinator implements class_4068 {
    private final List<TestFeatureRenderer> renderers = new ArrayList<>();

    public TestFeatureRendererCoordinator add(TestFeatureRenderer renderer) {
        renderers.add(renderer);
        return this;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int y = 0;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 1000);

        for (TestFeatureRenderer renderer : renderers) {
            y = renderer.render(guiGraphics, mouseX, mouseY, y, partialTick);
        }

        guiGraphics.method_51448().method_22909();
    }
}
