package io.github.fishstiz.testmod.gui;

import io.github.fishstiz.testmod.TestFeature;
import net.minecraft.class_332;

public abstract class TestFeatureRenderer {
    private final TestFeature feature;

    TestFeatureRenderer(TestFeature feature) {
        this.feature = feature;
    }

    protected abstract int renderFeature(class_332 guiGraphics, int mouseX, int mouseY, int y, float partialTick);

    public final int render(class_332 guiGraphics, int mouseX, int mouseY, int y, float partialTick) {
        if (feature.isEnabled()) {
            return renderFeature(guiGraphics, mouseX, mouseY, y, partialTick);
        }
        return y;
    }
}
