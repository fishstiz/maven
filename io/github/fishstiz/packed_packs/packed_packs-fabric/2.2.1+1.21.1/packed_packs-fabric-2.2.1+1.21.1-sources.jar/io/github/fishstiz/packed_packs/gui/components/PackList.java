package io.github.fishstiz.packed_packs.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.CollectionUtils;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.events.ContextMenuEvent;
import io.github.fishstiz.packed_packs.api.events.InitializePackEntryEvent;
import io.github.fishstiz.packed_packs.api.gui.ElementSink;
import io.github.fishstiz.packed_packs.compat.minecraftcursor.MinecraftCursor;
import io.github.fishstiz.packed_packs.config.Preferences;
import io.github.fishstiz.packed_packs.gui.FocusPathProvider;
import io.github.fishstiz.packed_packs.gui.FocusTarget;
import io.github.fishstiz.packed_packs.gui.model.PackListKey;
import io.github.fishstiz.packed_packs.gui.model.PackListUtils;
import io.github.fishstiz.packed_packs.gui.model.PackListViewModel;
import io.github.fishstiz.packed_packs.gui.states.ActiveAction;
import io.github.fishstiz.packed_packs.impl.PackedPacksApiImpl;
import io.github.fishstiz.packed_packs.impl.events.ContextMenuEventImpl;
import io.github.fishstiz.packed_packs.pack.folder.FolderPack;
import io.github.fishstiz.packed_packs.util.PackUtil;
import io.github.fishstiz.packed_packs.util.Colors;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_2960;
import net.minecraft.class_3288;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8028;

import static io.github.fishstiz.packed_packs.util.InputUtil.*;
import static io.github.fishstiz.packed_packs.util.GuiUtils.*;

public class PackList extends FZAbstractListWidget<PackList.Entry> implements FocusPathProvider, ContainerEventHandlerPatch {
    private static final int INNER_ITEM_PADDING = 2;
    private static final int INNER_ITEM_HEIGHT = 32;
    private static final int ITEM_HEIGHT = INNER_ITEM_HEIGHT + INNER_ITEM_PADDING * 2;
    private static final int DROP_INDEX_PADDING = 3;
    private static final double SCROLL_RATE = (double) ITEM_HEIGHT / 2;
    private final ScreenContext screenContext;
    private final PackListViewModel listModel;
    private int dropColor;
    private int dropRectColor;
    private int scrollColorFrom;
    private int scrollColorTo;
    private boolean scrolling;
    private boolean initialized;

    public PackList(ScreenContext screenContext, PackListViewModel listModel) {
        this.screenContext = screenContext;
        this.listModel = listModel;
        this.applyTheme();
        this.listModel.subscribe(PackListViewModel.Property.PACKS, this::refreshEntries);
    }

    public PackListKey key() {
        return listModel.key();
    }

    @Override
    protected int maxContentWidth() {
        return 0;
    }

    @Override
    protected int rowSpacing() {
        return -1;
    }

    @Override
    public double scrollRate() {
        return SCROLL_RATE;
    }

    private void applyTheme() {
        if (listModel.supportsReordering()) {
            this.dropColor = Colors.GREEN_500;
            this.scrollColorFrom = Colors.alpha(dropColor, 0.75f);
            this.scrollColorTo = Colors.alpha(dropColor, 0);
        } else {
            this.dropColor = Colors.RED_700;
            this.dropRectColor = Colors.alpha(Colors.RED_700, 0.25f);
        }
    }

    void initializeEntries() {
        if (!this.initialized) {
            refreshEntries();
            this.initialized = true;
        }
    }

    private void refreshEntries() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry previousFocused = this.method_25399();
        double previousScrollAmount = scrollAmount();
        clearEntries();
        listModel.forEachEntry((entry, i) -> {
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry listEntry = new io.github.fishstiz.packed_packs.gui.components.PackList.Entry(entry, i);
            addEntry(listEntry);
            if (previousFocused != null && previousFocused.pack().equals(entry.pack())) {
                method_25395(listEntry);
            }
        });
        repositionEntries();
        setScrollAmount(previousScrollAmount);
    }

    public void scrollToTop() {
        this.setScrollAmount(0);
    }

    public void scrollToLastSelected() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry selected = getSelected();
        if (selected != null) scrollToEntry(selected);
    }

    private int getDropIndex(double mouseY) {
        if (method_25396().isEmpty()) return -1;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = getHovered();
        if (entry == null) return -1;

        int index = entry.index;

        int centerY = entry.method_46427() + (entry.method_25364() / 2);
        if (mouseY >= centerY) {
            int next = index + 1;
            return next < method_25396().size() ? next : -1;
        }

        return index;
    }

    private boolean isMouseOverSelectionEntry(SequencedCollection<class_3288> selection, double mouseX, double mouseY, int index) {
        if (index < 0 || index >= method_25396().size()) return false;
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = method_25396().get(index);
        return entry.method_25405(mouseX, mouseY) && selection.contains(entry.pack());
    }

    private boolean isMouseOverSelection(SequencedCollection<class_3288> selection, double mouseX, double mouseY, int index) {
        return isMouseOverSelectionEntry(selection, mouseX, mouseY, index - 1) || isMouseOverSelectionEntry(selection, mouseX, mouseY, index);
    }

    private boolean canDropAt(ActiveAction.Dragging dragging, int mouseX, int mouseY, int index) {
        if (this.scrolling || (dragging.target() == key() && isMouseOverSelection(dragging.payload(), mouseX, mouseY, index))) {
            return false;
        }
        return listModel.canDrop(dragging.target(), dragging.ctx().pack(), dragging.payload(), index);
    }

    private void renderDroppableSlots(class_332 graphics, ActiveAction.Dragging dragging, int mouseX, int mouseY, float partialTick) {
        int x = method_46426();
        int y = method_46427();
        int width = scrollbarVisible() ? method_25368() - scrollbarWidth() : method_25368();
        int height = method_25364();
        int bottom = method_55443();

        if (method_49606()) {
            double scrollAmount = scrollAmount();

            int scrollDownY = bottom - INNER_ITEM_HEIGHT;
            if (scrollAmount < maxScrollAmount() && mouseY >= scrollDownY) {
                graphics.method_25296(x, scrollDownY, x + width, scrollDownY + INNER_ITEM_HEIGHT, scrollColorTo, scrollColorFrom);
                scroll(scrollRate() * partialTick);
                this.scrolling = true;
            } else if (scrollAmount > 0 && mouseY <= y + INNER_ITEM_HEIGHT) {
                graphics.method_25296(x, y, x + width, y + INNER_ITEM_HEIGHT, scrollColorFrom, scrollColorTo);
                scroll(-(scrollRate() * partialTick));
                this.scrolling = true;
            } else {
                this.scrolling = false;
            }

            int index = getDropIndex(mouseY);
            if (canDropAt(dragging, mouseX, mouseY, index)) {
                int rowTop;
                if (index != -1) {
                    rowTop = method_25396().get(index).method_46427();
                } else {
                    io.github.fishstiz.packed_packs.gui.components.PackList.Entry last = method_25396().isEmpty() ? null : method_25396().getLast();
                    rowTop = last == null ? method_55443() : last.method_46427() + last.method_25364();
                }

                rowTop = Math.clamp(rowTop, method_46427() + DROP_INDEX_PADDING, method_55443() - DROP_INDEX_PADDING);
                int indexY = rowTop - DROP_INDEX_PADDING;

                graphics.method_44379(method_46426(), method_46427(), method_55442(), method_55443());
                graphics.method_25294(x, indexY, x + width, indexY + (rowTop - indexY + DROP_INDEX_PADDING), dropColor);
                graphics.method_44380();
            }
        }

        graphics.method_49601(x, y, width, height, dropColor);
    }

    private void renderDroppableRect(class_332 graphics, ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        if (canDropAt(dragging, mouseX, mouseY, 0)) {
            if (method_49606()) {
                graphics.method_25294(method_46426(), method_46427(), method_55442(), method_55443(), dropRectColor);
            }
            graphics.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), dropColor);
        }
    }

    public void renderDroppableZone(class_332 guiGraphics, ActiveAction.Dragging dragging, int mouseX, int mouseY, float partialTick) {
        if (!listModel.locked() && PackListUtils.canInteract(dragging.target(), key())) {
            if (listModel.supportsReordering()) {
                renderDroppableSlots(guiGraphics, dragging, mouseX, mouseY, partialTick);
            } else {
                renderDroppableRect(guiGraphics, dragging, mouseX, mouseY);
            }
        }
    }

    public void onDrop(ActiveAction.Dragging dragging, int mouseX, int mouseY) {
        int index = getDropIndex(mouseY);
        if (canDropAt(dragging, mouseX, mouseY, index)) {
            listModel.applyDrop(dragging.target(), dragging.ctx(), dragging.payload(), index);
        } else {
            listModel.cancelDrop(dragging.target(), dragging.ctx(), dragging.payload());
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry previous = method_25399();
        if (previous != focused) {
            super.method_25395(focused);
            if (previous != null && previous.packWidget != null) {
                previous.packWidget.checkCompatibility(false);
            }
            if (focused instanceof io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry && entry.packWidget != null) {
                entry.packWidget.checkCompatibility(true);
            }
        }
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getSelected() {
        for (io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry : method_25396()) {
            if (entry.entryModel.selectedLast()) {
                return entry;
            }
        }
        return null;
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getFocusedOrSelected() {
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry focused = method_25399();
        return focused == null ? getSelected() : focused;
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getEntry(String packId) {
        for (io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry : this.method_25396()) {
            if (entry.pack().method_14463().equals(packId)) {
                return entry;
            }
        }
        return null;
    }

    private @Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry getNextEntryAt(class_8028 direction) {
        if (method_25396().isEmpty()) return null;
        io.github.fishstiz.packed_packs.gui.components.PackList.Entry selectedEntry = getFocusedOrSelected();
        return switch (direction) {
            case field_41826 -> Objects.equals(selectedEntry, method_25396().getFirst())
                    ? selectedEntry
                    : getPreviousEntry(selectedEntry);
            case field_41827 -> Objects.equals(selectedEntry, method_25396().getLast())
                    ? selectedEntry
                    : getNextEntry(selectedEntry);
            case field_41828 -> key().type().available() ? selectedEntry : null;
            case field_41829 -> key().type().enabled() ? selectedEntry : null;
        };
    }

    @Override
    public @Nullable class_8016 getFocusPath(FocusTarget target) {
        if (this.method_25396().isEmpty()) return null;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry targetEntry = switch (target) {
            case FocusTarget.LastSelected ignored -> getSelected();
            case FocusTarget.PackEntry entry -> getEntry(entry.packId());
        };

        return targetEntry == null ? null : new ListPath(this, targetEntry, target.scroll(), false);
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        if (method_25396().isEmpty()) return null;

        io.github.fishstiz.packed_packs.gui.components.PackList.Entry next = switch (event) {
            case class_8023.class_8025 ignored -> getFocusedOrSelected();
            case class_8023.class_8026 ignored -> method_25370()
                    ? null
                    : Objects.requireNonNullElse(getSelected(), method_25396().getFirst());
            case class_8023.class_8024(class_8028 direction) -> method_25370()
                    ? getNextEntryAt(direction)
                    : Objects.requireNonNullElse(getSelected(), method_25396().getFirst());
            default -> null;
        };

        return next == null ? null : ListPath.path(this, next);
    }

    record ListPath(PackList component, io.github.fishstiz.packed_packs.gui.components.PackList.Entry child, boolean scroll, boolean select) implements class_8016 {
        static ListPath path(PackList component, io.github.fishstiz.packed_packs.gui.components.PackList.Entry child) {
            return new ListPath(component, child, true, true);
        }

        @Override
        public void method_48195(boolean focused) {
            this.child.method_25365(focused);
            if (!focused) {
                this.component.method_25395(null);
                return;
            }
            this.component.method_25395(this.child);
            if (this.scroll) {
                this.component.scrollToEntry(this.child);
            }
            if (this.select && !this.child.entryModel.selectedLast()) {
                this.child.entryModel.select();
            }
        }
    }

    private void selectOnKeyPress(@Nullable io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry) {
        if (entry == null) return;
        if (isRangeModifierActive()) {
            entry.entryModel.selectRange();
        } else {
            entry.entryModel.selectExclusive();
        }
        method_25395(entry);
        scrollToEntry(entry);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (isSelectAll(keyCode, modifiers)) {
            listModel.selectAll();
            return true;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (isUp(keyCode) || isDown(keyCode)) {
            selectOnKeyPress(getNextEntryAt(isUp(keyCode) ? class_8028.field_41826 : class_8028.field_41827));
            return true;
        }
        if (isHome(keyCode) || isEnd(keyCode)) {
            if (method_25396().isEmpty()) return true;
            selectOnKeyPress(isHome(keyCode) ? method_25396().getFirst() : method_25396().getLast());
            return true;
        }
        if (isPageUp(keyCode) || isPageDown(keyCode)) {
            if (method_25396().isEmpty()) return true;
            int pageSize = Math.max(1, method_25364() / ITEM_HEIGHT);
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry selected = getFocusedOrSelected();
            int currentIndex = selected != null ? method_25396().indexOf(selected) : 0;
            int targetIndex = isPageUp(keyCode)
                    ? Math.max(0, currentIndex - pageSize)
                    : Math.min(method_25396().size() - 1, currentIndex + pageSize);
            io.github.fishstiz.packed_packs.gui.components.PackList.Entry entry = method_25396().get(targetIndex);
            selectOnKeyPress(entry);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean scrolling = updateScrolling(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button) || scrolling;
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (!listModel.isFolderOpened()) {
            super.extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
        }
    }

    public class Entry extends FZAbstractListWidget.Entry implements SelectableEntry, ContainerEventHandlerPatch, FZContextMenu.Source, ElementSink {
        private static final int ICON_SIZE = 32;
        private static final class_7919 FOLDER_OPEN_INFO = class_7919.method_47407(FolderPack.FOLDER_OPEN_TEXT);
        private static final RenderableRectangle SELECTED_OVERLAY = Renderables.fill(Colors.alpha(Colors.BLUE_500, 0.25f));
        private static final WidgetRenderables SELECT_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/select")),
                Renderables.sprite(class_2960.method_60656("transferable_list/select_highlighted"))
        );
        private static final WidgetRenderables UNSELECT_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/unselect")),
                Renderables.sprite(class_2960.method_60656("transferable_list/unselect_highlighted"))
        );
        private static final WidgetRenderables MOVE_UP_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/move_up")),
                Renderables.sprite(class_2960.method_60656("transferable_list/move_up_highlighted"))
        );
        private static final WidgetRenderables MOVE_DOWN_SPRITES = new WidgetRenderables(
                Renderables.sprite(class_2960.method_60656("transferable_list/move_down")),
                Renderables.sprite(class_2960.method_60656("transferable_list/move_down_highlighted"))
        );
        private final int index;
        private final PackListViewModel.Entry entryModel;
        private final MouseStateHandler mouseStateHandler;
        private final List<class_364> children = new ObjectArrayList<>();
        private final List<class_4068> renderables = new ObjectArrayList<>();
        private List<class_8021> rightElements = Collections.emptyList();
        private @Nullable PackWidget packWidget;
        private @Nullable class_339 folderWidget;
        private @Nullable PackListDevMenu devMenu;
        private boolean initialized;

        Entry(PackListViewModel.Entry entryModel, int index) {
            super(ITEM_HEIGHT);
            this.index = index;
            this.entryModel = entryModel;
            this.mouseStateHandler = new MouseStateHandler(this, entryModel);
        }

        private void init() {
            if (this.initialized) return;

            this.packWidget = new PackWidget(entryModel, INNER_ITEM_HEIGHT);
            repositionPackWidget();

            entryModel.folder().flatMap(ignored -> PreferenceHelper.wrap(Preferences.FOLDER_PACK_WIDGET, FZIconButton.builder()
                            .size(INNER_ITEM_HEIGHT / 3, INNER_ITEM_HEIGHT / 3)
                            .icon(new WidgetElements(HAMBURGER_RECT, 8, 8))
                            .tooltip(FOLDER_OPEN_INFO)
                            .focusOnInteraction(false)
                            .onPress(entryModel::openFolder)
                            .build()))
                    .ifPresent(widget -> {
                        int x = method_46426() + PackWidget.ICON_SIZE + INNER_ITEM_PADDING * 2;
                        int y = method_46427() + method_25364() - widget.method_25364() - INNER_ITEM_PADDING;
                        widget.method_48229(x, y);
                        acceptWidget(widget);
                        acceptRenderable(widget);
                        this.folderWidget = widget;
                    });

            this.devMenu = screenContext.devMode() ? entryModel.createDevMenu() : null;

            this.initialized = true;

            InitializePackEntryEvent event = new InitializePackEntryEvent(screenContext, entryModel, packWidget, this);
            PackedPacksApiImpl.getInstance().eventBus().post(event);
        }

        public class_3288 pack() {
            return entryModel.pack();
        }

        @Override
        public int getIndex() {
            return index;
        }

        @Override
        public void acceptWidget(class_364 widget) {
            if (widget instanceof FZHoverableElement hoverable && widget instanceof class_339 abstractWidget) {
                hoverable.fidgetz$setHovered(abstractWidget.method_49606());
            }
            children.addFirst(widget);
        }

        @Override
        public void acceptRenderable(class_4068 renderable) {
            renderables.add(renderable);
        }

        @Override
        public void acceptElement(class_8021 element) {
            this.rightElements = CollectionUtils.addLast(rightElements, element);
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);
            if (!focused && method_25399() != null) {
                method_25399().method_25365(false);
            }
        }

        private boolean isFocusedOrSelected() {
            return PackList.this.method_25399() == null ? entryModel.selectedLast() : method_25370();
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (super.method_25402(mouseX, mouseY, button) || isRightClick(button)) {
                if (!listModel.isFolderOpened()) return true;
                // ideally folderWidget should return false on #shouldTakeFocusAfterInteraction,
                // #shouldTakeFocusAfterInteraction also does not bubble up,
                // we want to return false regardless so that the folder can be focused
                this.method_25395(null);
                return false;
            }

            if (isLeftClick(button) && fidgetz$getHovered() == null) {
                int relativeX = (int) mouseX - (method_46426() + INNER_ITEM_PADDING);
                int relativeY = (int) mouseY - (method_46427() + INNER_ITEM_PADDING);

                if (entryModel.canEnable() && mouseOverIcon(relativeX, relativeY, ICON_SIZE)) {
                    entryModel.enable();
                    return false;
                }
                if (entryModel.canDisable() && mouseOverLeftHalf(relativeX, relativeY, ICON_SIZE)) {
                    entryModel.disable();
                    return false;
                }
                if (entryModel.canMoveUp() && mouseOverTopRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    entryModel.moveUp();
                    return false;
                }
                if (entryModel.canMoveDown() && mouseOverBottomRightQuarter(relativeX, relativeY, ICON_SIZE)) {
                    this.entryModel.moveDown();
                    return false;
                }
            }

            return mouseStateHandler.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return mouseStateHandler.mouseReleased(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            return mouseStateHandler.mouseDragged(mouseX, mouseY, button, dragX, dragY);
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (super.method_25404(keyCode, scanCode, modifiers)) {
                return true;
            }
            if (isExpandFolder(keyCode, modifiers) && entryModel.folder().isPresent() && entryModel.selectedExclusive()) {
                entryModel.openFolder();
                return true;
            }
            if (isTransfer(keyCode, modifiers) && listModel.supportsTransferring()) {
                entryModel.transfer();
                return true;
            }
            if (isMoveDown(keyCode, modifiers) && listModel.supportsReordering()) {
                entryModel.moveDown();
                return true;
            }
            if (isMoveUp(keyCode, modifiers) && listModel.supportsReordering()) {
                entryModel.moveUp();
                return true;
            }
            if (isOpenFile(keyCode, modifiers)) {
                PackUtil.openPack(pack());
                return true;
            }
            if (isOpenFolder(keyCode, modifiers)) {
                PackUtil.openParent(pack());
                return true;
            }
            if (isDelete(keyCode, modifiers) && entryModel.fileModifiable()) {
                entryModel.delete();
                return true;
            }
            if (isRename(keyCode, modifiers) && entryModel.fileModifiable()) {
                entryModel.openRename();
                return true;
            }
            return false;
        }

        public void renderBack(class_332 graphics, int top, int left, int width, int height) {
            if (!pack().method_14460().method_14437() && !entryModel.incompatibleWarningsHidden()) {
                int margin = INNER_ITEM_PADDING / 2;
                int backgroundLeft = left + margin;
                int backgroundTop = top + margin;
                int backgroundRight = (left + width) - margin;
                int backgroundBottom = (top + height) - margin;
                graphics.method_25294(backgroundLeft, backgroundTop, backgroundRight, backgroundBottom, Colors.RED_900);
            }
        }

        private void renderWidgetSprites(class_332 graphics, WidgetRenderables sprites, int left, int top, boolean hovered) {
            RenderableRectangle sprite = hovered ? sprites.enabledFocused() : sprites.enabled();
            sprite.extractRenderState(graphics, left, top, ICON_SIZE, ICON_SIZE, 0, 0, 0);
            if (hovered) {
                MinecraftCursor.get().setPointingHand();
            }
        }

        private void renderWidgetSprites(class_332 graphics, int top, int left, int mouseX, int mouseY) {
            boolean hovered = isHovered() && fidgetz$getHovered() == null;
            if (!hovered && !this.entryModel.selectedLast()) return;

            int relX = mouseX - left;
            int relY = mouseY - top;

            WHITE_OVERLAY.extractRenderState(graphics, left, top, ICON_SIZE, ICON_SIZE, 0, 0, 0);

            if (entryModel.canEnable()) {
                renderWidgetSprites(graphics, SELECT_SPRITES, left, top, hovered && mouseOverIcon(relX, relY, ICON_SIZE));
            }
            if (entryModel.canDisable()) {
                renderWidgetSprites(graphics, UNSELECT_SPRITES, left, top, hovered && mouseOverLeftHalf(relX, relY, ICON_SIZE));
            }
            if (entryModel.canMoveUp()) {
                renderWidgetSprites(graphics, MOVE_UP_SPRITES, left, top, hovered && mouseOverTopRightQuarter(relX, relY, ICON_SIZE));
            }
            if (entryModel.canMoveDown()) {
                renderWidgetSprites(graphics, MOVE_DOWN_SPRITES, left, top, hovered && mouseOverBottomRightQuarter(relX, relY, ICON_SIZE));
            }
        }

        private void renderSelection(class_332 graphics, int top, int left, int width, int height) {
            if (entryModel.selected()) {
                RenderableRectangle overlay = entryModel.selectedLast() ? WHITE_OVERLAY : SELECTED_OVERLAY;
                overlay.extractRenderState(graphics, left, top, width, height, 0, 0, 0);
                graphics.method_49601(left, top, width, height, Colors.BLUE_500);
            }
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            init();
            int left = method_46426();
            int top = method_46427();
            int width = method_25368();
            int height = method_25364();
            int innerTop = top + INNER_ITEM_PADDING;
            int innerLeft = left + INNER_ITEM_PADDING;

            renderBack(graphics, top, left, width, height);

            Objects.requireNonNull(packWidget).checkCompatibility(isHovered() || isFocusedOrSelected());
            packWidget.method_25394(graphics, mouseX, mouseY, partialTick);

            renderSelection(graphics, top, left, width, height);
            renderWidgetSprites(graphics, innerTop, innerLeft, mouseX, mouseY);

            if (!renderables.isEmpty()) {
                graphics.method_51448().method_22903();
                graphics.method_51448().method_46416(0f, 0f, 0.1f);
                for (class_4068 renderable : this.renderables) {
                    renderable.method_25394(graphics, mouseX, mouseY, partialTick);
                }
                graphics.method_51448().method_22909();
            }

            if (devMenu != null) {
                devMenu.render(graphics, innerTop, left, width);
            }
        }

        @Override
        public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
            if (!this.initialized) return;

            ContextMenuEventImpl<ContextMenuEvent.PackEntry.Pos> extensions = ContextMenuEventImpl.postPackEntry(
                    screenContext,
                    entryModel
            );

            extensions.entries(ContextMenuEvent.PackEntry.Pos.BEFORE_HEADER).forEach(collector::addEntry);

            collector.addEntry(builder -> builder
                    .message(pack().method_14457())
                    .icon(padded16Rect(Renderables.texture(entryModel.icon(), 32, 32)))
                    .background(Renderables.fill(Colors.GRAY_500))
                    .onPress(e -> {
                        e.context().closeMenu();
                        return false;
                    })
                    .allowAutoDivideAfterEntry(false));

            collector.nextSection();

            extensions.entries(ContextMenuEvent.PackEntry.Pos.AFTER_HEADER).forEach(collector::addEntry);

            if (devMenu != null) {
                devMenu.updateContextEntries(collector);
                collector.nextSection();
            }

            extensions.entries(ContextMenuEvent.PackEntry.Pos.AFTER_DEV).forEach(collector::addEntry);

            if (entryModel.folder().isPresent()) {
                collector.addEntry(builder -> builder
                        .message(FolderPack.FOLDER_OPEN_TEXT)
                        .onPress(entryModel::openFolder));
                collector.nextSection();
            }

            if (entryModel.fileModifiable()) {
                collector.addEntry(builder -> builder
                        .message(RENAME_FILE_TEXT)
                        .active(entryModel::fileModifiable)
                        .onPress(entryModel::openRename));
                collector.addEntry(builder -> builder
                        .message(DELETE_FILE_TEXT)
                        .active(entryModel::fileModifiable)
                        .onPress(entryModel::delete));
            }

            if (PackUtil.validatePackPath(pack()) != null) {
                collector.addEntry(builder -> builder.message(OPEN_FILE_TEXT).onPress(() -> PackUtil.openPack(pack())));
                collector.addEntry(builder -> builder.message(OPEN_PARENT_TEXT).onPress(() -> PackUtil.openParent(pack())));
            }

            extensions.entries(ContextMenuEvent.PackEntry.Pos.AFTER_PACK).forEach(collector::addEntry);

            FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
        }

        @Override
        public List<class_364> method_25396() {
            return this.children;
        }

        @Override
        public boolean isHovered() {
            return super.isHovered() && fidgetz$isHovered();
        }

        private void repositionPackWidget() {
            if (packWidget != null) {
                packWidget.method_48229(method_46426(), method_46427() + INNER_ITEM_PADDING);
                packWidget.setWidth(method_25368());
            }
        }

        @Override
        public void method_46421(int x) {
            rightElements.forEach(child -> child.method_46421(child.method_46426() + x - method_46426()));
            if (folderWidget != null) folderWidget.method_46421(folderWidget.method_46426() + x - method_46426());
            super.method_46421(x);
            repositionPackWidget();
        }

        @Override
        public void method_46419(int y) {
            rightElements.forEach(child -> child.method_46419(child.method_46427() + y - method_46427()));
            if (folderWidget != null) folderWidget.method_46419(folderWidget.method_46427() + y - method_46427());
            super.method_46419(y);
            repositionPackWidget();
        }

        @Override
        protected void setWidth(int width) {
            rightElements.forEach(child -> child.method_46421(child.method_46426() + width - method_25368()));
            super.setWidth(width);
            repositionPackWidget();
        }

        @Override
        protected void setHeight(int height) {
            super.setHeight(height);
            repositionPackWidget();
        }

        @Override
        protected void setBounds(int x, int y, int width, int height) {
            rightElements.forEach(child -> child.method_48229((child.method_46426() + x - method_46426()) + width - method_25368(), child.method_46427() + y - method_46427()));
            if (folderWidget != null) {
                folderWidget.method_48229(folderWidget.method_46426() + x - method_46426(), folderWidget.method_46427() + y - method_46427());
            }
            super.setBounds(x, y, width, height);
            repositionPackWidget();
        }
    }
}
