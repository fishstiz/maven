@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.packed_packs.api.context;
