package io.github.fishstiz.packed_packs.api.events;

import io.github.fishstiz.packed_packs.api.Event;
import io.github.fishstiz.packed_packs.api.context.PackContext;
import io.github.fishstiz.packed_packs.api.context.ScreenContext;
import io.github.fishstiz.packed_packs.api.gui.ElementSink;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_8021;

/**
 * Fired when a pack entry is created.
 * <p>
 * Used to add custom widgets on top of entries.
 */
public final class InitializePackEntryEvent extends ScreenEvent implements PackEntryEvent, Event {
    /**
     * Represents the anchor positions available within a pack entry.
     */
    public enum Pos {
        START,
        CENTER,
        END;

        private float value() {
            return switch (this) {
                case START -> 0.0f;
                case CENTER -> 0.5f;
                case END -> 1.0f;
            };
        }
    }

    private final @Nullable class_8021[] rows = new class_8021[3];
    private final PackContext packContext;
    private final class_8021 container;
    private final ElementSink sink;

    @ApiStatus.Internal
    public InitializePackEntryEvent(ScreenContext context, PackContext packContext, class_8021 container, ElementSink sink) {
        super(context);
        this.packContext = packContext;
        this.container = container;
        this.sink = sink;
    }

    /**
     * Returns the context of the pack associated with this entry.
     *
     * @return the pack context
     */
    @Override
    public PackContext packContext() {
        return packContext;
    }

    private void stackElement(Pos row, int marginRight, class_8021 element) {
        class_8021 previous = rows[row.ordinal()];

        float anchorX = container.method_46426() + container.method_25368();
        float anchorY = container.method_46427() + (container.method_25364() * row.value());
        int offsetX = previous != null ? previous.method_46426() - element.method_25368() - marginRight : Math.round(anchorX) - element.method_25368() - marginRight;
        int y = Math.round(anchorY - (element.method_25364() * row.value()));

        element.method_48229(offsetX, y);
        rows[row.ordinal()] = element;
    }

    /**
     * Adds a widget to a row, automatically stacking it to the left of the
     * previously added widgets and renderable elements in that same row.
     *
     * @param row         the vertical row to stack in
     * @param marginRight additional spacing to the right of this widget
     * @param widget      the widget to stack
     */
    public void addWidget(Pos row, int marginRight, class_339 widget) {
        stackElement(row, marginRight, widget);
        sink.acceptWidget(widget);
        sink.acceptRenderable(widget);
        sink.acceptElement(widget);
    }

    /**
     * Adds a renderable to a row, automatically stacking it to the left of the
     * previously added widgets and renderable elements in that same row.
     * <p>
     * The renderable element will not receive/consume any mouse events
     *
     * @param row         the vertical row to stack in
     * @param marginRight additional spacing to the right of this widget
     * @param renderable  the renderable element to stack
     */
    public <T extends class_4068 & class_8021> void addRenderable(Pos row, int marginRight, T renderable) {
        stackElement(row, marginRight, renderable);
        sink.acceptRenderable(renderable);
        sink.acceptElement(renderable);
    }

    private void anchorElement(Pos row, int offsetX, int offsetY, class_8021 element) {
        float anchorX = container.method_46426() + container.method_25368();
        float anchorY = container.method_46427() + (container.method_25364() * row.value());
        int x = Math.round(anchorX - (element.method_25368() * Pos.END.value())) - offsetX;
        int y = Math.round(anchorY - (element.method_25364() * row.value())) + offsetY;
        element.method_48229(x, y);
    }

    /**
     * Places a widget at a specific offset relative to the right-hand side of a row.
     * Unlike {@link #addWidget}, this does not account for previously added widgets.
     *
     * @param row     the vertical row to anchor to
     * @param offsetX the horizontal offset from the right edge (positive moves left)
     * @param offsetY the vertical offset from the row anchor
     * @param widget  the widget to add
     */
    public void addAnchoredWidget(Pos row, int offsetX, int offsetY, class_339 widget) {
        anchorElement(row, offsetX, offsetY, widget);
        sink.acceptWidget(widget);
        sink.acceptRenderable(widget);
        sink.acceptElement(widget);
    }

    /**
     * Places a renderable element at a specific offset relative to the right-hand side of a row.
     * Unlike {@link #addWidget}, this does not account for previously added widgets and renderable elements.
     * <p>
     * The renderable element will not receive/consume any mouse events
     *
     * @param row        the vertical row to anchor to
     * @param offsetX    the horizontal offset from the right edge (positive moves left)
     * @param offsetY    the vertical offset from the row anchor
     * @param renderable the renderable to add
     */
    public <T extends class_4068 & class_8021> void addAnchoredRenderable(Pos row, int offsetX, int offsetY, T renderable) {
        anchorElement(row, offsetX, offsetY, renderable);
        sink.acceptRenderable(renderable);
        sink.acceptElement(renderable);
    }

    /**
     * Adds a widget that is manually managed.
     *
     * @param widgetFactory a function that takes the container and returns a widget
     */
    public void addDetachedWidget(Function<class_8021, @Nullable class_339> widgetFactory) {
        class_339 widget = widgetFactory.apply(container);
        if (widget != null) {
            sink.acceptWidget(widget);
            sink.acceptRenderable(widget);
        }
    }

    /**
     * Adds a renderable that is manually managed.
     * <p>
     * The renderable will not receive/consume any mouse events
     *
     * @param renderableFactory a function that takes the container and returns a renderable element
     */
    public void addDetachedRenderable(Function<class_8021, @Nullable class_4068> renderableFactory) {
        class_4068 renderable = renderableFactory.apply(container);
        if (renderable != null) sink.acceptRenderable(renderable);
    }

    public void addTopRight(int marginRight, class_339 widget) {
        addWidget(Pos.START, marginRight, widget);
    }

    public void addTopRight(class_339 widget) {
        addTopRight(0, widget);
    }

    public void addCenterRight(int marginRight, class_339 widget) {
        addWidget(Pos.CENTER, marginRight, widget);
    }

    public void addCenterRight(class_339 widget) {
        addCenterRight(0, widget);
    }

    public void addBottomRight(int marginRight, class_339 widget) {
        addWidget(Pos.END, marginRight, widget);
    }

    public void addBottomRight(class_339 widget) {
        addBottomRight(0, widget);
    }

    public void anchorTopRight(int offsetX, int offsetY, class_339 widget) {
        addAnchoredWidget(Pos.START, offsetX, offsetY, widget);
    }

    public void anchorTopRight(int offsetX, class_339 widget) {
        anchorTopRight(offsetX, 0, widget);
    }

    public void anchorCenterRight(int offsetX, int offsetY, class_339 widget) {
        addAnchoredWidget(Pos.CENTER, offsetX, offsetY, widget);
    }

    public void anchorCenterRight(int offsetX, class_339 widget) {
        anchorCenterRight(offsetX, 0, widget);
    }

    public void anchorBottomRight(int offsetX, int offsetY, class_339 widget) {
        addAnchoredWidget(Pos.END, offsetX, offsetY, widget);
    }

    public void anchorBottomRight(int offsetX, class_339 widget) {
        anchorBottomRight(offsetX, 0, widget);
    }

    public <T extends class_4068 & class_8021> void addTopRightRenderable(int marginRight, T renderable) {
        addRenderable(Pos.START, marginRight, renderable);
    }

    public <T extends class_4068 & class_8021> void addTopRightRenderable(T renderable) {
        addTopRightRenderable(0, renderable);
    }

    public <T extends class_4068 & class_8021> void addCenterRightRenderable(int marginRight, T renderable) {
        addRenderable(Pos.CENTER, marginRight, renderable);
    }

    public <T extends class_4068 & class_8021> void addCenterRightRenderable(T renderable) {
        addCenterRightRenderable(0, renderable);
    }

    public <T extends class_4068 & class_8021> void addBottomRightRenderable(int marginRight, T renderable) {
        addRenderable(Pos.END, marginRight, renderable);
    }

    public <T extends class_4068 & class_8021> void addBottomRightRenderable(T renderable) {
        addBottomRightRenderable(0, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorTopRightRenderable(int offsetX, int offsetY, T renderable) {
        addAnchoredRenderable(Pos.START, offsetX, offsetY, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorTopRightRenderable(int offsetX, T renderable) {
        anchorTopRightRenderable(offsetX, 0, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorCenterRightRenderable(int offsetX, int offsetY, T renderable) {
        addAnchoredRenderable(Pos.CENTER, offsetX, offsetY, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorCenterRightRenderable(int offsetX, T renderable) {
        anchorCenterRightRenderable(offsetX, 0, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorBottomRightRenderable(int offsetX, int offsetY, T renderable) {
        addAnchoredRenderable(Pos.END, offsetX, offsetY, renderable);
    }

    public <T extends class_4068 & class_8021> void anchorBottomRightRenderable(int offsetX, T renderable) {
        anchorBottomRightRenderable(offsetX, 0, renderable);
    }
}
