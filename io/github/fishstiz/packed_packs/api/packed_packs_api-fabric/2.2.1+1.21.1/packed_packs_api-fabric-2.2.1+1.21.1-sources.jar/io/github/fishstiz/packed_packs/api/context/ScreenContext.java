package io.github.fishstiz.packed_packs.api.context;

import io.github.fishstiz.packed_packs.api.Preference;
import io.github.fishstiz.packed_packs.api.gui.ContextMenuSink;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5375;
import net.minecraft.class_6379;

/**
 * Provides contextual information to the current screen state.
 */
@ApiStatus.NonExtendable
public interface ScreenContext {
    /**
     * @return The Minecraft client instance
     */
    class_310 getMinecraft();

    /**
     * @return the currently displayed screen instance.
     */
    class_437 screen();

    /**
     * <b>Note:</b> If the original screen is replaced, a new instance is created.
     *
     * @return the underlying vanilla pack selection screen.
     */
    class_5375 originalScreen();

    /**
     * @return the pack repository associated with this screen.
     */
    class_3283 packRepository();

    /**
     * @return the type of packs (e.g., Resource, Data) being managed.
     */
    class_3264 packType();

    /**
     * @return {@code true} if the current screen is managing resource packs.
     */
    default boolean isClientResources() {
        return this.packType() == class_3264.field_14188;
    }

    /**
     * @return {@code true} if the current screen is managing data packs.
     */
    default boolean isServerData() {
        return this.packType() == class_3264.field_14190;
    }

    /**
     * <b>Note:</b> Reflects the screen state; may not match with the pack repository.
     *
     * @return packs currently listed in the available column.
     */
    List<class_3288> getAvailablePacks();

    /**
     * <b>Note:</b> Reflects the screen state; may not match with the pack repository.
     *
     * @return packs currently listed in the selected column.
     */
    List<class_3288> getSelectedPacks();

    /**
     * Forces a reload of the underlying {@link class_3283} to discover new or modified files.
     * <p>
     * Use this over {@link class_3283#method_14445()} to update the GUI state.
     */
    void reload();

    /**
     * Applies the changes in the selected list and may trigger a resource/data reload.
     * <p>
     * <b>Note:</b> This closes the screen when data packs are being managed.
     */
    void commit();

    /**
     * @return {@code true} if the screen is in developer mode.
     */
    boolean devMode();

    /**
     * Rebuilds the {@link #screen}
     */
    void rebuild();

    /**
     * Adds a widget to the {@link #screen}
     */
    <T extends class_364 & class_6379> T addWidget(T widget);

    /**
     * Adds a renderable to the {@link #screen}
     */
    <T extends class_4068> T addRenderableOnly(T renderable);

    /**
     * Adds a renderable widget to the {@link #screen}
     */
    <T extends class_364 & class_6379 & class_4068> T addRenderableWidget(T widget);

    /**
     * Removes a widget from the {@link #screen}
     */
    void removeWidget(class_364 widget);

    /**
     * Returns the widget if the preference is enabled, or {@code null} if disabled.
     * <p>
     * When in {@link #devMode()}, always returns the widget wrapped with an overlay
     * indicating that it is toggleable, and a context menu item to toggle the preference
     * when right-clicked.
     *
     * @param key    the boolean preference key to check
     * @param widget the widget to wrap
     * @return the widget, a wrapped widget in dev mode, or {@code null} if disabled
     */
    @Nullable
    class_339 wrapWidget(Preference<Boolean> key, class_2561 label, @Nullable class_339 widget);

    /**
     * Wraps a widget with a context menu that appears when it is right-clicked.
     * <p>
     * The provided {@code configurator} receives both the widget and the context menu sink,
     * allowing context menu items to be configured based on the widget's state.
     * <p>
     * <b>Note:</b> The widget must be a direct child of a non-injected {@link class_364},
     * or another {@code wrapWithContextMenu} wrapped widget.
     *
     * @param widget       the widget to wrap
     * @param configurator a consumer to configure the context menu, receiving the widget and the context menu sink
     * @return the wrapped widget
     */
    <T extends class_339> class_339 wrapWithContextMenu(T widget, BiConsumer<T, ContextMenuSink> configurator);
}
