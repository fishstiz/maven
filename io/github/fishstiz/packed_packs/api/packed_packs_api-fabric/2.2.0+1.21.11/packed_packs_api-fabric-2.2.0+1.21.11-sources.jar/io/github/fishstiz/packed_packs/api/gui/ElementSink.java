package io.github.fishstiz.packed_packs.api.gui;

import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_8021;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface ElementSink {
    void acceptWidget(class_364 widget);

    void acceptRenderable(class_4068 renderable);

    void acceptElement(class_8021 element);
}