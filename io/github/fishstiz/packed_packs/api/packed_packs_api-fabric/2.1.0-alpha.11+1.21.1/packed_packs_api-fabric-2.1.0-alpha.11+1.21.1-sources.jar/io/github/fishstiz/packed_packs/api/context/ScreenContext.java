package io.github.fishstiz.packed_packs.api.context;

import io.github.fishstiz.packed_packs.api.PreferenceRegistry;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_5375;

/**
 * Provides contextual information to the current screen state.
 */
@ApiStatus.NonExtendable
public interface ScreenContext {
    /**
     * @return the currently displayed screen instance.
     */
    class_437 screen();

    /**
     * <b>Note:</b> If the original screen is replaced, a new instance is created.
     *
     * @return the underlying vanilla pack selection screen.
     */
    class_5375 originalScreen();

    /**
     * @return the pack repository associated with this screen.
     */
    class_3283 packRepository();

    /**
     * @return the type of packs (e.g., Resource, Data) being managed.
     */
    class_3264 packType();

    /**
     * @return {@code true} if the current screen is managing resource packs.
     */
    default boolean isClientResources() {
        return this.packType() == class_3264.field_14188;
    }

    /**
     * @return {@code true} if the current screen is managing data packs.
     */
    default boolean isServerData() {
        return this.packType() == class_3264.field_14190;
    }

    /**
     * <b>Note:</b> Reflects the screen state; may not match with the pack repository.
     *
     * @return packs currently listed in the available column.
     */
    List<class_3288> getAvailablePacks();

    /**
     * <b>Note:</b> Reflects the screen state; may not match with the pack repository.
     *
     * @return packs currently listed in the selected column.
     */
    List<class_3288> getSelectedPacks();

    /**
     * Forces a reload of the underlying {@link class_3283} to discover new or modified files.
     * <p>
     * Use this over {@link class_3283#method_14445()} to update the GUI state.
     */
    void reload();

    /**
     * Applies the changes in the selected list and may trigger a resource/data reload.
     * <p>
     * <b>Note:</b> This closes the screen when data packs are being managed.
     */
    void commit();

    /**
     * @return {@code true} if the screen is in developer mode.
     */
    boolean devMode();

    /**
     * Returns the widget if the preference is enabled, or {@code null} if disabled.
     * <p>
     * When in {@link #devMode()}, always returns the widget wrapped with an overlay
     * indicating that it is toggleable, and a context menu item to toggle the preference
     * when right-clicked.
     *
     * @param key    the preference key to check
     * @param widget the widget to wrap
     * @return the widget, a wrapped widget in dev mode, or {@code null} if disabled
     */
    @Nullable
    class_339 wrapWidget(PreferenceRegistry.Key<Boolean> key, @Nullable class_339 widget);
}
