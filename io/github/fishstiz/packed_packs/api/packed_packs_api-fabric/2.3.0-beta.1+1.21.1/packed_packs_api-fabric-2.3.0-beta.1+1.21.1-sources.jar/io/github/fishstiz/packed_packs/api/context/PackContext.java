package io.github.fishstiz.packed_packs.api.context;

import net.minecraft.class_2960;
import net.minecraft.class_3288;
import net.minecraft.class_5369;
import org.jetbrains.annotations.ApiStatus;

/**
 * Provides contextual information about a specific resource or data pack.
 */
@ApiStatus.NonExtendable
public interface PackContext extends class_5369.class_5371 {
    /**
     * @return the underlying pack instance associated with this context
     */
    class_3288 pack();

    class_2960 icon();

    /**
     * Determines if the underlying file for this pack is modifiable.
     * <p>
     * If {@code true}, UI elements that involve editing, renaming, or deleting
     * the pack file should be enabled.
     *
     * @return {@code true} if the pack file can be modified, {@code false} otherwise
     */
    boolean fileModifiable();
}
