package io.github.fishstiz.packed_packs.compat;

import io.github.fishstiz.packed_packs.PackedPacks;
import org.apache.commons.lang3.exception.UncheckedReflectiveOperationException;

import java.lang.reflect.Constructor;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class ModScreenFactory {
    private ModScreenFactory() {
    }

    public static Runnable createScreenSetter(String className, Arg<?>... screenArgs) {
        try {
            Object[] args = new Object[screenArgs.length];
            Class<?>[] argTypes = new Class[screenArgs.length];
            for (int i = 0; i < screenArgs.length; i++) {
                args[i] = screenArgs[i].arg();
                argTypes[i] = screenArgs[i].type();
            }

            Constructor<? extends class_437> screenCtor = Class.forName(className)
                    .asSubclass(class_437.class)
                    .getConstructor(argTypes);

            return () -> {
                try {
                    class_310.method_1551().method_1507(screenCtor.newInstance(args));
                } catch (ReflectiveOperationException e) {
                    PackedPacks.LOGGER.error("[packed_packs] Error opening mod screen: '{}'", className, e);
                }
            };
        } catch (ReflectiveOperationException e) {
            throw new UncheckedReflectiveOperationException(e);
        }
    }

    public record Arg<T>(Class<T> type, T arg) {
    }
}
