package io.github.fishstiz.packed_packs.api.events;

import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_437;
import net.minecraft.class_5375;

/**
 * Provides access to the current screen state and environment details.
 */
public final class ScreenContext {
    private final class_437 screen;
    private final Supplier<class_5375> originalScreen;
    private final class_3283 repository;
    private final class_3264 packType;
    private final boolean devMode;

    @ApiStatus.Internal
    public ScreenContext(
            class_437 screen,
            Supplier<class_5375> originalScreen,
            class_3283 repository,
            class_3264 packType,
            boolean devMode
    ) {
        this.screen = screen;
        this.originalScreen = originalScreen;
        this.repository = repository;
        this.packType = packType;
        this.devMode = devMode;
    }

    /**
     * @return the currently displayed screen instance.
     */
    public class_437 getScreen() {
        return this.screen;
    }

    /**
     * @return the pack repository associated with this screen.
     */
    public class_3283 getRepository() {
        return this.repository;
    }

    /**
     * <b>Note:</b> If the original screen is replaced,
     * a new instance is created solely to satisfy contracts.
     * Cache this value if a consistent reference is required.
     *
     * @return the underlying vanilla pack selection screen.
     */
    public class_5375 getOriginalScreen() {
        return this.originalScreen.get();
    }

    /**
     * @return the type of packs (e.g., Resource, Data) being managed.
     */
    public class_3264 getPackType() {
        return this.packType;
    }

    /**
     * @return {@code true} if the screen is in developer mode.
     */
    public boolean isDevMode() {
        return this.devMode;
    }
}
