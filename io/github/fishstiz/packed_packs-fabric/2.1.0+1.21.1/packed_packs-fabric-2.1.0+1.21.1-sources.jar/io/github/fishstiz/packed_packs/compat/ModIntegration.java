package io.github.fishstiz.packed_packs.compat;

import io.github.fishstiz.packed_packs.api.PackedPacksInitializer;
import io.github.fishstiz.packed_packs.api.PreferenceRegistry;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

public interface ModIntegration extends PackedPacksInitializer {
    ModContext mod();

    default @NotNull class_2960 id() {
        return id(this.mod());
    }

    static class_2960 id(ModContext mod) {
        return ResourceUtil.id(mod.getId());
    }

    static class_2561 getWidgetPrefText(PreferenceRegistry.Key<?> key) {
        return ResourceUtil.getText("preferences.widgets." + key.id().method_12832());
    }
}
