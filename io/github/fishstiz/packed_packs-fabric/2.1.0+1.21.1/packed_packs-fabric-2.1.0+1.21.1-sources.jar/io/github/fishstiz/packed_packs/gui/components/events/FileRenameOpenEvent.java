package io.github.fishstiz.packed_packs.gui.components.events;

import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import net.minecraft.class_3288;

public record FileRenameOpenEvent(PackList target, class_3288 trigger) implements FileEvent {
}
