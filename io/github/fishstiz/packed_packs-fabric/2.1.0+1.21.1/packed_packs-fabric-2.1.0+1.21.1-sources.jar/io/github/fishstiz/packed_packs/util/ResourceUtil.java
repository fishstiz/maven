package io.github.fishstiz.packed_packs.util;

import io.github.fishstiz.packed_packs.PackedPacks;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

public class ResourceUtil {
    private ResourceUtil() {
    }

    public static class_5250 getModName() {
        return class_2561.method_43470(PackedPacks.MOD_NAME);
    }

    public static class_5250 getText(String keySuffix, Object... args) {
        return class_2561.method_43469(PackedPacks.MOD_ID + "." + keySuffix, args);
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(PackedPacks.MOD_ID, path);
    }

    public static class_2960 getIcon(String icon) {
        return id("textures/gui/sprites/icon/").method_48331(icon + ".png");
    }

    public static class_2960 getVanillaSprite(String path) {
        return class_2960.method_60656("textures/gui/sprites/" + path + ".png");
    }
}
