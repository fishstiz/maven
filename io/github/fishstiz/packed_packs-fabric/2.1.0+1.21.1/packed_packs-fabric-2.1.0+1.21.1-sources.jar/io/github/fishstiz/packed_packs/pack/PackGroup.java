package io.github.fishstiz.packed_packs.pack;

import com.google.common.collect.ImmutableList;
import java.util.List;
import net.minecraft.class_3288;

public record PackGroup(ImmutableList<class_3288> selected, ImmutableList<class_3288> unselected) {
    public static PackGroup of(List<class_3288> selected, List<class_3288> unselected) {
        return new PackGroup(ImmutableList.copyOf(selected), ImmutableList.copyOf(unselected));
    }
}