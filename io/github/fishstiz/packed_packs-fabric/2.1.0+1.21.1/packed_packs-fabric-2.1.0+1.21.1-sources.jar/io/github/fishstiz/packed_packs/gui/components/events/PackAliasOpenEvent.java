package io.github.fishstiz.packed_packs.gui.components.events;

import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import net.minecraft.class_3288;

public record PackAliasOpenEvent(PackList target, class_3288 trigger) implements PackListEvent {
    @Override
    public boolean pushToHistory() {
        return false;
    }
}
