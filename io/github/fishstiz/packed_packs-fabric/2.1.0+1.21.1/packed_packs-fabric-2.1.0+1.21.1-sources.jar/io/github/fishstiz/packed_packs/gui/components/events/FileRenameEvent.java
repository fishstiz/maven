package io.github.fishstiz.packed_packs.gui.components.events;

import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import net.minecraft.class_2561;
import net.minecraft.class_3288;

public record FileRenameEvent(PackList target, class_3288 renamed, class_2561 newName) implements FileEvent {
}
