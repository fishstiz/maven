package io.github.fishstiz.packed_packs.compat.resourcify;

import io.github.fishstiz.packed_packs.api.PackedPacksApi;
import io.github.fishstiz.packed_packs.api.events.ScreenEvent;
import io.github.fishstiz.packed_packs.compat.ModIntegration;
import io.github.fishstiz.packed_packs.compat.Mod;
import io.github.fishstiz.packed_packs.compat.ModContext;
import io.github.fishstiz.packed_packs.util.ResourceUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_4185;

public class ResourcifyIntegration implements ModIntegration {
    @Override
    public ModContext mod() {
        return Mod.RESOURCIFY;
    }

    @Override
    public void onInitialize(@NotNull PackedPacksApi api) {
        if (!this.mod().isLoaded()) return;

        api.eventBus().register(
                ScreenEvent.InitLayout.class,
                this.id(),
                List.of(ModIntegration.id(Mod.ETF), ResourceUtil.id("vt_downloader")),
                event -> {
                    List<? extends class_4185> buttons = ResourcifyButtons.getButtons(event.ctx().getOriginalScreen());
                    if (buttons != null) {
                        for (class_4185 button : buttons.reversed()) {
                            event.addElement(ScreenEvent.InitLayout.Phase.AFTER_HEADER_TITLE, button);
                        }
                    }
                }
        );
    }
}
