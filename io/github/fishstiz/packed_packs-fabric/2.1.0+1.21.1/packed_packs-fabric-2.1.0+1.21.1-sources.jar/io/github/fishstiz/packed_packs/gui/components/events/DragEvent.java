package io.github.fishstiz.packed_packs.gui.components.events;

import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import java.util.List;
import net.minecraft.class_3288;

public record DragEvent(PackList target, List<class_3288> payload, class_3288 trigger) implements PackListEvent {
    public DragEvent {
        if (payload.isEmpty()) {
            throw new IllegalStateException("Cannot create drag event with empty payload.");
        }

        payload = List.copyOf(payload);
    }

    @Override
    public boolean pushToHistory() {
        return false;
    }
}
