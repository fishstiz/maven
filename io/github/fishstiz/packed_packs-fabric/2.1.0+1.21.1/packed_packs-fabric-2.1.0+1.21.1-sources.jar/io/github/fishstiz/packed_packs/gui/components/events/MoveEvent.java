package io.github.fishstiz.packed_packs.gui.components.events;

import io.github.fishstiz.packed_packs.gui.components.pack.PackList;
import java.util.List;
import net.minecraft.class_3288;

public record MoveEvent(PackList target, class_3288 trigger, List<class_3288> payload) implements PackListEvent {
    public MoveEvent {
        payload = List.copyOf(payload);
    }

    @Override
    public boolean pushToHistory() {
        return true;
    }
}
