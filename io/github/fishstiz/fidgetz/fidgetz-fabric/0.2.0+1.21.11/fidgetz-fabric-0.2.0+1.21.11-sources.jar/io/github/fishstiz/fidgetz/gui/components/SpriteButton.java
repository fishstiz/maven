package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.renderables.sprites.ButtonSprites;
import io.github.fishstiz.fidgetz.gui.renderables.sprites.Sprite;
import org.jspecify.annotations.NonNull;

import java.util.Objects;
import net.minecraft.class_332;

public class SpriteButton<E> extends FidgetzButton<E> {
    private final Sprites sprites;

    protected SpriteButton(io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<E> builder) {
        super(builder);

        this.sprites = builder.sprites;
    }

    @Override
    protected boolean hasSprite() {
        return true;
    }

    @Override
    protected void method_75752(@NonNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.sprites.get(this.field_22763).get(this.method_25367()).render(guiGraphics, this.method_46426(), this.method_46427());
        this.renderForeground(guiGraphics, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), partialTick);
        this.updateCursor(guiGraphics);
    }

    public static <E> io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<E> builder(Sprites sprites) {
        return new io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<>(sprites);
    }

    public static class Builder<E> extends FidgetzButton.Builder<E, io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<E>> {
        private final Sprites sprites;

        private Builder(Sprites sprites) {
            this.sprites = Objects.requireNonNull(sprites);
        }

        @Override
        public io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<E> setSprite(Sprite sprite) {
            throw new UnsupportedOperationException();
        }

        @Override
        public io.github.fishstiz.fidgetz.gui.components.SpriteButton.Builder<E> setSprite(ButtonSprites sprites) {
            throw new UnsupportedOperationException();
        }

        @Override
        public SpriteButton<E> build() {
            return new SpriteButton<>(this);
        }
    }

    public record Sprites(ButtonSprites active, ButtonSprites inactive) {
        public static Sprites of(ButtonSprites active) {
            return new Sprites(active, ButtonSprites.of(active.get(false)));
        }

        public ButtonSprites get(boolean active) {
            return active ? this.active : this.inactive;
        }
    }
}
