package io.github.fishstiz.fidgetz.gui.components;

import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;

public class ContainedWidget extends class_339 implements Fidgetz, ContainerEventHandlerPatch {
    protected final class_339 widget;
    private final List<class_339> children;
    private @Nullable class_364 focused;
    private boolean dragging;

    public ContainedWidget(class_339 widget) {
        super(widget.method_46426(), widget.method_46427(), widget.method_25368(), widget.method_25364(), widget.method_25369());
        this.children = Collections.singletonList(widget);
        this.widget = widget;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.widget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        this.widget.method_37020(narrationElementOutput);
    }

    @Override
    public List<class_339> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }
            if (focused != null) {
                focused.method_25365(true);
            }
            this.focused = focused;
        }
    }

    @Override
    public void method_25365(boolean focused) {
        this.widget.method_25365(focused);
        if (!focused) this.method_25395(null);
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        this.widget.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        this.widget.method_46419(y);
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        this.widget.method_25358(width);
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        this.widget.method_53533(height);
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        this.widget.method_55445(width, height);
    }

    @Override
    public int method_25364() {
        return this.widget.method_25364();
    }

    @Override
    public int method_25368() {
        return this.widget.method_25368();
    }

    @Override
    public int method_46426() {
        return this.widget.method_46426();
    }

    @Override
    public int method_46427() {
        return this.widget.method_46427();
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 focusNavigationEvent) {
        return ContainerEventHandlerPatch.super.method_48205(focusNavigationEvent);
    }

    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
        return ContainerEventHandlerPatch.super.method_25402(mouseButtonEvent, doubleClicked);
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        return ContainerEventHandlerPatch.super.method_25406(mouseButtonEvent);
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dragX, double dragY) {
        return ContainerEventHandlerPatch.super.method_25403(mouseButtonEvent, dragX, dragY);
    }

    @Override
    public boolean method_25370() {
        return ContainerEventHandlerPatch.super.method_25370();
    }
}
