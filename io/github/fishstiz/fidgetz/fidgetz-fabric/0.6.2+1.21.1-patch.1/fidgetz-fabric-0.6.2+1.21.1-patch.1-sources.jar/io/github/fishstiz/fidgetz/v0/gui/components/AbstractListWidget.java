package io.github.fishstiz.fidgetz.v0.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.fishstiz.fidgetz.v0.gui.components.events.ScrollableContainer;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.inject.mixins.access.AbstractSelectionListAccess;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import org.jetbrains.annotations.Nullable;

// extend AbstractSelectionList for smooth scrolling compat even though we deprecate a lot of methods and would prefer
// AbstractScrollWidget or custom impl. Avoid on 1.21.1 if possible
public abstract class AbstractListWidget<T extends AbstractListWidget.Entry<T>> extends class_350<T> implements ScrollableContainer, ContainerEventHandlerPatch {
    protected static final int DEFAULT_MAX_CONTENT_WIDTH = 270;
    protected static final int DEFAULT_SCROLL_RATE = 10;
    protected static final int SEPARATOR_HEIGHT = 2;
    private static final class_2960 BACKGROUND = class_2960.method_60656("textures/gui/menu_list_background.png");
    private static final class_2960 INWORLD_BACKGROUND = class_2960.method_60656("textures/gui/inworld_menu_list_background.png");
    private static final RenderableRectangle HEADER_SEPARATOR = Renderables.texture(class_437.field_49895, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_HEADER_SEPARATOR = Renderables.texture(class_437.field_49897, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle FOOTER_SEPARATOR = Renderables.texture(class_437.field_49896, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_FOOTER_SEPARATOR = Renderables.texture(class_437.field_49898, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);

    protected AbstractListWidget(class_310 minecraft, int x, int y, int width, int height, class_2561 message) {
        super(minecraft, width, height, y, DEFAULT_SCROLL_RATE * 2);
        method_25355(message);
    }

    protected AbstractListWidget(int x, int y, int width, int height, class_2561 message) {
        this(class_310.method_1551(), x, y, width, height, message);
    }

    @Override
    @Deprecated
    protected final void method_57715(class_332 graphics) {
        extractBackgroundRenderState(graphics, 0, 0, 0);
    }

    protected void extractBackgroundRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_2960 background = field_22740.field_1687 == null ? BACKGROUND : INWORLD_BACKGROUND;
        RenderSystem.enableBlend();
        graphics.method_25290(
                background,
                method_46426(),
                method_46427(),
                method_55442(),
                method_55443() + (int) scrollAmount(),
                method_25368(),
                method_25364(),
                32,
                32
        );
        RenderSystem.disableBlend();
    }

    @Override
    @Deprecated
    protected final void method_57713(class_332 graphics) {
        extractSeparatorsRenderState(graphics, 0, 0, 0);
    }

    protected void extractSeparatorsRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        RenderableRectangle header = field_22740.field_1687 == null ? HEADER_SEPARATOR : INWORLD_HEADER_SEPARATOR;
        RenderableRectangle footer = field_22740.field_1687 == null ? FOOTER_SEPARATOR : INWORLD_FOOTER_SEPARATOR;
        RenderSystem.enableBlend();
        header.extractRenderState(graphics, method_46426(), method_46427() - SEPARATOR_HEIGHT, method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
        footer.extractRenderState(graphics, method_46426(), method_55443(), method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
        RenderSystem.disableBlend();
    }

    @Override
    @Deprecated
    protected final void method_25311(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
    }

    protected abstract void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick);

    @Override
    @Deprecated
    protected final void method_25320(class_332 graphics, int mouseX, int mouseY) {
    }

    // workaround for smooth scrolling which directly modifies scrollAmount instead of calling the setter.
    // it assumes that calls to setScrollAmount should snap
    // https://github.com/SmajloSlovakian/Minecraft-Smooth-Scrolling/blob/1.21.1/src/main/java/smsk/smoothscroll/mixin/EntryListWidgetMixin.java
    void onChangeScrollAmount(double scrollAmount) {
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        double lastScrollAmount = scrollAmount();
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
        double newScrollAmount = scrollAmount();
        if (lastScrollAmount != newScrollAmount) {
            onChangeScrollAmount(newScrollAmount);
        }
    }

    protected int contentPaddingLeft() {
        return 0;
    }

    protected int contentPaddingRight() {
        return 0;
    }

    protected int maxContentWidth() {
        return DEFAULT_MAX_CONTENT_WIDTH;
    }

    protected int contentWidth() {
        int contentWidth = method_25368() - scrollbarReserve() - contentPaddingLeft() - contentPaddingRight();
        return MathUtils.optionalMin(contentWidth, maxContentWidth());
    }

    @Override
    @Deprecated
    public final int method_25322() {
        return contentWidth();
    }

    protected abstract int contentHeight();

    @Override
    @Deprecated
    protected final int method_25317() {
        return contentHeight();
    }

    protected final int contentLeft() {
        return Math.min(
                method_46426() + (method_25368() / 2 - contentWidth() / 2) + contentPaddingLeft() - contentPaddingRight(),
                method_55442() - scrollbarReserve() - contentWidth()
        );
    }

    @Override
    @Deprecated
    public final int method_25342() {
        return contentLeft();
    }

    @Override
    @Deprecated
    public final int method_31383() {
        return contentLeft() + contentWidth();
    }

    @Override
    @Deprecated
    protected final int method_25337(int index) {
        Entry<T> entry = index >= 0 && index < method_25396().size() ? method_25396().get(index) : null;
        return entry == null ? 0 : entry.method_48202().method_49618();
    }

    @Override
    @Deprecated
    protected final int method_25319(int index) {
        Entry<T> entry = index >= 0 && index < method_25396().size() ? method_25396().get(index) : null;
        return entry == null ? 0 : entry.method_48202().method_49619();
    }

    protected final int scrollbarWidth() {
        return field_45909;
    }

    protected boolean method_57717() {
        return contentHeight() > method_25364();
    }

    protected boolean reserveScrollbarWidth() {
        return false;
    }

    protected int scrollbarReserve() {
        return reserveScrollbarWidth() || method_57717() ? scrollbarWidth() : 0;
    }

    protected int scrollBarX() {
        return Math.min(contentLeft() + contentWidth() + contentPaddingRight(), method_55442() - scrollbarWidth());
    }

    @Override
    @Deprecated
    protected final int method_25329() {
        return scrollBarX();
    }

    @Override
    @Deprecated
    public final double method_25341() {
        return super.method_25341();
    }

    @Override
    public double scrollAmount() {
        return super.method_25341();
    }

    public void refreshScrollAmount() {
        method_25307(scrollAmount());
    }

    public void setScrollRate(double scrollRate) {
        ((AbstractSelectionListAccess) this).fidgetz$setScrollRate(scrollRate);
    }

    @Override
    public final double scrollRate() {
        return (double) field_22741 / 2;
    }

    protected boolean isOverScrollbar(double x, double y) {
        return method_49606() && x >= scrollBarX() && x <= scrollBarX() + scrollbarWidth() && y >= method_46427() && y < method_55443();
    }

    protected boolean scrollable() {
        return maxScrollAmount() > 0;
    }

    public int maxScrollAmount() {
        return Math.max(0, this.contentHeight() - this.field_22759);
    }

    @Override
    @Deprecated
    public final int method_25331() {
        return maxScrollAmount();
    }

    protected int scrollerHeight() {
        return class_3532.method_15340((int) ((float) (this.field_22759 * this.field_22759) / this.contentHeight()), 32, this.field_22759 - 8);
    }

    @Override
    @Deprecated
    protected final void ensureVisible(T entry) {
    }

    public boolean updateScrolling(double mouseX, double mouseY, int button) {
        method_25318(mouseX, mouseY, button);
        return ((AbstractSelectionListAccess) this).fidgetz$getScrolling();
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        }
    }

    @Override
    @Deprecated
    public final @Nullable T method_25334() {
        return null;
    }

    @Override
    @Deprecated
    public final void setSelected(@Nullable T selected) {
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (method_25336() != focused) {
            super.method_25395(focused);
        }
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return addScrollEffectOnFocus(navigationEvent, super.method_48205(navigationEvent));
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (((AbstractSelectionListAccess) this).fidgetz$getScrolling()) {
            if (mouseY < this.method_46427()) {
                this.method_25307(0.0);
            } else if (mouseY > this.method_55443()) {
                this.method_25307(this.maxScrollAmount());
            } else {
                double max = Math.max(1, this.maxScrollAmount());
                int barHeight = this.scrollerHeight();
                double yDragScale = Math.max(1.0, max / (this.field_22759 - barHeight));
                this.method_25307(this.scrollAmount() + dragY * yDragScale);
            }

            return true;
        } else if (this.method_25351(button)) {
            this.method_25349(mouseX, mouseY, dragX, dragY);
        }

        return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
        if (method_37303() && method_19355(mx, my).filter(child -> child.method_25401(mx, my, scrollX, scrollY)).isPresent()) {
            return true;
        }
        return super.method_25401(mx, my, scrollX, scrollY) && scrollable();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean scrolling = updateScrolling(mouseX, mouseY, button);
        return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) || scrolling;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        method_25318(0, 0, -1); // reset scrolling state
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    protected void method_47399(class_6382 output) {
    }

    protected abstract static class Entry<T extends Entry<T>> extends class_350.class_351<T> implements ContainerEventHandlerPatch {
        @Nullable
        private class_364 focused;
        private boolean isDragging;

        @Override
        public boolean method_25397() {
            return this.isDragging;
        }

        @Override
        public void method_25398(boolean dragging) {
            this.isDragging = dragging;
        }

        @Override
        public @Nullable class_364 method_25399() {
            return this.focused;
        }

        @Override
        public void method_25395(@Nullable class_364 listener) {
            if (method_25399() != listener) {
                if (this.focused != null) {
                    this.focused.method_25365(false);
                }
                if (listener != null) {
                    listener.method_25365(true);
                }
                this.focused = listener;
            }
        }

        @Override
        public void method_25365(boolean focused) {
            if (!focused) {
                method_25395(null);
            }
        }

        @Override
        @Deprecated
        public final void method_25343(class_332 graphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dragX, dragY);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
            return ContainerEventHandlerPatch.super.method_25401(mouseX, mouseY, scrollX, scrollY);
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return method_48202().method_58137((int) mouseX, (int) mouseY);
        }
    }
}
