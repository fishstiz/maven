package io.github.fishstiz.fidgetz.v0.utils;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;
import org.jspecify.annotations.Nullable;

import java.util.ServiceLoader;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_11735;
import net.minecraft.class_12225;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import net.minecraft.class_8012;
import net.minecraft.class_8030;

public final class GuiGraphicsUtils {
    private static final Service GUI_GRAPHICS_SERVICE = ServiceLoader.load(Service.class).findFirst().orElseThrow();

    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height, int color) {
        graphics.method_52707(class_10799.field_56883, sprite, x, y, width, height, color);
    }

    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height) {
        sprite(graphics, sprite, x, y, width, height, class_8012.field_42973);
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int uWidth,
            int vHeight,
            int textureWidth,
            int textureHeight
    ) {
        graphics.method_25302(
                class_10799.field_56883,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                uWidth,
                vHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                0,
                0,
                width, height,
                textureWidth, textureHeight
        );
    }

    public static void texture(class_332 graphics, class_2960 texture, int x, int y, int textureWidth, int textureHeight) {
        texture(graphics, texture, x, y, textureWidth, textureHeight, textureWidth, textureHeight);
    }

    public static void fillFloat(class_332 graphics, float left, float top, float right, float bottom, int color) {
        Matrix3x2f pose = new Matrix3x2f(graphics.method_51448());
        class_8030 scissorArea = GUI_GRAPHICS_SERVICE.peekScissorStack(graphics);
        class_8030 bounds = new class_8030((int) left, (int) top, (int) (right - left), (int) (bottom - top)).method_71523(pose);
        class_8030 intersection = scissorArea == null ? bounds : scissorArea.method_49701(bounds);

        GUI_GRAPHICS_SERVICE.addGuiElement(graphics, new class_11244() {
            @Override
            public void method_70917(class_4588 vertexConsumer) {
                vertexConsumer.method_70815(pose, left, top).method_39415(color);
                vertexConsumer.method_70815(pose, left, bottom).method_39415(color);
                vertexConsumer.method_70815(pose, right, bottom).method_39415(color);
                vertexConsumer.method_70815(pose, right, top).method_39415(color);
            }

            @Override
            public RenderPipeline comp_4055() {
                return class_10799.field_56879;
            }

            @Override
            public class_11231 comp_4056() {
                return class_11231.method_70899();
            }

            @Override
            public @Nullable class_8030 comp_4069() {
                return scissorArea;
            }

            @Override
            public @Nullable class_8030 comp_4274() {
                return intersection;
            }
        });
    }

    public static void fillHorizontal(class_332 graphics, int left, int top, int right, int bottom, int colorFrom, int colorTo) {
        Matrix3x2f pose = new Matrix3x2f(graphics.method_51448());
        class_8030 scissorArea = GUI_GRAPHICS_SERVICE.peekScissorStack(graphics);
        class_8030 bounds = new class_8030(left, top, right - left, bottom - top).method_71523(pose);
        class_8030 intersection = scissorArea == null ? bounds : scissorArea.method_49701(bounds);

        GUI_GRAPHICS_SERVICE.addGuiElement(graphics, new class_11244() {
            @Override
            public void method_70917(class_4588 vertexConsumer) {
                vertexConsumer.method_70815(pose, left, top).method_39415(colorFrom);
                vertexConsumer.method_70815(pose, left, bottom).method_39415(colorFrom);
                vertexConsumer.method_70815(pose, right, bottom).method_39415(colorTo);
                vertexConsumer.method_70815(pose, right, top).method_39415(colorTo);
            }

            @Override
            public RenderPipeline comp_4055() {
                return class_10799.field_56879;
            }

            @Override
            public class_11231 comp_4056() {
                return class_11231.method_70899();
            }

            @Override
            public @Nullable class_8030 comp_4069() {
                return scissorArea;
            }

            @Override
            public @Nullable class_8030 comp_4274() {
                return intersection;
            }
        });
    }

    public static void text(class_332 graphics, class_2561 text, int x, int y, int color) {
        graphics.method_27535(class_310.method_1551().field_1772, text, x, y, color);
    }

    public static void scrollingText(
            class_12225 textCollector,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            class_12225.class_12227 localParameters = textCollector.method_75760().method_75779(left, right, top, bottom);
            textCollector.method_75766(class_11735.field_62009, left - (int) scrollOffset, textY, localParameters, component.method_30937());
        } else {
            textCollector.method_75765(class_11735.field_62009, left, textY, component.method_30937());
        }
    }

    public static void scrollingText(class_12225 textCollector, class_2561 component, int left, int top, int right, int bottom) {
        scrollingText(textCollector, class_310.method_1551().field_1772, component, left, top, right, bottom);
    }

    public static void scrollingText(
            class_332 graphics,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom,
            int color,
            boolean shadow
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_51439(font, component, left - (int) scrollOffset, textY, color, shadow);
            graphics.method_44380();
        } else {
            graphics.method_51439(font, component, left, textY, color, shadow);
        }
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color, boolean shadow) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color, shadow);
    }

    public static void scrollingText(class_332 graphics, class_327 font, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, font, component, left, top, right, bottom, color, true);
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color);
    }

    private GuiGraphicsUtils() {
    }

    interface Service {
        void addGuiElement(class_332 graphics, class_11244 blitState);

        @Nullable
        class_8030 peekScissorStack(class_332 graphics);
    }
}
