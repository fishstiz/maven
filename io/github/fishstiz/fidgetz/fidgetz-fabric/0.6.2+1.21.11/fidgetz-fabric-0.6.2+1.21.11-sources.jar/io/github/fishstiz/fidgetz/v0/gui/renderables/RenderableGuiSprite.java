package io.github.fishstiz.fidgetz.v0.gui.renderables;

import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import net.minecraft.class_2960;
import net.minecraft.class_332;

record RenderableGuiSprite(class_2960 sprite, int color) implements RenderableRectangle {
    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        GuiGraphicsUtils.sprite(graphics, sprite, left, top, width, height, color);
    }
}
