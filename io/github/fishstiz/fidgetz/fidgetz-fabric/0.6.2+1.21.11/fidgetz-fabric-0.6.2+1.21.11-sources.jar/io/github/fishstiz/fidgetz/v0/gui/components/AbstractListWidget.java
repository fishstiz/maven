package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.events.ScrollableContainer;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_9017;
import org.jspecify.annotations.Nullable;

abstract class AbstractListWidget extends class_9017 implements ScrollableContainer {
    protected static final int DEFAULT_MAX_CONTENT_WIDTH = 270;
    protected static final int DEFAULT_SCROLL_RATE = 10;
    protected static final int SEPARATOR_HEIGHT = 2;
    private static final class_2960 BACKGROUND = class_2960.method_60656("textures/gui/menu_list_background.png");
    private static final class_2960 INWORLD_BACKGROUND = class_2960.method_60656("textures/gui/inworld_menu_list_background.png");
    private static final RenderableRectangle HEADER_SEPARATOR = Renderables.texture(class_437.field_49895, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_HEADER_SEPARATOR = Renderables.texture(class_437.field_49897, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle FOOTER_SEPARATOR = Renderables.texture(class_437.field_49896, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_FOOTER_SEPARATOR = Renderables.texture(class_437.field_49898, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private final class_310 minecraft;

    protected AbstractListWidget(class_310 minecraft, int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
        this.minecraft = minecraft;
    }

    protected AbstractListWidget(int x, int y, int width, int height, class_2561 message) {
        this(class_310.method_1551(), x, y, width, height, message);
    }

    protected void extractBackgroundRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_2960 background = this.minecraft.field_1687 == null ? BACKGROUND : INWORLD_BACKGROUND;
        graphics.method_25290(
                class_10799.field_56883,
                background,
                method_46426(),
                method_46427(),
                method_55442(),
                method_55443() + (int) method_44387(),
                method_25368(),
                method_25364(),
                32,
                32
        );
    }

    protected void extractSeparatorsRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        RenderableRectangle header = minecraft.field_1687 == null ? HEADER_SEPARATOR : INWORLD_HEADER_SEPARATOR;
        RenderableRectangle footer = minecraft.field_1687 == null ? FOOTER_SEPARATOR : INWORLD_FOOTER_SEPARATOR;
        header.extractRenderState(graphics, method_46426(), method_46427() - SEPARATOR_HEIGHT, method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
        footer.extractRenderState(graphics, method_46426(), method_55443(), method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
    }

    protected abstract void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick);

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        extractBackgroundRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.method_44379(method_46426(), method_46427(), method_55442(), method_55443());
        extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.method_44380();
        extractSeparatorsRenderState(graphics, mouseX, mouseY, partialTick);
        method_44396(graphics, mouseX, mouseY);
    }

    protected int contentPaddingLeft() {
        return 0;
    }

    protected int contentPaddingRight() {
        return 0;
    }

    protected int maxContentWidth() {
        return DEFAULT_MAX_CONTENT_WIDTH;
    }

    protected int contentWidth() {
        int contentWidth = method_25368() - scrollbarReserve() - contentPaddingLeft() - contentPaddingRight();
        return MathUtils.optionalMin(contentWidth, maxContentWidth());
    }

    @Override
    protected abstract int method_44395();

    protected final int contentLeft() {
        return Math.min(
                method_46426() + (method_25368() / 2 - contentWidth() / 2) + contentPaddingLeft() - contentPaddingRight(),
                method_55442() - scrollbarReserve() - contentWidth()
        );
    }

    protected boolean method_44392() {
        return method_44395() > method_25364();
    }

    protected boolean reserveScrollbarWidth() {
        return false;
    }

    protected int scrollbarReserve() {
        return reserveScrollbarWidth() || method_44392() ? field_55258 : 0;
    }

    @Override
    protected int method_65507() {
        return Math.min(contentLeft() + contentWidth() + contentPaddingRight(), method_55442() - field_55258);
    }

    @Override
    public abstract double method_44393();

    @Override
    protected boolean method_74038(double x, double y) {
        return super.method_74038(x, y) && method_49606();
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (method_25399() != focused) {
            super.method_25395(focused);
        }
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return addScrollEffectOnFocus(navigationEvent, super.method_48205(navigationEvent));
    }

    protected boolean scrollable() {
        return method_44390() > 0;
    }

    @Override
    public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
        if (method_37303() && method_19355(mx, my).filter(child -> child.method_25401(mx, my, scrollX, scrollY)).isPresent()) {
            return true;
        }
        return super.method_25401(mx, my, scrollX, scrollY) && scrollable();
    }

    @Override
    protected void method_47399(class_6382 output) {
    }

    @Override
    public class_8030 method_65515(class_8028 opposite) {
        class_364 focused = method_25399();
        return focused != null
                ? focused.method_65515(opposite)
                : new class_8030(method_46426(), method_46427(), field_22758, method_44395()).method_48256(opposite);
    }
}
