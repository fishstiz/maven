package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.*;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_9110;

public sealed interface FZPopoverMenuItem {
    Factory factory();

    Settings settings();

    @FunctionalInterface
    interface Factory {
        Entry create(Context context);
    }

    record Settings(boolean closeOnInteract, boolean autoDividerAfter) {
        private static final Settings DEFAULT_SETTINGS = new Settings(true, true);

        public static Settings defaults() {
            return DEFAULT_SETTINGS;
        }
    }

    record Widget(Factory factory, Settings settings) implements FZPopoverMenuItem {
        public Widget(Factory factory) {
            this(factory, Settings.defaults());
        }
    }

    record Divider(@Nullable Factory factory, Settings settings) implements FZPopoverMenuItem {
        private static final Settings DEFAULT_SETTINGS = new Settings(false, false);

        public Divider(@Nullable Factory factory) {
            this(factory, DEFAULT_SETTINGS);
        }
    }

    static Divider divider() {
        return new Divider(null);
    }

    static Divider createDivider(RenderableRectangle rectangle, int height) {
        return new Divider(ctx -> new FZPopoverMenuEntryImpl.Divider(ctx, rectangle, height));
    }

    static Divider createDivider(class_2960 sprite, int height) {
        return new Divider(ctx -> new FZPopoverMenuEntryImpl.Divider(ctx, Renderables.sprite(sprite), height));
    }

    static Widget fromWidget(class_339 widget) {
        class Wrapped extends WrappedComponent implements Entry {
            private final Context context;

            public Wrapped(Context context, class_339 widget) {
                super(widget);
                this.context = context;
            }

            @Override
            public Context context() {
                return context;
            }
        }

        return new Widget(ctx -> new Wrapped(ctx, widget));
    }

    static Builder builder() {
        return new Builder();
    }

    interface Context {
        void closeMenu();

        boolean isActive();

        boolean isHovered();

        boolean isFocused();

        boolean isChildOpened();

        class_8030 getRectangle();

        default boolean isFocusedOrHovered() {
            return isFocused() || isHovered();
        }
    }

    interface Entry extends class_8021, class_364, class_6379, class_4068 {
        int DEFAULT_HEIGHT = 20;

        Context context();

        default List<FZPopoverMenuItem> childItems() {
            return Collections.emptyList();
        }

        @Override
        default void method_46421(int x) {
        }

        @Override
        default void method_46419(int y) {
        }

        default void setWidth(int width) {
        }

        @Override
        default int method_46426() {
            return context().getRectangle().method_49620();
        }

        @Override
        default int method_46427() {
            return context().getRectangle().method_49618();
        }

        @Override
        default int method_25364() {
            return DEFAULT_HEIGHT;
        }

        @Override
        default void method_25365(boolean focused) {
        }

        @Override
        default boolean method_25370() {
            return context().isFocused();
        }

        @Override
        default void method_37020(class_6382 output) {
        }

        @Override
        default class_6379.class_6380 method_37018() {
            if (method_37303()) {
                if (method_25370()) {
                    return class_6379.class_6380.field_33786;
                } else if (context().isHovered()) {
                    return class_6379.class_6380.field_33785;
                }
            }
            return class_6379.class_6380.field_33784;
        }

        @Override
        default @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            if (!method_37303()) return null;
            return !method_25370() ? class_8016.method_48193(this) : null;
        }

        @Override
        default void method_48206(Consumer<class_339> widgetVisitor) {
        }

        @Override
        default class_8030 method_48202() {
            return class_8021.super.method_48202();
        }
    }

    final class Builder {
        private static final int DEFAULT_WIDTH = 150;
        private static final Supplier<WidgetRenderables> DEFAULT_BACKGROUND;
        private final List<FZPopoverMenuItem> children = new ArrayList<>();
        private @Nullable Supplier<@Nullable WidgetRenderables> backgroundSupplier = DEFAULT_BACKGROUND;
        private @Nullable Supplier<@Nullable WidgetElements> iconSupplier;
        private @Nullable Supplier<@Nullable class_2561> messageSupplier;
        private FZPopoverMenuEntryImpl.@Nullable TooltipHolder tooltipHolder;
        private @Nullable BooleanSupplier activeSupplier;
        private @Nullable Function<PressEvent, Boolean> pressHandler;
        private boolean closeOnInteraction = true;
        private boolean allowDivideAfterEntry = true;
        private boolean playClickSoundOnInteraction = true;
        private boolean applyCursorWhenActive = true;
        private int height = Entry.DEFAULT_HEIGHT;
        private int minWidth = DEFAULT_WIDTH;

        static {
            RenderableRectangle background = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry"));
            RenderableRectangle highlighted = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry_highlighted"));
            WidgetRenderables renderables = new WidgetRenderables(background, background, highlighted);
            DEFAULT_BACKGROUND = () -> renderables;
        }

        private Builder() {
        }

        public record PressEvent(Context context, FZPopoverMenuItem.Entry entry) {
        }

        public Builder background(@Nullable Supplier<@Nullable WidgetRenderables> backgroundSupplier) {
            this.backgroundSupplier = backgroundSupplier;
            return this;
        }

        public Builder background(WidgetRenderables background) {
            Objects.requireNonNull(background, "background cannot be null");
            return background(() -> background);
        }

        public Builder background(RenderableRectangle background) {
            return background(new WidgetRenderables(Objects.requireNonNull(background, "background cannot be null")));
        }

        public Builder icon(@Nullable Supplier<@Nullable WidgetElements> iconSupplier) {
            this.iconSupplier = iconSupplier;
            return this;
        }

        public Builder icon(WidgetElements icon) {
            return icon(() -> icon);
        }

        public Builder icon(WidgetRenderables icon) {
            Objects.requireNonNull(icon, "icon cannot be null");
            return icon(new WidgetElements(icon, 16, 16));
        }

        public Builder icon(RenderableRectangle icon) {
            Objects.requireNonNull(icon, "icon cannot be null");
            return icon(new WidgetRenderables(icon));
        }

        public Builder message(@Nullable Supplier<@Nullable class_2561> textSupplier) {
            this.messageSupplier = textSupplier;
            return this;
        }

        public Builder message(@Nullable class_2561 message) {
            return message(() -> message);
        }

        public Builder tooltip(@Nullable Supplier<@Nullable class_7919> tooltipSupplier) {
            this.tooltipHolder = tooltipSupplier == null ? null : new FZPopoverMenuEntryImpl.TooltipHolder(tooltipSupplier);
            return this;
        }

        public Builder tooltip(@Nullable class_7919 tooltip) {
            return tooltip(() -> tooltip);
        }

        public Builder tooltip(@Nullable class_9110 tooltipHolder) {
            this.tooltipHolder = tooltipHolder == null ? null : new FZPopoverMenuEntryImpl.TooltipHolder(tooltipHolder);
            return this;
        }

        public Builder active(@Nullable BooleanSupplier activeSupplier) {
            this.activeSupplier = activeSupplier;
            return this;
        }

        public Builder active(boolean active) {
            return active(() -> active);
        }

        public Builder active() {
            return active(true);
        }

        public Builder child(FZPopoverMenuItem child) {
            children.add(child);
            return this;
        }

        public Builder child(UnaryOperator<Builder> builderConfigurator) {
            children.add(builderConfigurator.apply(builder()).build());
            return this;
        }

        public Builder nextSection() {
            return child(divider());
        }

        public Builder children(List<FZPopoverMenuItem> children) {
            this.children.addAll(children);
            return this;
        }

        public Builder closeOnInteraction(boolean closeOnInteraction) {
            this.closeOnInteraction = closeOnInteraction;
            return this;
        }

        public Builder closeOnInteraction() {
            return closeOnInteraction(true);
        }

        public Builder allowAutoDivideAfterEntry(boolean allowAutoDivideAfterEntry) {
            this.allowDivideAfterEntry = allowAutoDivideAfterEntry;
            return this;
        }

        public Builder allowAutoDivideAfterEntry() {
            this.allowDivideAfterEntry = true;
            return this;
        }

        public Builder playClickSoundOnInteraction(boolean playClickSoundOnInteraction) {
            this.playClickSoundOnInteraction = playClickSoundOnInteraction;
            return this;
        }

        public Builder playClickSoundOnInteraction() {
            return playClickSoundOnInteraction(true);
        }

        public Builder applyCursorChangeWhenActive(boolean applyCursorChangeWhenActive) {
            this.applyCursorWhenActive = applyCursorChangeWhenActive;
            return this;
        }

        public Builder applyCursorChangeWhenActive() {
            return applyCursorChangeWhenActive(true);
        }

        public Builder height(int height) {
            this.height = height;
            return this;
        }

        public Builder minWidth(int width) {
            this.minWidth = width;
            return this;
        }

        public Builder onPress(@Nullable Function<PressEvent, Boolean> pressHandler) {
            this.pressHandler = pressHandler;
            return this;
        }

        public Builder onPress(BooleanSupplier pressHandler) {
            Objects.requireNonNull(pressHandler, "pressHandler is null");
            return onPress(ignored -> pressHandler.getAsBoolean());
        }

        public Builder onPress(Runnable mouseAction) {
            Objects.requireNonNull(mouseAction, "mouseAction is null");
            return onPress(ignored -> {
                mouseAction.run();
                return true;
            });
        }

        public Builder preventPress() {
            this.pressHandler = null;
            return this;
        }

        public FZPopoverMenuItem build() {
            return new FZPopoverMenuItem.Widget(
                    ctx -> new FZPopoverMenuEntryImpl(
                            ctx,
                            children,
                            backgroundSupplier == null ? FunctionUtils.nullSupplier() : backgroundSupplier,
                            iconSupplier == null ? FunctionUtils.nullSupplier() : iconSupplier,
                            messageSupplier == null ? FunctionUtils.nullSupplier() : messageSupplier,
                            tooltipHolder == null ? new class_9110() : tooltipHolder,
                            activeSupplier == null ? () -> true : activeSupplier,
                            pressHandler == null ? ignored -> true : pressHandler,
                            playClickSoundOnInteraction,
                            applyCursorWhenActive && pressHandler != null,
                            height,
                            minWidth
                    ),
                    new Settings(closeOnInteraction, allowDivideAfterEntry)
            );
        }
    }
}