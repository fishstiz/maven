package io.github.fishstiz.fidgetz.v0.gui.screens;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_8016;
import net.minecraft.class_8030;

public abstract class FZScreen extends class_437 implements FZDialogContainer, FZHoverableContainer, FZContextMenu.Source, ContainerEventHandlerPatch {
    protected static final String GLOBAL_CONTEXT_MENU_ID = "FZScreen:FZContextMenu";
    protected final FZDialogManager dialogManager = new FZDialogManager(this);
    protected class_8030 screenRectangle = class_8030.method_48248();

    protected FZScreen(class_2561 title) {
        super(title);
    }


    @Override
    protected void method_25426() {
        GuiComponentCollector collector = new GuiComponentCollector();
        collectChildren(collector);
        collector.flushTo(this::method_25429, this::method_37060);
    }

    protected abstract void collectChildren(GuiComponentCollector collector);

    private void updateHovered(Object child) {
        if (shouldUpdateHovered() && child instanceof FZHoverableElement hoverable) {
            hoverable.fidgetz$setHovered(fidgetz$getHovered() == hoverable);
        }
    }

    @Override
    protected <T extends class_364 & class_6379> T method_25429(T widget) {
        updateHovered(widget);
        return super.method_25429(widget);
    }

    @Override
    protected <T extends class_4068> T method_37060(T renderable) {
        updateHovered(renderable);
        return super.method_37060(renderable);
    }

    @Override
    protected <T extends class_364 & class_4068 & class_6379> T method_37063(T widget) {
        updateHovered(widget);
        return super.method_37063(widget);
    }

    @Override
    protected void method_37066(class_364 widget) {
        super.method_37066(widget);
        if (widget == method_25399()) {
            method_25395(null);
        }
        if (widget == fidgetz$getHovered()) {
            fidgetz$setHovered(null);
        }
    }

    @Override
    protected void method_37067() {
        super.method_37067();
        method_25395(null);
        fidgetz$setHovered(null);
    }

    protected FZContextMenu.Builder buildContextMenu() {
        return FZContextMenu.builder(this).id(GLOBAL_CONTEXT_MENU_ID);
    }

    protected void openContextMenu(double x, double y, boolean focus) {
        dialogManager.put(buildContextMenu()
                .focusOnOpen(focus)
                .buildAndOpen(x, y, fidgetz$collectContextEntries(x, y)));
    }

    protected boolean canOpenContextMenu(double mouseX, double mouseY, int button) {
        return button == class_3675.field_32002 &&
               dialogManager.get(GLOBAL_CONTEXT_MENU_ID).filter(menu -> menu.method_25405(mouseX, mouseY)).isEmpty();
    }

    protected boolean shouldUpdateHovered() {
        return true;
    }

    protected boolean shouldCloseOnEscape() {
        return true;
    }

    @Override
    @Deprecated
    public final boolean method_25422() {
        return false;
    }

    @Override
    @ApiStatus.Internal
    protected void method_48263(class_8016 componentPath) {
        class_8016 currentPath = method_48218();
        // avoid clearing and reapplying focus
        if (currentPath != null && currentPath.equals(componentPath)) {
            componentPath.method_48195(true);
        } else {
            super.method_48263(componentPath);
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (shouldUpdateHovered()) {
            fidgetz$updateHovered(mouseX, mouseY);
        }
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (fidgetz$captureEventForDialogs(mouseX, mouseY, button)) {
            return true;
        }

        boolean clicked = ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button);

        if (canOpenContextMenu(mouseX, mouseY, button)) {
            openContextMenu(mouseX, mouseY, !clicked);
        }

        return clicked;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (fidgetz$captureEventForDialogs(keyCode) || super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (keyCode == class_3675.field_31958 && shouldCloseOnEscape()) {
            this.method_25419();
            return true;
        }
        return false;
    }

    @Override
    public void method_25365(boolean focused) {
        if (!focused) {
            method_25395(null);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (method_25399() != focused) {
            super.method_25395(focused);
        }
    }

    @Override
    public List<? extends FZDialog> fidgetz$Dialogs() {
        return dialogManager.dialogs();
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(screenRectangle, 0, 0, field_22789, field_22790)) {
            this.screenRectangle = super.method_48202();
        }
        return screenRectangle;
    }
}
