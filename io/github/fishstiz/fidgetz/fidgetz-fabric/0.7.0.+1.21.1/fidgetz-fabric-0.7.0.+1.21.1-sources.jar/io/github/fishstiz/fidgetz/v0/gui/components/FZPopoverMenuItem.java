package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.*;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_9110;

public sealed interface FZPopoverMenuItem {
    Factory factory();

    Settings settings();

    @FunctionalInterface
    interface Factory {
        Entry create(Context context);
    }

    record Settings(
            boolean closeOnInteract,
            boolean autoDividerAfter,
            boolean stretch,
            float xAlignment
    ) {
        private static final Settings DEFAULT_SETTINGS = new Settings(true, true, true, 0.0f);

        public static Settings defaults() {
            return DEFAULT_SETTINGS;
        }

        public Settings withCloseOnInteract(boolean closeOnInteract) {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, xAlignment);
        }

        public Settings withAutoDividerAfter(boolean autoDividerAfter) {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, xAlignment);
        }

        public Settings withStretch(boolean stretch) {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, xAlignment);
        }

        public Settings withXAlign(float xAlignment) {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, xAlignment);
        }

        public Settings withLeftXAlign() {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, 0.0f);
        }

        public Settings withCenterXAlign() {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, 0.5f);
        }

        public Settings withRightXAlign() {
            return new Settings(closeOnInteract, autoDividerAfter, stretch, 1.0f);
        }
    }

    record Widget(Factory factory, Settings settings) implements FZPopoverMenuItem {
        public Widget(Factory factory) {
            this(factory, Settings.defaults());
        }
    }

    record Divider(@Nullable Factory factory, Settings settings) implements FZPopoverMenuItem {
        private static final Settings DEFAULT_SETTINGS = new Settings(false, false, true, 0.0f);

        public Divider(@Nullable Factory factory) {
            this(factory, DEFAULT_SETTINGS);
        }
    }

    static Divider divider() {
        return new Divider(null);
    }

    static Divider createDivider(RenderableRectangle rectangle, int height) {
        return new Divider(ctx -> new FZPopoverMenuEntryImpl.Divider(ctx, rectangle, height));
    }

    static Divider createDivider(class_2960 sprite, int height) {
        return new Divider(ctx -> new FZPopoverMenuEntryImpl.Divider(ctx, Renderables.sprite(sprite), height));
    }

    static Widget fromWidget(Function<Context, class_339> widgetFactory, Settings settings) {
        // cant use WrappedComponent because of some mapping issue on fabric where the default methods of the Entry
        // interface are used instead of the methods on the concrete WrappedComponent class
        class Wrapped implements Entry, ContainerEventHandlerPatch, FZHoverableContainer {
            private final Context context;
            private final class_339 widget;
            private final List<class_339> children;
            private boolean dragging;
            private @Nullable class_364 fidgetz$hoveredElement;

            Wrapped(Context context) {
                this.context = context;
                this.widget = widgetFactory.apply(context);
                this.children = List.of(widget);
            }

            @Override
            public Context context() {
                return context;
            }

            @Override
            public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
                widget.method_25394(graphics, mouseX, mouseY, partialTick);
            }

            @Override
            public void method_46421(int x) {
                widget.method_46421(x);
            }

            @Override
            public void method_46419(int y) {
                widget.method_46419(y);
            }

            @Override
            public void setWidth(int width) {
                widget.method_25358(width);
            }

            @Override
            public int method_46426() {
                return widget.method_46426();
            }

            @Override
            public int method_46427() {
                return widget.method_46427();
            }

            @Override
            public int method_25368() {
                return widget.method_25368();
            }

            @Override
            public int method_25364() {
                return widget.method_25364();
            }

            @Override
            public void method_25365(boolean focused) {
                widget.method_25365(focused);
            }

            @Override
            public boolean method_25370() {
                return widget.method_25370();
            }

            @Override
            public void method_37020(class_6382 output) {
                widget.method_37020(output);
            }

            @Override
            public class_6380 method_37018() {
                return widget.method_37018();
            }

            @Override
            public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
                return class_8016.method_48192(this, widget.method_48205(navigationEvent));
            }

            @Override
            public void method_48206(Consumer<class_339> widgetVisitor) {
                widget.method_48206(widgetVisitor);
            }

            @Override
            public class_8030 method_48202() {
                return widget.method_48202();
            }

            @Override
            public void method_16014(double mouseX, double mouseY) {
                widget.method_16014(mouseX, mouseY);
            }

            @Override
            public List<class_339> method_25396() {
                return children;
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                return widget.method_25402(mouseX, mouseY, button);
            }

            @Override
            public boolean method_25406(double mouseX, double mouseY, int button) {
                return widget.method_25406(mouseX, mouseY, button);
            }

            @Override
            public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
                return widget.method_25403(mouseX, mouseY, button, dragX, dragY);
            }

            @Override
            public boolean method_25397() {
                return dragging;
            }

            @Override
            public void method_25398(boolean dragging) {
                this.dragging = dragging;
            }

            @Override
            public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
                return widget.method_25401(mouseX, mouseY, scrollX, scrollY);
            }

            @Override
            public boolean method_25404(int keyCode, int scanCode, int modifiers) {
                return widget.method_25404(keyCode, scanCode, modifiers);
            }

            @Override
            public boolean method_16803(int keyCode, int scanCode, int modifiers) {
                return widget.method_16803(keyCode, scanCode, modifiers);
            }

            @Override
            public boolean method_25400(char codePoint, int modifiers) {
                return widget.method_25400(codePoint, modifiers);
            }

            @Override
            public @Nullable class_364 method_25399() {
                return widget.method_25370() ? widget : null;
            }

            @Override
            public void method_25395(@Nullable class_364 focused) {
                if (focused == null) {
                    widget.method_25365(false);
                } else if (focused == widget) {
                    widget.method_25365(true);
                }
            }

            @Override
            public boolean method_25405(double mouseX, double mouseY) {
                return widget.method_25405(mouseX, mouseY);
            }

            @Override
            public @Nullable class_8016 method_48218() {
                return class_8016.method_48192(this, widget.method_48218());
            }

            @Override
            public int method_48590() {
                return widget.method_48590();
            }

            @Override
            public void method_48229(int x, int y) {
                widget.method_48229(x, y);
            }

            @Override
            public boolean method_37303() {
                return widget.method_37303();
            }

            @Override
            public boolean fidgetz$shouldTakeFocusAfterInteraction() {
                return widget instanceof FZComponent component
                        ? component.fidgetz$shouldTakeFocusAfterInteraction()
                        : Entry.super.fidgetz$shouldTakeFocusAfterInteraction();
            }

            @Override
            public @Nullable class_364 fidgetz$getHovered() {
                return fidgetz$hoveredElement;
            }

            @Override
            public void fidgetz$setHovered(@Nullable class_364 hovered) {
                class_364 previous = fidgetz$getHovered();
                if (previous != hovered) {
                    if (previous instanceof FZHoverableElement previousElement) {
                        previousElement.fidgetz$setHovered(false);
                    }

                    if (hovered instanceof FZHoverableElement hoveredElement) {
                        hoveredElement.fidgetz$setHovered(true);
                    }

                    fidgetz$hoveredElement = hovered;
                }
            }
        }

        return new Widget(Wrapped::new, settings);
    }

    static Widget fromWidget(Function<Context, class_339> widgetFactory, UnaryOperator<Settings> settingsBuilder) {
        return fromWidget(widgetFactory, settingsBuilder.apply(Settings.defaults()));
    }

    static Widget fromWidget(class_339 widget, Settings settings) {
        return fromWidget(ignored -> widget, settings);
    }

    static Widget fromWidget(class_339 widget, UnaryOperator<Settings> settingsBuilder) {
        return fromWidget(widget, settingsBuilder.apply(Settings.defaults()));
    }

    static Widget fromWidget(Function<Context, class_339> widgetFactory) {
        return fromWidget(widgetFactory, Settings.defaults());
    }

    static Widget fromWidget(class_339 widget) {
        return fromWidget(widget, Settings.defaults());
    }

    static Builder builder() {
        return new Builder();
    }

    @ApiStatus.NonExtendable
    interface Context {
        void closeMenu();

        boolean isActive();

        boolean isHovered();

        boolean isFocused();

        boolean isChildOpened();

        class_8030 getRectangle();

        default boolean isFocusedOrHovered() {
            return isFocused() || isHovered();
        }
    }

    interface Entry extends class_8021, class_364, class_6379, class_4068, FZComponent {
        int DEFAULT_HEIGHT = 20;

        Context context();

        default List<FZPopoverMenuItem> childItems() {
            return Collections.emptyList();
        }

        @Override
        default void method_46421(int x) {
        }

        @Override
        default void method_46419(int y) {
        }

        default void setWidth(int width) {
        }

        @Override
        default int method_46426() {
            return context().getRectangle().method_49620();
        }

        @Override
        default int method_46427() {
            return context().getRectangle().method_49618();
        }

        @Override
        default int method_25364() {
            return DEFAULT_HEIGHT;
        }

        @Override
        default void method_25365(boolean focused) {
        }

        @Override
        default boolean method_25370() {
            return context().isFocused();
        }

        @Override
        default void method_37020(class_6382 output) {
        }

        @Override
        default class_6379.class_6380 method_37018() {
            if (method_37303()) {
                if (method_25370()) {
                    return class_6379.class_6380.field_33786;
                } else if (context().isHovered()) {
                    return class_6379.class_6380.field_33785;
                }
            }
            return class_6379.class_6380.field_33784;
        }

        @Override
        default @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            if (!method_37303()) return null;
            return !method_25370() ? class_8016.method_48193(this) : null;
        }

        @Override
        default void method_48206(Consumer<class_339> widgetVisitor) {
        }

        @Override
        default class_8030 method_48202() {
            return class_8021.super.method_48202();
        }
    }

    final class Builder {
        private static final int DEFAULT_WIDTH = 150;
        private static final Supplier<WidgetRenderables> DEFAULT_BACKGROUND;
        private final List<FZPopoverMenuItem> children = new ArrayList<>();
        private @Nullable Supplier<@Nullable WidgetRenderables> backgroundSupplier = DEFAULT_BACKGROUND;
        private @Nullable Supplier<@Nullable WidgetElements> iconSupplier;
        private @Nullable Supplier<@Nullable class_2561> messageSupplier;
        private FZPopoverMenuEntryImpl.@Nullable TooltipHolder tooltipHolder;
        private @Nullable BooleanSupplier activeSupplier;
        private @Nullable Function<PressEvent, Boolean> pressHandler;
        private boolean closeOnInteraction = true;
        private boolean allowDivideAfterEntry = true;
        private boolean playClickSoundOnInteraction = true;
        private int height = Entry.DEFAULT_HEIGHT;
        private int minWidth = DEFAULT_WIDTH;

        static {
            RenderableRectangle background = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry")).withBlend();
            RenderableRectangle highlighted = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry_highlighted")).withBlend();
            WidgetRenderables renderables = new WidgetRenderables(background, background, highlighted);
            DEFAULT_BACKGROUND = () -> renderables;
        }

        private Builder() {
        }

        public record PressEvent(Context context, FZPopoverMenuItem.Entry entry) {
        }

        public Builder background(@Nullable Supplier<@Nullable WidgetRenderables> backgroundSupplier) {
            this.backgroundSupplier = backgroundSupplier;
            return this;
        }

        public Builder background(WidgetRenderables background) {
            Objects.requireNonNull(background, "background cannot be null");
            return background(() -> background);
        }

        public Builder background(RenderableRectangle background) {
            return background(new WidgetRenderables(Objects.requireNonNull(background, "background cannot be null")));
        }

        public Builder icon(@Nullable Supplier<@Nullable WidgetElements> iconSupplier) {
            this.iconSupplier = iconSupplier;
            return this;
        }

        public Builder icon(WidgetElements icon) {
            return icon(() -> icon);
        }

        public Builder icon(WidgetRenderables icon) {
            Objects.requireNonNull(icon, "icon cannot be null");
            return icon(new WidgetElements(icon, 16, 16));
        }

        public Builder icon(RenderableRectangle icon) {
            Objects.requireNonNull(icon, "icon cannot be null");
            return icon(new WidgetRenderables(icon));
        }

        public Builder message(@Nullable Supplier<@Nullable class_2561> textSupplier) {
            this.messageSupplier = textSupplier;
            return this;
        }

        public Builder message(@Nullable class_2561 message) {
            return message(() -> message);
        }

        public Builder tooltip(@Nullable Supplier<@Nullable class_7919> tooltipSupplier) {
            this.tooltipHolder = tooltipSupplier == null ? null : new FZPopoverMenuEntryImpl.TooltipHolder(tooltipSupplier);
            return this;
        }

        public Builder tooltip(@Nullable class_7919 tooltip) {
            return tooltip(() -> tooltip);
        }

        public Builder tooltip(@Nullable class_9110 tooltipHolder) {
            this.tooltipHolder = tooltipHolder == null ? null : new FZPopoverMenuEntryImpl.TooltipHolder(tooltipHolder);
            return this;
        }

        public Builder active(@Nullable BooleanSupplier activeSupplier) {
            this.activeSupplier = activeSupplier;
            return this;
        }

        public Builder active(boolean active) {
            return active(() -> active);
        }

        public Builder active() {
            return active(true);
        }

        public Builder child(FZPopoverMenuItem child) {
            children.add(child);
            return this;
        }

        public Builder child(UnaryOperator<Builder> builderConfigurator) {
            children.add(builderConfigurator.apply(builder()).build());
            return this;
        }

        public Builder nextSection() {
            return child(divider());
        }

        public Builder children(List<FZPopoverMenuItem> children) {
            this.children.addAll(children);
            return this;
        }

        public Builder closeOnInteraction(boolean closeOnInteraction) {
            this.closeOnInteraction = closeOnInteraction;
            return this;
        }

        public Builder closeOnInteraction() {
            return closeOnInteraction(true);
        }

        public Builder allowAutoDivideAfterEntry(boolean allowAutoDivideAfterEntry) {
            this.allowDivideAfterEntry = allowAutoDivideAfterEntry;
            return this;
        }

        public Builder allowAutoDivideAfterEntry() {
            this.allowDivideAfterEntry = true;
            return this;
        }

        public Builder playClickSoundOnInteraction(boolean playClickSoundOnInteraction) {
            this.playClickSoundOnInteraction = playClickSoundOnInteraction;
            return this;
        }

        public Builder playClickSoundOnInteraction() {
            return playClickSoundOnInteraction(true);
        }

        public Builder height(int height) {
            this.height = height;
            return this;
        }

        public Builder minWidth(int width) {
            this.minWidth = width;
            return this;
        }

        public Builder onPress(@Nullable Function<PressEvent, Boolean> pressHandler) {
            this.pressHandler = pressHandler;
            return this;
        }

        public Builder onPress(BooleanSupplier pressHandler) {
            Objects.requireNonNull(pressHandler, "pressHandler is null");
            return onPress(ignored -> pressHandler.getAsBoolean());
        }

        public Builder onPress(Runnable mouseAction) {
            Objects.requireNonNull(mouseAction, "mouseAction is null");
            return onPress(ignored -> {
                mouseAction.run();
                return true;
            });
        }

        public Builder preventPress() {
            this.pressHandler = null;
            return this;
        }

        public FZPopoverMenuItem build() {
            return new FZPopoverMenuItem.Widget(
                    ctx -> new FZPopoverMenuEntryImpl(
                            ctx,
                            children,
                            backgroundSupplier == null ? FunctionUtils.nullSupplier() : backgroundSupplier,
                            iconSupplier == null ? FunctionUtils.nullSupplier() : iconSupplier,
                            messageSupplier == null ? FunctionUtils.nullSupplier() : messageSupplier,
                            tooltipHolder == null ? new class_9110() : tooltipHolder,
                            activeSupplier == null ? () -> true : activeSupplier,
                            pressHandler == null ? ignored -> true : pressHandler,
                            playClickSoundOnInteraction,
                            height,
                            minWidth
                    ),
                    new Settings(closeOnInteraction, allowDivideAfterEntry, true, 0.0f)
            );
        }
    }
}