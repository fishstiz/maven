package io.github.fishstiz.fidgetz.v0.gui.layouts;

import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_7838;
import net.minecraft.class_7847;
import net.minecraft.class_8021;
import net.minecraft.class_8027;
import net.minecraft.class_8029;
import net.minecraft.class_8030;

public class FZAutoGridLayout extends class_7838 implements FZLayout {
    private final Supplier<class_8030> screenArea;
    private final class_7847 defaultChildSettings = class_7847.method_46481();
    private final List<ChildContainer> children = new ArrayList<>();
    private final class_8027 axis;
    private int minCellWidth;
    private int minCellHeight;
    private int maxCellWidth;
    private int maxCellHeight;
    private int mainSpacing;
    private int crossSpacing;
    private int maxWidth;
    private int maxHeight;
    private Justification mainJustification = Justification.START;
    private Justification crossJustification = Justification.START;

    public FZAutoGridLayout(Supplier<class_8030> screenArea, class_8027 axis) {
        super(0, 0, screenArea.get().comp_1196(), screenArea.get().comp_1197());
        this.screenArea = screenArea;
        this.axis = axis;
    }

    static FZAutoGridLayout auto(Supplier<class_8030> screenArea, class_8027 axis) {
        return new FZAutoGridLayout(screenArea, axis);
    }

    public static FZAutoGridLayout horizontal() {
        return auto(class_8030::method_48248, class_8027.field_41822);
    }

    public static FZAutoGridLayout horizontal(class_437 screen) {
        return new FZAutoGridLayout(screen::method_48202, class_8027.field_41822);
    }

    public static FZAutoGridLayout horizontal(class_8021 container) {
        return new FZAutoGridLayout(container::method_48202, class_8027.field_41822);
    }

    public static FZAutoGridLayout vertical() {
        return auto(class_8030::method_48248, class_8027.field_41823);
    }

    public static FZAutoGridLayout vertical(class_437 screen) {
        return new FZAutoGridLayout(screen::method_48202, class_8027.field_41823);
    }

    public static FZAutoGridLayout vertical(class_8021 container) {
        return new FZAutoGridLayout(container::method_48202, class_8027.field_41823);
    }

    private static <T> T getAxisValue(class_8027 axis, T horizontalValue, T verticalValue) {
        return switch (axis) {
            case field_41822 -> horizontalValue;
            case field_41823 -> verticalValue;
        };
    }

    private <T> T getMainValue(T horizontalValue, T verticalValue) {
        return getAxisValue(axis, horizontalValue, verticalValue);
    }

    private <T> T getCrossValue(T horizontalValue, T verticalValue) {
        return getAxisValue(axis.method_48232(), horizontalValue, verticalValue);
    }

    public FZAutoGridLayout maxWidth(int maxWidth) {
        this.maxWidth = MathUtils.optionalMin(maxWidth, screenArea.get().comp_1196());
        return this;
    }

    public FZAutoGridLayout maxHeight(int maxHeight) {
        this.maxHeight = MathUtils.optionalMin(maxHeight, screenArea.get().comp_1197());
        return this;
    }

    public FZAutoGridLayout minCellWidth(int minCellWidth) {
        this.minCellWidth = minCellWidth;
        return this;
    }

    public FZAutoGridLayout minCellHeight(int minCellHeight) {
        this.minCellHeight = minCellHeight;
        return this;
    }

    public FZAutoGridLayout maxCellWidth(int maxCellWidth) {
        this.maxCellWidth = maxCellWidth;
        return this;
    }

    public FZAutoGridLayout maxCellHeight(int maxCellHeight) {
        this.maxCellHeight = maxCellHeight;
        return this;
    }

    public FZAutoGridLayout cellWidth(int cellWidth) {
        return maxCellWidth(cellWidth).minCellWidth(cellWidth);
    }

    public FZAutoGridLayout cellHeight(int cellHeight) {
        return maxCellHeight(cellHeight).minCellHeight(cellHeight);
    }

    public FZAutoGridLayout rowSpacing(int spacing) {
        switch (axis) {
            case field_41823 -> this.mainSpacing = spacing;
            case field_41822 -> this.crossSpacing = spacing;
        };
        return this;
    }

    public FZAutoGridLayout colSpacing(int spacing) {
        switch (axis) {
            case field_41822 -> this.mainSpacing = spacing;
            case field_41823 -> this.crossSpacing = spacing;
        }
        return this;
    }

    public FZAutoGridLayout spacing(int spacing) {
        return rowSpacing(spacing).colSpacing(spacing);
    }

    public FZAutoGridLayout justifyContents(Justification justification) {
        this.mainJustification = justification;
        return this;
    }

    public FZAutoGridLayout alignContents(Justification justification) {
        this.crossJustification = justification;
        return this;
    }

    @Override
    public void fidgetz$setWidth(int width) {
        int previousMaxWidth = this.maxWidth;
        maxWidth(width);
        if (previousMaxWidth != maxWidth) {
            method_48222();
        }
    }

    @Override
    public void fidgetz$setHeight(int height) {
        int previousMaxHeight = this.maxHeight;
        maxHeight(height);
        if (previousMaxHeight != maxHeight) {
            method_48222();
        }
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        int previousMaxWidth = this.maxWidth;
        int previousMaxHeight = this.maxHeight;
        maxWidth(width).maxHeight(height);
        if (previousMaxWidth != maxWidth || previousMaxHeight != maxHeight) {
            method_48222();
        }
    }

    private int getMaxLength(class_8027 axis) {
        return switch (axis) {
            case field_41822 -> MathUtils.eitherOptionalMin(maxWidth, screenArea.get().comp_1196());
            case field_41823 -> MathUtils.eitherOptionalMin(maxHeight, screenArea.get().comp_1197());
        };
    }

    public <T extends class_339> T child(T child, class_7847 settings) {
        children.add(new ChildContainer(child, settings, () -> child.field_22764));
        return child;
    }

    public <T extends class_339> T child(T child) {
        return child(child, defaultChildSettings);
    }

    public <T extends FZFlexElement> T child(T child, class_7847 settings) {
        children.add(new ChildContainer(child, settings, child::fidgetz$isVisible));
        return child;
    }

    public <T extends FZFlexElement> T child(T child) {
        return child(child, defaultChildSettings);
    }

    public <T extends class_8021> T child(T child, class_7847 settings) {
        children.add(new ChildContainer(child, settings, () -> true));
        return child;
    }

    public <T extends class_8021> T child(T child) {
        return child(child, defaultChildSettings);
    }

    @Override
    public void method_48222() {
        super.method_48222();

        final class_8027 crossAxis = axis.method_48232();
        int maxMain = getMaxLength(axis);
        int maxCross = getMaxLength(crossAxis);

        int mainMaxCell = getAxisValue(axis, this.maxCellWidth, this.maxCellHeight);
        int crossMaxCell = getAxisValue(crossAxis, this.maxCellWidth, this.maxCellHeight);

        int mainCellSize = MathUtils.optionalMin(getAxisValue(axis, this.minCellWidth, this.minCellHeight), mainMaxCell);
        int crossCellSize = MathUtils.optionalMin(getAxisValue(crossAxis, this.minCellWidth, this.minCellHeight), crossMaxCell);

        List<ChildContainer> visibleChildren = new ArrayList<>(children.size());

        for (ChildContainer container : children) {
            if (container.visible()) {
                visibleChildren.add(container);
                mainCellSize = MathUtils.clampOptionalMax(container.getLength(axis), mainCellSize, mainMaxCell);
                crossCellSize = MathUtils.clampOptionalMax(container.getLength(crossAxis), crossCellSize, crossMaxCell);
            }
        }

        if (visibleChildren.isEmpty() || (mainCellSize == 0 && crossCellSize == 0)) {
            this.field_41813 = 0;
            this.field_41814 = 0;
            return;
        }

        if (maxMain == 0) {
            maxMain = visibleChildren.size() * mainCellSize + Math.max(0, visibleChildren.size() - 1) * this.mainSpacing;
        }

        int mainCount = (maxMain + this.mainSpacing) / (mainCellSize + this.mainSpacing);
        int crossCount = (int) Math.ceil((double) visibleChildren.size() / mainCount);

        Justification.Results mainJustified = this.mainJustification.compute(
                getAxisValue(axis, method_46426(), method_46427()),
                this.mainSpacing,
                mainCount,
                maxMain - (mainCount * (mainCellSize + this.mainSpacing) - this.mainSpacing)
        );

        int occupiedCross = crossCount * (crossCellSize + this.crossSpacing) - this.crossSpacing;

        Justification.Results crossJustified = this.crossJustification.compute(
                getAxisValue(crossAxis, method_46426(), method_46427()),
                this.crossSpacing,
                crossCount,
                Math.max(0, maxCross - occupiedCross)
        );

        int[] mainOffsets = new int[mainCount];
        int mainPos = mainJustified.pos();
        for (int i = 0; i < mainCount; i++) {
            mainOffsets[i] = mainPos;
            mainPos += mainCellSize + mainJustified.adjustSpacing(i);
        }

        int[] crossOffsets = new int[crossCount];
        int crossPos = crossJustified.pos();
        for (int i = 0; i < crossCount; i++) {
            crossOffsets[i] = crossPos;
            crossPos += crossCellSize + crossJustified.adjustSpacing(i);
        }

        for (int i = 0; i < visibleChildren.size(); i++) {
            ChildContainer container = visibleChildren.get(i);
            int mainIndex = i % mainCount;
            int crossIndex = i / mainCount;

            container.setPosition(axis, mainOffsets[mainIndex], mainCellSize);
            container.setPosition(crossAxis, crossOffsets[crossIndex], crossCellSize);
        }

        if (maxCross == 0) {
            maxCross = Math.max(0, occupiedCross);
        }

        class_8029 size = class_8029.method_48246(axis, maxMain, maxCross);
        this.field_41813 = size.comp_1193();
        this.field_41814 = size.comp_1194();
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        this.children.forEach(container -> layoutElementVisitor.accept(container.field_40752));
    }

    public void removeChildren() {
        this.children.clear();
    }

    private static class ChildContainer extends class_7838.class_7839 {
        private final BooleanSupplier visibleSupplier;

        protected ChildContainer(
                class_8021 child,
                class_7847 layoutSettings,
                BooleanSupplier visibleSupplier
        ) {
            super(child, layoutSettings);
            this.visibleSupplier = visibleSupplier;
        }

        boolean visible() {
            return visibleSupplier.getAsBoolean();
        }

        private void setPosition(class_8027 axis, int position, int availableSpace) {
            switch (axis) {
                case field_41822 -> method_46423(position, availableSpace);
                case field_41823 -> method_46425(position, availableSpace);
            }
        }

        private int getLength(class_8027 axis) {
            return switch (axis) {
                case field_41822 -> method_46424();
                case field_41823 -> method_46422();
            };
        }

        private int getPosition(class_8027 axis) {
            return switch (axis) {
                case field_41822 -> field_40752.method_46426();
                case field_41823 -> field_40752.method_46427();
            };
        }
    }
}