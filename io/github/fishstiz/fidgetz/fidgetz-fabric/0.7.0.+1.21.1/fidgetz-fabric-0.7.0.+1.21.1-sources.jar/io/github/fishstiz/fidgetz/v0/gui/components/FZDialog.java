package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4068;
import net.minecraft.class_4069;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;

public abstract class FZDialog extends FZContainer implements FZComponent, FZPopover, ContainerEventHandlerPatch {
    protected static final int DEFAULT_POPOVER_ORDER = 0;
    protected final class_4069 container;
    protected @Nullable String componentId;
    protected int popoverOrder = DEFAULT_POPOVER_ORDER;
    private @Nullable class_8016 lastContainerFocusPath;
    private boolean open;

    protected FZDialog(class_4069 container) {
        this.container = container;
    }

    public boolean shouldCloseOnEscape() {
        return true;
    }

    public boolean shouldCaptureClick() {
        return true;
    }

    public boolean shouldCloseAfterClickOutOfBounds() {
        return true;
    }

    public boolean shouldCaptureFocus() {
        return true;
    }

    public boolean shouldFocusOnOpen() {
        return true;
    }

    public boolean shouldRefocusLastPath() {
        return true;
    }

    public boolean isOpen() {
        return open;
    }

    protected void setOpen(boolean open) {
        boolean previous = isOpen();
        this.open = open;

        if (previous != isOpen()) {
            if (isOpen()) {
                lastContainerFocusPath = container.method_48218();
                onOpen();
            } else {
                onClose();
            }
        }
    }

    protected void refocusLastContainerPath() {
        if (shouldRefocusLastPath() && lastContainerFocusPath != null) {
            MutableObject<@Nullable List<? extends class_364>> current = new MutableObject<>();
            class_8016 path = NavigationUtils.takeWhile(lastContainerFocusPath, component -> {
                List<? extends class_364> children = current.getValue();
                if (children == null || children.contains(component)) {
                    current.setValue(component instanceof class_4069 subContainer ? subContainer.method_25396() : null);
                    return true;
                }
                return false;
            });
            if (path != null) {
                path.method_48195(true);
            }

            lastContainerFocusPath = null;
        }
    }

    protected void onClose() {
        class_8016 parentFocusPath = container.method_48218();
        boolean focused = NavigationUtils.inFocusPath(container, this);

        if (focused) {
            NavigationUtils.findParent(parentFocusPath, containerPath -> containerPath.comp_1190().comp_1188() == this)
                    .ifPresent(parentPath -> parentPath.method_48195(false));
        }

        class_8016 path = method_48218();
        if (path != null) {
            path.method_48195(false);
        }
    }

    protected void onOpen() {
        if (shouldFocusOnOpen()) {
            class_8016 path = NavigationUtils.findPath(container, this);
            if (path != null) {
                path.method_48195(true);
            }
        }
    }

    @Override
    public abstract class_8030 method_48202();

    protected boolean areCoordinatesInBounds(double x, double y) {
        return method_48202().method_58137((int) x, (int) y);
    }

    protected void extractDialogRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        for (class_4068 renderable : renderables()) {
            renderable.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    protected float getZ() {
        return Math.abs(DEFAULT_ORDER - fidgetz$popoverOrder());
    }

    @Override
    public final void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (isOpen()) {
            graphics.method_51448().method_22903();
            graphics.method_51448().method_46416(0f, 0f, getZ());
            extractDialogRenderState(graphics, mouseX, mouseY, partialTick);
            graphics.method_51448().method_22909();
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!isOpen()) return false;
        if (super.method_25402(mouseX, mouseY, button)) return true;
        return shouldCaptureClick()
               // 1.21.1 only, default mouseClicked would iterate through all children, this will stop it
               || method_25405(mouseX, mouseY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!isOpen()) {
            return false;
        }
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (keyCode == class_3675.field_31958 && shouldCloseOnEscape()) {
            setOpen(false);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return isOpen() && (shouldCaptureClick() || areCoordinatesInBounds(mouseX, mouseY));
    }

    public @Nullable class_8016 method_48205(class_8023 event) {
        if (!isOpen()) return null;

        class_8016 next = super.method_48205(event);
        if (next != null) return next;

        if (event instanceof class_8023.class_8025 && !method_25396().isEmpty()) {
            return NavigationUtils.initialFocus(this);
        }

        return shouldCaptureFocus() ? method_48218() : null;
    }

    public void repositionElements() {
    }

    @Override
    public void fidgetz$visitWidgets(WidgetVisitor visitor) {
        visitor.visitWidget(this);
    }

    @Override
    public void fidgetz$visitRenderables(Consumer<class_4068> visitor) {
        visitor.accept(this);
    }

    @Override
    public int fidgetz$popoverOrder() {
        return popoverOrder;
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return componentId;
    }

    @Override
    public boolean fidgetz$shouldTakeFocusAfterInteraction() {
        return isOpen();
    }
}
