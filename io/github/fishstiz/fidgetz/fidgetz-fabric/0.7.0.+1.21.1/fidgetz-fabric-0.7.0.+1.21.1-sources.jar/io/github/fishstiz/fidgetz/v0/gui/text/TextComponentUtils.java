package io.github.fishstiz.fidgetz.v0.gui.text;

import net.minecraft.class_2561;

public final class TextComponentUtils {
    public static final class_2561 BLACK_RIGHT_POINTING_TRIANGLE = class_2561.method_43470("▶");
    public static final class_2561 BLACK_DOWN_POINTING_TRIANGLE = class_2561.method_43470("▼");
    public static final class_2561 BLACK_SQUARE = class_2561.method_43470("■");

    private TextComponentUtils() {
    }
}
