package io.github.fishstiz.fidgetz.v0.gui.components.color;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import net.minecraft.class_332;
import net.minecraft.class_8012;

public record SaturationValueGradient(int color) implements RenderableRectangle {
    private static final int BLACK_TRANSPARENT = 0x00000000;

    @Override
    public void extractRenderState(
            class_332 graphics,
            int left,
            int top,
            int width,
            int height,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        extractRenderState(graphics, left, top, left + width, top + height, color);
    }

    public static void extractRenderState(
            class_332 graphics,
            int left,
            int top,
            int right,
            int bottom,
            int color
    ) {
        GuiGraphicsUtils.fillHorizontal(
                graphics,
                left,
                top,
                right,
                bottom,
                class_8012.field_42973,
                color
        );

        graphics.method_25296(
                left,
                top,
                right,
                bottom,
                BLACK_TRANSPARENT,
                class_8012.field_42974
        );
    }
}
