package io.github.fishstiz.fidgetz.v0.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.fishstiz.fidgetz.v0.Fidgetz;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public final class GuiGraphicsUtils {
    private static final class_2960 BOX_SHADOW_SPRITE = Fidgetz.id("box_shadow");
    private static final float BOX_SHADOW_BORDER = 48f;
    private static final class_2960 CHECKERBOARD_TEXTURE = Fidgetz.id("textures/gui/checkerboard.png");
    private static final int CHECKERBOARD_TEXTURE_SIZE = 16;
    private static final int CHECKERBOARD_TEXEL_SIZE = 8;

    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height) {
        graphics.method_52706(sprite, x, y, width, height);
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int uWidth,
            int vHeight,
            int textureWidth,
            int textureHeight
    ) {
        graphics.method_25293(
                texture,
                x,
                y,
                width,
                height,
                u,
                v,
                uWidth,
                vHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                0,
                0,
                width, height,
                textureWidth, textureHeight
        );
    }

    public static void texture(class_332 graphics, class_2960 texture, int x, int y, int textureWidth, int textureHeight) {
        texture(graphics, texture, x, y, textureWidth, textureHeight, textureWidth, textureHeight);
    }

    public static void fillFloat(class_332 graphics, float left, float top, float right, float bottom, int color) {
        class_4588 vertexConsumer = graphics.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = graphics.method_51448().method_23760().method_23761();
        vertexConsumer.method_22918(matrix4f, left, top, 0).method_39415(color);
        vertexConsumer.method_22918(matrix4f, left, bottom, 0).method_39415(color);
        vertexConsumer.method_22918(matrix4f, right, bottom, 0).method_39415(color);
        vertexConsumer.method_22918(matrix4f, right, top, 0).method_39415(color);
    }

    public static void fillHorizontal(class_332 graphics, int left, int top, int right, int bottom, int colorFrom, int colorTo) {
        class_4588 vertexConsumer = graphics.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = graphics.method_51448().method_23760().method_23761();
        vertexConsumer.method_22918(matrix4f, left, top, 0).method_39415(colorFrom);
        vertexConsumer.method_22918(matrix4f, left, bottom, 0).method_39415(colorFrom);
        vertexConsumer.method_22918(matrix4f, right, bottom, 0).method_39415(colorTo);
        vertexConsumer.method_22918(matrix4f, right, top, 0).method_39415(colorTo);
    }

    public static void text(class_332 graphics, class_2561 text, int x, int y, int color) {
        graphics.method_27535(class_310.method_1551().field_1772, text, x, y, color);
    }

    public static void scrollingText(
            class_332 graphics,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom,
            int color,
            boolean shadow
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_51439(font, component, left - (int) scrollOffset, textY, color, shadow);
            graphics.method_44380();
        } else {
            graphics.method_51439(font, component, left, textY, color, shadow);
        }
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color, boolean shadow) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color, shadow);
    }

    public static void scrollingText(class_332 graphics, class_327 font, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, font, component, left, top, right, bottom, color, true);
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color);
    }

    public static void scrollingCenteredText(
            class_332 graphics,
            class_2561 component,
            int centerX,
            int left,
            int right,
            int top,
            int bottom,
            int color
    ) {
        class_327 font = class_310.method_1551().field_1772;
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_27535(font, component, left - (int) scrollOffset, textY, color);
            graphics.method_44380();
        } else {
            int i1 = class_3532.method_15340(centerX, left + textWidth / 2, right - textWidth / 2);
            graphics.method_27534(font, component, i1, textY, color);
        }
    }

    public static void boxShadow(
            class_332 graphics,
            int x,
            int y,
            int width,
            int height,
            float shadowSize,
            float shadowOffsetX,
            float shadowOffsetY
    ) {
        float scale = shadowSize / BOX_SHADOW_BORDER;
        int baseOffset = Math.round(BOX_SHADOW_BORDER * scale);
        int offsetX = Math.round(baseOffset + shadowOffsetX);
        int offsetY = Math.round(baseOffset + shadowOffsetY);

        RenderSystem.enableBlend();
        RenderSystem.depthMask(false);
        sprite(graphics, BOX_SHADOW_SPRITE, x - offsetX, y - offsetY, width + offsetX * 2, height + offsetY * 2);
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    public static void checkerboard(
            class_332 graphics,
            int left,
            int top,
            int width,
            int height,
            int cellSize,
            int uOffset,
            int vOffset
    ) {
        float scale = (float) CHECKERBOARD_TEXEL_SIZE / cellSize;

        float uTexelStart = (uOffset * scale) % CHECKERBOARD_TEXTURE_SIZE;
        float vTexelStart = (vOffset * scale) % CHECKERBOARD_TEXTURE_SIZE;

        if (uTexelStart < 0) uTexelStart += CHECKERBOARD_TEXTURE_SIZE;
        if (vTexelStart < 0) vTexelStart += CHECKERBOARD_TEXTURE_SIZE;

        graphics.method_25293(
                CHECKERBOARD_TEXTURE,
                left,
                top,
                width,
                height,
                uTexelStart,
                vTexelStart,
                (int) (width * scale),
                (int) (height * scale),
                CHECKERBOARD_TEXTURE_SIZE,
                CHECKERBOARD_TEXTURE_SIZE
        );
    }

    public static void checkerboard(class_332 graphics, int left, int top, int width, int height, int cellSize) {
        checkerboard(graphics, left, top, width, height, cellSize, 0, 0);
    }

    private GuiGraphicsUtils() {
    }
}
