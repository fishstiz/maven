package io.github.fishstiz.fidgetz.v0.gui.text;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_2583;
import net.minecraft.class_5224;
import net.minecraft.class_5481;

public final class TextStyleFormatter implements BiFunction<String, Integer, class_5481> {
    private final TextStyleMatcher[] matchers;
    private final Supplier<String> fullText;
    private final Executor executor;
    private final StyledSequence readSequence = new StyledSequence();
    private final StyledSequence writeSequence = new StyledSequence();
    private final Runnable styleFinder = this::findStyles;
    private volatile StyledSequence currentSequence = readSequence;
    private volatile String lastText = "";

    public TextStyleFormatter(List<TextStyleMatcher> matchers, Supplier<String> fullText, Executor executor) {
        this.matchers = matchers.stream().map(TextStyleMatcher::copy).toArray(TextStyleMatcher[]::new);
        this.fullText = fullText;
        this.executor = executor;
    }

    public TextStyleFormatter(List<TextStyleMatcher> matchers, Supplier<String> fullText) {
        this(matchers, fullText, class_156.method_18349());
    }

    // prevents flashing unformatted styles when rebuilt
    public void initializeStyles(TextStyleFormatter formatter) {
        StyledSequence prevSeq = formatter.currentSequence;
        String prevText = prevSeq.text;
        if (prevText.isEmpty()) return;

        readSequence.text = prevText;
        readSequence.charStyles.size(prevSeq.charStyles.size());
        for (int i = 0; i < prevSeq.charStyles.size(); i++) {
            readSequence.charStyles.set(i, prevSeq.charStyles.get(i));
        }
        currentSequence = readSequence;
    }

    @Override
    public @Nullable class_5481 apply(String displayText, Integer displayPos) {
        String currentText = fullText.get();
        if (currentText.isBlank()) return null;

        StyledSequence current = currentSequence;
        current.text = currentText;
        current.displayPos = displayPos;
        current.displayEnd = displayPos + displayText.length();

        if (!currentText.equals(lastText)) {
            lastText = currentText;
            executor.execute(styleFinder);
        }

        return current;
    }

    private void findStyles() {
        StyledSequence write = (currentSequence == readSequence) ? writeSequence : readSequence;
        String text = lastText;

        write.text = text;
        write.charStyles.size(text.length());
        Arrays.fill(write.charStyles.elements(), 0, write.charStyles.size(), null);

        for (TextStyleMatcher matcher : matchers) {
            if (!matcher.styleable(text)) continue;
            matcher.reset(text);
            while (matcher.find()) {
                for (int i = matcher.start(); i < matcher.end(); i++) {
                    write.charStyles.set(i, matcher.style());
                }
            }
        }

        currentSequence = write;
    }

    private static final class StyledSequence implements class_5481 {
        private final ObjectArrayList<class_2583> charStyles = new ObjectArrayList<>();
        private volatile String text = "";
        private int displayPos;
        private int displayEnd;

        @Override
        public boolean accept(class_5224 sink) {
            String currentText = text;
            int start = Math.max(0, displayPos);
            int end = Math.min(currentText.length(), displayEnd);

            for (int i = start; i < end; i++) {
                class_2583 style = i < charStyles.size() ? charStyles.get(i) : null;
                if (!sink.accept(i - displayPos, Objects.requireNonNullElse(style, class_2583.field_24360), currentText.charAt(i))) {
                    return false;
                }
            }

            return true;
        }
    }
}
