package io.github.fishstiz.fidgetz.v0.gui.renderables;

import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import net.minecraft.class_332;

record BoxShadow(float size, float offsetX, float offsetY) implements RenderableRectangle {
    @Override
    public void extractRenderState(
            class_332 graphics,
            int left,
            int top,
            int width,
            int height,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        GuiGraphicsUtils.boxShadow(graphics, left, top, width, height, size, offsetX, offsetY);
    }
}
