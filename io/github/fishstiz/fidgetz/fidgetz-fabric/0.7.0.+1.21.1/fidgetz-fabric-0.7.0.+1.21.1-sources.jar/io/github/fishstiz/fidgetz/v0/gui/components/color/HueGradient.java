package io.github.fishstiz.fidgetz.v0.gui.components.color;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import io.github.fishstiz.fidgetz.v0.gui.color.HSVA;
import org.joml.Matrix4f;

public record HueGradient() implements RenderableRectangle {
    private static final int GRADIENTS = 6;

    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        extractRenderState(graphics, left, top, width, height);
    }

    public static void extractRenderState(class_332 graphics, int left, int top, int width, int height) {
        float gradientWidth = (float) width / GRADIENTS;
        int bottom = top + height;

        class_4588 vertexConsumer = graphics.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = graphics.method_51448().method_23760().method_23761();

        for (int i = 0; i < GRADIENTS; i++) {
            int colorLeft = HSVA.toARGB(i * 60f, 1.0f, 1.0f, 1.0f);
            int colorRight = HSVA.toARGB((i + 1) * 60f, 1.0f, 1.0f, 1.0f);

            float x0 = left + i * gradientWidth;
            float x1 = left + (i + 1) * gradientWidth;

            vertexConsumer.method_22918(matrix4f, x0, top, 0).method_39415(colorLeft);
            vertexConsumer.method_22918(matrix4f, x0, bottom, 0).method_39415(colorLeft);
            vertexConsumer.method_22918(matrix4f, x1, bottom, 0).method_39415(colorRight);
            vertexConsumer.method_22918(matrix4f, x1, top, 0).method_39415(colorRight);
        }
    }
}
