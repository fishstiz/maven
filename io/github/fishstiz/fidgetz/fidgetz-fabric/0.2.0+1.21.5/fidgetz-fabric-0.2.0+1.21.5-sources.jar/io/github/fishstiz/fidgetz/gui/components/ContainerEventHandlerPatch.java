package io.github.fishstiz.fidgetz.gui.components;

import net.minecraft.class_3675;
import net.minecraft.class_4069;

public interface ContainerEventHandlerPatch extends class_4069 {
    @Override
    default boolean method_25402(double mouseX, double mouseY, int button) {
        return this.isMouseClickHandled(mouseX, mouseY, button);
    }

    /**
     * {@link class_4069#method_25402(double, double, int)}, except it only
     * returns true if mouse click is actually handled instead of when child is present.
     */
    private boolean isMouseClickHandled(double mouseX, double mouseY, int button) {
        return this.method_19355(mouseX, mouseY).map(child -> {
            if (child.method_25402(mouseX, mouseY, button)) {
                this.method_25395(child);
                if (button == class_3675.field_32000) {
                    this.method_25398(true);
                }
                return true;
            }
            return false;
        }).orElse(false);
    }

    @Override
    default boolean method_25406(double mouseX, double mouseY, int button) {
        return class_4069.super.method_25406(mouseX, mouseY, button);
    }

    @Override
    default boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return class_4069.super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }
}
