package io.github.fishstiz.fidgetz.v0.gui.renderables;

import org.joml.Matrix3x2fStack;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_8030;

@FunctionalInterface
public interface RenderableRectangle {
    void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick);

    default RenderableRectangle shrink(int inset) {
        return (graphics, left, top, width, height, mouseX, mouseY, partialTick) ->
                extractRenderState(
                        graphics,
                        left + inset,
                        top + inset,
                        width - (inset * 2),
                        height - (inset * 2),
                        mouseX,
                        mouseY,
                        partialTick
                );
    }

    default RenderableRectangle expand(int outset) {
        return shrink(-outset);
    }

    default RenderableRectangle crop(int inset) {
        return (graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            graphics.method_44379(left + inset, top + inset, (left + width) - inset, (top + height) - inset);
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            graphics.method_44380();
        };
    }

    default RenderableRectangle pose(Consumer<Matrix3x2fStack> transformer) {
        return ((graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            graphics.method_51448().pushMatrix();
            transformer.accept(graphics.method_51448());
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            graphics.method_51448().popMatrix();
        });
    }

    default RenderableRectangle then(RenderableRectangle after) {
        return (graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            after.extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
        };
    }

    default class_4068 toRenderable(class_8030 bounds) {
        int left = bounds.method_49620();
        int top = bounds.method_49618();
        int width = bounds.comp_1196();
        int height = bounds.comp_1197();
        return (graphics, mouseX, mouseY, partialTick) ->
                extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
    }

    default class_4068 toRenderable(Supplier<class_8030> boundsSupplier) {
        return (graphics, mouseX, mouseY, partialTick) -> {
            class_8030 bounds = boundsSupplier.get();
            extractRenderState(graphics, bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197(), mouseX, mouseY, partialTick);
        };
    }

    default class_4068 toPopover(class_8030 bounds) {
        return new Popover(toRenderable(bounds));
    }

    default class_4068 toPopover(class_8030 bounds, int order) {
        return new Popover(toRenderable(bounds), order);
    }

    default class_4068 toPopover(Supplier<class_8030> boundsSupplier) {
        return new Popover(toRenderable(boundsSupplier));
    }

    default class_4068 toPopover(Supplier<class_8030> boundsSupplier, int order) {
        return new Popover(toRenderable(boundsSupplier), order);
    }
}
