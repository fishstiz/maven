package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexElement;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4069;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

public class WrappedLayout<T extends class_8133> extends class_339 implements
        class_4069,
        FZComponent,
        FZContextMenu.Source,
        FZHoverableContainer {
    private final List<class_364> children = new ArrayList<>();
    private final List<class_4068> renderables = new ArrayList<>();
    protected T layout;
    private class_8030 cachedBounds = class_8030.method_48248();
    private @Nullable class_364 focused;
    private boolean dragging;
    protected class_8030 padding = class_8030.method_48248();

    protected WrappedLayout(T layout) {
        super(0, 0, 0, 0, class_5244.field_39003);
        this.layout = layout;
    }

    public static <T extends class_8133> WrappedLayout<T> wrap(T layout) {
        WrappedLayout<T> wrappedLayout = new WrappedLayout<>(layout);
        wrappedLayout.buildWidgets();
        return wrappedLayout;
    }

    protected void buildWidgets(GuiComponentCollector collector) {
    }

    protected final void buildWidgets() {
        GuiComponentCollector collector = new GuiComponentCollector();
        buildWidgets(collector);
        this.layout.method_48206(collector::renderableWidget);
        collector.flushTo(this::addWidget, this::addRenderableOnly);

        if (!children.isEmpty() || !renderables.isEmpty()) {
            arrangeElements();
        }
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        for (class_4068 child : renderables) {
            child.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    public void setPadding(int left, int top, int right, int bottom) {
        if (this.padding.method_49620() != left
            || this.padding.method_49618() != top
            || this.padding.method_49621() != right
            || this.padding.method_49619() != bottom) {
            this.padding = ScreenRectangleUtils.insets(left, top, right, bottom);
            method_55445(method_25368(), method_25364());
        }
    }

    public void setPadding(int padding) {
        setPadding(padding, padding, padding, padding);
    }

    public WrappedLayout<T> padding(int left, int top, int right, int bottom) {
        setPadding(left, top, right, bottom);
        return this;
    }

    public WrappedLayout<T> padding(int padding) {
        return padding(padding, padding, padding, padding);
    }

    private void updateBounds() {
        this.field_22758 = layout.method_25368() + this.padding.method_49620() + this.padding.method_49621();
        this.field_22759 = layout.method_25364() + this.padding.method_49618() + this.padding.method_49619();
        this.cachedBounds = method_48202();
    }

    @Override
    public void method_25358(int width) {
        if (layout instanceof FZFlexElement flexLayout) {
            flexLayout.fidgetz$setWidth(width - this.padding.method_49620() - this.padding.method_49621());
        }
        updateBounds();
    }

    @Override
    public void method_53533(int height) {
        if (layout instanceof FZFlexElement flexLayout) {
            flexLayout.fidgetz$setHeight(height - this.padding.method_49618() - this.padding.method_49619());
        }
        updateBounds();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        if (layout instanceof FZFlexElement flexLayout) {
            flexLayout.fidgetz$setSize(
                    width - this.padding.method_49620() - this.padding.method_49621(),
                    height - this.padding.method_49618() - this.padding.method_49619()
            );
        }
        updateBounds();
    }

    @Override
    public void method_46421(final int x) {
        layout.method_46421(x + this.padding.method_49620());
        super.method_46421(x);
        updateBounds();
    }

    @Override
    public void method_46419(final int y) {
        layout.method_46419(y + this.padding.method_49618());
        super.method_46419(y);
        updateBounds();
    }

    protected void repositionLayout() {
        layout.method_48229(method_46426() + this.padding.method_49620(), method_46427() + this.padding.method_49618());
    }

    protected void arrangeElements() {
        layout.method_48222();
        repositionLayout();
        updateBounds();
    }

    @Override
    protected void method_47399(class_6382 output) {
    }

    protected void clearWidgets() {
        for (Iterator<class_364> it = children.iterator(); it.hasNext(); ) {
            class_364 widget = it.next();

            if (method_25399() == widget) {
                method_25395(null);
            }
            if (fidgetz$getHovered() == widget) {
                fidgetz$setHovered(null);
            }

            it.remove();
        }

        renderables.clear();
    }

    protected void addWidget(class_364 widget) {
        children.add(widget);
    }

    protected void addRenderableOnly(class_4068 renderable) {
        renderables.add(renderable);
    }

    protected void removeWidget(class_364 widget) {
        children.remove(widget);
        if (widget instanceof class_4068 renderable) {
            renderables.remove(renderable);
        }
        if (method_25399() == widget) {
            method_25395(null);
        }
        if (fidgetz$getHovered() == widget) {
            fidgetz$setHovered(null);
        }
    }

    @Override
    public List<? extends class_364> method_25396() {
        return children;
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return focused;
    }

    @Override
    public void method_25365(boolean focused) {
        if (!focused) {
            method_25395(null);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (this.focused != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }

            if (focused != null) {
                focused.method_25365(true);
            }

            this.focused = focused;
        }
    }

    @Override
    public boolean method_25370() {
        return class_4069.super.method_25370();
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        if (super.method_25405(mouseX, mouseY)) {
            return true;
        }

        for (class_364 child : children) {
            if (child.method_25405(mouseX, mouseY)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return class_4069.super.method_48205(navigationEvent);
    }

    @Override
    public @Nullable class_8016 method_48218() {
        return class_4069.super.method_48218();
    }

    @Override
    public boolean method_25402(final class_11909 event, final boolean doubleClick) {
        return class_4069.super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25406(final class_11909 event) {
        super.method_25406(event);
        return class_4069.super.method_25406(event);
    }

    @Override
    public boolean method_25403(final class_11909 event, final double dx, final double dy) {
        super.method_25403(event, dx, dy);
        return class_4069.super.method_25403(event, dx, dy);
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(this.cachedBounds, this)) {
            this.cachedBounds = super.method_48202();
        }
        return this.cachedBounds;
    }
}
