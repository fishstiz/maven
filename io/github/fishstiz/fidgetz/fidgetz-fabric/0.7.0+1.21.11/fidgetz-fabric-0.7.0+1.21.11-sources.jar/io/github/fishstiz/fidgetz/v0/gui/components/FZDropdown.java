package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.*;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.gui.text.TextComponentUtils;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_11907;
import net.minecraft.class_11908;
import net.minecraft.class_12225;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8027;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_8133;
import net.minecraft.class_9851;

public final class FZDropdown extends class_4185.class_12231 implements FZComponent, FZContextMenu.Source, FZPopoverContainer, class_8133 {
    private static final int DEFAULT_ELEMENT_SPACING = 8;
    private static final int ENTRY_SPACING = 4;
    private static final int DEFAULT_SELECTION_HEIGHT = 200;
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private final SelectionContainer selectionContainer;
    private final class_4069 parentContainer;
    private final class_327 font;
    private List<FZPopoverMenuItem> items = Collections.emptyList();
    private boolean hideMessage;
    private @Nullable WidgetElements leftIcon;
    private boolean closeOnBlur = true;
    private class_2561 interactSymbol = TextComponentUtils.BLACK_RIGHT_POINTING_TRIANGLE;
    private class_2561 inactiveInteractSymbol = method_75800(interactSymbol);
    private int interactIconWidth;
    private boolean iconWidthDirty = true;
    private class_8030 bounds;

    FZDropdown(int x, int y, int width, int height, class_2561 message, class_4069 parentContainer) {
        super(x, y, width, height, message, FZButton.NOP, field_40754);
        this.font = class_310.method_1551().field_1772;
        this.parentContainer = parentContainer;
        this.selectionContainer = new SelectionContainer(parentContainer);
        this.bounds = super.method_48202();
    }

    FZDropdown(class_4069 parentContainer) {
        this(0, 0, field_39500, field_39501, class_5244.field_39003, parentContainer);
    }

    public void openSelection() {
        selectionContainer.build(this.items);
        selectionContainer.repositionElements();
        selectionContainer.setOpen(true);
    }

    public void closeSelection() {
        selectionContainer.setOpen(false);
    }

    @Override
    public void method_25306(class_11907 input) {
        super.method_25306(input);
        if (selectionContainer.isOpen()) {
            closeSelection();
        } else {
            openSelection();
        }
    }

    private int getInteractIconWidth() {
        if (iconWidthDirty) {
            interactIconWidth = font.method_27525(interactSymbol);
            iconWidthDirty = false;
        }
        return interactIconWidth;
    }

    private class_2561 getInteractSymbol() {
        return field_22763 ? interactSymbol : inactiveInteractSymbol;
    }

    @Override
    protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        method_75794(graphics);

        int left = method_46426();
        int top = method_46427();
        int width = method_25368();
        int height = method_25364();
        int right = method_55442();
        int spacing = DEFAULT_ELEMENT_SPACING;

        right -= spacing + getInteractIconWidth();

        if (leftIcon != null) {
            left += spacing + leftIcon.margin().method_49620();

            int iconY = (top + height / 2 - leftIcon.height() / 2) + leftIcon.margin().method_49618() - leftIcon.margin().method_49619();

            leftIcon.elements()
                    .get(method_37303(), method_25367())
                    .extractRenderState(graphics, left, iconY, leftIcon.width(), leftIcon.height(), mouseX, mouseY, partialTick);

            left += leftIcon.width() + leftIcon.margin().method_49621();
        }

        class_12225 textRenderer = graphics.method_75787(this, class_332.class_12228.field_63850);

        if (!hideMessage) {
            GuiGraphicsUtils.scrollingText(textRenderer, method_25369(), left + spacing, top, right - spacing, method_55443());
        }

        int symbolX = MathUtils.clampOrAverage(right, method_46426() + spacing, right);
        int symbolY = top + (height / 2) - (font.field_2000 / 2);
        textRenderer.method_75763(symbolX, symbolY, getInteractSymbol());

        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (super.method_25404(event)) {
            return true;
        }
        if (selectionContainer.isOpen() && event.method_74231()) {
            closeSelection();
            class_8016 path = NavigationUtils.findPath(parentContainer, this);
            if (path != null) {
                path.method_48195(true);
            }
            return true;
        }

        if (!selectionContainer.isOpen()) {
            return false;
        }

        class_8028 selectionDirection = selectionContainer.isPositionedDown()
                ? class_8028.field_41827
                : class_8028.field_41826;

        if (NavigationUtils.getDirection(event) != selectionDirection) {
            return false;
        }

        class_8016 containerPath = NavigationUtils.findPath(parentContainer, selectionContainer);
        class_8016 selectionPath = selectionContainer.method_48205(
                new class_8023.class_8024(selectionDirection)
        );

        if (containerPath != null) {
            NavigationUtils.appendPath(containerPath, selectionPath).method_48195(true);
            return true;
        }

        return false;
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

    @Override
    public boolean method_72784() {
        return propsState.focusOnInteraction;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        class_8016 path = super.method_48205(navigationEvent);
        if (path != null || !method_25370() || !selectionContainer.isOpen()) {
            return path;
        }

        class_8028 selectionDirection = selectionContainer.isPositionedDown()
                ? class_8028.field_41827
                : class_8028.field_41826;

        if ((selectionDirection == class_8028.field_41827 && NavigationUtils.isUp(navigationEvent, true)) ||
            (selectionDirection == class_8028.field_41826 && NavigationUtils.isDown(navigationEvent, true))) {
            return method_48218();
        }

        return null;
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            this.bounds = super.method_48202();
        }
        return this.bounds;
    }

    @Override
    public void fidgetz$visitPopovers(Consumer<FZPopover> visitor) {
        visitor.accept(selectionContainer);
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void method_46421(int x) {
        if (selectionContainer.isOpen()) {
            selectionContainer.setX(selectionContainer.getX() + (x - method_46426()));
        }
        super.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        if (selectionContainer.isOpen()) {
            selectionContainer.setY(selectionContainer.getY() + (y - method_46427()));
        }
        super.method_46419(y);
    }

    @Override
    public void method_48222() {
        if (selectionContainer.isOpen()) {
            selectionContainer.repositionElements();
        }
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    void applyProps(Props props) {
        if (props.parentContainer() != parentContainer) {
            throw new UnsupportedOperationException("Updating the parent container of FZDropdown is not supported.");
        }

        propsState.apply(this, props);

        if (props.hideMessage() != class_9851.field_52396) {
            hideMessage = props.hideMessage().method_61348(false);
        }
        if (props.closeOnBlur() != class_9851.field_52396) {
            closeOnBlur = props.closeOnBlur().method_61348(true);
        }

        props.leftIcon().ifDefined(leftIcon -> this.leftIcon = leftIcon);
        props.containerBackground().ifPresent(selectionContainer::setBackground);
        props.maxContainerHeight().ifPresent(maxHeight -> selectionContainer.maxHeight = maxHeight);
        props.minContainerWidth().ifPresent(minContainerWidth -> selectionContainer.minWidth = minContainerWidth);
        props.maxContainerWidth().ifPresent(maxContainerWidth -> selectionContainer.maxWidth = maxContainerWidth);
        props.preferredDirection().ifPresent(direction -> selectionContainer.rootDirection = direction);

        props.entryDivider().ifDefined(selectionContainer::setEntryDivider);
        props.sectionDivider().ifDefined(selectionContainer::setSectionDivider);
        props.containerPadding().ifPresent(selectionContainer::setPadding);
        props.containerBorder().ifPresent(selectionContainer::setBorder);

        List<FZPopoverMenuItem> previousEntries = this.items;
        this.items = props.entries();
        if (selectionContainer.isOpen() && !Objects.equals(previousEntries, this.items)) {
            selectionContainer.build(this.items);
            selectionContainer.repositionElements();
        }
    }

    public static FZDropdown bind(String key, FZRef<Props> ref) {
        Props props = ref.value();
        FZDropdown dropdown = new FZDropdown(props.parentContainer());
        dropdown.applyProps(props);
        ref.subscribe(key, dropdown::applyProps);
        return dropdown;
    }

    public static Builder builder(class_4069 container) {
        return new Builder(container);
    }

    private final class SelectionContainer extends FZPopoverMenu {
        private HorizontalDirection rootDirection = HorizontalDirection.RIGHT;
        private int maxHeight = DEFAULT_SELECTION_HEIGHT;
        private Length minWidth = Length.fill();
        private Length maxWidth = Length.fill();
        private boolean focused;

        SelectionContainer(class_4069 container) {
            super(container);
            setPadding(ScreenRectangleUtils.insets(ENTRY_SPACING));
            setRowSpacing(ENTRY_SPACING);
        }

        private void updateIcon() {
            interactSymbol = isOpen() ? TextComponentUtils.BLACK_DOWN_POINTING_TRIANGLE : TextComponentUtils.BLACK_RIGHT_POINTING_TRIANGLE;
            inactiveInteractSymbol = method_75800(interactSymbol);
            iconWidthDirty = true;
        }

        @Override
        protected void onOpen() {
            super.onOpen();
            updateIcon();
        }

        @Override
        protected void onClose() {
            boolean focused = NavigationUtils.inFocusPath(parentContainer, this);
            super.onClose();
            if (focused) {
                class_8016 path = NavigationUtils.findPath(parentContainer, FZDropdown.this);
                if (path != null) {
                    path.method_48195(true);
                }
            }
            updateIcon();
        }

        @Override
        protected void build(List<FZPopoverMenuItem> items) {
            setMaxHeight(maxHeight);
            super.build(items);
        }

        @Override
        public void repositionElements() {
            class_8030 parentBounds = parentContainer.method_48202();
            class_8030 buttonBounds = FZDropdown.this.method_48202();
            class_8030 selectionBounds = method_48202();

            int minWidthLength = minWidth.resolve(buttonBounds.comp_1196());
            int maxWidthLength = maxWidth.resolve(buttonBounds.comp_1196());;
            if (maxWidthLength > 0 && minWidthLength > maxWidthLength) {
                maxWidthLength = minWidthLength;
            }

            int selectionWidth = MathUtils.clampOptionalMax(selectionBounds.comp_1196(), minWidthLength, maxWidthLength);
            int selectionHeight = selectionBounds.comp_1197();

            int spaceBelow = parentBounds.method_49619() - buttonBounds.method_49619();
            int spaceAbove = buttonBounds.method_49618() - parentBounds.method_49618();

            int anchor = rootDirection.flip().edge(buttonBounds);

            HorizontalDirection newDirection = rootDirection.resolve(parentBounds, selectionWidth, anchor);
            anchor = newDirection.flip().edge(buttonBounds);

            int selectionX = newDirection.clamp(parentBounds, selectionWidth, anchor);
            int selectionY;
            if (selectionHeight > spaceBelow) {
                if (spaceAbove > spaceBelow) {
                    selectionHeight = Math.min(selectionHeight, spaceAbove);
                    selectionY = buttonBounds.method_49618() - selectionHeight;
                    setMaxHeight(selectionHeight);
                } else {
                    selectionHeight = spaceBelow;
                    selectionY = buttonBounds.method_49619();
                    setMaxHeight(selectionHeight);
                }
            } else {
                selectionY = buttonBounds.method_49619();
            }

            setMinWidth(selectionWidth);
            setMaxWidth(selectionWidth);
            super.repositionElements();

            setX(selectionX);
            setY(selectionY);
            setMaxHeight(maxHeight);
        }

        @Override
        protected void extractDialogRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            super.extractDialogRenderState(graphics, mouseX, mouseY, partialTick);

            if ((FZDropdown.this.closeOnBlur && !method_25370() && !FZDropdown.this.method_25370()) || !FZDropdown.this.method_37303()) {
                closeSelection();
            }
        }

        @Override
        public boolean shouldCaptureFocus() {
            return false;
        }

        @Override
        public boolean shouldFocusOnOpen() {
            return false;
        }

        @Override
        public boolean shouldRefocusLastPath() {
            return false;
        }

        @Override
        public void method_25365(boolean focused) {
            this.focused = focused;
            super.method_25365(focused);
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (focused == null || isOpen()) {
                super.method_25395(focused);
            }
        }

        @Override
        public boolean method_25370() {
            return focused || method_25399() != null;
        }

        @Override
        public @Nullable class_8016 method_48218() {
            if (!method_25370()) return null;
            return method_25399() == null ? class_8016.method_48193(this) : super.method_48218();
        }

        @Override
        public class_8030 method_65515(class_8028 opposite) {
            if (opposite.method_48237() == class_8027.field_41822) {
                return FZDropdown.this.method_65515(opposite);
            }
            return super.method_65515(opposite);
        }

        private boolean isPositionedUp() {
            return getY() < FZDropdown.this.method_46427();
        }

        private boolean isPositionedDown() {
            return getY() > FZDropdown.this.method_46427();
        }

        @Override
        public boolean method_25404(class_11908 event) {
            if (!isOpen()) {
                return false;
            }

            if (super.method_25404(event)) {
                return true;
            }

            class_8028 dropdownDirection = isPositionedDown() ? class_8028.field_41826 : class_8028.field_41827;
            if (NavigationUtils.getDirection(event) != dropdownDirection) {
                return false;
            }

            class_8023 navigationEvent = new class_8023.class_8024(dropdownDirection);
            class_8016 nextPath = method_48205(navigationEvent);
            if (nextPath != null) {
                return false;
            }

            class_8016 containerPath = NavigationUtils.findPath(parentContainer, FZDropdown.this);
            class_8016 dropdownPath = FZDropdown.this.method_48205(navigationEvent);
            if (containerPath != null) {
                NavigationUtils.appendPath(containerPath, dropdownPath).method_48195(true);
                return true;
            }

            return false;
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            if (!isOpen()) return null;

            class_8016 path = super.method_48205(navigationEvent);
            if (path != null || !method_25370()) return path;

            class_8028 dropdownDirection = isPositionedDown() ? class_8028.field_41826 : class_8028.field_41827;
            if ((dropdownDirection == class_8028.field_41827 && NavigationUtils.isUp(navigationEvent, true)) ||
                (dropdownDirection == class_8028.field_41826 && NavigationUtils.isDown(navigationEvent, true))) {
                return method_48218();
            }

            return null;
        }

        @Override
        public int method_48590() {
            return FZDropdown.this.method_48590();
        }

        @Override
        public boolean method_37303() {
            return FZDropdown.this.method_37303() && super.method_37303();
        }
    }

    public interface Props extends GuiComponentProps {
        class_4069 parentContainer();

        List<FZPopoverMenuItem> entries();

        default class_9851 hideMessage() {
            return class_9851.field_52396;
        }

        default class_9851 closeOnBlur() {
            return class_9851.field_52396;
        }

        default Undefinable<@Nullable WidgetElements> leftIcon() {
            return Undefinable.undefined();
        }

        default Optional<RenderableRectangle> containerBackground() {
            return Optional.empty();
        }

        default OptionalInt maxContainerHeight() {
            return OptionalInt.empty();
        }

        default Optional<HorizontalDirection> preferredDirection() {
            return Optional.empty();
        }

        default Optional<Length> minContainerWidth() {
            return Optional.empty();
        }

        default Optional<Length> maxContainerWidth() {
            return Optional.empty();
        }

        default Optional<class_8030> containerPadding() {
            return Optional.empty();
        }

        default Optional<class_8030> containerBorder() {
            return Optional.empty();
        }

        default Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider() {
            return Undefinable.undefined();
        }

        default Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider() {
            return Undefinable.undefined();
        }
    }

    private static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final class_4069 parentContainer;
        private final List<FZPopoverMenuItem> entries;
        private final class_9851 hideMessage;
        private final class_9851 closeOnBlur;
        private final Undefinable<@Nullable WidgetElements> leftIcon;
        private final @Nullable RenderableRectangle containerBackground;
        private final @Nullable Integer maxContainerHeight;
        private final @Nullable HorizontalDirection preferredDirection;
        private final @Nullable Length minContainerWidth;
        private final @Nullable Length maxContainerWidth;
        private final @Nullable class_8030 containerPadding;
        private final @Nullable class_8030 containerBorder;
        private final Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider;
        private final Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider;

        private PropsImpl(
                class_4069 parentContainer,
                List<FZPopoverMenuItem> entries,
                class_9851 hideMessage,
                class_9851 closeOnBlur,
                Undefinable<@Nullable WidgetElements> leftIcon,
                @Nullable RenderableRectangle containerBackground,
                @Nullable Integer maxContainerHeight,
                @Nullable HorizontalDirection preferredDirection,
                @Nullable Length minContainerWidth,
                @Nullable Length maxContainerWidth,
                @Nullable class_8030 containerPadding,
                @Nullable class_8030 containerBorder,
                Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider,
                Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider,
                GuiComponentProps props
        ) {
            super(props);
            this.parentContainer = parentContainer;
            this.entries = entries;
            this.hideMessage = hideMessage;
            this.closeOnBlur = closeOnBlur;
            this.leftIcon = leftIcon;
            this.preferredDirection = preferredDirection;
            this.containerBackground = containerBackground;
            this.maxContainerHeight = maxContainerHeight;
            this.minContainerWidth = minContainerWidth;
            this.maxContainerWidth = maxContainerWidth;
            this.containerPadding = containerPadding;
            this.containerBorder = containerBorder;
            this.entryDivider = entryDivider;
            this.sectionDivider = sectionDivider;
        }

        @Override
        public class_4069 parentContainer() {
            return parentContainer;
        }

        @Override
        public List<FZPopoverMenuItem> entries() {
            return entries;
        }

        @Override
        public class_9851 hideMessage() {
            return hideMessage;
        }

        @Override
        public class_9851 closeOnBlur() {
            return closeOnBlur;
        }

        @Override
        public Undefinable<@Nullable WidgetElements> leftIcon() {
            return leftIcon;
        }

        @Override
        public Optional<RenderableRectangle> containerBackground() {
            return Optional.ofNullable(containerBackground);
        }

        @Override
        public OptionalInt maxContainerHeight() {
            return wrapBoxedInt(maxContainerHeight);
        }

        @Override
        public Optional<Length> minContainerWidth() {
            return Optional.ofNullable(minContainerWidth);
        }

        @Override
        public Optional<Length> maxContainerWidth() {
            return Optional.ofNullable(maxContainerWidth);
        }

        @Override
        public Optional<HorizontalDirection> preferredDirection() {
            return Optional.ofNullable(preferredDirection);
        }

        @Override
        public Optional<class_8030> containerPadding() {
            return Optional.ofNullable(containerPadding);
        }

        @Override
        public Optional<class_8030> containerBorder() {
            return Optional.ofNullable(containerBorder);
        }

        @Override
        public Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider() {
            return entryDivider;
        }

        @Override
        public Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider() {
            return sectionDivider;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(parentContainer, other.parentContainer()) &&
                   Objects.equals(entries, other.entries()) &&
                   hideMessage == other.hideMessage() &&
                   closeOnBlur == other.closeOnBlur() &&
                   Objects.equals(leftIcon, other.leftIcon()) &&
                   Objects.equals(containerBackground(), other.containerBackground()) &&
                   Objects.equals(maxContainerHeight(), other.maxContainerHeight()) &&
                   Objects.equals(minContainerWidth(), other.minContainerWidth()) &&
                   Objects.equals(maxContainerWidth(), other.maxContainerWidth()) &&
                   Objects.equals(preferredDirection(), other.preferredDirection()) &&
                   Objects.equals(containerPadding(), other.containerPadding()) &&
                   Objects.equals(containerBorder(), other.containerBorder()) &&
                   Objects.equals(entryDivider(), other.entryDivider()) &&
                   Objects.equals(sectionDivider(), other.sectionDivider());
        }

        @Override
        public int hashCode() {
            return Objects.hash(
                    super.hashCode(),
                    parentContainer,
                    entries,
                    hideMessage,
                    closeOnBlur,
                    leftIcon,
                    containerBackground,
                    maxContainerHeight,
                    minContainerWidth,
                    maxContainerWidth,
                    preferredDirection,
                    containerPadding,
                    containerBorder,
                    entryDivider,
                    sectionDivider
            );
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private static final WidgetRenderables DEFAULT_ENTRY_BACKGROUND = new WidgetRenderables(
                Renderables.sprite(Fidgetz.id("widget/popovermenu_entry")),
                Renderables.sprite(Fidgetz.id("widget/popovermenu_entry")),
                Renderables.sprite(Fidgetz.id("widget/popovermenu_entry_highlighted"))
        );
        private final class_4069 container;
        private final List<FZPopoverMenuItem> entries = new ArrayList<>();
        private class_9851 hideMessage = class_9851.field_52396;
        private class_9851 closeOnBlur = class_9851.field_52396;
        private Undefinable<@Nullable WidgetElements> leftIcon = Undefinable.undefined();
        private @Nullable RenderableRectangle containerBackground;
        private @Nullable Integer maxContainerHeight;
        private @Nullable HorizontalDirection preferredDirection;
        private @Nullable Length minContainerWidth;
        private @Nullable Length maxContainerWidth;
        private @Nullable class_8030 containerPadding;
        private @Nullable class_8030 containerBorder;
        private Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider = Undefinable.undefined();
        private Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider = Undefinable.undefined();

        private Builder(class_4069 container) {
            this.container = container;
        }

        public Builder hideMessage(boolean hideMessage) {
            this.hideMessage = class_9851.method_76393(hideMessage);
            return this;
        }

        public Builder hideMessage() {
            return hideMessage(true);
        }

        public Builder closeOnBlur(boolean closeOnBlur) {
            this.closeOnBlur = class_9851.method_76393(closeOnBlur);
            return this;
        }

        public Builder closeOnBlur() {
            return closeOnBlur(true);
        }

        public Builder leftIcon(@Nullable WidgetElements leftIcon) {
            this.leftIcon = Undefinable.of(leftIcon);
            return this;
        }

        public Builder containerBackground(@Nullable RenderableRectangle containerBackground) {
            this.containerBackground = containerBackground;
            return this;
        }

        public Builder maxContainerHeight(int maxContainerHeight) {
            this.maxContainerHeight = maxContainerHeight;
            return this;
        }

        public Builder minContainerWidth(int minContainerWidth, HorizontalDirection preferredDirection) {
            this.minContainerWidth = Length.fixed(minContainerWidth);
            this.preferredDirection = preferredDirection;
            return this;
        }

        public Builder minContainerWidth(int minContainerWidth) {
            this.minContainerWidth = Length.fixed(minContainerWidth);
            return this;
        }

        public Builder minContainerWidth(float buttonRatio) {
            this.minContainerWidth = Length.relative(buttonRatio);
            return this;
        }

        public Builder maxContainerWidth(int maxContainerWidth) {
            this.maxContainerWidth = Length.fixed(maxContainerWidth);
            return this;
        }

        public Builder maxContainerWidth(float buttonRatio) {
            this.maxContainerWidth = Length.relative(buttonRatio);
            return this;
        }

        public Builder preferredDirection(HorizontalDirection preferredDirection) {
            this.preferredDirection = preferredDirection;
            return this;
        }

        public Builder containerPadding(int left, int top, int right, int bottom) {
            this.containerPadding = ScreenRectangleUtils.insets(left, top, right, bottom);
            return this;
        }

        public Builder containerPadding(int padding) {
            return containerPadding(padding, padding, padding, padding);
        }

        public Builder containerBorder(int left, int top, int right, int bottom) {
            this.containerBorder = ScreenRectangleUtils.insets(left, top, right, bottom);
            return this;
        }

        public Builder containerBorder(int border) {
            return containerBorder(border, border, border, border);
        }

        private FZButton.Builder defaultButtonBuilder() {
            return FZButton.builder()
                    .height(field_39501)
                    .sprites(DEFAULT_ENTRY_BACKGROUND)
                    .leftAlignedMessage();
        }

        public Builder entry(class_2561 message, Runnable selectionHandler) {
            Objects.requireNonNull(selectionHandler, "selectionHandler cannot be null");
            this.entries.add(FZPopoverMenuItem.fromWidget(defaultButtonBuilder().message(message).onPress(selectionHandler).build()));
            return this;
        }

        public Builder entry(UnaryOperator<FZButton.Builder> entryBuilder) {
            this.entries.add(FZPopoverMenuItem.fromWidget(entryBuilder.apply(defaultButtonBuilder()).build()));
            return this;
        }

        public Builder entry(FZPopoverMenuItem entry) {
            this.entries.add(entry);
            return this;
        }

        public Builder entryWidget(class_339 widget) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widget));
            return this;
        }

        public Builder entryWidget(class_339 widget, FZPopoverMenuItem.Settings settings) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widget, settings));
            return this;
        }

        public Builder entryWidget(class_339 widget, UnaryOperator<FZPopoverMenuItem.Settings> settingsBuilder) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widget, settingsBuilder));
            return this;
        }

        public Builder entryWidget(Function<FZPopoverMenuItem.Context, class_339> widgetFactory) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widgetFactory));
            return this;
        }

        public Builder entryWidget(
                Function<FZPopoverMenuItem.Context, class_339> widgetFactory,
                FZPopoverMenuItem.Settings settings
        ) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widgetFactory, settings));
            return this;
        }

        public Builder entryWidget(
                Function<FZPopoverMenuItem.Context, class_339> widgetFactory,
                UnaryOperator<FZPopoverMenuItem.Settings> settingsBuilder
        ) {
            this.entries.add(FZPopoverMenuItem.fromWidget(widgetFactory, settingsBuilder));
            return this;
        }

        public Builder entries(List<? extends FZPopoverMenuItem> entries) {
            this.entries.addAll(entries);
            return this;
        }

        public Builder entryDivider(FZPopoverMenuItem.@Nullable Divider entryDivider) {
            this.entryDivider = Undefinable.of(entryDivider);
            return this;
        }

        public Builder sectionDivider(FZPopoverMenuItem.@Nullable Divider sectionDivider) {
            this.sectionDivider = Undefinable.of(sectionDivider);
            return this;
        }

        public Props toProps() {
            return new PropsImpl(
                    container,
                    List.copyOf(entries),
                    hideMessage,
                    closeOnBlur,
                    leftIcon,
                    containerBackground,
                    maxContainerHeight,
                    preferredDirection,
                    minContainerWidth,
                    maxContainerWidth,
                    containerPadding,
                    containerBorder,
                    entryDivider,
                    sectionDivider,
                    props
            );
        }

        public FZDropdown build() {
            FZDropdown dropdown = new FZDropdown(container);
            dropdown.applyProps(toProps());
            return dropdown;
        }
    }
}
