package io.github.fishstiz.fidgetz.v0.utils;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.renderables.SimpleGuiRenderState;
import org.jspecify.annotations.Nullable;

import java.util.ServiceLoader;
import net.minecraft.class_10799;
import net.minecraft.class_11244;
import net.minecraft.class_11735;
import net.minecraft.class_12225;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_8012;
import net.minecraft.class_8030;

public final class GuiGraphicsUtils {
    private static final Service GUI_GRAPHICS_SERVICE = ServiceLoader.load(Service.class).findFirst().orElseThrow();
    private static final class_2960 BOX_SHADOW_SPRITE = Fidgetz.id("box_shadow");
    private static final float BOX_SHADOW_BORDER = 48f;
    private static final class_2960 CHECKERBOARD_TEXTURE = Fidgetz.id("textures/gui/checkerboard.png");
    private static final int CHECKERBOARD_TEXTURE_SIZE = 16;
    private static final int CHECKERBOARD_TEXEL_SIZE = 8;

    public static void addGuiElement(class_332 graphics, class_11244 blitState) {
        GUI_GRAPHICS_SERVICE.addGuiElement(graphics, blitState);
    }

    public static @Nullable class_8030 peekScissorStack(class_332 graphics) {
        return GUI_GRAPHICS_SERVICE.peekScissorStack(graphics);
    }

    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height, int color) {
        graphics.method_52707(class_10799.field_56883, sprite, x, y, width, height, color);
    }

    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height) {
        sprite(graphics, sprite, x, y, width, height, class_8012.field_42973);
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int uWidth,
            int vHeight,
            int textureWidth,
            int textureHeight
    ) {
        graphics.method_25302(
                class_10799.field_56883,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                uWidth,
                vHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                0,
                0,
                width, height,
                textureWidth, textureHeight
        );
    }

    public static void texture(class_332 graphics, class_2960 texture, int x, int y, int textureWidth, int textureHeight) {
        texture(graphics, texture, x, y, textureWidth, textureHeight, textureWidth, textureHeight);
    }

    public static void fillFloat(class_332 graphics, float left, float top, float right, float bottom, int color) {
        class_8030 bounds = new class_8030((int) left, (int) top, (int) (right - left), (int) (bottom - top));

        addGuiElement(graphics, SimpleGuiRenderState.from(graphics, bounds, (renderState, vertexConsumer) -> {
            class_8030 intersection = renderState.comp_4274();
            if (intersection != null) {
                vertexConsumer.method_70815(renderState.pose(), left, top).method_39415(color);
                vertexConsumer.method_70815(renderState.pose(), left, bottom).method_39415(color);
                vertexConsumer.method_70815(renderState.pose(), right, bottom).method_39415(color);
                vertexConsumer.method_70815(renderState.pose(), right, top).method_39415(color);
            }
        }));
    }

    public static void fillHorizontal(class_332 graphics, int left, int top, int right, int bottom, int colorFrom, int colorTo) {
        class_8030 bounds = new class_8030(left, top, right - left, bottom - top);

        addGuiElement(graphics, SimpleGuiRenderState.from(graphics, bounds, (renderState, vertexConsumer) -> {
            class_8030 intersection = renderState.comp_4274();
            if (intersection != null) {
                renderState.addQuadWith2DPose(vertexConsumer, intersection, colorFrom, colorFrom, colorTo, colorTo);
            }
        }));
    }

    public static void text(class_332 graphics, class_2561 text, int x, int y, int color) {
        graphics.method_27535(class_310.method_1551().field_1772, text, x, y, color);
    }

    public static void scrollingText(
            class_12225 textCollector,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            class_12225.class_12227 localParameters = textCollector.method_75760().method_75779(left, right, top, bottom);
            textCollector.method_75766(class_11735.field_62009, left - (int) scrollOffset, textY, localParameters, component.method_30937());
        } else {
            textCollector.method_75765(class_11735.field_62009, left, textY, component.method_30937());
        }
    }

    public static void scrollingText(class_12225 textCollector, class_2561 component, int left, int top, int right, int bottom) {
        scrollingText(textCollector, class_310.method_1551().field_1772, component, left, top, right, bottom);
    }

    public static void scrollingText(
            class_332 graphics,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom,
            int color,
            boolean shadow
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_51439(font, component, left - (int) scrollOffset, textY, color, shadow);
            graphics.method_44380();
        } else {
            graphics.method_51439(font, component, left, textY, color, shadow);
        }
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color, boolean shadow) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color, shadow);
    }

    public static void scrollingText(class_332 graphics, class_327 font, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, font, component, left, top, right, bottom, color, true);
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color);
    }

    public static void boxShadow(
            class_332 graphics,
            int x,
            int y,
            int width,
            int height,
            float shadowSize,
            float shadowOffsetX,
            float shadowOffsetY
    ) {
        float scale = shadowSize / BOX_SHADOW_BORDER;
        int baseOffset = Math.round(BOX_SHADOW_BORDER * scale);
        int offsetX = Math.round(baseOffset + shadowOffsetX);
        int offsetY = Math.round(baseOffset + shadowOffsetY);

        sprite(graphics, BOX_SHADOW_SPRITE, x - offsetX, y - offsetY, width + offsetX * 2, height + offsetY * 2);
    }

    public static void checkerboard(
            class_332 graphics,
            int left,
            int top,
            int width,
            int height,
            int cellSize,
            int uOffset,
            int vOffset
    ) {
        float scale = (float) CHECKERBOARD_TEXEL_SIZE / cellSize;

        float uTexelStart = (uOffset * scale) % CHECKERBOARD_TEXTURE_SIZE;
        float vTexelStart = (vOffset * scale) % CHECKERBOARD_TEXTURE_SIZE;

        if (uTexelStart < 0) uTexelStart += CHECKERBOARD_TEXTURE_SIZE;
        if (vTexelStart < 0) vTexelStart += CHECKERBOARD_TEXTURE_SIZE;

        float uTexelEnd = uTexelStart + (width * scale);
        float vTexelEnd = vTexelStart + (height * scale);

        float u0 = uTexelStart / CHECKERBOARD_TEXTURE_SIZE;
        float v0 = vTexelStart / CHECKERBOARD_TEXTURE_SIZE;
        float u1 = uTexelEnd / CHECKERBOARD_TEXTURE_SIZE;
        float v1 = vTexelEnd / CHECKERBOARD_TEXTURE_SIZE;

        graphics.method_70845(
                CHECKERBOARD_TEXTURE,
                left,
                top,
                left + width,
                top + height,
                u0,
                u1,
                v0,
                v1
        );
    }

    public static void checkerboard(class_332 graphics, int left, int top, int width, int height, int cellSize) {
        checkerboard(graphics, left, top, width, height, cellSize, 0, 0);
    }

    private GuiGraphicsUtils() {
    }

    interface Service {
        void addGuiElement(class_332 graphics, class_11244 blitState);

        @Nullable
        class_8030 peekScissorStack(class_332 graphics);
    }
}
