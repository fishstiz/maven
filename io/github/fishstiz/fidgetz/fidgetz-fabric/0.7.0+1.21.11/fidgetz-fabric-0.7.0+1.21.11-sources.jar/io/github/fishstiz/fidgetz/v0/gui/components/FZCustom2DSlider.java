package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.Consumer;
import net.minecraft.class_1144;
import net.minecraft.class_11876;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8012;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import net.minecraft.class_8030;

public final class FZCustom2DSlider extends class_339 implements FZComponent, FZContextMenu.Source {
    private static final int DEFAULT_CURSOR_SIZE = 8;
    private static final int DEFAULT_WIDTH = 64;
    private static final int DEFAULT_HEIGHT = 64;
    private final boolean bound;
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private WidgetRenderables background = new WidgetRenderables(Renderables.fill(class_8012.field_42973));
    private WidgetRenderables cursor = new WidgetRenderables(Renderables.fill(class_8012.field_42974));
    private int cursorSize = DEFAULT_CURSOR_SIZE;
    private class_8030 cursorBounds = class_8030.method_48248();
    private class_8030 cachedBounds = super.method_48202();
    private Consumer<ChangeEvent> changeHandler = FunctionUtils.nopConsumer();
    private Consumer<ClickEvent> clickHandler = FunctionUtils.nopConsumer();
    private Consumer<DragEvent> dragHandler = FunctionUtils.nopConsumer();
    private Consumer<ReleaseEvent> releaseHandler = FunctionUtils.nopConsumer();
    private boolean canChangeValue;
    private boolean dragging;
    private double valueX;
    private double valueY;

    private boolean valueXBound;
    private boolean valueYBound;

    private FZCustom2DSlider(boolean bound) {
        super(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT, class_5244.field_39003);
        this.bound = bound;
        updateCursorBounds();
    }

    private static double clamp(double value) {
        return Math.clamp(value, 0.0, 1.0);
    }

    public double getValueX() {
        return valueX;
    }

    public double getValueY() {
        return valueY;
    }

    private boolean isXBound() {
        return bound && valueXBound;
    }

    private boolean isYBound() {
        return bound && valueYBound;
    }

    private void updateCursorBounds() {
        class_8030 bounds = method_48202();

        double cursorCenterX = bounds.method_49620() + this.valueX * bounds.comp_1196();
        double cursorCenterY = bounds.method_49618() + (1f - this.valueY) * bounds.comp_1197();

        int cursorX = (int) (cursorCenterX - this.cursorSize / 2f);
        int cursorY = (int) (cursorCenterY - this.cursorSize / 2f);

        if (ScreenRectangleUtils.unequal(this.cursorBounds, cursorX, cursorY, this.cursorSize, this.cursorSize)) {
            this.cursorBounds = new class_8030(cursorX, cursorY, this.cursorSize, this.cursorSize);
        }
    }

    private void setBoundX(double x) {
        x = clamp(x);

        this.valueXBound = true;
        if (this.valueX != x) {
            this.valueX = x;
            updateCursorBounds();
        }
    }

    private void setBoundY(double y) {
        y = clamp(y);

        this.valueXBound = true;
        if (this.valueY != y) {
            this.valueY = y;
            updateCursorBounds();
        }
    }

    private void setBoundValues(double x, double y) {
        x = clamp(x);
        y = clamp(y);

        this.valueXBound = true;
        this.valueYBound = true;

        boolean updated = false;

        if (x != this.valueX) {
            this.valueX = x;
            updated = true;
        }

        if (y != this.valueY) {
            this.valueY = y;
            updated = true;
        }

        if (updated) {
            updateCursorBounds();
        }
    }

    private void setValues(double x, double y) {
        x = clamp(x);
        y = clamp(y);

        boolean xChanged = this.valueX != x;
        boolean yChanged = this.valueY != y;

        if (xChanged || yChanged) {
            boolean updated = false;

            if (!isXBound() && xChanged) {
                this.valueX = x;
                updated = true;
            }

            if (!isYBound() && yChanged) {
                this.valueY = y;
                updated = true;
            }

            if (updated) {
                updateCursorBounds();
            }

            this.changeHandler.accept(new ChangeEvent(this, x, y));
        }
    }

    private void setValuesFromMouse(double mouseX, double mouseY) {
        setValues((mouseX - method_46426()) / method_25368(), 1.0 - (mouseY - method_46427()) / method_25364());
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        this.canChangeValue = true;
        this.dragging = method_37303();
        setValuesFromMouse(event.comp_4798(), event.comp_4799());
        clickHandler.accept(new ClickEvent(this, event));
    }

    @Override
    protected void method_25349(class_11909 event, double dx, double dy) {
        setValuesFromMouse(event.comp_4798(), event.comp_4799());
        dragHandler.accept(new DragEvent(this, event));
    }

    @Override
    public void method_25357(class_11909 event) {
        if (this.dragging) {
            this.dragging = false;
            super.method_25354(class_310.method_1551().method_1483());
            releaseHandler.accept(new ReleaseEvent(this, event));
        }
    }

    @Override
    public void method_25354(class_1144 soundManager) {
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        boolean cursorHovered = cursorBounds.method_58137(mouseX, mouseY) && graphics.method_58135(mouseX, mouseY);
        this.field_22762 |= cursorHovered;

        this.background.get(method_37303(), method_25370() && !this.canChangeValue).extractRenderState(
                graphics,
                method_46426(),
                method_46427(),
                method_25368(),
                method_25364(),
                mouseX,
                mouseY,
                partialTick
        );

        if (method_49606()) {
            graphics.method_74037(method_37303() ? class_11876.field_62454 : class_11876.field_62459);
        }

        cursor.get(method_37303(), method_49606() || this.canChangeValue).extractRenderState(
                graphics,
                cursorBounds.method_49620(),
                cursorBounds.method_49618(),
                cursorBounds.comp_1196(),
                cursorBounds.comp_1197(),
                mouseX,
                mouseY,
                partialTick
        );

        if (this.dragging) {
            graphics.method_74037(class_11876.field_62458);
        }

        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        updateCursorBounds();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        updateCursorBounds();
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        updateCursorBounds();
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        updateCursorBounds();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        updateCursorBounds();
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return super.method_25405(mouseX, mouseY) || (method_37303() && cursorBounds.method_58137((int) mouseX, (int) mouseY));
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(cachedBounds, this)) {
            this.cachedBounds = super.method_48202();
        }
        return super.method_48202();
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (event.method_74229()) {
            this.canChangeValue = !this.canChangeValue;
            return true;
        }

        if (this.canChangeValue) {
            class_8028 screenDirection = NavigationUtils.getDirection(event);

            if (screenDirection != null) {
                switch (screenDirection.method_48237()) {
                    case field_41822 -> {
                        float direction = screenDirection.method_48241() ? 1f : -1f;
                        setValues(this.valueX + direction / (method_25368() - cursorBounds.comp_1196()), this.valueY);
                    }
                    case field_41823 -> {
                        float direction = screenDirection.method_48241() ? -1f : 1f;
                        setValues(this.valueX, this.valueY + direction / (method_25364() - cursorBounds.comp_1197()));
                    }
                }
                return true;
            }
        }

        return false;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            this.canChangeValue = false;
        }
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        class_8016 path = super.method_48205(event);

        if (event instanceof class_8023.class_8026 && path != null && path.comp_1188() == this) {
            return NavigationUtils.afterFocusEffect(path, (ignored, focused) -> this.canChangeValue = focused);
        }

        return path;
    }

    @Override
    public boolean method_72784() {
        return propsState.focusOnInteraction;
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    private void applyProps(Props props) {
        propsState.apply(this, props);

        props.background().ifPresent(background -> this.background = background);
        props.cursor().ifPresent(cursor -> this.cursor = cursor);
        props.cursorSize().ifPresent(size -> {
            this.cursorSize = size;
            updateCursorBounds();
        });

        props.changeHandler().ifPresent(changeHandler -> this.changeHandler = changeHandler.value());
        props.clickHandler().ifPresent(clickHandler -> this.clickHandler = clickHandler.value());
        props.dragHandler().ifPresent(dragHandler -> this.dragHandler = dragHandler.value());
        props.releaseHandler().ifPresent(releaseHandler -> this.releaseHandler = releaseHandler.value());

        if (props.valueX().isPresent() && props.valueY().isPresent()) {
            setBoundValues(props.valueX().getAsDouble(), props.valueY().getAsDouble());
        } else {
            props.valueY().ifPresentOrElse(this::setBoundX, () -> this.valueYBound = false);
            props.valueY().ifPresentOrElse(this::setBoundY, () -> this.valueYBound = false);
        }
    }

    public static FZCustom2DSlider bind(String key, FZRef<Props> props) {
        FZCustom2DSlider saturationValueArea = new FZCustom2DSlider(true);
        saturationValueArea.applyProps(props.value());
        props.subscribe(key, saturationValueArea::applyProps);
        return saturationValueArea;
    }

    public static Builder builder() {
        return new Builder();
    }

    public record ChangeEvent(FZCustom2DSlider target, double x, double y) {
    }

    public record ClickEvent(FZCustom2DSlider target, class_11909 buttonEvent) {
    }

    public record DragEvent(FZCustom2DSlider target, class_11909 buttonEvent) {
    }

    public record ReleaseEvent(FZCustom2DSlider target, class_11909 buttonEvent) {
    }

    public interface Props extends GuiComponentProps {
        default Optional<WidgetRenderables> background() {
            return Optional.empty();
        }

        default Optional<WidgetRenderables> cursor() {
            return Optional.empty();
        }

        default OptionalInt cursorSize() {
            return OptionalInt.empty();
        }

        default OptionalDouble valueX() {
            return OptionalDouble.empty();
        }

        default OptionalDouble valueY() {
            return OptionalDouble.empty();
        }

        default Optional<FZKeyed<Consumer<ChangeEvent>>> changeHandler() {
            return Optional.empty();
        }

        default Optional<FZKeyed<Consumer<ClickEvent>>> clickHandler() {
            return Optional.empty();
        }

        default Optional<FZKeyed<Consumer<DragEvent>>> dragHandler() {
            return Optional.empty();
        }

        default Optional<FZKeyed<Consumer<ReleaseEvent>>> releaseHandler() {
            return Optional.empty();
        }
    }

    private static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final @Nullable FZKeyed<Consumer<ChangeEvent>> changeHandler;
        private final @Nullable FZKeyed<Consumer<ClickEvent>> clickHandler;
        private final @Nullable FZKeyed<Consumer<DragEvent>> dragHandler;
        private final @Nullable FZKeyed<Consumer<ReleaseEvent>> releaseHandler;
        private final @Nullable Double valueX;
        private final @Nullable Double valueY;
        private final @Nullable WidgetRenderables background;
        private final @Nullable WidgetRenderables cursor;
        private final @Nullable Integer cursorSize;

        public PropsImpl(
                GuiComponentProps props,
                @Nullable FZKeyed<Consumer<ChangeEvent>> changeHandler,
                @Nullable FZKeyed<Consumer<ClickEvent>> clickHandler,
                @Nullable FZKeyed<Consumer<DragEvent>> dragHandler,
                @Nullable FZKeyed<Consumer<ReleaseEvent>> releaseHandler,
                @Nullable Double valueX,
                @Nullable Double valueY,
                @Nullable WidgetRenderables background,
                @Nullable WidgetRenderables cursor,
                @Nullable Integer cursorSize
        ) {
            super(props);
            this.changeHandler = changeHandler;
            this.clickHandler = clickHandler;
            this.dragHandler = dragHandler;
            this.releaseHandler = releaseHandler;
            this.valueX = valueX;
            this.valueY = valueY;
            this.background = background;
            this.cursor = cursor;
            this.cursorSize = cursorSize;
        }

        @Override
        public Optional<WidgetRenderables> background() {
            return Optional.ofNullable(background);
        }

        @Override
        public Optional<WidgetRenderables> cursor() {
            return Optional.ofNullable(cursor);
        }

        @Override
        public OptionalInt cursorSize() {
            return wrapBoxedInt(cursorSize);
        }

        @Override
        public OptionalDouble valueX() {
            return wrapBoxedDouble(valueX);
        }

        @Override
        public OptionalDouble valueY() {
            return wrapBoxedDouble(valueY);
        }

        @Override
        public Optional<FZKeyed<Consumer<ChangeEvent>>> changeHandler() {
            return Optional.ofNullable(changeHandler);
        }

        @Override
        public Optional<FZKeyed<Consumer<ClickEvent>>> clickHandler() {
            return Optional.ofNullable(clickHandler);
        }

        @Override
        public Optional<FZKeyed<Consumer<DragEvent>>> dragHandler() {
            return Optional.ofNullable(dragHandler);
        }

        @Override
        public Optional<FZKeyed<Consumer<ReleaseEvent>>> releaseHandler() {
            return Optional.ofNullable(releaseHandler);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(changeHandler(), other.changeHandler()) &&
                   Objects.equals(clickHandler(), other.clickHandler()) &&
                   Objects.equals(dragHandler(), other.dragHandler()) &&
                   Objects.equals(releaseHandler(), other.releaseHandler()) &&
                   Objects.equals(valueX(), other.valueX()) &&
                   Objects.equals(valueY(), other.valueY()) &&
                   Objects.equals(background(), other.background()) &&
                   Objects.equals(cursor(), other.cursor()) &&
                   Objects.equals(cursorSize(), other.cursorSize());
        }

        @Override
        public int hashCode() {
            return Objects.hash(
                    super.hashCode(),
                    changeHandler,
                    clickHandler,
                    dragHandler,
                    releaseHandler,
                    valueX,
                    valueY,
                    background,
                    cursor,
                    cursorSize
            );
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private @Nullable FZKeyed<Consumer<ChangeEvent>> changeHandler;
        private @Nullable FZKeyed<Consumer<ClickEvent>> clickHandler;
        private @Nullable FZKeyed<Consumer<DragEvent>> dragHandler;
        private @Nullable FZKeyed<Consumer<ReleaseEvent>> releaseHandler;
        private @Nullable Double valueX;
        private @Nullable Double valueY;
        private @Nullable WidgetRenderables background;
        private @Nullable WidgetRenderables cursor;
        private @Nullable Integer cursorSize;

        private Builder() {
        }

        public Builder background(WidgetRenderables background) {
            this.background = background;
            return this;
        }

        public Builder background(RenderableRectangle background) {
            return background(new WidgetRenderables(background));
        }

        public Builder background(class_2960 sprite) {
            return background(Renderables.sprite(sprite));
        }

        public Builder cursor(WidgetRenderables cursor) {
            this.cursor = cursor;
            return this;
        }

        public Builder cursor(RenderableRectangle cursor) {
            return cursor(new WidgetRenderables(cursor));
        }

        public Builder cursor(class_2960 sprite) {
            return cursor(Renderables.sprite(sprite));
        }

        public Builder cursorSize(int size) {
            this.cursorSize = size;
            return this;
        }

        public Builder valueX(double x) {
            this.valueX = x;
            return this;
        }

        public Builder valueY(double y) {
            this.valueY = y;
            return this;
        }

        public Builder values(double x, double y) {
            return valueX(x).valueY(y);
        }

        public Builder onChange(Consumer<ChangeEvent> changeHandler) {
            this.changeHandler = FZKeyed.selfKey(Objects.requireNonNull(changeHandler, "changeHandler cannot be null"));
            return this;
        }

        public Builder onChange(Object key, Consumer<ChangeEvent> changeHandler) {
            this.changeHandler = new FZKeyed<>(key, Objects.requireNonNull(changeHandler, "changeHandler cannot be null"));
            return this;
        }

        public Builder onClick(Consumer<ClickEvent> clickHandler) {
            this.clickHandler = FZKeyed.selfKey(Objects.requireNonNull(clickHandler, "clickHandler cannot be null"));
            return this;
        }

        public Builder onClick(Object key, Consumer<ClickEvent> clickHandler) {
            this.clickHandler = new FZKeyed<>(key, Objects.requireNonNull(clickHandler, "clickHandler cannot be null"));
            return this;
        }

        public Builder onDrag(Consumer<DragEvent> dragHandler) {
            this.dragHandler = FZKeyed.selfKey(Objects.requireNonNull(dragHandler, "dragHandler cannot be null"));
            return this;
        }

        public Builder onDrag(Object key, Consumer<DragEvent> dragHandler) {
            this.dragHandler = new FZKeyed<>(key, Objects.requireNonNull(dragHandler, "dragHandler cannot be null"));
            return this;
        }

        public Builder onRelease(Consumer<ReleaseEvent> releaseHandler) {
            this.releaseHandler = FZKeyed.selfKey(Objects.requireNonNull(releaseHandler, "releaseHandler cannot be null"));
            return this;
        }

        public Builder onRelease(Object key, Consumer<ReleaseEvent> releaseHandler) {
            this.releaseHandler = new FZKeyed<>(key, Objects.requireNonNull(releaseHandler, "releaseHandler cannot be null"));
            return this;
        }

        public Props toProps() {
            return new PropsImpl(
                    props,
                    changeHandler,
                    clickHandler,
                    dragHandler,
                    releaseHandler,
                    valueX,
                    valueY,
                    background,
                    cursor,
                    cursorSize
            );
        }

        public FZCustom2DSlider build() {
            FZCustom2DSlider saturationValueArea = new FZCustom2DSlider(false);
            saturationValueArea.applyProps(toProps());
            return saturationValueArea;
        }
    }
}
