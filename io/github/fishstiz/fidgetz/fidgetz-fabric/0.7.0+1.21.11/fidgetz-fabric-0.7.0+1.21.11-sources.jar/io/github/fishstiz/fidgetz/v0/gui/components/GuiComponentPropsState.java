package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import org.jspecify.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_339;

public class GuiComponentPropsState {
    public @Nullable String id;
    public boolean focusOnInteraction = true;
    public @Nullable RenderableRectangle overlay = null;
    public Consumer<FZContextMenu.Collector> contextEntries = FunctionUtils.nopConsumer();
    private int boundWidth;
    private int boundHeight;

    public GuiComponentPropsState() {
    }

    private void apply(GuiComponentProps props) {
        props.id().ifPresent(id -> this.id = id);
        GuiComponentPropsBase.ifNonDefault(props.focusOnInteraction(), f -> this.focusOnInteraction = f.method_61348(true));
        props.overlay().ifDefined(overlay -> this.overlay = overlay);
        props.contextEntries().ifPresent(entries -> this.contextEntries = entries.value());
    }

    public void apply(class_339 widget, GuiComponentProps props) {
        props.width().ifPresent(width -> {
            // workaround to allow setting an initial width for bound widgets without locking it into that initial width
            // if the width is static. for flex layout
            if (widget.method_25368() != this.boundWidth && this.boundWidth == width) {
                return;
            }
            this.boundWidth = width;
            if (widget.method_25368() != width) {
                widget.method_25358(width);
            }
        });
        props.height().ifPresent(height -> {
            if (widget.method_25364() != this.boundHeight && this.boundHeight == height) {
                return;
            }
            this.boundHeight = height;
            if (widget.method_25364() != height) {
                widget.method_53533(height);
            }
        });
        GuiComponentPropsBase.ifNonDefault(props.active(), a -> widget.field_22763 = a.method_61348(true));
        GuiComponentPropsBase.ifNonDefault(props.visible(), a -> widget.field_22764 = a.method_61348(true));
        props.tooltip().ifDefined(widget::method_47400);
        props.message().ifPresent(widget::method_25355);
        props.tabOrderGroup().ifPresent(widget::method_48591);
        apply(props);
    }
}
