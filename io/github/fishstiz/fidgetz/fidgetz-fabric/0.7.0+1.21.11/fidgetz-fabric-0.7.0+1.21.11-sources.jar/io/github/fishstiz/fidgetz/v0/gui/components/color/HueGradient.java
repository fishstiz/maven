package io.github.fishstiz.fidgetz.v0.gui.components.color;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.SimpleGuiRenderState;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import net.minecraft.class_332;
import net.minecraft.class_8030;
import io.github.fishstiz.fidgetz.v0.gui.color.HSVA;
import org.joml.Matrix3x2f;

public record HueGradient() implements RenderableRectangle {
    private static final int GRADIENTS = 6;

    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        extractRenderState(graphics, left, top, width, height);
    }

    public static void extractRenderState(class_332 graphics, int left, int top, int width, int height) {
        class_8030 bounds = new class_8030(left, top, width, height);

        GuiGraphicsUtils.addGuiElement(graphics, SimpleGuiRenderState.from(graphics, bounds, (state, vertexConsumer) -> {
            class_8030 area = state.comp_4274();
            if (area == null) return;

            Matrix3x2f pose = state.pose();
            float gradientWidth = (float) area.comp_1196() / GRADIENTS;

            for (int i = 0; i < GRADIENTS; i++) {
                int colorLeft = HSVA.toARGB(i * 60f, 1.0f, 1.0f, 1.0f);
                int colorRight = HSVA.toARGB((i + 1) * 60f, 1.0f, 1.0f, 1.0f);

                float x0 = area.method_49620() + i * gradientWidth;
                float x1 = area.method_49620() + (i + 1) * gradientWidth;

                vertexConsumer.method_70815(pose, x0, area.method_49618()).method_39415(colorLeft);
                vertexConsumer.method_70815(pose, x0, area.method_49619()).method_39415(colorLeft);
                vertexConsumer.method_70815(pose, x1, area.method_49619()).method_39415(colorRight);
                vertexConsumer.method_70815(pose, x1, area.method_49618()).method_39415(colorRight);
            }
        }));
    }
}
