package io.github.fishstiz.fidgetz.v0.gui.renderables;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import org.joml.Matrix3x2f;
import org.jspecify.annotations.Nullable;

import java.util.function.BiConsumer;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_8030;

public record SimpleGuiRenderState(
        BiConsumer<SimpleGuiRenderState, class_4588> verticesBuilder,
        Matrix3x2f pose,
        @Nullable class_8030 bounds,
        @Nullable class_8030 scissorArea
) implements class_11244 {
    public static SimpleGuiRenderState from(
            class_332 graphics,
            class_8030 bounds,
            BiConsumer<SimpleGuiRenderState, class_4588> verticesBuilder
    ) {
        Matrix3x2f pose = new Matrix3x2f(graphics.method_51448());
        class_8030 scissorArea = GuiGraphicsUtils.peekScissorStack(graphics);
        bounds = bounds.method_71523(pose);
        class_8030 intersection = scissorArea == null ? bounds : scissorArea.method_49701(bounds);
        return new SimpleGuiRenderState(verticesBuilder, pose, intersection, scissorArea);
    }

    @Override
    public RenderPipeline comp_4055() {
        return class_10799.field_56879;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public void method_70917(class_4588 vertexConsumer) {
        verticesBuilder.accept(this, vertexConsumer);
    }

    public void addQuadWith2DPose(
            class_4588 vertexConsumer,
            class_8030 bounds,
            int color1,
            int color2,
            int color3,
            int color4
    ) {
        vertexConsumer.method_70815(pose, bounds.method_49620(), bounds.method_49618()).method_39415(color1);
        vertexConsumer.method_70815(pose, bounds.method_49620(), bounds.method_49619()).method_39415(color2);
        vertexConsumer.method_70815(pose, bounds.method_49621(), bounds.method_49619()).method_39415(color3);
        vertexConsumer.method_70815(pose, bounds.method_49621(), bounds.method_49618()).method_39415(color4);
    }
}
