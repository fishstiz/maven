package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import io.github.fishstiz.fidgetz.v0.utils.TriState;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

public class FZLayoutList extends AbstractListWidget<FZLayoutList.Entry> implements class_8133, FZComponent, FZContextMenu.Source {
    protected static final int DEFAULT_WIDTH = 300;
    protected static final int DEFAULT_HEIGHT = 150;
    protected static final int DEFAULT_SCROLL_RATE = 10;
    private final List<class_4068> renderables = new ArrayList<>();
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private FZFlexLayout layout;
    private FZKeyed<Consumer<RefreshEvent>> entryInitializer = FZKeyed.selfKey(FunctionUtils.nopConsumer());
    private int maxContentWidth = DEFAULT_MAX_CONTENT_WIDTH;
    private int contentPaddingLeft;
    private int contentPaddingRight;
    private boolean reserveScrollbarWidth;
    private class_8030 bounds;

    protected FZLayoutList(int width, int height, class_2561 message) {
        super(0, 0, width, height, message);
        setScrollRate(DEFAULT_SCROLL_RATE);
        layout = FZFlexLayout.vertical();
        bounds = super.method_48202();
    }

    protected FZLayoutList() {
        this(DEFAULT_WIDTH, DEFAULT_HEIGHT, class_5244.field_39003);
    }

    protected void collectEntries(RefreshEvent event) {
        entryInitializer.value().accept(event);
    }

    public final void refreshEntries() {
        class_364 lastFocused = method_25336();
        String lastFocusedId = null;

        for (Iterator<io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry> it = method_25396().listIterator(); it.hasNext(); ) {
            io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry entry = it.next();
            it.remove();
            if (lastFocused != null && entry.widget == lastFocused) {
                lastFocusedId = entry.id;
            }
        }

        renderables.clear();

        FZFlexLayout newLayout = FZFlexLayout.vertical().maxWidth(contentWidth()).maxHeight(0);

        MutableBoolean focusUnresolved = new MutableBoolean(true);
        MutableInt count = new MutableInt(0);
        int hashCode = hashCode();

        WidgetVisitor widgetSink = getWidgetSink(lastFocused, lastFocusedId, focusUnresolved, count, hashCode);
        RefreshEvent refreshEvent = new RefreshEvent(widgetSink, newLayout);
        collectEntries(refreshEvent);
        refreshEvent.flushComponents();

        if (focusUnresolved.booleanValue()) method_25395(null);

        this.layout = newLayout;
        method_48222();
    }

    private WidgetVisitor getWidgetSink(
            @Nullable class_364 lastFocused,
            @Nullable String lastFocusedId,
            MutableBoolean focusUnresolved,
            MutableInt count,
            int hashCode
    ) {
        return new WidgetVisitor() {
            @Override
            public <T extends class_364 & class_6379> void visitWidget(T widget) {
                String id = widget instanceof FZComponent component ? component.fidgetz$componentId() : null;
                if (id == null)
                    id = "FZList@%s-element-%s-%s".formatted(hashCode, count.intValue(), widget.getClass().getName());

                io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry entry = new io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry(id, widget);
                method_25321(entry);
                count.increment();

                if (widget == lastFocused || (Objects.equals(id, lastFocusedId) && focusUnresolved.booleanValue())) {
                    method_25395(entry);
                    focusUnresolved.setValue(false);
                }
            }
        };
    }

    protected int maxContentWidth() {
        return maxContentWidth;
    }

    protected int contentPaddingLeft() {
        return contentPaddingLeft;
    }

    protected int contentPaddingRight() {
        return contentPaddingRight;
    }

    protected boolean reserveScrollbarWidth() {
        return reserveScrollbarWidth;
    }

    @Override
    protected int contentHeight() {
        return layout.method_25364();
    }

    @Override
    protected int scrollBarX() {
        return Math.min(layout.method_46426() + layout.method_25368() + contentPaddingRight(), method_55442() - scrollbarWidth());
    }

    @Override
    public void method_48222() {
        int contentWidth = contentWidth();
        int contentLeft = contentLeft();
        layout.maxWidth(contentWidth);
        layout.method_48222();
        layout.method_48229(contentLeft(), method_46427());

        if (!reserveScrollbarWidth()) {
            int newContentWidth = contentWidth();
            int newContentLeft = contentLeft();
            if (contentWidth != newContentWidth || contentLeft != newContentLeft) {
                layout.fidgetz$setWidth(newContentWidth);
            }
        }

        refreshScrollAmount();
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_8030 bounds = method_48202();
        for (class_4068 renderable : renderables) {
            if (!(renderable instanceof class_8021 element) || element.method_48202().method_48252(bounds)) {
                renderable.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(graphics, mouseX, mouseY, partialTick);
        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, partialTick);
        }
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        layout.method_46421(contentLeft());
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        layout.method_46419(y - (int) scrollAmount());
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        method_48222();
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        method_48222();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        method_48222();
    }

    @Override
    public void method_25307(double scrollAmount) {
        super.method_25307(scrollAmount);
        layout.method_46419(method_46427() - (int) scrollAmount());
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            this.bounds = super.method_48202();
        }
        return this.bounds;
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
        FZContextMenu.Source.super.fidgetz$updateContextEntries(x, y, collector);
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    @Override
    public boolean fidgetz$shouldTakeFocusAfterInteraction() {
        return propsState.focusOnInteraction;
    }

    private @Nullable io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry getEntryAt(double x, double y) {
        for (io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry entry : method_25396()) {
            if (entry.widget.method_25405(x, y)) {
                return entry;
            }
        }
        return null;
    }

    private @Nullable io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry resolveEntry(io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry unknownEntry) {
        for (io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry entry : method_25396()) {
            if (unknownEntry == entry ||
                unknownEntry.widget == entry.widget ||
                unknownEntry.id.equals(entry.id)) {
                return entry;
            }
        }
        return null;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean scrolled = updateScrolling(mouseX, mouseY, button);

        io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry entry = getEntryAt(mouseX, mouseY);
        if (entry != null && entry.widget.method_25402(mouseX, mouseY, button)) {
            // buttons are only focused after end of mouseClicked,
            // so when a button inside the list reinitializes entries,
            // the new button instance with the same id as the clicked button cannot be refocused
            io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry clickedEntry = resolveEntry(entry);
            if (clickedEntry != null) {
                method_25395(clickedEntry);
                if (method_25351(button)) {
                    method_25398(true);
                }
                return true;
            }
        }

        return scrolled;
    }

    protected void applyProps(Props props) {
        this.propsState.apply(this, props);

        props.maxContentWidth().ifPresent(maxWidth -> this.maxContentWidth = maxWidth);
        props.contentPaddingLeft().ifPresent(padding -> this.contentPaddingLeft = padding);
        props.contentPaddingRight().ifPresent(padding -> this.contentPaddingRight = padding);

        if (props.reserveScrollbarWidth() != TriState.DEFAULT) {
            this.reserveScrollbarWidth = props.reserveScrollbarWidth().toBoolean(false);
        }

        props.scrollRate().ifPresent(this::setScrollRate);

        props.refreshHandler().ifPresent(initializer -> {
            FZKeyed<Consumer<RefreshEvent>> previousEntryInitializer = this.entryInitializer;
            this.entryInitializer = initializer;
            if (!Objects.equals(previousEntryInitializer, this.entryInitializer)) {
                this.refreshEntries();
            }
        });
    }

    public static FZLayoutList bind(String key, FZRef<Props> ref) {
        Props props = ref.value();
        FZLayoutList list = new FZLayoutList();
        list.applyProps(props);
        ref.subscribe(key, list::applyProps);
        return list;
    }

    public static Builder builder() {
        return new Builder();
    }

    static final class Entry extends AbstractListWidget.Entry<io.github.fishstiz.fidgetz.v0.gui.components.FZLayoutList.Entry> implements FZComponent {
        private final String id;
        private final class_364 widget;
        private final List<class_364> children;

        private Entry(String id, class_364 widget) {
            this.id = id;
            this.widget = widget;
            this.children = List.of(widget);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return children;
        }

        @Override
        public void method_25365(boolean focused) {
            widget.method_25365(focused);
        }

        @Override
        public boolean method_25370() {
            return widget.method_25370();
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            return widget.method_48205(navigationEvent);
        }

        @Override
        public class_8030 method_48202() {
            return widget.method_48202();
        }

        @Override
        public void method_16014(double mouseX, double mouseY) {
            widget.method_16014(mouseX, mouseY);
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            return widget.method_25402(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return widget.method_25406(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
            return widget.method_25403(mouseX, mouseY, button, dragX, dragY);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
            return widget.method_25401(mouseX, mouseY, scrollX, scrollY);
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            return widget.method_25404(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean method_16803(int keyCode, int scanCode, int modifiers) {
            return widget.method_16803(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean method_25400(char codePoint, int modifiers) {
            return widget.method_25400(codePoint, modifiers);
        }

        @Override
        public @Nullable class_364 method_25399() {
            return widget.method_25370() ? widget : null;
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (focused == null) {
                widget.method_25365(false);
            } else if (focused == widget) {
                widget.method_25365(true);
            }
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return widget.method_25405(mouseX, mouseY);
        }

        @Override
        public @Nullable class_8016 method_48218() {
            return widget.method_48218();
        }

        @Override
        public int method_48590() {
            return widget.method_48590();
        }

        @Override
        public boolean fidgetz$shouldTakeFocusAfterInteraction() {
            return widget instanceof FZComponent component
                    ? component.fidgetz$shouldTakeFocusAfterInteraction()
                    : FZComponent.super.fidgetz$shouldTakeFocusAfterInteraction();
        }
    }

    public final class RefreshEvent {
        private final GuiComponentCollector collector = new GuiComponentCollector();
        private final WidgetVisitor widgetSink;
        private final FZFlexLayout layout;

        private RefreshEvent(WidgetVisitor widgetSink, FZFlexLayout layout) {
            this.widgetSink = widgetSink;
            this.layout = layout;
        }

        public GuiComponentCollector collector() {
            return collector;
        }

        public FZLayoutList target() {
            return FZLayoutList.this;
        }

        public FZFlexLayout layout() {
            return layout;
        }

        public void flushComponents() {
            layout.method_48206(collector::renderableWidget);
            collector.flushTo(widgetSink, renderables::add);
        }
    }

    public interface Props extends GuiComponentProps {
        default OptionalInt maxContentWidth() {
            return OptionalInt.empty();
        }

        default OptionalInt contentPaddingLeft() {
            return OptionalInt.empty();
        }

        default OptionalInt contentPaddingRight() {
            return OptionalInt.empty();
        }

        default TriState reserveScrollbarWidth() {
            return TriState.DEFAULT;
        }

        default OptionalInt scrollRate() {
            return OptionalInt.empty();
        }

        default Optional<FZKeyed<Consumer<RefreshEvent>>> refreshHandler() {
            return Optional.empty();
        }
    }

    protected static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final @Nullable FZKeyed<Consumer<RefreshEvent>> refreshHandler;
        private final @Nullable Integer maxContentWidth;
        private final @Nullable Integer contentPaddingLeft;
        private final @Nullable Integer contentPaddingRight;
        private final TriState reserveScrollbarWidth;
        private final @Nullable Integer scrollRate;

        protected PropsImpl(
                GuiComponentProps props,
                @Nullable FZKeyed<Consumer<RefreshEvent>> refreshHandler,
                @Nullable Integer maxContentWidth,
                @Nullable Integer contentPaddingLeft,
                @Nullable Integer contentPaddingRight,
                TriState reserveScrollbarWidth,
                @Nullable Integer scrollRate
        ) {
            super(props);
            this.refreshHandler = refreshHandler;
            this.maxContentWidth = maxContentWidth;
            this.contentPaddingLeft = contentPaddingLeft;
            this.contentPaddingRight = contentPaddingRight;
            this.reserveScrollbarWidth = reserveScrollbarWidth;
            this.scrollRate = scrollRate;
        }

        @Override
        public Optional<FZKeyed<Consumer<RefreshEvent>>> refreshHandler() {
            return Optional.ofNullable(refreshHandler);
        }

        @Override
        public OptionalInt maxContentWidth() {
            return wrapBoxedInt(maxContentWidth);
        }

        @Override
        public OptionalInt contentPaddingLeft() {
            return wrapBoxedInt(contentPaddingLeft);
        }

        @Override
        public OptionalInt contentPaddingRight() {
            return wrapBoxedInt(contentPaddingRight);
        }

        @Override
        public TriState reserveScrollbarWidth() {
            return reserveScrollbarWidth;
        }

        @Override
        public OptionalInt scrollRate() {
            return wrapBoxedInt(scrollRate);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o)
                   && Objects.equals(maxContentWidth(), other.maxContentWidth())
                   && Objects.equals(contentPaddingLeft(), other.contentPaddingLeft())
                   && Objects.equals(contentPaddingRight(), other.contentPaddingRight())
                   && reserveScrollbarWidth == other.reserveScrollbarWidth()
                   && Objects.equals(scrollRate(), other.scrollRate())
                   && Objects.equals(refreshHandler(), other.refreshHandler());
        }

        @Override
        public int hashCode() {
            return Objects.hash(
                    super.hashCode(),
                    maxContentWidth,
                    contentPaddingLeft,
                    contentPaddingRight,
                    reserveScrollbarWidth,
                    scrollRate,
                    refreshHandler
            );
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private @Nullable FZKeyed<Consumer<RefreshEvent>> refreshHandler;
        private @Nullable Integer maxContentWidth;
        private @Nullable Integer contentPaddingLeft;
        private @Nullable Integer contentPaddingRight;
        private TriState reserveScrollbarWidth = TriState.DEFAULT;
        private @Nullable Integer scrollRate;

        private Builder() {
        }

        public Builder scrollRate(int scrollRate) {
            this.scrollRate = scrollRate;
            return this;
        }

        public Builder onRefresh(Consumer<RefreshEvent> refreshHandler) {
            this.refreshHandler = FZKeyed.selfKey(refreshHandler);
            return this;
        }


        public Builder onRefresh(Object key, Consumer<RefreshEvent> refreshHandler) {
            this.refreshHandler = new FZKeyed<>(key, Objects.requireNonNull(refreshHandler, "refreshHandler cannot be null"));
            return this;
        }

        public Builder maxContentWidth(int maxContentWidth) {
            this.maxContentWidth = maxContentWidth;
            return this;
        }

        public Builder contentPaddingLeft(int contentPaddingLeft) {
            this.contentPaddingLeft = contentPaddingLeft;
            return this;
        }

        public Builder contentPaddingRight(int contentPaddingRight) {
            this.contentPaddingRight = contentPaddingRight;
            return this;
        }

        public Builder contentPadding(int contentPadding) {
            return contentPaddingLeft(contentPadding).contentPaddingRight(contentPadding);
        }

        public Builder reserveScrollbarWidth(boolean reserveScrollbarWidth) {
            this.reserveScrollbarWidth = TriState.from(reserveScrollbarWidth);
            return this;
        }

        public Builder reserveScrollbarWidth() {
            return reserveScrollbarWidth(true);
        }

        public Props toProps() {
            return new PropsImpl(
                    props,
                    refreshHandler,
                    maxContentWidth,
                    contentPaddingLeft,
                    contentPaddingRight,
                    reserveScrollbarWidth,
                    scrollRate
            );
        }

        public FZLayoutList build() {
            FZLayoutList list = new FZLayoutList(DEFAULT_WIDTH, DEFAULT_HEIGHT, props.message().orElse(class_5244.field_39003));
            list.applyProps(toProps());
            list.refreshEntries();
            return list;
        }
    }
}
