package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import io.github.fishstiz.fidgetz.v0.utils.TriState;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_8012;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

public abstract class FZAbstractListWidget<E extends FZAbstractListWidget.Entry<E>> extends AbstractListWidget<E> {
    protected static final int DEFAULT_SCROLL_RATE = 10;
    private @Nullable E hovered;
    private class_8030 bounds;
    private int cachedContentHeight;
    private double previousScrollAmount;

    protected FZAbstractListWidget(int x, int y, int width, int height, class_2561 message) {
        super(class_310.method_1551(), x, y, width, height, message);
        this.bounds = new class_8030(method_46426(), method_46427(), method_25368(), method_25364());
        setScrollRate(DEFAULT_SCROLL_RATE);
    }

    protected FZAbstractListWidget(class_2561 message) {
        this(0, 0, 0, 0, message);
    }

    protected FZAbstractListWidget() {
        this(class_5244.field_39003);
    }

    @Override
    protected int addEntry(E entry) {
        entry.index = method_25396().size();
        super.method_25321(entry);
        return entry.getIndex();
    }

    @Override
    protected boolean removeEntry(E entry) {
        if (super.method_25330(entry)) {
            entry.index = -1;
            if (entry == method_25399()) {
                method_25395(null);
            }
            if (entry == method_37019()) {
                setHovered(null);
            }

            return true;
        }
        return false;
    }

    protected void method_25339() {
        for (Iterator<E> iterator = method_25396().iterator(); iterator.hasNext(); ) {
            E entry = iterator.next();
            entry.index = -1;
            iterator.remove();
        }

        method_25395(null);
        setHovered(null);

        this.cachedContentHeight = 0;

        refreshScrollAmount();
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (focused == null || focused instanceof io.github.fishstiz.fidgetz.v0.gui.components.FZAbstractListWidget.Entry) {
            super.method_25395(focused);
        } else {
            focused.method_25365(false);
        }
    }

    @Override
    public @Nullable E method_25399() {
        return super.method_25336();
    }

    protected void setHovered(@Nullable E hovered) {
        if (this.hovered != hovered) {
            if (this.hovered != null) {
                this.hovered.setHovered(false);
            }
            if (hovered != null) {
                hovered.setHovered(true);
            }
            this.hovered = hovered;
        }
    }

    protected @Nullable E method_37019() {
        return this.hovered;
    }

    protected @Nullable E getPreviousEntry(@Nullable E current) {
        if (current != null && current.getIndex() > 0) {
            return this.method_25396().get(current.getIndex() - 1);
        } else if (current == null && !this.method_25396().isEmpty()) {
            return this.method_25396().getFirst();
        }
        return null;
    }

    protected @Nullable E getNextEntry(@Nullable E current) {
        if (current != null && current.getIndex() + 1 < this.method_25396().size()) {
            return this.method_25396().get(current.getIndex() + 1);
        } else if (current == null && !this.method_25396().isEmpty()) {
            return this.method_25396().getFirst();
        }
        return null;
    }

    protected void extractFocusedRenderState(class_332 graphics, E focused) {
        graphics.method_49601(focused.method_46426(), focused.method_46427(), focused.method_25368(), focused.method_25364(), class_8012.field_42973);
    }

    @Override
    protected void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_8030 bounds = method_48202();
        for (E entry : method_25396()) {
            if (entry.method_48202().method_48252(bounds)) {
                if (entry.method_25405(mouseX, mouseY)) {
                    setHovered(entry);
                } else if (method_37019() == entry) {
                    setHovered(null);
                }
                entry.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        E focused = method_25399();
        if (focused != null) {
            extractFocusedRenderState(graphics, focused);
        }
    }

    @Override
    protected int contentHeight() {
        return cachedContentHeight;
    }

    protected int rowSpacing() {
        return 0;
    }

    private void refreshEntries() {
        int childX = contentLeft();
        int childY = method_46427() - (int) scrollAmount();
        int childWidth = contentWidth();
        int totalheight = 0;

        for (int i = 0; i < method_25396().size(); i++) {
            E child = method_25396().get(i);
            child.index = i;

            int height = child.method_25364();
            int marginTop = child.getMarginTop();
            int marginBottom = child.getMarginBottom();

            child.setBounds(childX, childY + marginTop, childWidth, height);
            int occupiedHeight = height + marginTop + marginBottom + (i + 1 < method_25396().size() ? rowSpacing() : 0);

            childY += occupiedHeight;
            totalheight += occupiedHeight;
        }

        this.cachedContentHeight = totalheight;

        if (!reserveScrollbarWidth()) {
            int newChildX = contentLeft();
            int newChildWidth = contentWidth();
            if (newChildWidth != childWidth || newChildX != childX) {
                for (E child : method_25396()) {
                    child.setBounds(newChildX, child.method_46427(), newChildWidth, child.method_25364());
                }
            }
        }
    }

    protected void repositionEntries() {
        refreshEntries();
        refreshScrollAmount();
    }

    @Override
    public void method_25307(double scrollAmount) {
        super.method_25307(scrollAmount);
        double currentScrollAmount = scrollAmount();
        if (this.previousScrollAmount != currentScrollAmount) {
            // SmoothScrolling is directly modifying the scroll amount field before using the setter to redraw only,
            // so can't check diff with just another local variable as scroll amount is already updated when this is called.
            // https://github.com/SmajloSlovakian/Minecraft-Smooth-Scrolling/blob/54b2fcb0c3a9494781961f571a1426bafb24958f/src/client/java/io/github/smajloslovakian/smoothscroll/mixin/client/Widgets/AbstractScrollAreaMixin.java#L41-L47
            this.previousScrollAmount = currentScrollAmount;
            refreshEntries();
        }
    }

    protected void scrollToEntry(E entry) {
        int topDelta = entry.method_46427() - method_46427() - 2;
        if (topDelta < 0) {
            scroll(topDelta);
        }
        int bottomDelta = method_55443() - entry.method_46427() - entry.method_25364() - 2;
        if (bottomDelta < 0) {
            scroll(-bottomDelta);
        }
    }

    protected void centerScrollOn(E entry) {
        int y = 0;
        for (E child : this.method_25396()) {
            if (child == entry) {
                y += child.method_25364() / 2;
                break;
            }
            y += child.method_25364();
        }
        method_25307(y - method_25364() / 2.0);
    }

    protected void scroll(double amount) {
        method_25307(scrollAmount() + amount);
    }

    private void updateBounds() {
        this.bounds = new class_8030(method_46426(), method_46427(), method_25368(), method_25364());
    }

    @Override
    public void method_46421(int x) {
        int previousX = method_46426();
        super.method_46421(x);
        updateBounds();
        if (previousX != method_46426()) {
            repositionEntries();
        }
    }

    @Override
    public void method_46419(int y) {
        int previousY = method_46427();
        super.method_46419(y);
        updateBounds();
        if (previousY != method_46427()) {
            repositionEntries();
        }
    }

    @Override
    public void method_25358(int width) {
        int previousWidth = method_25368();
        super.method_25358(width);
        updateBounds();
        if (previousWidth != method_25368()) {
            int childWidth = contentWidth();
            for (E child : method_25396()) {
                child.setWidth(childWidth);
            }
        }
    }

    @Override
    public void method_53533(int height) {
        int previousHeight = method_25364();
        super.method_53533(height);
        updateBounds();
        if (previousHeight != method_25364()) {
            refreshScrollAmount();
        }
    }

    @Override
    public void method_55445(int width, int height) {
        int previousWidth = method_25368();
        int previousHeight = method_25364();
        super.method_55445(width, height);
        updateBounds();
        if (previousWidth != method_25368() || previousHeight != method_25364()) {
            repositionEntries();
        }
    }

    @Override
    public class_8030 method_48202() {
        return bounds;
    }

    protected abstract static class Entry<E extends io.github.fishstiz.fidgetz.v0.gui.components.FZAbstractListWidget.Entry<E>> extends AbstractListWidget.Entry<E> implements
            class_8021,
            class_4068,
            class_6379,
            FZHoverableContainer,
            ContainerEventHandlerPatch {
        private class_8030 bounds;
        int index;
        private boolean focused;
        private boolean hovered;
        private TriState fidgetz$hovered = TriState.DEFAULT;
        private @Nullable class_364 fidgetz$hoveredElement;

        protected Entry(int height) {
            this.bounds = new class_8030(0, 0, 0, height);
        }

        protected Entry() {
            this.bounds = class_8030.method_48248();
        }

        protected int getIndex() {
            return index;
        }

        @Override
        public void method_46421(int x) {
            this.bounds = ScreenRectangleUtils.withLeft(bounds, x);
        }

        @Override
        public void method_46419(int y) {
            this.bounds = ScreenRectangleUtils.withTop(bounds, y);
        }

        protected void setWidth(int width) {
            this.bounds = ScreenRectangleUtils.withWidth(bounds, width);
        }

        protected void setHeight(int height) {
            this.bounds = ScreenRectangleUtils.withHeight(bounds, height);
        }

        protected void setBounds(int x, int y, int width, int height) {
            this.bounds = new class_8030(x, y, width, height);
        }

        @Override
        public int method_46426() {
            return bounds.method_49620();
        }

        @Override
        public int method_46427() {
            return bounds.method_49618();
        }

        @Override
        public int method_25368() {
            return bounds.comp_1196();
        }

        @Override
        public int method_25364() {
            return bounds.comp_1197();
        }

        protected int getMarginTop() {
            return 0;
        }

        protected int getMarginBottom() {
            return 0;
        }

        @Override
        public void method_25365(boolean focused) {
            this.focused = focused;
            if (!focused) {
                method_25395(null);
            }
        }

        @Override
        public boolean method_25370() {
            return focused;
        }

        void setHovered(boolean hovered) {
            this.hovered = hovered;
            if (!hovered) {
                fidgetz$setHovered(null);
            }
        }

        public boolean isHovered() {
            return hovered && fidgetz$hovered != TriState.FALSE;
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return method_48202().method_58137((int) mouseX, (int) mouseY);
        }

        @Override
        public class_8030 method_48202() {
            return bounds;
        }

        @Override
        public class_6380 method_37018() {
            if (method_25370()) {
                return class_6380.field_33786;
            } else if (isHovered()) {
                return class_6380.field_33785;
            }
            return class_6380.field_33784;
        }

        @Override
        public void method_37020(class_6382 output) {
        }

        @Override
        public void method_48206(Consumer<class_339> widgetVisitor) {
        }

        @Override
        public final boolean fidgetz$isHovered() {
            return fidgetz$hovered == TriState.TRUE || fidgetz$getHovered() != null;
        }

        @Override
        public final void fidgetz$setHovered(boolean hovered) {
            this.fidgetz$hovered = TriState.from(hovered);
            if (!hovered) {
                fidgetz$setHovered(null);
            }
        }

        @Override
        public final void fidgetz$setHovered(@Nullable class_364 hovered) {
            class_364 previous = fidgetz$getHovered();
            if (previous != hovered) {
                if (previous instanceof FZHoverableElement previousElement) {
                    previousElement.fidgetz$setHovered(false);
                }
                if (hovered instanceof FZHoverableElement hoverableElement) {
                    hoverableElement.fidgetz$setHovered(true);
                }
                fidgetz$hoveredElement = hovered;
            }
        }

        @Override
        public final @Nullable class_364 fidgetz$getHovered() {
            return fidgetz$hoveredElement;
        }

        @Override
        public final boolean fidgetz$updateHovered(double mouseX, double mouseY) {
            fidgetz$setHovered(method_25405(mouseX, mouseY));
            boolean hovered = fidgetz$isHovered();
            if (hovered) {
                for (class_364 child : method_25396()) {
                    if (((FZHoverableElement) child).fidgetz$updateHovered(mouseX, mouseY)) {
                        fidgetz$setHovered(child);
                        return true;
                    }
                }
                fidgetz$setHovered(null);
                return true;
            }
            fidgetz$setHovered(null);
            return false;
        }
    }
}
