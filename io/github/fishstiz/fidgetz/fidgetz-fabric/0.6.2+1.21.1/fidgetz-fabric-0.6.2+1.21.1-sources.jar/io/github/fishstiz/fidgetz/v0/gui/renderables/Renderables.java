package io.github.fishstiz.fidgetz.v0.gui.renderables;

import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class Renderables {
    private Renderables() {
    }

    public static RenderableRectangle fill(int color) {
        return new ColoredRectangle(color);
    }

    public static RenderableRectangle outline(int color) {
        return new Outline(color);
    }

    public static RenderableRectangle text(String text) {
        return text(class_2561.method_43470(Objects.requireNonNull(text, "text cannot be null")));
    }

    public static RenderableRectangle text(class_2561 text) {
        Objects.requireNonNull(text, "text cannot be null");
        return new TextRectangle(() -> text);
    }

    public static RenderableRectangle text(Supplier<class_2561> text) {
        return new TextRectangle(Objects.requireNonNull(text, "text cannot be null"));
    }

    public static RenderableRectangle boxShadow(float scale) {
        return new BoxShadow(scale, 0, 0);
    }

    public static RenderableRectangle boxShadow(float scale, int xOffset, int yOffset) {
        return new BoxShadow(scale, xOffset, yOffset);
    }

    public static RenderableRectangle sprite(class_2960 sprite) {
        return new RenderableGuiSprite(Objects.requireNonNull(sprite, "sprite cannot be null"));
    }

    public static RenderableRectangle texture(
            class_2960 texture,
            int textureWidth,
            int textureHeight,
            float u,
            float v,
            int uWidth,
            int vHeight
    ) {
        return new RenderableTexture(Objects.requireNonNull(texture, "texture cannot be null"), textureWidth, textureHeight, u, v, uWidth, vHeight);
    }

    public static RenderableRectangle texture(class_2960 texture, int textureWidth, int textureHeight, int width, int height) {
        return texture(texture, textureWidth, textureHeight, 0, 0, width, height);
    }

    public static RenderableRectangle texture(class_2960 texture, int textureWidth, int textureHeight) {
        return texture(texture, textureWidth, textureHeight, 0, 0, textureWidth, textureHeight);
    }
}
