package io.github.fishstiz.fidgetz.v0.inject.mixins.debug;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.fishstiz.fidgetz.v0.gui.debug.FZDebugOverlay;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings({"unused", "UnusedMixin"})
@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "render", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V"
    ))
    public void extractTestmodRenderState(
            class_9779 deltaTracker,
            boolean shouldRenderLevel,
            CallbackInfo ci,
            @Local(ordinal = 0) class_332 graphics
    ) {
        FZDebugOverlay.extractRenderState(graphics);
    }
}
