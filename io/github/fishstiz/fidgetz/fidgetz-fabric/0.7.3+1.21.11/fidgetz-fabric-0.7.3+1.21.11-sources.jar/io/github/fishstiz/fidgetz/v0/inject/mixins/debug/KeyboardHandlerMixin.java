package io.github.fishstiz.fidgetz.v0.inject.mixins.debug;

import io.github.fishstiz.fidgetz.v0.gui.debug.FZDebugOverlay;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings({"unused", "UnusedMixin"})
@Mixin(class_309.class)
abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"), require = 0)
    private void onKeyPress(long handle, int action, class_11908 event, CallbackInfo ci) {
        if (action != 0) {
            switch (event.comp_4795()) {
                case class_3675.field_31922 -> FZDebugOverlay.focusPath = !FZDebugOverlay.focusPath;
                case class_3675.field_31923 -> FZDebugOverlay.hovered = !FZDebugOverlay.hovered;
            }
        }
    }
}
