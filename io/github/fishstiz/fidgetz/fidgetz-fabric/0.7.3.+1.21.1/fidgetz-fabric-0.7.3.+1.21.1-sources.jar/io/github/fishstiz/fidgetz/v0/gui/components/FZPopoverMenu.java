package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZComposedLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZFlexLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZLayout;
import io.github.fishstiz.fidgetz.v0.gui.layouts.FZScrollableLayout;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;

public class FZPopoverMenu extends FZDialog {
    protected static final class_8030 DEFAULT_PADDING = ScreenRectangleUtils.insets(4);
    private static final class_8030 DEFAULT_BORDER = class_8030.method_48248();
    protected static final RenderableRectangle DEFAULT_BACKGROUND = Renderables
            .boxShadow(24)
            .then(Renderables.sprite(Fidgetz.id("widget/popovermenu")));
    protected static final int DEFAULT_MAX_HEIGHT = 240;
    protected static final int DEFAULT_SPACING = 1;
    private final @Nullable FZPopoverMenu parent;
    private @Nullable RenderableRectangle background = DEFAULT_BACKGROUND;
    private FZPopoverMenuItem.@Nullable Divider sectionDivider = FZPopoverMenuEntryImpl.Divider.DEFAULT_SECTION;
    private FZPopoverMenuItem.@Nullable Divider entryDivider = FZPopoverMenuEntryImpl.Divider.DEFAULT_ENTRY;
    private class_8030 padding = DEFAULT_PADDING;
    private class_8030 border = DEFAULT_BORDER;
    private int rowSpacing = DEFAULT_SPACING;
    private int maxHeight = DEFAULT_MAX_HEIGHT;
    private int minWidth;
    private int maxWidth;
    private @Nullable ChildDetails child;
    private HorizontalDirection preferredDirection = HorizontalDirection.RIGHT;
    private HorizontalDirection currentDirection = HorizontalDirection.RIGHT;
    private class_8030 bounds = class_8030.method_48248();
    private @Nullable FZLayout layout;
    private @Nullable FZScrollableLayout innerLayout;

    private FZPopoverMenu(class_4069 container, @Nullable FZPopoverMenu parent) {
        super(container);
        this.parent = parent;
    }

    protected FZPopoverMenu(class_4069 container) {
        this(container, null);
    }

    protected void setBackground(@Nullable RenderableRectangle background) {
        this.background = background;
        if (child != null) {
            child.menu.setBackground(background);
        }
    }

    protected void setSectionDivider(FZPopoverMenuItem.@Nullable Divider sectionDivider) {
        this.sectionDivider = sectionDivider;
        if (child != null) {
            child.menu.setSectionDivider(sectionDivider);
        }
    }

    protected void setEntryDivider(FZPopoverMenuItem.@Nullable Divider entryDivider) {
        this.entryDivider = entryDivider;
        if (child != null) {
            child.menu.setEntryDivider(entryDivider);
        }
    }

    protected void setPreferredDirection(HorizontalDirection preferredDirection) {
        this.preferredDirection = preferredDirection;
        if (child != null) {
            child.menu.setPreferredDirection(preferredDirection);
        }
    }

    protected void setPadding(class_8030 padding) {
        this.padding = padding;
        if (child != null) {
            child.menu.setPadding(padding);
        }
    }

    protected void setBorder(class_8030 border) {
        this.border = border;
        if (child != null) {
            child.menu.setBorder(border);
        }
    }

    protected void setRowSpacing(int rowSpacing) {
        this.rowSpacing = rowSpacing;
        if (child != null) {
            child.menu.setRowSpacing(rowSpacing);
        }
    }

    protected void setMaxHeight(int maxHeight) {
        this.maxHeight = maxHeight;
        if (child != null) {
            child.menu.setMaxHeight(maxHeight);
        }
    }

    protected void setMinWidth(int minWidth) {
        this.minWidth = minWidth;
        if (child != null) {
            child.menu.setMinWidth(minWidth);
        }
    }

    protected void setMaxWidth(int maxWidth) {
        this.maxWidth = maxWidth;
        if (child != null) {
            child.menu.setMinWidth(maxWidth);
        }
    }

    protected void setX(int x) {
        if (layout != null) {
            if (child != null) {
                child.menu.setX(child.menu.getX() + x - layout.method_46426());
            }
            layout.method_46421(x);
            bounds = layout.method_48202();
        }
    }

    protected void setY(int y) {
        if (layout != null) {
            if (child != null) {
                child.menu.setY(child.menu.getY() + y - layout.method_46427());
            }
            layout.method_46419(y);
            bounds = layout.method_48202();
        }
    }

    protected int getX() {
        return method_48202().method_49620();
    }

    protected int getY() {
        return method_48202().method_49618();
    }

    @Override
    protected float getZ() {
        return parent == null ? super.getZ() : 1f;
    }

    private void applyLayout(@Nullable FZScrollableLayout newScrollableLayout) {
        if (newScrollableLayout == null) {
            this.layout = null;
            this.innerLayout = null;
            this.bounds = class_8030.method_48248();
            return;
        }

        int borderX = border.method_49620() + border.method_49621();
        int borderY = border.method_49618() + border.method_49619();

        newScrollableLayout.maxHeight(Math.max(0, maxHeight - borderY));

        FZLayout bordered = FZComposedLayout.compose(newScrollableLayout)
                .padding(border.method_49620(), border.method_49618(), border.method_49621(), border.method_49619());

        bordered.method_48222();

        if (newScrollableLayout.method_25368() + borderX < this.minWidth
            || (this.maxWidth > 0 && newScrollableLayout.method_25368() + borderX > this.maxWidth)) {

            newScrollableLayout.fidgetz$setWidth(MathUtils.clampOptionalMax(
                    newScrollableLayout.method_25368(),
                    this.minWidth - borderX,
                    this.maxWidth - borderX
            ));
        }

        this.layout = bordered;
        this.innerLayout = newScrollableLayout;
        this.bounds = bordered.method_48202();
    }

    @Override
    public void repositionElements() {
        applyLayout(this.innerLayout);
        if (child != null) {
            child.menu.repositionElements();
        }
    }

    protected HorizontalDirection getPreferredDirection() {
        return HorizontalDirection.RIGHT;
    }

    @Override
    public boolean shouldCaptureClick() {
        return false;
    }

    @Override
    public boolean shouldFocusOnOpen() {
        return parent == null;
    }

    @Override
    public boolean shouldRefocusLastPath() {
        return parent == null;
    }

    @Override
    public class_8030 method_48202() {
        return bounds;
    }

    protected void build(List<FZPopoverMenuItem> items) {
        FZFlexLayout content = FZFlexLayout.vertical().spacing(rowSpacing);
        content.defaultChildSettings().flexCross();

        int entryCount = 0;
        int maxEntryWidth = 0;

        for (int i = 0; i < items.size(); i++) {
            FZPopoverMenuItem current = items.get(i);
            FZPopoverMenuItem next = (i + 1 < items.size()) ? items.get(i + 1) : null;
            boolean canDivideNext = next != null && !(next instanceof FZPopoverMenuItem.Divider);

            if (current instanceof FZPopoverMenuItem.Divider divider) {
                if (canDivideNext && entryCount > 0) {
                    FZPopoverMenuItem.Divider resolved = FZPopoverMenuEntryImpl.Divider.DEFAULT_SECTION;
                    if (divider.factory() != null) {
                        resolved = divider;
                    }
                    if (sectionDivider != null && sectionDivider.factory() != null) {
                        resolved = sectionDivider;
                    }
                    content.child(new EntryWidget(resolved));
                }
            } else {
                EntryWidget entryWidget = new EntryWidget(current);
                FZPopoverMenuItem.Entry entry = entryWidget.entry;
                content.child(entryWidget);
                maxEntryWidth = Math.max(maxEntryWidth, entry.method_25368());
                entryCount++;
                if (canDivideNext && entryDivider != null && current.settings().autoDividerAfter()) {
                    content.child(new EntryWidget(Objects.requireNonNullElse(
                            entryDivider,
                            FZPopoverMenuEntryImpl.Divider.DEFAULT_ENTRY
                    )));
                }
            }
        }

        if (entryCount == 0) {
            applyLayout(null);
            clearWidgets();
            return;
        }

        content.fidgetz$setWidth(maxEntryWidth);

        FZScrollableLayout newScrollableLayout = FZComposedLayout.compose(content)
                .padding(padding.method_49620(), padding.method_49618(), padding.method_49621(), padding.method_49619())
                .toScrollable(container)
                .scrollbarSpacing(0)
                .maxHeight(Math.max(0, maxHeight));

        applyLayout(newScrollableLayout);

        clearWidgets();
        GuiComponentCollector collector = new GuiComponentCollector();
        newScrollableLayout.method_48206(collector::renderableWidget);
        collector.flushTo(this::addWidget, this::addRenderableOnly);
    }

    private void openAndPosition(int x, int y, HorizontalDirection direction, List<FZPopoverMenuItem> items) {
        build(items);
        if (layout == null) {
            close();
        } else {
            class_8030 targetBounds = layout.method_48202();
            class_8030 containerBounds = container.method_48202();
            HorizontalDirection newDirection = direction.resolve(containerBounds, targetBounds.comp_1196(), x);
            layout.method_46421(newDirection.clamp(containerBounds, targetBounds.comp_1196(), x));
            layout.method_46419(Math.max(0, y + targetBounds.comp_1197() > containerBounds.comp_1197() ? containerBounds.comp_1197() - targetBounds.comp_1197() : y));
            this.currentDirection = newDirection;
            this.bounds = layout.method_48202();
            setOpen(true);
        }
    }

    protected void openAndPosition(int x, int y, List<FZPopoverMenuItem> entries) {
        openAndPosition(x, y, getPreferredDirection(), entries);
    }

    @Override
    protected void clearWidgets() {
        super.clearWidgets();
        this.child = null;
    }

    @Override
    protected void onClose() {
        super.onClose();

        if (child != null) {
            child.menu.close();
        }

        clearWidgets();
        this.currentDirection = getPreferredDirection();
        this.layout = null;
        this.bounds = class_8030.method_48248();

        if (parent != null) {
            if (parent.child != null) {
                parent.child.key.method_25365(false);
            }

            parent.child = null;

            if (parent.method_25399() == this) {
                parent.method_25395(null);
                class_8016 path = menuPath(parent, null);
                if (path != null) {
                    path.method_48195(true);
                }
            }
        }
    }

    public void close() {
        setOpen(false);
    }

    private void closeAll() {
        if (parent != null) {
            parent.closeAll();
        } else {
            close();
        }
    }

    private void closeChild() {
        if (child != null) {
            child.menu.close();
        }
    }

    private void openChild(EntryWidget entry, List<FZPopoverMenuItem> entries) {
        if (child != null && child.key == entry) return;

        FZPopoverMenu menu = new FZPopoverMenu(container, this);
        menu.background = background;
        menu.sectionDivider = sectionDivider;
        menu.entryDivider = entryDivider;
        menu.padding = padding;
        menu.border = border;
        menu.preferredDirection = preferredDirection;
        menu.rowSpacing = rowSpacing;
        menu.maxHeight = maxHeight;
        menu.minWidth = minWidth;

        class_8030 entryBounds = entry.method_48202();
        int anchor = currentDirection.edge(entryBounds);
        HorizontalDirection newDirection = currentDirection.resolve(container.method_48202(), method_48202().comp_1196(), anchor);
        int x = newDirection.edge(entryBounds);
        int y = entryBounds.method_49618();

        menu.openAndPosition(x, y, newDirection, entries);
        closeChild();
        addWidgetFirst(menu);

        child = new ChildDetails(entry, menu);
    }

    @Override
    protected void extractDialogRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (background != null) {
            background.extractRenderState(graphics, bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197(), mouseX, mouseY, partialTick);
        }
        super.extractDialogRenderState(graphics, mouseX, mouseY, partialTick);
        if (child != null) {
            child.menu.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected boolean areCoordinatesInBounds(double x, double y) {
        return super.areCoordinatesInBounds(x, y) || (child != null && child.menu.areCoordinatesInBounds(x, y));
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return super.method_25405(mouseX, mouseY) || (child != null && child.menu.method_25405(mouseX, mouseY));
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 event) {
        if (child != null) {
            class_8016 path = child.menu.method_48205(event);
            if (path != null) {
                return class_8016.method_48192(this, path);
            }
        }

        return super.method_48205(event);
    }

    private static @Nullable class_8016 menuPath(FZPopoverMenu current, @Nullable class_8016 childPath) {
        if (childPath == null) {
            return current.parent == null
                    ? NavigationUtils.findPath(current.container, current)
                    : menuPath(current.parent, class_8016.method_48193(current));
        }

        class_8016 path = childPath.comp_1188() == current
                ? childPath
                : class_8016.method_48192(current, childPath);

        if (current.parent != null) {
            return menuPath(current.parent, path);
        }

        class_8016 containerPath = NavigationUtils.findPath(current.container, current);
        return containerPath == null
                ? null
                : NavigationUtils.appendPath(containerPath, path);
    }

    private record ChildDetails(EntryWidget key, FZPopoverMenu menu) {
    }

    private final class EntryWidget extends class_339 implements FZPopoverMenuItem.Context, FZComponent, ContainerEventHandlerPatch {
        private final FZPopoverMenuItem.Entry entry;
        private final FZPopoverMenuItem.Settings settings;
        private final List<FZPopoverMenuItem.Entry> singletonChild;
        private class_8030 entryBounds = class_8030.method_48248();
        private @Nullable class_364 focused;
        private boolean lastHovered;
        private boolean dragging;

        private EntryWidget(FZPopoverMenuItem item) {
            super(0, 0, minWidth, 0, class_5244.field_39003);
            this.settings = item.settings();
            this.entry = item.factory().create(this);
            this.singletonChild = List.of(entry);
            this.field_22759 = this.entry.method_25364();
            this.field_22758 = this.entry.method_25368();
            this.entryBounds = super.method_48202();
        }

        @Override
        public void closeMenu() {
            closeAll();
        }

        @Override
        public List<FZPopoverMenuItem.Entry> method_25396() {
            return singletonChild;
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (method_37303() && entry.method_25402(mouseX, mouseY, button)) {
                if (settings.closeOnInteract()) {
                    closeMenu();
                } else if (isOpen() && entry.fidgetz$shouldTakeFocusAfterInteraction()) {
                    method_25395(entry);

                    if (button == class_3675.field_32000) {
                        method_25398(true);
                    }
                }
                return true;
            }
            return false;
        }

        @Override
        protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            entry.method_25394(graphics, mouseX, mouseY, partialTick);
            boolean hovered = method_49606();
            if (hovered && !lastHovered) {
                updateChild();
            }
            lastHovered = hovered;
        }

        private void updateChild() {
            if (FZPopoverMenu.this.method_25399() == null || !FZPopoverMenu.this.method_25397()) {
                List<FZPopoverMenuItem> children = entry.childItems();
                if (children.isEmpty() || !entry.method_37303()) {
                    closeChild();
                } else {
                    openChild(this, children);
                }
            }
        }

        @Override
        protected void method_47399(class_6382 output) {
            entry.method_37020(output);
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            return class_8016.method_48192(this, entry.method_48205(navigationEvent));
        }

        @Override
        public @Nullable class_8016 method_48218() {
            return class_8016.method_48192(this, entry.method_48218());
        }

        @Override
        public boolean method_37303() {
            return entry.method_37303();
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return (super.method_25405(mouseX, mouseY) || (method_37303() && entry.method_25405(mouseX, mouseY)))
                   && (child == null || !child.menu().method_25405(mouseX, mouseY));
        }

        @Override
        public boolean isChildOpened() {
            return child != null && child.key == this && child.menu.isOpen();
        }

        private boolean handleKeyboardFocusOnClose() {
            if (parent == null) return false;

            ChildDetails child = parent.child;
            close();

            class_8016 path = menuPath(parent, child == null
                    ? parent.method_48205(new class_8023.class_8025())
                    : NavigationUtils.findPath(parent, child.key)
            );

            if (path != null) {
                path.method_48195(true);
                return true;
            }

            return false;
        }

        private boolean handleKeyboardFocusOnOpen() {
            if (isChildOpened()) return false;

            List<FZPopoverMenuItem> children = entry.childItems();
            if (children.isEmpty()) return false;

            openChild(this, children);
            if (child == null) return false;

            class_8016 path = menuPath(child.menu, NavigationUtils.initialFocus(child.menu));
            if (path != null) {
                path.method_48195(true);
                method_25365(true);
                return true;
            }
            return false;
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (!isOpen()) {
                return false;
            }
            if (entry.method_25404(keyCode, scanCode, modifiers)) {
                if ((keyCode == class_3675.field_31957 || keyCode == class_3675.field_31980) &&
                    settings.closeOnInteract()) {
                    closeMenu();
                }
                return true;
            }
            if (keyCode == class_3675.field_31983) {
                return handleKeyboardFocusOnClose();
            }
            if (keyCode == class_3675.field_31984 ||
                keyCode == class_3675.field_31957 ||
                keyCode == class_3675.field_31947 ||
                keyCode == class_3675.field_31980) {
                return handleKeyboardFocusOnOpen();
            }
            return false;
        }

        @Override
        public @Nullable class_364 method_25399() {
            return focused;
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            class_364 previous = method_25399();
            if (previous != focused) {
                if (previous != null) {
                    previous.method_25365(false);
                }
                if (focused != null) {
                    focused.method_25365(true);
                }
                this.focused = focused;
            }
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);
            if (!focused) {
                method_25395(null);
            }
        }

        @Override
        public boolean method_25397() {
            return this.dragging;
        }

        @Override
        public void method_25398(boolean dragging) {
            this.dragging = dragging;
        }

        private void updateEntryX() {
            int availableSpace = method_25368() - entry.method_25368();
            int alignedX = method_46426() + Math.round(availableSpace * Math.clamp(settings.xAlignment(), 0.0f, 1.0f));
            entry.method_46421(alignedX);
        }

        @Override
        public void method_46421(int x) {
            super.method_46421(x);
            entryBounds = super.method_48202();
            updateEntryX();
        }

        @Override
        public void method_46419(int y) {
            super.method_46419(y);
            entryBounds = super.method_48202();
            entry.method_46419(y);
        }

        @Override
        public void method_55445(int width, int height) {
            method_25358(width);
            method_53533(entry.method_25364());
        }

        @Override
        public void method_25358(int width) {
            super.method_25358(width);
            entryBounds = super.method_48202();
            if (settings.stretch() || width <= entry.method_25368()) {
                entry.setWidth(width);
            }
            updateEntryX();
        }

        @Override
        public void method_53533(int height) {
            super.method_53533(entry.method_25364());
            entryBounds = super.method_48202();
        }

        @Override
        public int method_25364() {
            return entry.method_25364();
        }

        @Override
        public class_8030 method_48202() {
            return entryBounds;
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            super.method_25406(mouseX, mouseY, button);
            return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, final double dx, final double dy) {
            super.method_25403(mouseX, mouseY, button, dx, dy);
            return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dx, dy);
        }

        @Override
        public boolean fidgetz$shouldTakeFocusAfterInteraction() {
            return isOpen() && entry.fidgetz$shouldTakeFocusAfterInteraction();
        }

        @Override
        public boolean method_25370() {
            return super.method_25370() || method_25399() != null;
        }

        // override methods to resolve mappings on fabric

        @Override
        public boolean method_49606() {
            return super.method_49606();
        }

        @Override
        public boolean isFocusedOrHovered() {
            return method_25370() || method_49606();
        }
    }
}
