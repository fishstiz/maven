package io.github.fishstiz.fidgetz.v0.gui.debug;

import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_437;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public final class FZDebugOverlay {
    private static final float SCALE = 0.8f;
    private static final String FOCUS_LABEL = "Focus Path: ";
    private static final String HOVERED_LABEL = "Hovered Path: ";

    public static boolean hovered = System.getProperty("fidgetz.debug.hovered") != null;
    public static boolean focusPath = System.getProperty("fidgetz.debug.focusPath") != null;

    private static void pushScale(class_332 graphics) {
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0.0f, 0.0f, 5000);
        graphics.method_51448().method_22905(SCALE, SCALE, 0);
    }

    public static void extractRenderState(class_332 graphics) {
        class_310 minecraft = class_310.method_1551();
        class_437 screen = minecraft.field_1755;

        if (screen != null) {
            int y = 0;

            class_327 font = minecraft.field_1772;
            boolean scaled = false;

            if (focusPath) {
                pushScale(graphics);
                scaled = true;
                y += extractFocusRenderState(graphics, font, screen, y) + font.field_2000;
            }
            if (hovered) {
                if (!scaled) pushScale(graphics);
                scaled = true;

                extractHoveredRenderState(graphics, font, screen, y, minecraft);
            }

            if (scaled) {
                graphics.method_51448().method_22909();
            }
        }
    }

    private static int extractFocusRenderState(class_332 graphics, class_327 font, class_437 screen, int y) {
        graphics.method_25294(0, y, font.method_1727(FOCUS_LABEL), y + font.field_2000, 0x5FFF0000);
        graphics.method_25303(font, FOCUS_LABEL, 0, y, 0xFFFFFFFF);
        return extractFocusRenderState(graphics, font, screen.method_25399(), y + font.field_2000);
    }

    private static int extractFocusRenderState(
            class_332 graphics,
            class_327 font,
            @Nullable class_364 focused,
            int y
    ) {
        if (focused == null) return y;

        String name = focused.getClass().getName();
        graphics.method_25294(0, y, font.method_1727(name), y + font.field_2000, 0x5FFF0000);
        graphics.method_25303(font, name, 0, y, 0xFFFFFFFF);

        if (focused instanceof class_4069 container) {
            return extractFocusRenderState(graphics, font, container.method_25399(), y + font.field_2000);
        }

        return y + font.field_2000;
    }

    private static void extractHoveredRenderState(
            class_332 graphics,
            class_327 font,
            class_437 screen,
            int y,
            class_310 minecraft
    ) {
        if (screen == null) return;

        int mouseX = (int) (minecraft.field_1729.method_1603() * (double) minecraft.method_22683().method_4486() / (double) minecraft.method_22683().method_4480());
        int mouseY = (int) (minecraft.field_1729.method_1604() * (double) minecraft.method_22683().method_4502() / (double) minecraft.method_22683().method_4507());

        FZHoverableContainer hoverable = ((FZHoverableContainer) screen);
        hoverable.fidgetz$updateHovered(mouseX, mouseY);

        graphics.method_25294(0, y, font.method_1727(HOVERED_LABEL), y + font.field_2000, 0x5F0000FF);
        graphics.method_25303(font, HOVERED_LABEL, 0, y, 0xFFFFFFFF);
        extractHoveredRenderState(graphics, font, hoverable.fidgetz$getHovered(), y + font.field_2000, mouseX, mouseY);
    }

    private static int extractHoveredRenderState(
            class_332 graphics,
            class_327 font,
            @Nullable class_364 hovered,
            int y,
            int mouseX,
            int mouseY
    ) {
        if (hovered == null) {
            extractMousePosRenderState(
                    graphics,
                    font,
                    (int) (mouseX / SCALE) + 16,
                    clampY(graphics, font, (int) (mouseY / SCALE), 1),
                    mouseX,
                    mouseY
            );
            return y;
        }

        String name = hovered.getClass().getName();
        graphics.method_25294(0, y, font.method_1727(name), y + font.field_2000, 0x5F0000FF);
        graphics.method_25303(font, name, 0, y, 0xFFFFFFFF);

        if (hovered instanceof FZHoverableContainer container) {
            class_364 child = container.fidgetz$getHovered();
            if (child != null) {
                return extractHoveredRenderState(
                        graphics,
                        font,
                        container.fidgetz$getHovered(),
                        y + font.field_2000,
                        mouseX,
                        mouseY
                );
            }
            extractHoveredBoundsRenderState(graphics, font, hovered, mouseX, mouseY);
        } else {
            extractHoveredBoundsRenderState(graphics, font, hovered, mouseX, mouseY);
        }

        return y + font.field_2000;
    }

    private static void extractHoveredBoundsRenderState(
            class_332 graphics,
            class_327 font,
            class_364 hovered,
            int mouseX,
            int mouseY
    ) {
        class_8030 bounds = getBounds(hovered);
        String label = hovered.getClass().getName();

        int left = (int) (bounds.method_49620() / SCALE);
        int top = (int) (bounds.method_49618() / SCALE);
        int width = (int) (bounds.comp_1196() / SCALE);
        int height = (int) (bounds.comp_1197() / SCALE);

        int labelX = clampX(graphics, font, (int) (mouseX / SCALE) + 16, label);
        int labelY = clampY(graphics, font, (int) (mouseY / SCALE), 3);

        graphics.method_25294(labelX, labelY, labelX + font.method_1727(label), labelY + font.field_2000, 0xAF0000FF);
        graphics.method_49601(left, top, width, height, 0xFF0000FF);

        graphics.method_25294(left, top, left + width, top + height, 0x1F0000FF);
        graphics.method_25303(font, label, labelX, labelY, 0xFFFFFFFF);

        String boundsString = "x=%s,y=%s,w=%s,h=%s".formatted(bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197());
        int boundsY = labelY + font.field_2000;

        graphics.method_25294(labelX, boundsY, labelX + font.method_1727(boundsString), boundsY + font.field_2000, 0xAF0000FF);
        graphics.method_25303(font, boundsString, labelX, boundsY, 0xFFFFFFFF);

        extractMousePosRenderState(graphics, font, labelX, boundsY + font.field_2000, mouseX, mouseY);
    }

    private static void extractMousePosRenderState(
            class_332 graphics,
            class_327 font,
            int x,
            int y,
            int mouseX,
            int mouseY
    ) {
        String mousePos = "mx=%s,my=%s".formatted(mouseX, mouseY);
        x = clampX(graphics, font, x, mousePos);

        graphics.method_25294(x, y, x + font.method_1727(mousePos), y + font.field_2000, 0xAF0000FF);
        graphics.method_25303(font, mousePos, x, y, 0xFFFFFFFF);
    }

    private static int clampX(class_332 graphics, class_327 font, int x, String label) {
        int textWidth = font.method_1727(label);
        int screenWidth = (int) (graphics.method_51421() / SCALE);
        if (x + textWidth > screenWidth) {
            x = screenWidth - textWidth - 2;
        }
        return Math.max(0, x);
    }

    private static int clampY(class_332 graphics, class_327 font, int y, int lineCount) {
        int totalHeight = lineCount * font.field_2000;
        int screenHeight = (int) (graphics.method_51443() / SCALE);
        if (y + totalHeight > screenHeight) {
            y = screenHeight - totalHeight - 2;
        }
        return Math.max(0, y);
    }

    private static class_8030 getBounds(@Nullable class_364 element) {
        if (element instanceof class_8021 layoutElement) return layoutElement.method_48202();
        return element != null ? element.method_48202() : class_8030.method_48248();
    }

    private FZDebugOverlay() {
    }
}
