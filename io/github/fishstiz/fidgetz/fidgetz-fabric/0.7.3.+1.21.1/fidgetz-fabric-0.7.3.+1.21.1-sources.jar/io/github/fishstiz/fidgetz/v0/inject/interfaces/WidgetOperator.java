package io.github.fishstiz.fidgetz.v0.inject.interfaces;

import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public interface WidgetOperator {
    default void fidgetz$modifyWidgets(UnaryOperator<List<class_364>> modifier) {
    }

    default void fidgetz$modifyNarratables(UnaryOperator<List<class_6379>> modifier) {
    }

    default void fidgetz$modifyRenderables(UnaryOperator<List<class_4068>> modifier) {
    }

    default <T extends class_364 & class_6379> T fidgetz$addWidget(T widget) {
        return widget;
    }

    default <T extends class_4068> T fidgetz$addRenderableOnly(T renderable) {
        return renderable;
    }

    default <T extends class_364 & class_6379 & class_4068> T fidgetz$addRenderableWIdget(T widget) {
        return widget;
    }

    default void fidgetz$removeWidget(class_364 widget) {
    }

    default void fidgetz$rebuildWidgets() {
    }
}
