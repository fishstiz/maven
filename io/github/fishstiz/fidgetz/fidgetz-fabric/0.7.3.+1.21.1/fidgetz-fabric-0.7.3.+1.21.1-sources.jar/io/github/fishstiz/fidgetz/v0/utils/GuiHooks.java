package io.github.fishstiz.fidgetz.v0.utils;

import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.fidgetz.v0.inject.interfaces.ContextMenuSourceConsumer;
import io.github.fishstiz.fidgetz.v0.inject.interfaces.WidgetOperator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

public final class GuiHooks {
    public static void modifyRenderables(class_437 screen, UnaryOperator<List<class_4068>> modifier) {
        ((WidgetOperator) screen).fidgetz$modifyRenderables(modifier);
    }

    public static void modifyWidgets(class_437 screen, UnaryOperator<List<class_364>> modifier) {
        ((WidgetOperator) screen).fidgetz$modifyWidgets(modifier);
    }

    public static void modifyNarratables(class_437 screen, UnaryOperator<List<class_6379>> modifier) {
        ((WidgetOperator) screen).fidgetz$modifyNarratables(modifier);
    }

    public static <T extends class_364 & class_6379> T addWidget(class_437 screen, T widget) {
        return ((WidgetOperator) screen).fidgetz$addWidget(widget);
    }

    public static <T extends class_4068> T addRenderableOnly(class_437 screen, T renderable) {
        return ((WidgetOperator) screen).fidgetz$addRenderableOnly(renderable);
    }

    public static <T extends class_364 & class_4068 & class_6379> T addRenderableWidget(class_437 screen, T widget) {
        return ((WidgetOperator) screen).fidgetz$addRenderableWIdget(widget);
    }

    public static void removeWidget(class_437 screen, class_364 widget) {
        ((WidgetOperator) screen).fidgetz$removeWidget(widget);
    }

    public static void rebuildWidgets(class_437 screen) {
        ((WidgetOperator) screen).fidgetz$rebuildWidgets();
    }

    public static void supplyContextMenuEntries(class_339 widget, Consumer<FZContextMenu.Collector> entrySupplier) {
        ((ContextMenuSourceConsumer) widget).fidgetz$setContextMenuSource(entrySupplier);
    }

    private GuiHooks() {
    }
}
