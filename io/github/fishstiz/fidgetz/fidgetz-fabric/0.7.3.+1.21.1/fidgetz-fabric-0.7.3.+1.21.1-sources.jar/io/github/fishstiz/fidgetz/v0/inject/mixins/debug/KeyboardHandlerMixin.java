package io.github.fishstiz.fidgetz.v0.inject.mixins.debug;

import io.github.fishstiz.fidgetz.v0.gui.debug.FZDebugOverlay;
import net.minecraft.class_309;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings({"unused", "UnusedMixin"})
@Mixin(class_309.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"))
    private void onKeyPress(long handle, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        if (action != 0) {
            switch (key) {
                case class_3675.field_31922 -> FZDebugOverlay.focusPath = !FZDebugOverlay.focusPath;
                case class_3675.field_31923 -> FZDebugOverlay.hovered = !FZDebugOverlay.hovered;
            }
        }
    }
}
