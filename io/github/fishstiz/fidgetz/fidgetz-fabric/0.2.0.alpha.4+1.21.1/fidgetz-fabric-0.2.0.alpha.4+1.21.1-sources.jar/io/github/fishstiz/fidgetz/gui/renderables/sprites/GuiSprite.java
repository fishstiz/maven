package io.github.fishstiz.fidgetz.gui.renderables.sprites;

import net.minecraft.class_2960;
import net.minecraft.class_332;

public class GuiSprite extends Sprite {
    public GuiSprite(class_2960 location, int width, int height) {
        super(location, width, height);
    }

    public GuiSprite(class_2960 location, int size) {
        this(location, size, size);
    }

    public static GuiSprite of32(class_2960 location) {
        return new GuiSprite(location, 32);
    }

    @Override
    public void render(class_332 guiGraphics, int x, int y, int width, int height, float partialTick) {
        guiGraphics.method_52706(this.location, x, y, width, height);
    }
}
