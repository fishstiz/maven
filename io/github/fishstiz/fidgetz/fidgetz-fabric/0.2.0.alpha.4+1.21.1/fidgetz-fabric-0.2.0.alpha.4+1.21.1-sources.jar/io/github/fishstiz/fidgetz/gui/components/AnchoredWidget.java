package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.components.contextmenu.ContextMenuContainer;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_8021;

public class AnchoredWidget extends ContainedWidget implements ContextMenuContainer {
    private final class_8021 container;
    private final float rowAnchor;
    private final float colAnchor;
    private float alignX;
    private float alignY;
    private int offsetX;
    private int offsetY;

    public AnchoredWidget(class_339 widget, class_8021 container, float rowAnchor, float colAnchor, float alignX, float alignY, int offsetX, int offsetY) {
        super(widget);
        this.container = container;
        this.rowAnchor = rowAnchor;
        this.colAnchor = colAnchor;
        this.alignX = alignX;
        this.alignY = alignY;
        this.offsetX = offsetX;
        this.offsetY = offsetY;

        this.updatePosition();
    }

    public AnchoredWidget(class_339 widget, class_8021 container, float rowAnchor, float colAnchor, float alignX, float alignY) {
        this(widget, container, rowAnchor, colAnchor, alignX, alignY, 0, 0);
    }

    public void setOffsetX(int offsetX) {
        this.offsetX = offsetX;
    }

    public void setOffsetY(int offsetY) {
        this.offsetY = offsetY;
    }

    public void setOffset(int offsetX, int offsetY) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }

    public void setAlignX(float alignX) {
        this.alignX = alignX;
    }

    public void setAlignY(float alignY) {
        this.alignY = alignY;
    }

    public void setAlignment(float hAlign, float vAlign) {
        this.alignX = hAlign;
        this.alignY = vAlign;
    }

    public int getOffsetX() {
        return offsetX;
    }

    public int getOffsetY() {
        return offsetY;
    }

    public float getAlignX() {
        return alignX;
    }

    public float getAlignY() {
        return alignY;
    }

    public void updatePosition() {
        float anchorX = this.container.method_46426() + (this.container.method_25368() * this.colAnchor);
        float anchorY = this.container.method_46427() + (this.container.method_25364() * this.rowAnchor);

        int x = Math.round(anchorX - (this.method_25368() * this.alignX)) + this.offsetX;
        int y = Math.round(anchorY - (this.method_25364() * this.alignY)) + this.offsetY;

        this.method_48229(x, y);
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.updatePosition();
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
    }
}
