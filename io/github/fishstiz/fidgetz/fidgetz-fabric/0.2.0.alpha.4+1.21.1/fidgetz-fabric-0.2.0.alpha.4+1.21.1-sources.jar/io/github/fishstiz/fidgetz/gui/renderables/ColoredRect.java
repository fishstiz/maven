package io.github.fishstiz.fidgetz.gui.renderables;

import net.minecraft.class_332;

public record ColoredRect(int value) implements RenderableRect {
    @Override
    public void render(class_332 guiGraphics, int x, int y, int width, int height, float partialTick) {
        guiGraphics.method_25294(x, y, x + width, y + height, this.value);
    }
}
