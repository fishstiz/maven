package io.github.fishstiz.fidgetz.util.text;

import net.minecraft.class_2583;

public interface TextStylizer {
    boolean canStylize(String input);

    void reset(String input);

    boolean find();

    int start();

    int end();

    class_2583 style();

    TextStylizer copy();
}
