package io.github.fishstiz.fidgetz.transform.mixin.format;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import io.github.fishstiz.fidgetz.transform.mixin.EditBoxAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_342;

@Mixin(class_342.class)
public abstract class EditBoxMixin extends class_339 implements EditBoxAccess {
    @Unique
    private static final String fidgetz$SECTION_PLACEHOLDER = Pattern.quote("fidgetz¶¶¶section¶¶¶placeholder" + Math.random());

    @Unique
    private boolean fidgetz$allowPastingSectionSign = false;

    protected EditBoxMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Override
    public void fidgetz$allowPastingSectionSign(boolean allow) {
        this.fidgetz$allowPastingSectionSign = allow;
    }

    @ModifyArg(method = "insertText", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/util/StringUtil;filterText(Ljava/lang/String;)Ljava/lang/String;"
    ))
    private String placeholderSectionSigns(String text, @Share("isReplacedRef") LocalBooleanRef isReplacedRef) {
        if (!this.fidgetz$allowPastingSectionSign || !text.contains("§")) {
            return text;
        }

        isReplacedRef.set(true);
        return text.replaceAll("§", fidgetz$SECTION_PLACEHOLDER);
    }

    @ModifyExpressionValue(method = "insertText", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/util/StringUtil;filterText(Ljava/lang/String;)Ljava/lang/String;"
    ))
    private String replacePlaceholders(String original, @Share("isReplacedRef") LocalBooleanRef isReplacedRef) {
        if (!isReplacedRef.get()) {
            return original;
        }

        return original.replaceAll(fidgetz$SECTION_PLACEHOLDER, "§");
    }
}
