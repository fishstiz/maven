package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.shapes.GuiRectangle;
import io.github.fishstiz.fidgetz.util.GuiUtil;
import net.minecraft.class_364;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import org.jetbrains.annotations.NotNull;

public interface Fidgetz extends class_364, GuiRectangle, class_8021 {
    default boolean isHovered(double mouseX, double mouseY) {
        return GuiUtil.isHovered(this, mouseX, mouseY);
    }

    @Override
    default boolean method_25405(double mouseX, double mouseY) {
        return this.containsPoint(mouseX, mouseY);
    }

    @Override
    default @NotNull class_8030 method_48202() {
        return class_8021.super.method_48202();
    }
}
