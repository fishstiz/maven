package io.github.fishstiz.fidgetz.gui.renderables;

import net.minecraft.class_332;

public interface RenderableRect {
    void render(class_332 guiGraphics, int x, int y, int width, int height, float partialTick);

    default void render(class_332 guiGraphics, int x, int y, int width, int height) {
        this.render(guiGraphics, x, y, width, height, 0);
    }
}
