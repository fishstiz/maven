package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.Metadata;
import io.github.fishstiz.fidgetz.transform.interfaces.IStringWidget;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5244;
import net.minecraft.class_7842;

public class FidgetzText<E> extends class_7842 implements Fidgetz, Metadata<E> {
    private E metadata;

    private FidgetzText(Builder<E> builder) {
        super(
                builder.x,
                builder.y,
                builder.width,
                builder.height,
                builder.message,
                builder.font
        );

        this.metadata = builder.metadata;

        if (builder.color != null) this.method_46438(builder.color);

        ((IStringWidget) this).fidgetz$setShadow(builder.shadow);
        ((IStringWidget) this).fidgetz$setAlignX(0);
        ((IStringWidget) this).fidgetz$setOffsetY(builder.offsetY);
    }

    public void setOffsetY(int offsetY) {
        ((IStringWidget) this).fidgetz$setOffsetY(offsetY);
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.field_22762 = this.field_22762 && Fidgetz.super.isHovered(mouseX, mouseY);
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return this.field_22764 && Fidgetz.super.method_25405(mouseX, mouseY);
    }

    @Override
    public E getMetadata() {
        return this.metadata;
    }

    @Override
    public void setMetadata(E metadata) {
        this.metadata = metadata;
    }

    public static <E> Builder<E> builder(class_327 font) {
        return new Builder<>(font);
    }

    public static <E> Builder<E> builder() {
        return builder(class_310.method_1551().field_1772);
    }

    public static class Builder<E> extends AbstractWidgetBuilder<Builder<E>> {
        private final class_327 font;
        private int offsetY;
        private class_2561 message = class_5244.field_39003;
        private Integer color;
        private boolean shadow = true;
        private E metadata;

        private Builder(class_327 font) {
            this.font = font;
        }

        public Builder<E> setOffsetY(int offsetY) {
            this.offsetY = offsetY;
            return this;
        }

        public Builder<E> setColor(Integer color) {
            this.color = color;
            return this;
        }

        public Builder<E> setShadow(boolean shadow) {
            this.shadow = shadow;
            return this;
        }

        public Builder<E> setMessage(class_2561 message) {
            this.message = message;
            return this;
        }

        public Builder<E> setMessage(String message) {
            this.message = class_2561.method_43471(message);
            return this;
        }

        public Builder<E> setMetadata(E metadata) {
            this.metadata = metadata;
            return this;
        }

        public FidgetzText<E> build() {
            return new FidgetzText<>(this);
        }
    }
}
