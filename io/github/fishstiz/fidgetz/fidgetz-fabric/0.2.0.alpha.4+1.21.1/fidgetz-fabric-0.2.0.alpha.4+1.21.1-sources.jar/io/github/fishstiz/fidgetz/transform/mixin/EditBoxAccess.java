package io.github.fishstiz.fidgetz.transform.mixin;

import io.github.fishstiz.fidgetz.transform.interfaces.FidgetzEditBox;
import io.github.fishstiz.fidgetz.transform.interfaces.ITextRenderer;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_342.class)
public interface EditBoxAccess extends ITextRenderer, FidgetzEditBox {
    @Accessor("textColor")
    int getTextColor();

    @Accessor("textColorUneditable")
    int getTextColorUneditable();

    @Invoker("isEditable")
    boolean invokeIsEditable();
}
