package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.util.lang.CollectionsUtil;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_3675;

import static io.github.fishstiz.fidgetz.util.GuiUtil.isDescendant;

public interface ToggleableDialogContainer extends ContainerEventHandlerPatch {
    List<ToggleableDialog<?>> getDialogs();

    default List<ToggleableDialog<?>> getOpenDialogs() {
        return CollectionsUtil.filter(this.getDialogs(), ToggleableDialog::isOpen, ObjectArrayList::new);
    }

    default boolean isChildCovered(class_364 child) {
        boolean isDialogChild = false;
        boolean isEnclosed = false;

        for (ToggleableDialog<?> dialog : this.getOpenDialogsFromTop()) {
            if (dialog != child && (dialog.isCaptureClick() || dialog.isCaptureFocus()) && !isDescendant(dialog, child)) {
                return true;
            }
            if (!isEnclosed && isDescendant(dialog, child)) {
                isDialogChild = true;
                break;
            }
            if (!isEnclosed && dialog != child && dialog.encloses(child)) {
                isEnclosed = true;
            }
        }

        return !isDialogChild && isEnclosed;
    }

    private List<ToggleableDialog<?>> getOpenDialogsFromTop() {
        List<ToggleableDialog<?>> dialogs = this.getOpenDialogs();
        dialogs.sort(Comparator.<ToggleableDialog<?>, Float>comparing(ToggleableDialog::getZ).reversed());
        return dialogs;
    }

    @Override
    default boolean method_25402(double mouseX, double mouseY, int button) {
        boolean propagateNonDialogs = true;

        for (ToggleableDialog<?> dialog : this.getDialogs()) {
            if (dialog.method_25402(mouseX, mouseY, button)) {
                if (dialog.isOpen()) {
                    this.method_25395(dialog);
                }
                if (button == class_3675.field_32000) {
                    this.method_25398(true);
                }
                return true;
            }
            if (dialog.method_25405(mouseX, mouseY)) {
                propagateNonDialogs = false;
            }
        }

        return propagateNonDialogs && ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button);
    }
}
