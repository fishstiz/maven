package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.shapes.GuiRectangle;
import java.util.function.Consumer;
import net.minecraft.class_339;
import net.minecraft.class_8021;

public abstract class AbstractLayoutElement implements class_8021, GuiRectangle {
    private int x;
    private int y;
    private int width;
    private int height;

    @Override
    public void method_46421(int x) {
        this.x = x;
    }

    @Override
    public void method_46419(int y) {
        this.y = y;
    }

    @Override
    public int method_46426() {
        return this.x;
    }

    @Override
    public int method_46427() {
        return this.y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public int method_25368() {
        return this.width;
    }

    @Override
    public int method_25364() {
        return this.height;
    }

    public void setSize(int width, int height) {
        this.setWidth(width);
        this.setHeight(height);
    }

    @Override
    public void method_48206(Consumer<class_339> consumer) {
    }
}
