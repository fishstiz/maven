package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.gui.renderables.sprites.ButtonSprites;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public class CyclicButton<T extends CyclicButton.Option, E> extends FidgetzButton<E> {
    private final @Nullable class_2561 prefix;
    private final List<Consumer<T>> listeners;
    private final T[] options;
    private final boolean allowReverseClick;
    private int value = 0;

    private CyclicButton(io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> builder) {
        super(builder);

        this.listeners = builder.listeners;
        this.options = builder.options;
        this.prefix = builder.prefix;
        this.allowReverseClick = builder.allowReverseClick;

        this.setValueSilently(builder.value);
    }

    private void setValue(T value, boolean silent) {
        for (int i = 0; i < this.options.length; i++) {
            if (this.options[i] == value) {
                this.value = i;
                break;
            }
        }
        if (!silent) {
            this.informListeners();
        }
        this.updateMessage();
    }

    public void setValue(T value) {
        this.setValue(value, false);
    }

    public void setValueSilently(T value) {
        this.setValue(value, true);
    }

    public T getValue() {
        return this.options[this.value];
    }

    @Override
    public void method_25306() {
        if (this.allowReverseClick && class_437.method_25442()) {
            this.value = this.value <= 0 ? this.options.length - 1 : this.value - 1;
        } else {
            this.value = this.value >= this.options.length - 1 ? 0 : this.value + 1;
        }

        this.updateMessage();
        this.informListeners();
    }

    private void updateMessage() {
        this.method_25355(this.prefix != null
                ? this.prefix.method_27661().method_27693(": ").method_10852(this.getValue().text())
                : this.getValue().text()
        );
        this.method_47400(this.getValue().tooltip());
    }

    private void informListeners() {
        T option = this.getValue();
        for (var listener : this.listeners) {
            listener.accept(option);
        }
    }

    public void addListener(Consumer<T> listener) {
        this.listeners.add(listener);
    }

    @Override
    protected boolean hasSprite() {
        return super.hasSprite() || this.getValue() instanceof SpriteOption;
    }

    @Override
    protected void renderSprite(class_332 guiGraphics, int x, int y, int width, int height, float partialTick) {
        if (!(this.getValue() instanceof SpriteOption spriteOption)) {
            super.renderSprite(guiGraphics, x, y, width, height, partialTick);
            return;
        }

        ButtonSprites sprites = spriteOption.sprites();
        if (sprites != null) {
            sprites.render(guiGraphics, x, y, width, height, this.field_22763, partialTick);
        }
    }

    public static <E> io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<Option, E> builder(class_2561... components) {
        Option[] options = new Option[components.length];

        for (int i = 0; i < components.length; i++) {
            options[i] = Option.create(components[i]);
        }

        return new io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<>(options);
    }

    public static <T extends Option, E> io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> builder(T[] options) {
        return new io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<>(options);
    }

    public static class Builder<T extends Option, E> extends FidgetzButton.Builder<E, io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E>> {
        private final List<Consumer<T>> listeners = new ArrayList<>();
        private final T[] options;
        private T value;
        private class_2561 prefix;
        private boolean allowReverseClick = true;

        private Builder(T[] options) {
            this.options = options;
        }

        public io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> setValue(T value) {
            this.value = value;
            return this;
        }

        public io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> setPrefix(class_2561 prefix) {
            this.prefix = prefix;
            return this;
        }

        public io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> disableReverseClick() {
            this.allowReverseClick = false;
            return this;
        }

        public io.github.fishstiz.fidgetz.gui.components.CyclicButton.Builder<T, E> addListener(Consumer<T> listener) {
            this.listeners.add(listener);
            return this;
        }

        @Override
        public CyclicButton<T, E> build() {
            return new CyclicButton<>(this);
        }
    }

    public interface Option {
        @NotNull class_2561 text();

        default @Nullable class_7919 tooltip() {
            return null;
        }

        static Option create(class_2561 component) {
            return () -> component;
        }
    }

    public interface SpriteOption extends Option {
        @Nullable ButtonSprites sprites();
    }
}
