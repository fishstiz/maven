package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.util.LogUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4265;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

public abstract class AbstractFixedListWidget<T extends AbstractFixedListWidget<T>.Entry> extends class_4265<T> {
    protected static final int DEFAULT_SCROLLBAR_OFFSET = 6;
    protected int scrollbarOffset;
    protected int offsetY;
    protected int rowGap;

    protected AbstractFixedListWidget(int itemHeight, int scrollbarOffset, int offsetY, int rowGap) {
        super(class_310.method_1551(), 0, 0, 0, itemHeight);

        this.scrollbarOffset = scrollbarOffset;
        this.offsetY = offsetY;
        this.rowGap = rowGap;
    }

    protected AbstractFixedListWidget(int itemHeight) {
        this(itemHeight, DEFAULT_SCROLLBAR_OFFSET, 0, 0);
    }

    @Override
    protected int method_25329() {
        return this.method_55442() - this.scrollbarOffset;
    }

    protected boolean beforeScrollbarX(double mouseX) {
        return !this.method_57717() || mouseX < this.method_25329();
    }

    public int method_25317() {
        return this.method_25340() * this.field_22741 + this.offsetY;
    }

    @Override
    public int method_25331() {
        return Math.max(0, this.method_25317() - (this.method_55443() - (this.method_46427() + this.offsetY * 2)) + (this.rowGap * method_25340()) - this.rowGap);
    }

    @Override
    protected int method_25337(int index) {
        return this.method_46427() + this.offsetY + (this.field_22741 + this.rowGap) * index - (int) this.method_25341();
    }

    protected int getRowIndex(double y) {
        int index = ((int) Math.floor(y - this.method_46427() - this.offsetY) + (int) this.method_25341()) / (this.field_22741 + this.rowGap);
        return index >= 0 && index < this.method_25340() ? index : -1;
    }

    @Override
    protected @Nullable T method_25308(double mouseX, double mouseY) {
        int index = this.getRowIndex(mouseY);
        return index >= 0 && this.method_25405(mouseX, mouseY) ? this.method_25326(index) : null;
    }

    @Override
    protected void method_25311(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int left = this.method_46426();
        int width = this.method_25368() - (this.method_57717() ? this.scrollbarOffset : 0);

        for (int i = 0; i < this.method_25340(); i++) {
            int top = this.method_25337(i);
            int bottom = this.method_25319(i);
            if (bottom >= this.method_46427() && top <= this.method_55443()) {
                this.method_44397(guiGraphics, mouseX, mouseY, partialTick, i, left, top, width, this.field_22741);
            }
        }
    }

    protected @Nullable T getPreviousEntry(T current) {
        if (current != null && current.getIndex() > 0) {
            return this.method_25396().get(current.getIndex() - 1);
        } else if (current == null && !this.method_25396().isEmpty()) {
            return this.method_48200();
        }
        return null;
    }

    protected @Nullable T getNextEntry(T current) {
        if (current != null && current.getIndex() + 1 < this.method_25396().size()) {
            return this.method_25396().get(current.getIndex() + 1);
        } else if (current == null && !this.method_25396().isEmpty()) {
            return this.method_48200();
        }
        return null;
    }

    //  === compat ===

    protected int getItemHeight() {
        return this.field_22741;
    }

    protected int maxScrollAmount() {
        return this.method_25331();
    }

    protected double scrollAmount() {
        return this.method_25341();
    }

    protected void scrollToEntry(T entry) {
        this.method_25328(entry);
    }

    public abstract class Entry extends class_4265.class_4266<T> implements class_8021 {
        protected final int index;

        protected Entry(int index) {
            this.index = index;
        }

        protected Entry() {
            this(AbstractFixedListWidget.this.method_25396().size());
        }

        public int getIndex() {
            return this.index;
        }

        @Override
        public final void method_46421(int x) {
            LogUtil.logUnsupported();
        }

        @Override
        public final void method_46419(int y) {
            LogUtil.logUnsupported();
        }

        @Override
        public int method_46426() {
            return AbstractFixedListWidget.this.method_46426();
        }

        @Override
        public int method_46427() {
            return AbstractFixedListWidget.this.method_25337(this.index);
        }

        @Override
        public int method_25368() {
            int offset = AbstractFixedListWidget.this.method_57717() ? AbstractFixedListWidget.this.scrollbarOffset : 0;
            return AbstractFixedListWidget.this.method_25368() - offset;
        }

        @Override
        public int method_25364() {
            return AbstractFixedListWidget.this.field_22741;
        }

        public int getRight() {
            return this.method_46426() + this.method_25368();
        }

        public int getBottom() {
            return this.method_46427() + this.method_25364();
        }

        @Override
        public void method_48206(Consumer<class_339> consumer) {
        }

        @Override
        public @NotNull class_8030 method_48202() {
            return new class_8030(this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364());
        }
    }
}
