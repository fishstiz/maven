package io.github.fishstiz.fidgetz.gui.components;

import io.github.fishstiz.fidgetz.util.GuiUtil;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import org.jetbrains.annotations.Nullable;

public interface HoverStateHandler extends class_4069 {
    @Nullable class_364 getHovered();

    default @Nullable class_364 findHovered(double mouseX, double mouseY) {
        return GuiUtil.findHovered(this, mouseX, mouseY);
    }
}
