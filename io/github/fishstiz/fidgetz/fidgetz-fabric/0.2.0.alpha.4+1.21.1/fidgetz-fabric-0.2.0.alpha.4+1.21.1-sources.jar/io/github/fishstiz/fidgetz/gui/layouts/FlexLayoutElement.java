package io.github.fishstiz.fidgetz.gui.layouts;

import net.minecraft.class_8021;

public interface FlexLayoutElement extends class_8021 {
    void setWidth(int width);

    void setHeight(int height);

    default void setSize(int size) {
        this.setWidth(size);
        this.setHeight(size);
    }
}
