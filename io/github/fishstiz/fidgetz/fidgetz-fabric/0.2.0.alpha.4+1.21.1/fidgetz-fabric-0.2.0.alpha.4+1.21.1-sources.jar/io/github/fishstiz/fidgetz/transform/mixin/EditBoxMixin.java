package io.github.fishstiz.fidgetz.transform.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.fishstiz.fidgetz.gui.components.ToggleableEditBox;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import static io.github.fishstiz.fidgetz.util.DrawUtil.renderScrollingStringLeftAlign;

@Mixin(class_342.class)
public abstract class EditBoxMixin extends class_339 implements EditBoxAccess {
    @Unique
    private boolean fidgetz$textShadow = true;

    public EditBoxMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Shadow
    protected abstract boolean isEditable();

    @Override
    public void fidgetz$setShadow(boolean shadow) {
        this.fidgetz$textShadow = shadow;
    }

    @Override
    public boolean fidgetz$hasShadow() {
        return this.fidgetz$textShadow;
    }

    @WrapOperation(method = "renderWidget", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)I",
            ordinal = 0
    ))
    public int drawScrollingString(class_332 guiGraphics, class_327 font, class_5481 text, int x, int y, int color, Operation<Integer> original) {
        if ((class_342) (Object) this instanceof ToggleableEditBox<?> toggleableEditBox && !this.isEditable()) {
            return renderScrollingStringLeftAlign(
                    guiGraphics,
                    font,
                    toggleableEditBox.getInactiveText(),
                    this.method_46426(),
                    this.method_46427(),
                    this.method_55442(),
                    this.method_55443(),
                    color,
                    this.fidgetz$hasShadow()
            );
        }

        return original.call(guiGraphics, font, text, x, y, color);
    }

    @WrapWithCondition(method = "renderWidget", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)I",
            ordinal = 1
    ))
    public boolean isToggled(class_332 instance, class_327 font, class_5481 text, int x, int y, int color) {
        return !((class_342) (Object) this instanceof ToggleableEditBox) || this.isEditable();
    }

    @WrapOperation(method = "renderWidget", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)I"
    ))
    public int drawHintShadow(class_332 instance, class_327 font, class_2561 text, int x, int y, int color, Operation<Integer> original) {
        if (!((class_342) (Object) this instanceof ToggleableEditBox)) {
            return original.call(instance, font, text, x, y, color);
        }
        return instance.method_51439(font, text, x, y, color, this.fidgetz$hasShadow());
    }

}
