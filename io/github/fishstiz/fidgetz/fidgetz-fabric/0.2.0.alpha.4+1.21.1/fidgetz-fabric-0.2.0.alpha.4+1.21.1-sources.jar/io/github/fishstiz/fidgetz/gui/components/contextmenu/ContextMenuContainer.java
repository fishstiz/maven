package io.github.fishstiz.fidgetz.gui.components.contextmenu;

import net.minecraft.class_4069;

public interface ContextMenuContainer extends ContextMenuProvider, class_4069 {
    @Override
    default void buildItems(ContextMenuItemBuilder builder, int mouseX, int mouseY) {
        this.method_19355(mouseX, mouseY)
                .filter(ContextMenuProvider.class::isInstance)
                .map(ContextMenuProvider.class::cast)
                .ifPresent(provider -> provider.buildItems(builder, mouseX, mouseY));
    }
}
