package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.*;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import it.unimi.dsi.fastutil.ints.IntObjectPair;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_8012;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_8133;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

public final class FZDropdown extends class_4185 implements FZComponent, FZContextMenu.Source, FZPopoverContainer, class_8133 {
    private static final int DEFAULT_ELEMENT_SPACING = 8;
    private static final int ENTRY_SPACING = 4;
    private static final int DEFAULT_SELECTION_HEIGHT = 200;
    private static final class_2561 BLACK_RIGHT_POINTING_TRIANGLE = class_2561.method_43470("▶");
    private static final class_2561 BLACK_DOWN_POINTING_TRIANGLE = class_2561.method_43470("▼");
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private final SelectionContainer selectionContainer;
    private final class_4069 parentContainer;
    private final class_327 font;
    private List<FZPopoverMenuItem> items = Collections.emptyList();
    private boolean hideMessage;
    private @Nullable WidgetElements leftIcon;
    private class_2561 interactSymbol = BLACK_RIGHT_POINTING_TRIANGLE;
    private class_2561 inactiveInteractSymbol = inactiveMessage(interactSymbol);
    private int interactIconWidth;
    private boolean iconWidthDirty = true;
    private class_8030 bounds;

    FZDropdown(int x, int y, int width, int height, class_2561 message, class_4069 parentContainer) {
        super(x, y, width, height, message, FZButton.NOP, field_40754);
        this.font = class_310.method_1551().field_1772;
        this.parentContainer = parentContainer;
        this.selectionContainer = new SelectionContainer(parentContainer);
        this.bounds = super.method_48202();
    }

    FZDropdown(class_4069 parentContainer) {
        this(0, 0, field_39500, field_39501, class_5244.field_39003, parentContainer);
    }

    private static class_2561 inactiveMessage(class_2561 message) {
        return class_2564.method_10889(message.method_27661(), class_2583.field_24360.method_36139(class_8012.field_45073));
    }

    public void openSelection() {
        selectionContainer.build(this.items);
        selectionContainer.repositionElements();
        selectionContainer.setOpen(true);
    }

    public void closeSelection() {
        selectionContainer.setOpen(false);
    }

    @Override
    public void method_25306() {
        super.method_25306();
        if (selectionContainer.isOpen()) {
            closeSelection();
        } else {
            openSelection();
        }
    }

    private int getInteractIconWidth() {
        if (iconWidthDirty) {
            interactIconWidth = font.method_27525(interactSymbol);
            iconWidthDirty = false;
        }
        return interactIconWidth;
    }

    private class_2561 getInteractSymbol() {
        return field_22763 ? interactSymbol : inactiveInteractSymbol;
    }

    @Override
    public void method_48589(class_332 graphics, class_327 font, int color) {
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(graphics, mouseX, mouseY, partialTick);

        int left = method_46426();
        int top = method_46427();
        int width = method_25368();
        int height = method_25364();
        int right = method_55442();
        int spacing = DEFAULT_ELEMENT_SPACING;

        right -= spacing + getInteractIconWidth();

        if (leftIcon != null) {
            left += spacing + leftIcon.margin().method_49620();

            int iconY = (top + height / 2 - leftIcon.height() / 2) + leftIcon.margin().method_49618() - leftIcon.margin().method_49619();

            leftIcon.elements()
                    .get(method_37303(), method_25367())
                    .extractRenderState(graphics, left, iconY, leftIcon.width(), leftIcon.height(), mouseX, mouseY, partialTick);

            left += spacing + leftIcon.width() + leftIcon.margin().method_49621();
        }

        if (!hideMessage) {
            int color = method_37303() ? class_8012.field_42973 : 0xFFA0A0A0;
            super.method_48589(graphics, font, color | class_3532.method_15386(this.field_22765 * 255.0F) << 24);
        }

        int symbolX = MathUtils.clampOrAverage(right, method_46426() + spacing, right);
        int symbolY = top + (height / 2) - (font.field_2000 / 2);
        graphics.method_27535(font, getInteractSymbol(), symbolX, symbolY, class_8012.field_42973);

        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (selectionContainer.isOpen() && keyCode == class_3675.field_31958) {
            closeSelection();
            parentContainer.method_25395(this);
            return true;
        }
        return false;
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

//    @Override
//    public boolean shouldTakeFocusAfterInteraction() {
//        return propsState.focusOnInteraction;
//    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        class_8016 path = super.method_48205(navigationEvent);
        if (path != null || !method_25370() || !selectionContainer.isOpen() || selectionContainer.method_25370()) return path;

        boolean up = NavigationUtils.isUp(navigationEvent, true);
        boolean down = NavigationUtils.isDown(navigationEvent, true);

        if ((up && selectionContainer.isPositionedUp()) || (down && selectionContainer.isPositionedDown())) {
            return selectionContainer.method_48205(navigationEvent);
        }

        if (up || down) {
            return method_48218();
        }

        return null;
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            this.bounds = super.method_48202();
        }
        return this.bounds;
    }

    @Override
    public void fidgetz$visitPopovers(Consumer<FZPopover> visitor) {
        visitor.accept(selectionContainer);
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(this);
    }

    @Override
    public void method_46421(int x) {
        if (selectionContainer.isOpen()) {
            selectionContainer.setX(selectionContainer.getX() + (x - method_46426()));
        }
        super.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        if (selectionContainer.isOpen()) {
            selectionContainer.setY(selectionContainer.getY() + (y - method_46427()));
        }
        super.method_46419(y);
    }

    @Override
    public void method_48222() {
        if (selectionContainer.isOpen()) {
            selectionContainer.repositionElements();
        }
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    @Override
    public boolean fidgetz$shouldTakeFocusAfterInteraction() {
        return propsState.focusOnInteraction;
    }

    void applyProps(Props props) {
        if (props.parentContainer() != parentContainer) {
            throw new UnsupportedOperationException("Updating the parent container of FZDropdown is not supported.");
        }

        propsState.apply(this, props);

        if (props.hideMessage() != TriState.DEFAULT) {
            hideMessage = props.hideMessage().toBoolean(false);
        }
        props.leftIcon().ifDefined(leftIcon -> this.leftIcon = leftIcon);
        props.containerBackground().ifPresent(selectionContainer::setBackground);
        props.maxContainerHeight().ifPresent(maxHeight -> selectionContainer.maxHeight = maxHeight);
        props.minContainerWidth().ifPresent(minContainerWidth -> {
            selectionContainer.minWidth = minContainerWidth.leftInt();
            selectionContainer.rootDirection = minContainerWidth.right();
        });
        props.entryDivider().ifDefined(selectionContainer::setEntryDivider);
        props.sectionDivider().ifDefined(selectionContainer::setSectionDivider);

        List<FZPopoverMenuItem> previousEntries = this.items;
        this.items = props.entries();
        if (selectionContainer.isOpen() && !Objects.equals(previousEntries, this.items)) {
            selectionContainer.build(this.items);
            selectionContainer.repositionElements();
        }
    }

    public static FZDropdown bind(String key, FZRef<Props> ref) {
        Props props = ref.value();
        FZDropdown dropdown = new FZDropdown(props.parentContainer());
        dropdown.applyProps(props);
        ref.subscribe(key, dropdown::applyProps);
        return dropdown;
    }

    public static Builder builder(class_4069 container) {
        return new Builder(container);
    }

    private final class SelectionContainer extends FZPopoverMenu {
        private HorizontalDirection rootDirection = HorizontalDirection.RIGHT;
        private int maxHeight = DEFAULT_SELECTION_HEIGHT;
        private int minWidth;
        private boolean focused;

        SelectionContainer(class_4069 container) {
            super(container);
            setPadding(ScreenRectangleUtils.insets(ENTRY_SPACING));
            setRowSpacing(ENTRY_SPACING);
        }

        private void updateIcon() {
            interactSymbol = isOpen() ? BLACK_DOWN_POINTING_TRIANGLE : BLACK_RIGHT_POINTING_TRIANGLE;
            inactiveInteractSymbol = inactiveMessage(interactSymbol);
            iconWidthDirty = true;
        }

        @Override
        protected void onOpen() {
            super.onOpen();
            updateIcon();
        }

        @Override
        protected void onClose() {
            boolean focused = parentContainer.method_25399() == this;
            super.onClose();
            if (focused) parentContainer.method_25395(FZDropdown.this);
            updateIcon();
        }

        @Override
        protected void build(List<FZPopoverMenuItem> items) {
            setMaxHeight(maxHeight);
            super.build(items);
        }

        @Override
        public void repositionElements() {
            class_8030 parentBounds = parentContainer.method_48202();
            class_8030 buttonBounds = FZDropdown.this.method_48202();
            class_8030 selectionBounds = method_48202();

            int selectionWidth = Math.max(buttonBounds.comp_1196(), minWidth);
            int selectionHeight = MathUtils.optionalMin(selectionBounds.comp_1197(), maxHeight);

            int spaceBelow = parentBounds.method_49619() - buttonBounds.method_49619();
            int spaceAbove = buttonBounds.method_49618() - parentBounds.method_49618();

            int anchor = rootDirection.flip().edge(buttonBounds);

            HorizontalDirection newDirection = rootDirection.resolve(parentBounds, selectionWidth, anchor);
            anchor = newDirection.flip().edge(buttonBounds);

            int selectionX = newDirection.clamp(parentBounds, selectionWidth, anchor);
            int selectionY;
            if (selectionHeight > spaceBelow) {
                if (spaceAbove > spaceBelow) {
                    selectionHeight = Math.min(selectionHeight, spaceAbove);
                    selectionY = buttonBounds.method_49618() - selectionHeight;
                } else {
                    selectionHeight = spaceBelow;
                    selectionY = buttonBounds.method_49619();
                }
            } else {
                selectionY = buttonBounds.method_49619();
            }

            setMaxHeight(selectionHeight);
            setMinWidth(selectionWidth);
            setMaxWidth(selectionWidth);
            super.repositionElements();

            setX(selectionX);
            setY(selectionY);
        }

        @Override
        protected void extractDialogRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            super.extractDialogRenderState(graphics, mouseX, mouseY, partialTick);

            class_364 sibling = parentContainer.method_25399();
            if ((sibling != this && sibling != FZDropdown.this) || !FZDropdown.this.method_37303()) {
                closeSelection();
            }
        }

        @Override
        public boolean shouldCaptureFocus() {
            return false;
        }

        @Override
        public boolean shouldFocusOnOpen() {
            return false;
        }

        @Override
        public boolean shouldRefocusLastPath() {
            return false;
        }

        @Override
        public void method_25365(boolean focused) {
            this.focused = focused;
            super.method_25365(focused);
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (focused == null || isOpen()) {
                super.method_25395(focused);
            }
        }

        @Override
        public boolean method_25370() {
            return isOpen() && (focused || method_25399() != null);
        }

        @Override
        public @Nullable class_8016 method_48218() {
            if (!method_25370()) return null;
            return method_25399() == null ? class_8016.method_48193(this) : super.method_48218();
        }

        private boolean isPositionedUp() {
            return getY() < FZDropdown.this.method_46427();
        }

        private boolean isPositionedDown() {
            return getY() > FZDropdown.this.method_46427();
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            if (!isOpen()) return null;

            class_8016 path = super.method_48205(navigationEvent);
            if (path != null || !method_25370() || FZDropdown.this.method_25370()) return path;

            boolean up = NavigationUtils.isUp(navigationEvent, true);
            boolean down = NavigationUtils.isDown(navigationEvent, true);

            if ((up && isPositionedDown()) || (down && isPositionedUp())) {
                return FZDropdown.this.method_48205(navigationEvent);
            }

            if (up || down) {
                return method_48218();
            }

            return null;
        }

        @Override
        public int method_48590() {
            return FZDropdown.this.method_48590();
        }

        @Override
        public boolean method_37303() {
            return FZDropdown.this.method_37303() && super.method_37303();
        }
    }

    public interface Props extends GuiComponentProps {
        class_4069 parentContainer();

        List<FZPopoverMenuItem> entries();

        default TriState hideMessage() {
            return TriState.DEFAULT;
        }

        default Undefinable<@Nullable WidgetElements> leftIcon() {
            return Undefinable.undefined();
        }

        default Optional<RenderableRectangle> containerBackground() {
            return Optional.empty();
        }

        default OptionalInt maxContainerHeight() {
            return OptionalInt.empty();
        }

        default Optional<IntObjectPair<HorizontalDirection>> minContainerWidth() {
            return Optional.empty();
        }

        default Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider() {
            return Undefinable.undefined();
        }

        default Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider() {
            return Undefinable.undefined();
        }
    }

    private static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final class_4069 parentContainer;
        private final List<FZPopoverMenuItem> entries;
        private final TriState hideMessage;
        private final Undefinable<@Nullable WidgetElements> leftIcon;
        private final @Nullable RenderableRectangle containerBackground;
        private final @Nullable Integer maxContainerHeight;
        private final @Nullable IntObjectPair<HorizontalDirection> minContainerWidth;
        private final Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider;
        private final Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider;

        private PropsImpl(
                class_4069 parentContainer,
                List<FZPopoverMenuItem> entries,
                TriState hideMessage,
                Undefinable<@Nullable WidgetElements> leftIcon,
                @Nullable RenderableRectangle containerBackground,
                @Nullable Integer maxContainerHeight,
                @Nullable IntObjectPair<HorizontalDirection> minContainerWidth,
                Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider,
                Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider,
                GuiComponentProps props
        ) {
            super(props);
            this.parentContainer = parentContainer;
            this.entries = entries;
            this.hideMessage = hideMessage;
            this.leftIcon = leftIcon;
            this.containerBackground = containerBackground;
            this.maxContainerHeight = maxContainerHeight;
            this.minContainerWidth = minContainerWidth;
            this.entryDivider = entryDivider;
            this.sectionDivider = sectionDivider;
        }

        @Override
        public class_4069 parentContainer() {
            return parentContainer;
        }

        @Override
        public List<FZPopoverMenuItem> entries() {
            return entries;
        }

        @Override
        public TriState hideMessage() {
            return hideMessage;
        }

        @Override
        public Undefinable<@Nullable WidgetElements> leftIcon() {
            return leftIcon;
        }

        @Override
        public Optional<RenderableRectangle> containerBackground() {
            return Optional.ofNullable(containerBackground);
        }

        @Override
        public OptionalInt maxContainerHeight() {
            return wrapBoxedInt(maxContainerHeight);
        }

        @Override
        public Optional<IntObjectPair<HorizontalDirection>> minContainerWidth() {
            return Optional.ofNullable(minContainerWidth);
        }

        @Override
        public Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider() {
            return entryDivider;
        }

        @Override
        public Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider() {
            return sectionDivider;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(parentContainer, other.parentContainer()) &&
                   Objects.equals(entries, other.entries()) &&
                   hideMessage == other.hideMessage() &&
                   Objects.equals(leftIcon, other.leftIcon()) &&
                   Objects.equals(containerBackground(), other.containerBackground()) &&
                   Objects.equals(maxContainerHeight(), other.maxContainerHeight()) &&
                   Objects.equals(entryDivider(), other.entryDivider()) &&
                   Objects.equals(sectionDivider(), other.sectionDivider());
        }

        @Override
        public int hashCode() {
            return Objects.hash(
                    super.hashCode(),
                    parentContainer,
                    entries,
                    hideMessage,
                    leftIcon,
                    containerBackground,
                    maxContainerHeight,
                    entryDivider
            );
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private static final WidgetRenderables DEFAULT_ENTRY_BACKGROUND;
        private final class_4069 container;
        private final List<FZPopoverMenuItem> entries = new ArrayList<>();
        private TriState hideMessage = TriState.DEFAULT;
        private Undefinable<@Nullable WidgetElements> leftIcon = Undefinable.undefined();
        private @Nullable RenderableRectangle containerBackground;
        private @Nullable Integer maxContainerHeight;
        private @Nullable IntObjectPair<HorizontalDirection> minContainerWidth;
        private Undefinable<FZPopoverMenuItem.@Nullable Divider> entryDivider = Undefinable.undefined();
        private Undefinable<FZPopoverMenuItem.@Nullable Divider> sectionDivider = Undefinable.undefined();

        static {
            RenderableRectangle background = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry")).withBlend();
            RenderableRectangle higlighted = Renderables.sprite(Fidgetz.id("widget/popovermenu_entry_highlighted")).withBlend();
            DEFAULT_ENTRY_BACKGROUND = new WidgetRenderables(background, background, higlighted);
        }

        private Builder(class_4069 container) {
            this.container = container;
        }

        public Builder hideMessage(boolean hideMessage) {
            this.hideMessage = TriState.from(hideMessage);
            return this;
        }

        public Builder hideMessage() {
            return hideMessage(true);
        }

        public Builder leftIcon(@Nullable WidgetElements leftIcon) {
            this.leftIcon = Undefinable.of(leftIcon);
            return this;
        }

        public Builder containerBackground(@Nullable RenderableRectangle containerBackground) {
            this.containerBackground = containerBackground;
            return this;
        }

        public Builder maxContainerHeight(int maxContainerHeight) {
            this.maxContainerHeight = maxContainerHeight;
            return this;
        }

        public Builder minContainerWidth(int minContainerWidth, HorizontalDirection preferredDirection) {
            this.minContainerWidth = IntObjectPair.of(minContainerWidth, preferredDirection);
            return this;
        }

        public Builder minContainerWidth(int minContainerWidth) {
            this.minContainerWidth = this.minContainerWidth == null
                    ? IntObjectPair.of(minContainerWidth, HorizontalDirection.RIGHT)
                    : IntObjectPair.of(minContainerWidth, this.minContainerWidth.right());

            return this;
        }

        private FZButton.Builder defaultButtonBuilder() {
            return FZButton.builder()
                    .height(field_39501)
                    .sprites(DEFAULT_ENTRY_BACKGROUND)
                    .leftAlignedMessage();
        }

        public Builder entry(class_2561 message, Runnable selectionHandler) {
            Objects.requireNonNull(selectionHandler, "selectionHandler cannot be null");
            this.entries.add(FZPopoverMenuItem.fromWidget(defaultButtonBuilder().message(message).onPress(selectionHandler).build()));
            return this;
        }

        public Builder entry(UnaryOperator<FZButton.Builder> entryBuilder) {
            this.entries.add(FZPopoverMenuItem.fromWidget(entryBuilder.apply(defaultButtonBuilder()).build()));
            return this;
        }

        public Builder entry(FZPopoverMenuItem entry) {
            this.entries.add(entry);
            return this;
        }

        public Builder entries(List<FZPopoverMenuItem> entries) {
            this.entries.addAll(entries);
            return this;
        }

        public Builder entryDivider(FZPopoverMenuItem.@Nullable Divider entryDivider) {
            this.entryDivider = Undefinable.of(entryDivider);
            return this;
        }

        public Builder sectionDivider(FZPopoverMenuItem.@Nullable Divider sectionDivider) {
            this.sectionDivider = Undefinable.of(sectionDivider);
            return this;
        }

        public Props toProps() {
            return new PropsImpl(
                    container,
                    List.copyOf(entries),
                    hideMessage,
                    leftIcon,
                    containerBackground,
                    maxContainerHeight,
                    minContainerWidth,
                    entryDivider,
                    sectionDivider,
                    props
            );
        }

        public FZDropdown build() {
            FZDropdown dropdown = new FZDropdown(container);
            dropdown.applyProps(toProps());
            return dropdown;
        }
    }
}
