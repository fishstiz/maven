package io.github.fishstiz.fidgetz.v0.utils;

import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_6379;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8023.class_8024;
import net.minecraft.class_8023.class_8026;
import net.minecraft.class_8028;

public final class NavigationUtils {
    public static @Nullable class_8028 getDirection(int keyCode) {
        if (keyCode == class_3675.field_31932) {
            return class_8028.field_41826;
        }
        if (keyCode == class_3675.field_31982) {
            return class_8028.field_41827;
        }
        if (keyCode == class_3675.field_31983) {
            return class_8028.field_41828;
        }
        if (keyCode == class_3675.field_31984) {
            return class_8028.field_41829;
        }
        return null;
    }

    public static boolean isUp(class_8023 event, boolean includeTab) {
        return (includeTab && event instanceof class_8026(boolean forward) && !forward) ||
               (event instanceof class_8024(class_8028 direction) && direction == class_8028.field_41826);
    }

    public static boolean isDown(class_8023 event, boolean includeTab) {
        return (includeTab && event instanceof class_8026(boolean forward) && forward) ||
               (event instanceof class_8024(class_8028 direction) && direction == class_8028.field_41827);
    }

    public static void walk(class_8016 path, Consumer<class_364> walker) {
        walker.accept(path.comp_1188());
        if (path instanceof class_8016.class_8018(class_4069 ignored, class_8016 childPath)) {
            walk(childPath, walker);
        }
    }

    public static Stream<class_364> stream(class_8016 path) {
        Stream.Builder<class_364> builder = Stream.builder();
        walk(path, builder::add);
        return builder.build();
    }

    public static @Nullable class_8016 takeWhile(class_8016 path, Predicate<class_364> walker) {
        class_364 component = path.comp_1188();

        if (!walker.test(component)) {
            return null;
        }

        if (path instanceof class_8016.class_8018(class_4069 container, class_8016 childPath)) {
            class_8016 validPath = takeWhile(childPath, walker);
            if (validPath != null) {
                return class_8016.method_48192(container, validPath);
            }
        }

        return class_8016.method_48193(component);
    }

    public static @Nullable class_8016 initialFocus(class_4069 container) {
        class_364 focused = container.method_25399();
        if (focused != null) {
            class_8016 path = focused.method_48205(new class_8023.class_8025());
            return path == null ? class_8016.method_48194(focused, container) : class_8016.method_48192(container, path);
        }

        List<? extends class_364> children = container.method_25396();
        if (children.isEmpty()) return null;

        class_364 firstFocusable = null;
        for (class_364 child : children) {
            if (child instanceof class_6379 narratable && !narratable.method_37303()) {
                continue;
            }
            if (firstFocusable == null || child.method_48590() < firstFocusable.method_48590()) {
                firstFocusable = child;
            }
        }

        if (firstFocusable == null) return null;

        class_8016 path = firstFocusable instanceof class_4069 subContainer
                ? initialFocus(subContainer)
                : firstFocusable.method_48205(new class_8023.class_8025());

        return path == null ? class_8016.method_48194(firstFocusable, container) : class_8016.method_48192(container, path);
    }

    public static @Nullable class_8016 findPath(class_4069 container, class_364 targetChild) {
        for (class_364 child : container.method_25396()) {
            if (child == targetChild) {
                return class_8016.method_48194(child, container);
            }
            if (child instanceof class_4069 subContainer) {
                class_8016 path = findPath(subContainer, targetChild);
                if (path != null) {
                    return class_8016.method_48192(container, path);
                }
            }
        }
        return null;
    }

    public static Optional<class_364> find(@Nullable class_8016 path, Predicate<class_364> predicate) {
        if (path == null) {
            return Optional.empty();
        }

        if (predicate.test(path.comp_1188())) {
            return Optional.of(path.comp_1188());
        }

        if (path instanceof class_8016.class_8018(class_4069 ignored, class_8016 childPath)) {
            return find(childPath, predicate);
        }

        return Optional.empty();
    }

    public static Optional<class_8016.class_8018> findParent(
            @Nullable class_8016 path,
            Predicate<class_8016.class_8018> predicate
    ) {
        if (path == null) {
            return Optional.empty();
        }
        if (path instanceof class_8016.class_8018 parentPath) {
            return predicate.test(parentPath)
                    ? Optional.of(parentPath)
                    : findParent(parentPath.comp_1190(), predicate);
        }
        return Optional.empty();
    }

    public static boolean inFocusPath(class_4069 container, class_364 targetChild) {
        // ideally should use something like getCurrentFocusPath, but there is a bug in ContainerEventHandler
        // where getCurrentFocusPath returns null if the child component is a ContainerEventHandler with no focused child.
        class_364 focused = container.method_25399();
        if (Objects.equals(focused, targetChild)) {
            return true;
        }
        if (focused instanceof class_4069 childContainer) {
            return inFocusPath(childContainer, targetChild);
        }
        return false;
    }

    public static class_8016 appendPath(class_8016 parentPath, @Nullable class_8016 childPath) {
        if (childPath == null) return parentPath;

        if (parentPath instanceof class_8016.class_8018(class_4069 container, class_8016 child)) {
            return class_8016.method_48192(container, appendPath(child, childPath));
        }
        if (parentPath.comp_1188() == childPath.comp_1188()) {
            return childPath;
        }
        return parentPath;
    }

    // ideally setFocused impl should have the validation instead
    public static @Nullable class_8016 validatePath(@Nullable class_8016 path) {
        if (path == null) {
            return null;
        }

        MutableObject<@Nullable List<? extends class_364>> current = new MutableObject<>();
        return NavigationUtils.takeWhile(path, component -> {
            List<? extends class_364> children = current.getValue();
            if (children == null || children.contains(component)) {
                current.setValue(component instanceof class_4069 subContainer ? subContainer.method_25396() : null);
                return true;
            }
            return false;
        });
    }

    public static class_8016 addFocusEffects(
            class_8016 path,
            @Nullable BiConsumer<class_364, Boolean> preFocus,
            @Nullable BiConsumer<class_364, Boolean> postFocus
    ) {
        return new EffectComponentPath(path, preFocus, postFocus);
    }

    public static class_8016 beforeFocusEffect(class_8016 path, Consumer<class_364> effect) {
        Objects.requireNonNull(effect, "effect cannot be null");
        return addFocusEffects(path, null, (component, focused) -> {
            if (focused) effect.accept(component);
        });
    }

    public static class_8016 afterFocusEffect(class_8016 path, Consumer<class_364> effect) {
        Objects.requireNonNull(effect, "effect cannot be null");
        return addFocusEffects(path, null, (component, focused) -> {
            if (focused) effect.accept(component);
        });
    }

    public static class_8016 afterFocusEffect(class_8016 path, BiConsumer<class_364, Boolean> effect) {
        return addFocusEffects(path, null, effect);
    }

    private record EffectComponentPath(
            class_8016 path,
            @Nullable BiConsumer<class_364, Boolean> preFocusEffect,
            @Nullable BiConsumer<class_364, Boolean> postFocusEffect
    ) implements class_8016 {
        @Override
        public void method_48195(boolean focused) {
            if (preFocusEffect != null) preFocusEffect.accept(comp_1188(), focused);
            path.method_48195(focused);
            if (postFocusEffect != null) postFocusEffect.accept(comp_1188(), focused);
        }

        @Override
        public class_364 comp_1188() {
            return path.comp_1188();
        }
    }


    private NavigationUtils() {
    }
}
