package io.github.fishstiz.fidgetz.gui.components;

import net.minecraft.class_3675;
import net.minecraft.class_4069;

public interface ContainerEventHandlerPatch extends class_4069 {
    /**
     * {@link class_4069#method_25402(double, double, int)}, except it only
     * propagates to the hovered child
     */
    default boolean mouseClickedAt(double mouseX, double mouseY, int button) {
        return this.method_19355(mouseX, mouseY).map(child -> {
            if (child.method_25402(mouseX, mouseY, button)) {
                this.method_25395(child);
                if (button == class_3675.field_32000) this.method_25398(true);
                return true;
            }
            return false;
        }).orElse(false);
    }
}
