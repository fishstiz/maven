package io.github.fishstiz.fidgetz.gui.layouts;

import io.github.fishstiz.fidgetz.transform.interfaces.UnpaddedScrollableLayout;
import net.minecraft.class_11467;
import net.minecraft.class_310;
import net.minecraft.class_8133;

public class Layouts {
    private Layouts() {
    }

    public static class_11467 unpaddedScrollableLayout(class_310 minecraft, class_8133 layout) {
        class_11467 scrollableLayout = new class_11467(minecraft, layout, layout.method_25364());
        ((UnpaddedScrollableLayout) scrollableLayout).fidgetz$setUnpadded(true);
        return scrollableLayout;
    }

    public static class_11467 unpaddedScrollableLayout(class_8133 layout) {
        class_11467 scrollableLayout = new class_11467(class_310.method_1551(), layout, layout.method_25364());
        ((UnpaddedScrollableLayout) scrollableLayout).fidgetz$setUnpadded(true);
        return scrollableLayout;
    }
}
