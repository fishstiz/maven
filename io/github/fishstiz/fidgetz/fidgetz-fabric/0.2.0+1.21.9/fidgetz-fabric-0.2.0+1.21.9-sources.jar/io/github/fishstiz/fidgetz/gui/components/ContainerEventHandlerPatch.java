package io.github.fishstiz.fidgetz.gui.components;

import net.minecraft.class_11909;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import org.jetbrains.annotations.NotNull;

public interface ContainerEventHandlerPatch extends class_4069 {
    @Override
    default boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClicked) {
        return this.isMouseClickHandled(mouseButtonEvent, doubleClicked);
    }

    /**
     * {@link class_4069#method_25402}, except it only
     * returns {@code true} if mouse click is actually handled instead of when child is present.
     * This is to allow elements to not focus by returning false.
     * Note that #shouldTakeFocusAfterInteraction does not exist in older versions.
     */
    private boolean isMouseClickHandled(class_11909 mouseButtonEvent, boolean doubleClicked) {
        return this.method_19355(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799()).map(child -> {
            if (child.method_25402(mouseButtonEvent, doubleClicked)) {
                if (child.method_72784()) {
                    this.method_25395(child);
                }
                if (mouseButtonEvent.method_74245() == class_3675.field_32000) {
                    this.method_25398(true);
                }
                return true;
            }
            return false;
        }).orElse(false);
    }

    @Override
    default boolean method_25406(@NotNull class_11909 mouseButtonEvent) {
        return class_4069.super.method_25406(mouseButtonEvent);
    }

    @Override
    default boolean method_25403(@NotNull class_11909 mouseButtonEvent, double dragX, double dragY) {
        return class_4069.super.method_25403(mouseButtonEvent, dragX, dragY);
    }
}
