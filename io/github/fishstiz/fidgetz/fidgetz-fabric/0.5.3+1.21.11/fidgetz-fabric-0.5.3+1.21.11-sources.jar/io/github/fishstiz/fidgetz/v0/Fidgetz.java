package io.github.fishstiz.fidgetz.v0;

import net.minecraft.class_2960;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ApiStatus.Internal
public final class Fidgetz {
    public static final String MOD_ID = "fidgetz";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    private Fidgetz() {
    }
}
