package io.github.fishstiz.fidgetz.v0.gui.screens;

import io.github.fishstiz.fidgetz.v0.gui.components.*;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_8030;

public abstract class FZScreen extends class_437 implements FZDialogContainer, FZHoverableContainer, FZContextMenu.Source {
    protected static final String GLOBAL_CONTEXT_MENU_ID = "FZScreen:FZContextMenu";
    protected final FZDialogManager dialogManager = new FZDialogManager(this);
    protected class_8030 screenRectangle = class_8030.method_48248();

    protected FZScreen(class_2561 title) {
        super(title);
    }


    @Override
    protected void method_25426() {
        GuiComponentCollector collector = new GuiComponentCollector();
        collectChildren(collector);
        collector.flushTo(this::method_25429, this::method_37060);
    }

    protected abstract void collectChildren(GuiComponentCollector collector);

    private void updateHovered(Object child) {
        if (shouldUpdateHovered() && child instanceof FZHoverableElement hoverable) {
            hoverable.fidgetz$setHovered(fidgetz$getHovered() == hoverable);
        }
    }

    @Override
    protected <T extends class_364 & class_6379> T method_25429(T widget) {
        updateHovered(widget);
        return super.method_25429(widget);
    }

    @Override
    protected <T extends class_4068> T method_37060(T renderable) {
        updateHovered(renderable);
        return super.method_37060(renderable);
    }

    @Override
    protected <T extends class_364 & class_4068 & class_6379> T method_37063(T widget) {
        updateHovered(widget);
        return super.method_37063(widget);
    }

    @Override
    protected void method_37066(class_364 widget) {
        super.method_37066(widget);
        if (widget == method_25399()) {
            method_25395(null);
        }
        if (widget == fidgetz$getHovered()) {
            fidgetz$setHovered(null);
        }
    }

    @Override
    protected void method_37067() {
        super.method_37067();
        method_25395(null);
        fidgetz$setHovered(null);
    }

    protected void openContextMenu(double x, double y, boolean focus) {
        dialogManager.put(FZContextMenu.builder(this)
                .id(GLOBAL_CONTEXT_MENU_ID)
                .focusOnOpen(focus)
                .buildAndOpen(x, y, fidgetz$collectContextEntries(x, y)));
    }

    protected boolean canOpenContextMenu(class_11909 mouseButtonEvent) {
        double x = mouseButtonEvent.comp_4798();
        double y = mouseButtonEvent.comp_4799();
        return mouseButtonEvent.method_74245() == class_3675.field_32002 &&
               dialogManager.get(GLOBAL_CONTEXT_MENU_ID).map(menu -> !menu.method_25405(x, y)).orElse(true);
    }

    protected boolean shouldUpdateHovered() {
        return true;
    }

    protected boolean shouldCloseOnEscape() {
        return true;
    }

    @Override
    @Deprecated
    public final boolean method_25422() {
        return false;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float a) {
        if (shouldUpdateHovered()) {
            fidgetz$updateHovered(mouseX, mouseY);
        }
        super.method_25394(graphics, mouseX, mouseY, a);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (fidgetz$captureEventForDialogs(event)) {
            return true;
        }

        boolean clicked = super.method_25402(event, doubleClick);

        if (canOpenContextMenu(event)) {
            openContextMenu(event.comp_4798(), event.comp_4799(), !clicked);
        }

        return clicked;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (fidgetz$captureEventForDialogs(event) || super.method_25404(event)) {
            return true;
        }
        if (event.method_74231() && shouldCloseOnEscape()) {
            this.method_25419();
            return true;
        }
        return false;
    }

    @Override
    public List<? extends FZDialog> fidgetz$Dialogs() {
        return dialogManager.dialogs();
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(screenRectangle, 0, 0, field_22789, field_22790)) {
            this.screenRectangle = super.method_48202();
        }
        return screenRectangle;
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        }
    }
}
