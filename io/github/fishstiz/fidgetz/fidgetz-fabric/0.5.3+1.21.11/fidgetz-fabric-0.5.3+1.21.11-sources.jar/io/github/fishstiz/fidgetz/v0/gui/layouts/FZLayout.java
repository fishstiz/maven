package io.github.fishstiz.fidgetz.v0.gui.layouts;

import net.minecraft.class_8133;

public interface FZLayout extends class_8133, FZFlexElement {
}
