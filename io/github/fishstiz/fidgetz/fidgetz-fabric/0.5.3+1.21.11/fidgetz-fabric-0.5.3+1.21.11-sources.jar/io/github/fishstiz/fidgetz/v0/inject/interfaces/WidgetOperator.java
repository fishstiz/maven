package io.github.fishstiz.fidgetz.v0.inject.interfaces;

import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public interface WidgetOperator {
    default void fidgetz$modifyWidgets(UnaryOperator<List<class_364>> modifier) {
    }

    default void fidgetz$modifyNarratables(UnaryOperator<List<class_6379>> modifier) {
    }

    default void fidgetz$modifyRenderables(UnaryOperator<List<class_4068>> modifier) {
    }
}
