package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import net.minecraft.class_2960;
import net.minecraft.class_8030;

public record WidgetElements(WidgetRenderables elements, int width, int height, class_8030 margin) {
    public WidgetElements(WidgetRenderables elements, int width, int height) {
        this(elements, width, height, class_8030.method_48248());
    }

    public WidgetElements(RenderableRectangle renderable, int width, int height) {
        this(new WidgetRenderables(renderable), width, height);
    }

    public WidgetElements(class_2960 sprite, int width, int height) {
        this(Renderables.sprite(sprite), width, height);
    }

    public WidgetElements(RenderableRectangle sprite, RenderableRectangle focused, int width, int height) {
        this(new WidgetRenderables(sprite, focused), width, height);
    }

    public WidgetElements(RenderableRectangle enabled, RenderableRectangle disabled, RenderableRectangle focused, int width, int height) {
        this(new WidgetRenderables(enabled, disabled, focused), width, height);
    }

    public static WidgetElements noFocus(RenderableRectangle enabled, RenderableRectangle disabled, int width, int height) {
        return new WidgetElements(WidgetRenderables.noFocus(enabled, disabled), width, height);
    }

    public static WidgetElements noFocus(class_2960 enabled, class_2960 disabled, int width, int height) {
        return new WidgetElements(WidgetRenderables.noFocus(enabled, disabled), width, height);
    }

    public WidgetElements margin(int margin) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(margin));
    }

    public WidgetElements margin(int marginLeft, int marginTop, int marginRight, int marginBottom) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(marginLeft, marginTop, marginRight, marginBottom));
    }

    public WidgetElements marginLeft(int marginLeft) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(marginLeft, margin.method_49618(), margin.method_49621(), margin.method_49619()));
    }

    public WidgetElements marginTop(int marginTop) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(margin.method_49620(), marginTop, margin.method_49621(), margin.method_49619()));
    }

    public WidgetElements marginRight(int marginRight) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(margin.method_49620(), margin.method_49618(), marginRight, margin.method_49619()));
    }

    public WidgetElements marginBottom(int marginBottom) {
        return new WidgetElements(elements, width, height, ScreenRectangleUtils.insets(margin.method_49620(), margin.method_49618(), margin.method_49621(), marginBottom));
    }
}
