package io.github.fishstiz.fidgetz.v0.inject.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.fishstiz.fidgetz.v0.gui.components.FZContextMenu;
import io.github.fishstiz.fidgetz.v0.gui.components.FZDialog;
import io.github.fishstiz.fidgetz.v0.gui.components.FZDialogContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_8016;
import net.minecraft.class_8023;

@Mixin(class_4069.class)
interface ContainerEventHandlerMixin extends class_364, FZHoverableContainer, FZContextMenu.Source {
    @Shadow
    List<? extends class_364> children();

    @Override
    default @Nullable class_364 fidgetz$getHovered() {
        return null;
    }

    @Override
    default void fidgetz$setHovered(@Nullable class_364 hovered) {
    }

    @Override
    default boolean fidgetz$isHovered() {
        return FZHoverableContainer.super.fidgetz$isHovered();
    }

    @Override
    default void fidgetz$setHovered(boolean hovered) {
        FZHoverableContainer.super.fidgetz$setHovered(hovered);
    }

    @Override
    default boolean fidgetz$updateHovered(double mouseX, double mouseY) {
        if (method_25405(mouseX, mouseY)) {
            for (class_364 child : children()) {
                if (((FZHoverableElement) child).fidgetz$updateHovered(mouseX, mouseY)) {
                    fidgetz$setHovered(child);
                    return true;
                }
            }
            fidgetz$setHovered(null);
            return true;
        }
        fidgetz$setHovered(null);
        return false;
    }

    @WrapMethod(method = "nextFocusPath")
    private class_8016 initializeExcludedAreas(class_8023 navigationEvent, Operation<class_8016> original) {
        if (this instanceof FZDialogContainer container) {
            for (FZDialog dialog : container.fidgetz$Dialogs()) {
                if (dialog.isOpen() && dialog.shouldCaptureFocus()) {
                    class_8016 path = dialog.method_48205(navigationEvent);
                    if (path != null) {
                        return class_8016.method_48192((class_4069) this, path);
                    }
                }
            }
        }

        return original.call(navigationEvent);
    }

    @ModifyExpressionValue(
            method = {"handleTabNavigation", "nextFocusPathInDirection", "nextFocusPathVaguelyInDirection"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/events/ContainerEventHandler;children()Ljava/util/List;")
    )
    private List<? extends class_364> removeOccludedChildren(List<? extends class_364> original) {
        if (!(this instanceof FZDialogContainer container)) return original;

        List<? extends FZDialog> dialogs = container.fidgetz$Dialogs();
        if (dialogs.isEmpty()) return original;

        List<class_364> potentialChildren = new ArrayList<>(original.size());
        for (class_364 child : original) {
            boolean visible = true;
            for (FZDialog dialog : dialogs) {
                if (child == dialog) {
                    break;
                }
                if (dialog.isOpen() && dialog.method_48202().method_71525(child.method_48202())) {
                    visible = false;
                    break;
                }
            }

            if (visible) {
                potentialChildren.add(child);
            }
        }

        return potentialChildren;
    }
}
