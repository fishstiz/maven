package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import io.github.fishstiz.fidgetz.v0.utils.Undefinable;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_12225;
import net.minecraft.class_332;
import net.minecraft.class_9851;

public final class FZButton extends FZButtonBase {
    private @Nullable WidgetRenderables sprites = DEFAULT_RENDERABLES;
    private @Nullable WidgetElements leftIcon;
    private @Nullable WidgetElements rightIcon;
    private boolean centeredMessage = true;

    FZButton() {
    }

    private void extractSprite(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (sprites != null) {
            sprites.get(method_37303(), method_25367()).extractRenderState(
                    graphics,
                    method_46426(),
                    method_46427(),
                    method_25368(),
                    method_25364(),
                    mouseX,
                    mouseY,
                    partialTick
            );
        }
    }

    @Override
    protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        extractSprite(graphics, mouseX, mouseY, partialTick);

        int margin = centeredMessage ? field_43050 : field_46856;
        int spacing = field_46856;
        int left = method_46426() + margin;
        int right = method_55442() - margin;
        int top = method_46427();
        int height = method_25364();
        int bottom = top + height;

        if (leftIcon != null) {
            left += spacing - margin + leftIcon.margin().method_49620();

            int iconTop = (top + height / 2 - leftIcon.height() / 2) + leftIcon.margin().method_49618() - leftIcon.margin().method_49619();

            leftIcon.elements()
                    .get(method_37303(), method_25367())
                    .extractRenderState(graphics, left, iconTop, leftIcon.width(), leftIcon.height(), mouseX, mouseY, partialTick);

            left += leftIcon.width() + leftIcon.margin().method_49621() + spacing / 2;
        }

        if (rightIcon != null) {
            right -= spacing - margin + rightIcon.width() + rightIcon.margin().method_49621();

            int iconTop = (top + height / 2 - rightIcon.height() / 2) + rightIcon.margin().method_49618() - rightIcon.margin().method_49619();

            rightIcon.elements()
                    .get(method_37303(), method_25367())
                    .extractRenderState(graphics, right, iconTop, rightIcon.width(), rightIcon.height(), mouseX, mouseY, partialTick);

            right -= spacing / 2 + rightIcon.margin().method_49620();
        }

        if (centeredMessage) {
            graphics.method_75787(this, class_332.class_12228.field_63850)
                    .method_75770(method_25369(), left, right, top, bottom);
        } else {
            class_12225 textRenderer = graphics.method_75787(this, class_332.class_12228.field_63850);
            GuiGraphicsUtils.scrollingText(textRenderer, method_25369(), left, top, right, bottom);
        }

        extractOverlay(graphics, mouseX, mouseY, partialTick);
    }

    void applyProps(io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props props) {
        super.applyProps(props);
        props.sprites().ifDefined(sprites -> this.sprites = sprites);
        props.leftIcon().ifDefined(leftIcon -> this.leftIcon = leftIcon);
        props.rightIcon().ifDefined(rightIcon -> this.rightIcon = rightIcon);
        if (props.centeredMessage() != class_9851.field_52396) {
            this.centeredMessage = props.centeredMessage().method_61348(true);
        }
    }

    public static FZButton bind(String key, FZRef<io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props> ref) {
        FZButton button = new FZButton();
        button.applyProps(ref.value());
        ref.subscribe(key, button::applyProps);
        return button;
    }

    public static Builder builder() {
        return new Builder();
    }

    public interface Props extends FZButtonBase.Props {
        default Undefinable<@Nullable WidgetRenderables> sprites() {
            return Undefinable.undefined();
        }

        default Undefinable<@Nullable WidgetElements> leftIcon() {
            return Undefinable.undefined();
        }

        default Undefinable<@Nullable WidgetElements> rightIcon() {
            return Undefinable.undefined();
        }

        default class_9851 centeredMessage() {
            return class_9851.field_52396;
        }
    }

    private static final class PropsImpl extends FZButtonBase.PropsImpl implements io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props {
        private final Undefinable<@Nullable WidgetRenderables> sprites;
        private final Undefinable<@Nullable WidgetElements> leftIcon;
        private final Undefinable<@Nullable WidgetElements> rightIcon;
        private final class_9851 centeredMessage;

        PropsImpl(
                Undefinable<@Nullable WidgetRenderables> sprites,
                Undefinable<@Nullable WidgetElements> leftIcon,
                Undefinable<@Nullable WidgetElements> rightIcon,
                class_9851 centeredMessage,
                @Nullable FZKeyed<Consumer<PressEvent>> pressHandler,
                class_9851 allowCursorChanges,
                GuiComponentProps props
        ) {
            super(pressHandler, allowCursorChanges, props);
            this.sprites = sprites;
            this.leftIcon = leftIcon;
            this.rightIcon = rightIcon;
            this.centeredMessage = centeredMessage;
        }

        @Override
        public Undefinable<@Nullable WidgetRenderables> sprites() {
            return sprites;
        }

        @Override
        public Undefinable<@Nullable WidgetElements> leftIcon() {
            return leftIcon;
        }

        @Override
        public Undefinable<@Nullable WidgetElements> rightIcon() {
            return rightIcon;
        }

        @Override
        public class_9851 centeredMessage() {
            return centeredMessage;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(sprites, other.sprites()) &&
                   Objects.equals(leftIcon, other.leftIcon()) &&
                   Objects.equals(rightIcon, other.rightIcon()) &&
                   centeredMessage.equals(other.centeredMessage());
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), sprites, leftIcon, rightIcon, centeredMessage);
        }
    }

    public static final class Builder extends AbstractBuilder<Builder, FZButton, io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props> {
        private Undefinable<@Nullable WidgetRenderables> sprites = Undefinable.undefined();
        private Undefinable<@Nullable WidgetElements> leftIcon = Undefinable.undefined();
        private Undefinable<@Nullable WidgetElements> rightIcon = Undefinable.undefined();
        private class_9851 centeredMessage = class_9851.field_52396;

        private Builder() {
        }

        public Builder sprites(@Nullable WidgetRenderables sprites) {
            this.sprites = Undefinable.of(sprites);
            return this;
        }

        public Builder leftIcon(@Nullable WidgetElements leftIcon) {
            this.leftIcon = Undefinable.of(leftIcon);
            return this;
        }

        public Builder leftIcon(RenderableRectangle leftIcon, int width, int height) {
            WidgetRenderables sprites = new WidgetRenderables(Objects.requireNonNull(leftIcon, "leftIcon cannot be null"));
            this.leftIcon = Undefinable.of(new WidgetElements(sprites, width, height));
            return this;
        }

        public Builder leftIcon(WidgetRenderables leftIcon, int width, int height) {
            this.leftIcon = Undefinable.of(new WidgetElements(leftIcon, width, height));
            return this;
        }

        public Builder rightIcon(@Nullable WidgetElements rightIcon) {
            this.rightIcon = Undefinable.of(rightIcon);
            return this;
        }

        public Builder rightIcon(RenderableRectangle rightIcon, int width, int height) {
            WidgetRenderables sprites = new WidgetRenderables(Objects.requireNonNull(rightIcon, "leftIcon cannot be null"));
            this.rightIcon = Undefinable.of(new WidgetElements(sprites, width, height));
            return this;
        }

        public Builder rightIcon(WidgetRenderables rightIcon, int width, int height) {
            this.rightIcon = Undefinable.of(new WidgetElements(rightIcon, width, height));
            return this;
        }

        public Builder centeredMessage() {
            this.centeredMessage = class_9851.field_52394;
            return this;
        }

        public Builder leftAlignedMessage() {
            this.centeredMessage = class_9851.field_52395;
            return this;
        }

        @Override
        public io.github.fishstiz.fidgetz.v0.gui.components.FZButton.Props toProps() {
            return new io.github.fishstiz.fidgetz.v0.gui.components.FZButton.PropsImpl(sprites, leftIcon, rightIcon, centeredMessage, pressHandler, allowCursorChanges, props);
        }

        @Override
        public FZButton build() {
            FZButton button = new FZButton();
            button.applyProps(toProps());
            return button;
        }
    }
}
