package io.github.fishstiz.fidgetz.v0.gui.layouts;

import io.github.fishstiz.fidgetz.v0.gui.components.events.ScrollableContainer;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.class_8133;
import net.minecraft.class_9017;

public final class FZScrollableLayout extends ComposedLayout {
    private static final int DEFAULT_SCROLL_RATE = 10;
    private static final int DEFAULT_SCROLLBAR_SPACING = 4;
    private final Supplier<class_8030> screenArea;
    private final FZScrollableLayout.Container container;
    private double scrollRate;
    private boolean reserveScrollbarArea;
    private int scrollbarSpacing = DEFAULT_SCROLLBAR_SPACING;
    private int minWidth;
    private int maxWidth;
    private int minHeight;
    private int maxHeight;

    FZScrollableLayout(Supplier<class_8030> screenArea, class_8133 content) {
        super(content);
        this.screenArea = screenArea;
        this.container = new FZScrollableLayout.Container(0, 0);
        this.scrollRate = DEFAULT_SCROLL_RATE;
    }

    public static FZScrollableLayout from(Supplier<class_8030> maxScrollArea, class_8133 content) {
        return new FZScrollableLayout(maxScrollArea, content);
    }


    public static FZScrollableLayout from(class_8021 container, class_8133 content) {
        return from(container::method_48202, content);
    }

    public static FZScrollableLayout from(class_364 container, class_8133 content) {
        return from(container::method_48202, content);
    }

    public static FZScrollableLayout from(class_8133 content) {
        return from(class_8030::method_48248, content);
    }

    public static FZScrollableLayout from(int maxHeight, class_8133 content) {
        return from(content).maxHeight(maxHeight);
    }

    public FZScrollableLayout minWidth(int minWidth) {
        this.minWidth = MathUtils.clampOptionalMax(minWidth, 0, screenArea.get().comp_1196());
        container.method_25358(Math.max(composed.method_25368(), minWidth));
        return this;
    }

    public FZScrollableLayout maxWidth(int maxWidth) {
        this.maxWidth = MathUtils.clampOptionalMax(maxWidth, 0, screenArea.get().comp_1196());
        this.minWidth = MathUtils.optionalMin(this.minWidth, this.maxWidth);
        if (container.method_25368() > this.method_25368()) {
            fidgetz$setWidth(this.maxWidth);
            container.method_25358(this.maxWidth);
        }
        return this;
    }

    public FZScrollableLayout minHeight(int minHeight) {
        this.minHeight = MathUtils.clampOptionalMax(minHeight, 0, screenArea.get().comp_1197());
        container.method_53533(Math.max(composed.method_25364(), minHeight));
        return this;
    }

    public FZScrollableLayout maxHeight(int maxHeight) {
        this.maxHeight = MathUtils.clampOptionalMax(maxHeight, 0, screenArea.get().comp_1197());
        container.method_53533(MathUtils.clampOptionalMax(container.method_25364(), minHeight, this.maxHeight));
        return this;
    }

    public FZScrollableLayout scrollRate(double scrollRate) {
        this.scrollRate = scrollRate;
        return this;
    }

    public FZScrollableLayout scrollbarSpacing(int scrollbarSpacing) {
        this.scrollbarSpacing = scrollbarSpacing;
        return this;
    }

    public FZScrollableLayout reserveScrollbarArea(boolean reserveScrollbarArea) {
        this.reserveScrollbarArea = reserveScrollbarArea;
        return this;
    }

    public FZScrollableLayout reserveScrollbarArea() {
        return reserveScrollbarArea(true);
    }

    private int reservedWidth() {
        return reserveScrollbarArea || container.method_44392() ? container.scrollbarReserve() : 0;
    }

    @Override
    public void method_48222() {
        composed.method_48222();
        container.children.clear();
        composed.method_48206(container.children::add);
        int contentWidth = composed.method_25368();
        class_8030 containerBounds = screenArea.get();
        container.method_25358(MathUtils.clampOptionalMax(Math.max(contentWidth, minWidth) + reservedWidth(), 0, containerBounds.comp_1196()));
        container.method_53533(MathUtils.optionalMin(MathUtils.clampOptionalMax(composed.method_25364(), minHeight, maxHeight), containerBounds.comp_1197()));
        container.method_65506();
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        layoutElementVisitor.accept(container);
    }

    @Override
    public void method_46421(int x) {
        container.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        container.method_46419(y);
    }

    @Override
    public int method_46426() {
        return container.method_46426();
    }

    @Override
    public int method_46427() {
        return container.method_46427();
    }

    @Override
    public int method_25368() {
        return container.method_25368();
    }

    @Override
    public int method_25364() {
        return container.method_25364();
    }

    @Override
    public void fidgetz$setWidth(int width) {
        super.fidgetz$setWidth(Math.max(0, width - reservedWidth()));
        method_48222();
    }

    @Override
    public void fidgetz$setHeight(int height) {
        minHeight(height);
        maxHeight(height);
        method_48222();
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        super.fidgetz$setWidth(Math.max(0, width - reservedWidth()));
        minHeight(height);
        maxHeight(height);
        method_48222();
    }

    @Override
    public class_8030 method_48202() {
        return container.method_48202();
    }

    private final class Container extends class_9017 implements ScrollableContainer {
        private final List<class_339> children = new ArrayList<>();
        private class_8030 bounds;

        public Container(int width, int height) {
            super(0, 0, width, height, class_5244.field_39003);
            bounds = super.method_48202();
        }

        @Override
        protected int method_44395() {
            return composed.method_25364();
        }

        @Override
        protected void method_48579(class_332 graphics, int mouseX, int mouseY, float a) {
            graphics.method_44379(method_46426(), method_46427(), method_55442(), method_55443());

            for (class_339 child : children) {
                child.method_25394(graphics, mouseX, mouseY, a);
            }

            graphics.method_44380();
            method_44396(graphics, mouseX, mouseY);
        }

        private boolean scrollable() {
            return method_44390() > 0;
        }

        @Override
        public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
            if (method_37303() && method_19355(mx, my).filter(child -> child.method_25401(mx, my, scrollX, scrollY)).isPresent()) {
                return true;
            }
            return super.method_25401(mx, my, scrollX, scrollY) && scrollable();
        }

        @Override
        protected void method_47399(class_6382 output) {
        }

        @Override
        public class_8030 method_65515(class_8028 opposite) {
            class_364 focused = method_25399();
            return focused != null
                    ? focused.method_65515(opposite)
                    : new class_8030(method_46426(), method_46427(), field_22758, method_44395()).method_48256(opposite);
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            return addScrollEffectOnFocus(navigationEvent, super.method_48205(navigationEvent));
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);
            if (!focused) {
                method_25395(null);
            }
        }

        @Override
        public void method_25395(@Nullable class_364 focused) {
            if (focused != method_25399()) {
                super.method_25395(focused);
            }
        }

        @Override
        public void method_25358(int width) {
            super.method_25358(width);
            bounds = super.method_48202();
        }

        @Override
        public void method_53533(int height) {
            super.method_53533(height);
            bounds = super.method_48202();
        }

        @Override
        public void method_55445(int width, int height) {
            super.method_55445(width, height);
            bounds = super.method_48202();
        }

        @Override
        public void method_46421(int x) {
            super.method_46421(x);
            composed.method_46421(x);
            bounds = super.method_48202();
        }

        @Override
        public void method_46419(int y) {
            super.method_46419(y);
            composed.method_46419(y - (int) method_44387());
            bounds = super.method_48202();
        }

        @Override
        protected boolean method_74038(double x, double y) {
            return super.method_74038(x, y) && method_49606();
        }

        private int scrollbarReserve() {
            return scrollbarSpacing + field_55258;
        }

        @Override
        protected boolean method_44392() {
            return method_44395() > MathUtils.optionalMin(screenArea.get().comp_1197(), maxHeight);
        }

        @Override
        public double method_44393() {
            return scrollRate;
        }

        @Override
        public void method_44382(double scrollAmount) {
            super.method_44382(scrollAmount);
            FZScrollableLayout.this.composed.method_46419(method_48202().method_49618() - (int) method_44387());
        }

        @Override
        public List<? extends class_364> method_25396() {
            return children;
        }

        @Override
        public Collection<? extends class_6379> method_65516() {
            return children;
        }

        @Override
        public class_8030 method_48202() {
            return bounds;
        }
    }
}
