package io.github.fishstiz.fidgetz.v0.utils.timer;

import java.util.function.Consumer;
import net.minecraft.class_156;

public class ImmediateDebouncer<T> extends Debouncer<T> {
    private long lastCallTime = 0;

    public ImmediateDebouncer(Consumer<T> task, long delay) {
        super(task, delay);
    }

    public ImmediateDebouncer(Runnable task, long delay) {
        super(task, delay);
    }

    @Override
    public void accept(T t) {
        long currentTime = class_156.method_658();
        if (currentTime - this.lastCallTime >= this.delay) {
            this.task.accept(t);
            this.lastCallTime = currentTime;
        }
    }
}
