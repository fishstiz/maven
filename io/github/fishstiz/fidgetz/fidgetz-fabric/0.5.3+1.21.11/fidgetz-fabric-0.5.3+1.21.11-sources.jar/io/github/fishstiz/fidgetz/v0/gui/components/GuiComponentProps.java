package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.Undefinable;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_7919;
import net.minecraft.class_9851;

public interface GuiComponentProps {
    default Optional<String> id() {
        return Optional.empty();
    }

    default OptionalInt width() {
        return OptionalInt.empty();
    }

    default OptionalInt height() {
        return OptionalInt.empty();
    }

    default class_9851 active() {
        return class_9851.field_52396;
    }

    default class_9851 visible() {
        return class_9851.field_52396;
    }

    default class_9851 focusOnInteraction() {
        return class_9851.field_52396;
    }

    default Optional<class_2561> message() {
        return Optional.empty();
    }

    default Undefinable<@Nullable class_7919> tooltip() {
        return Undefinable.undefined();
    }

    default Undefinable<@Nullable RenderableRectangle> overlay() {
        return Undefinable.undefined();
    }

    default Optional<FZKeyed<Consumer<FZContextMenu.Collector>>> contextEntries() {
        return Optional.empty();
    }

    default OptionalInt tabOrderGroup() {
        return OptionalInt.empty();
    }
}