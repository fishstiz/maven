package io.github.fishstiz.fidgetz.v0.gui.components;

import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_6382;

public abstract class FZContainer extends class_362 implements class_4068, class_6379 {
    private final List<class_364> children = new ArrayList<>();
    private final List<class_6379> narratables = new ArrayList<>();
    private final List<class_4068> renderables = new ArrayList<>();
    private @Nullable class_6379 lastNarratable;

    @Override
    public List<? extends class_364> method_25396() {
        return children;
    }

    protected List<? extends class_6379> narratables() {
        return narratables;
    }

    protected List<? extends class_4068> renderables() {
        return renderables;
    }

    protected <T extends class_364 & class_6379 & class_4068> T addRenderableWidget(T widget) {
        children.add(widget);
        renderables.add(widget);
        narratables.add(widget);
        return widget;
    }

    protected <T extends class_364 & class_6379 & class_4068> T addRenderableWidgetFirst(T widget) {
        children.addFirst(widget);
        renderables.addFirst(widget);
        narratables.addFirst(widget);
        return widget;
    }

    protected <T extends class_364 & class_6379 & class_4068> T addRenderableWidget(int index, T widget) {
        int clampedChildrenIndex = Math.min(index, children.size());
        int clampedNarratablesIndex = Math.min(index, narratables.size());
        int clampedRenderablesIndex = Math.min(index, renderables.size());
        children.add(clampedChildrenIndex, widget);
        narratables.add(clampedNarratablesIndex, widget);
        renderables.add(clampedRenderablesIndex, widget);
        return widget;
    }

    protected <T extends class_364 & class_6379> T addWidget(T widget) {
        children.add(widget);
        narratables.add(widget);
        return widget;
    }

    protected <T extends class_364 & class_6379> T addWidget(int index, T widget) {
        int clampedChildrenIndex = Math.min(index, children.size());
        int clampedNarratablesIndex = Math.min(index, narratables.size());
        children.add(clampedChildrenIndex, widget);
        narratables.add(clampedNarratablesIndex, widget);
        return widget;
    }

    protected <T extends class_364 & class_6379> T addWidgetFirst(T widget) {
        children.addFirst(widget);
        narratables.addFirst(widget);
        return widget;
    }

    protected <T extends class_4068> T addRenderableOnly(T renderable) {
        renderables.add(renderable);
        return renderable;
    }

    protected <T extends class_4068> T addRenderableOnly(int index, T renderable) {
        renderables.add(Math.min(index, renderables.size()), renderable);
        return renderable;
    }

    protected <T extends class_4068> T addRenderableOnlyFirst(T renderable) {
        renderables.addFirst(renderable);
        return renderable;
    }

    protected void removeWidget(class_364 widget) {
        children.remove(widget);

        if (widget instanceof class_6379) {
            narratables.remove(widget);
        }

        if (widget instanceof class_4068) {
            renderables.remove(widget);
        }
    }

    protected void clearWidgets() {
        method_25365(false);
        children.clear();
        narratables.clear();
        renderables.clear();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        for (class_4068 renderable : renderables()) {
            renderable.method_25394(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public class_6380 method_37018() {
        if (method_25370()) {
            return class_6380.field_33786;
        }
        for (class_364 child : method_25396()) {
            if (child instanceof class_339 widget && widget.method_49606()) {
                return class_6380.field_33785;
            }
        }
        return class_6380.field_33784;
    }

    @Override
    public void method_37020(class_6382 output) {
        List<? extends class_6379> narratables = narratables();
        class_437.class_6390 result = class_437.method_37061(narratables, lastNarratable);
        if (result != null) {
            if (result.comp_4465().method_37028()) {
                lastNarratable = result.comp_4463();
            }
            result.comp_4463().method_37020(output.method_37031());
        }
    }

    @Override
    public void method_25365(boolean focused) {
        if (!focused) {
            method_25395(null);
        }
    }
}
