package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import io.github.fishstiz.fidgetz.v0.utils.Undefinable;
import it.unimi.dsi.fastutil.ints.IntObjectPair;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5244;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_7842;
import net.minecraft.class_8030;
import net.minecraft.class_9848;

public final class FZText extends class_7842 implements FZComponent, FZContextMenu.Source {
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private class_8030 bounds;

    FZText(class_2561 message) {
        super(message, class_310.method_1551().field_1772);
        bounds = super.method_48202();
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float a) {
        super.method_48579(graphics, mouseX, mouseY, a);
        if (method_25370()) {
            graphics.method_73198(method_46426(), method_46427(), method_25368(), method_25364(), class_9848.method_61317(method_75798()));
        }
        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, a);
        }
    }

    @Override
    public void method_25354(class_1144 soundManager) {
    }

    @Override
    public boolean method_72784() {
        return propsState.focusOnInteraction;
    }

    @Override
    protected void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, this.method_25369());
    }

    @Override
    public void method_25355(class_2561 message) {
        this.field_22754 = message;
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            bounds = super.method_48202();
        }
        return bounds;
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    void applyProps(Props props) {
        propsState.apply(this, props);
        props.maxWidth().ifPresent(pair -> method_73395(pair.leftInt(), pair.right()));
        props.componentClickHandler().ifDefined(this::method_75797);
    }

    public static FZText bind(String key, FZRef<Props> ref) {
        Props props = ref.value();
        FZText text = new FZText(props.message().orElse(class_5244.field_39003));
        text.applyProps(props);
        if (props.width().isEmpty()) {
            text.method_25358(text.method_48977().method_27525(text.method_25369()));
        }
        ref.subscribe(key, text::applyProps);
        return text;
    }

    public static Builder builder(class_2561 message) {
        return new Builder(message);
    }

    public interface Props extends GuiComponentProps {
        default Optional<IntObjectPair<class_11764>> maxWidth() {
            return Optional.empty();
        }

        default Undefinable<@Nullable Consumer<class_2583>> componentClickHandler() {
            return Undefinable.undefined();
        }
    }

    private static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final @Nullable IntObjectPair<class_11764> maxWidth;
        private final Undefinable<@Nullable Consumer<class_2583>> componentClickHandler;

        private PropsImpl(
                GuiComponentProps props,
                @Nullable IntObjectPair<class_11764> maxWidth,
                Undefinable<@Nullable Consumer<class_2583>> componentClickHandler
        ) {
            super(props);
            this.maxWidth = maxWidth;
            this.componentClickHandler = componentClickHandler;
        }

        @Override
        public Optional<IntObjectPair<class_11764>> maxWidth() {
            return Optional.ofNullable(maxWidth);
        }

        @Override
        public Undefinable<@Nullable Consumer<class_2583>> componentClickHandler() {
            return componentClickHandler;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(maxWidth(), other.maxWidth()) &&
                   Objects.equals(componentClickHandler(), other.componentClickHandler());
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), maxWidth, componentClickHandler);
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private @Nullable IntObjectPair<class_11764> maxWidth;
        private Undefinable<@Nullable Consumer<class_2583>> componentClickHandler = Undefinable.undefined();

        private Builder(class_2561 message) {
            props.message = message;
        }

        public Builder maxWidth(int maxWidth, class_11764 overflow) {
            this.maxWidth = IntObjectPair.of(maxWidth, overflow);
            return this;
        }

        public Builder maxWidth(int maxWidth) {
            this.maxWidth = this.maxWidth == null
                    ? IntObjectPair.of(maxWidth, class_11764.field_62126)
                    : IntObjectPair.of(maxWidth, this.maxWidth.right());

            return this;
        }

        public Builder onComponentClick(@Nullable Consumer<class_2583> componentClickHandler) {
            this.componentClickHandler = Undefinable.of(componentClickHandler);
            return this;
        }

        public Props toProps() {
            return new PropsImpl(props, maxWidth, componentClickHandler);
        }

        public FZText build() {
            FZText text = new FZText(props.message().orElse(class_5244.field_39003));
            Props props = toProps();
            text.applyProps(props);
            if (props.width().isEmpty()) {
                text.method_25358(text.method_48977().method_27525(text.method_25369()));
            }
            return text;
        }
    }
}
