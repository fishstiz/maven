package io.github.fishstiz.fidgetz.v0.gui.renderables;

import io.github.fishstiz.fidgetz.v0.gui.components.FZPopover;
import io.github.fishstiz.fidgetz.v0.gui.components.WidgetVisitor;
import java.util.function.Consumer;
import net.minecraft.class_332;
import net.minecraft.class_4068;

record Popover(class_4068 renderable, int fidgetz$popoverOrder) implements class_4068, FZPopover {
    Popover(class_4068 renderable) {
        this(renderable, DEFAULT_ORDER);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        renderable.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void fidgetz$visitWidgets(WidgetVisitor visitor) {
    }

    @Override
    public void fidgetz$visitRenderables(Consumer<class_4068> visitor) {
        visitor.accept(this);
    }
}
