package io.github.fishstiz.fidgetz.v0.gui.renderables;

import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;

record TextRectangle(Supplier<class_2561> text) implements RenderableRectangle {
    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        graphics.method_75788().method_75771(text.get(), left + (width / 2), left, left + width, top, top + height);
    }
}
