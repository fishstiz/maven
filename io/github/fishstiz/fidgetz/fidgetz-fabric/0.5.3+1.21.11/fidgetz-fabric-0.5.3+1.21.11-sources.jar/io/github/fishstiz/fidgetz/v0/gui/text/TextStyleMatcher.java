package io.github.fishstiz.fidgetz.v0.gui.text;

import net.minecraft.class_2583;

public interface TextStyleMatcher {
    boolean styleable(String input);

    void reset(String input);

    boolean find();

    int start();

    int end();

    class_2583 style();

    TextStyleMatcher copy();
}
