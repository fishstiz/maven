package io.github.fishstiz.fidgetz.v0.gui.components;

import java.util.function.Consumer;
import net.minecraft.class_4068;

public interface FZPopover {
    int DEFAULT_ORDER = 1000;

    void fidgetz$visitWidgets(WidgetVisitor visitor);

    void fidgetz$visitRenderables(Consumer<class_4068> visitor);

    default int fidgetz$popoverOrder() {
        return DEFAULT_ORDER;
    }
}
