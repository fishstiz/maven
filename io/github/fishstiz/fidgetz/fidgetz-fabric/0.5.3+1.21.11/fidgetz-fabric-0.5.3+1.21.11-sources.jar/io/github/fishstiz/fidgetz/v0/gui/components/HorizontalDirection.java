package io.github.fishstiz.fidgetz.v0.gui.components;

import net.minecraft.class_8030;

public enum HorizontalDirection {
    LEFT {
        @Override
        HorizontalDirection resolve(class_8030 container, int width, int anchor) {
            return anchor - width * FLIP_THRESHOLD < 0 ? flip() : this;
        }

        @Override
        int clamp(class_8030 container, int width, int anchor) {
            return Math.max(0, anchor - width);
        }

        @Override
        int edge(class_8030 bounds) {
            return bounds.method_49620();
        }

        @Override
        HorizontalDirection flip() {
            return RIGHT;
        }
    },
    RIGHT {
        @Override
        HorizontalDirection resolve(class_8030 container, int width, int anchor) {
            return anchor + width * FLIP_THRESHOLD > container.comp_1196() ? flip() : this;
        }

        @Override
        int clamp(class_8030 container, int width, int anchor) {
            return Math.max(0, anchor + width > container.comp_1196() ? container.comp_1196() - width : anchor);
        }

        @Override
        int edge(class_8030 bounds) {
            return bounds.method_49621();
        }

        @Override
        HorizontalDirection flip() {
            return LEFT;
        }
    };

    private static final float FLIP_THRESHOLD = 0.75f;

    abstract HorizontalDirection resolve(class_8030 container, int width, int anchor);

    abstract int clamp(class_8030 container, int width, int anchor);

    abstract int edge(class_8030 bounds);

    abstract HorizontalDirection flip();
}
