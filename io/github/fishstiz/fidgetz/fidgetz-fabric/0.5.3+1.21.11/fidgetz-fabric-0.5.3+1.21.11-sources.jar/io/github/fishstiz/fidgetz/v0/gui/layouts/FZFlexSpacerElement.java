package io.github.fishstiz.fidgetz.v0.gui.layouts;

import java.util.function.Consumer;
import net.minecraft.class_339;

public final class FZFlexSpacerElement implements FZFlexElement {
    private int x;
    private int y;
    private int width;
    private int height;

    @Override
    public void method_46421(int x) {
        this.x = x;
    }

    @Override
    public void method_46419(int y) {
        this.y = y;
    }

    @Override
    public int method_46426() {
        return this.x;
    }

    @Override
    public int method_46427() {
        return this.y;
    }

    @Override
    public int method_25368() {
        return this.width;
    }

    @Override
    public int method_25364() {
        return this.height;
    }

    @Override
    public void method_48206(Consumer<class_339> widgetVisitor) {
    }

    @Override
    public void fidgetz$setWidth(int width) {
        this.width = width;
    }

    @Override
    public void fidgetz$setHeight(int height) {
        this.height = height;
    }

    public FZFlexSpacerElement width(int width) {
        fidgetz$setWidth(width);
        return this;
    }

    public FZFlexSpacerElement height(int height) {
        fidgetz$setHeight(height);
        return this;
    }

    public FZFlexSpacerElement size(int width, int height) {
        return width(width).height(height);
    }
}
