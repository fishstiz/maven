package io.github.fishstiz.fidgetz.v0.inject.mixins.access;

import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_342.class)
public interface EditBoxAccess {
    @Accessor("highlightPos")
    int fidgetz$getHighlightPos();
}
