package io.github.fishstiz.fidgetz.v0.gui.components;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_8030;

public interface FZDialogContainer extends class_4069, FZPopoverContainer {
    default List<? extends FZDialog> fidgetz$Dialogs() {
        return method_25396().stream().filter(FZDialog.class::isInstance).map(FZDialog.class::cast).toList();
    }

    default boolean fidgetz$captureEventForDialogs(class_11908 event) {
        if (event.method_74231()) {
            for (FZDialog dialog : fidgetz$Dialogs()) {
                if (dialog.isOpen() && dialog.shouldCloseOnEscape()) {
                    class_364 focused = this.method_25399();
                    dialog.setOpen(false);
                    if (focused == dialog) {
                        dialog.refocusLastContainerPath();
                    }
                    return true;
                }
            }
        }
        return false;
    }

    default boolean fidgetz$captureEventForDialogs(class_11909 event) {
        if (event.method_74245() == class_3675.field_32000) {
            for (FZDialog dialog : fidgetz$Dialogs()) {
                if (!dialog.isOpen()) continue;

                if (dialog.shouldCloseAfterClickOutOfBounds() && !dialog.areCoordinatesInBounds((int) event.comp_4798(), (int) event.comp_4799())) {
                    dialog.setOpen(false);
                    return dialog.shouldCaptureClick();
                }

                if (dialog.method_25405(event.comp_4798(), event.comp_4799())) {
                    return false;
                }
            }
        }
        return false;
    }

    @Override
    default void fidgetz$visitPopovers(Consumer<FZPopover> visitor) {
        fidgetz$Dialogs().forEach(visitor);
    }

    @Override
    class_8030 method_48202();
}
