package io.github.fishstiz.fidgetz.v0.gui.components;

import net.minecraft.class_364;
import net.minecraft.class_6379;

@FunctionalInterface
public interface WidgetVisitor {
    <T extends class_364 & class_6379> void visitWidget(T widget);
}
