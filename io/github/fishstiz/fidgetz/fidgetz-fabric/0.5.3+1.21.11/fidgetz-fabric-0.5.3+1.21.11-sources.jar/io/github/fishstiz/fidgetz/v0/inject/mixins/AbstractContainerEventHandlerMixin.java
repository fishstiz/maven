package io.github.fishstiz.fidgetz.v0.inject.mixins;

import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableContainer;
import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_362.class)
abstract class AbstractContainerEventHandlerMixin implements class_4069, FZHoverableContainer {
    @Unique
    @Nullable
    private class_364 fidgetz$hoveredElement;

    @Override
    public @Nullable class_364 fidgetz$getHovered() {
        return fidgetz$hoveredElement;
    }

    @Override
    public void fidgetz$setHovered(@Nullable class_364 hovered) {
        class_364 previous = fidgetz$getHovered();
        if (previous != hovered) {
            if (previous instanceof FZHoverableElement previousElement) {
                previousElement.fidgetz$setHovered(false);
            }

            if (hovered instanceof FZHoverableElement hoveredElement) {
                hoveredElement.fidgetz$setHovered(true);
            }

            fidgetz$hoveredElement = hovered;
        }
    }
}
