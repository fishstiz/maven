package io.github.fishstiz.fidgetz.v0.gui.components;

import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public final class GuiComponentCollector {
    private static final Comparator<OrderedEntry<?>> WIDGET_COMPARATOR = Comparator.comparingInt(OrderedEntry::order);
    private static final Comparator<OrderedEntry<?>> RENDERABLE_COMPARATOR = WIDGET_COMPARATOR.reversed();
    private final List<OrderedEntry<? extends class_364>> popoverWidgets = new ArrayList<>();
    private final List<OrderedEntry<class_4068>> popoverRenderables = new ArrayList<>();
    private final List<class_364> widgets = new ArrayList<>();
    private final List<class_4068> renderables = new ArrayList<>();

    private record OrderedEntry<T>(T value, int order) {
    }

    @SuppressWarnings("unchecked")
    private static <T extends class_364 & class_6379> T asWidget(class_364 widget) {
        return (T) widget;
    }

    private void collectPopover(FZPopover popover, boolean includeWidgets, boolean includeRenderables) {
        if (popover instanceof FZPopoverContainer container) {
            container.fidgetz$visitPopovers(nested -> collectPopover(nested, includeWidgets, includeRenderables));
        }

        int order = popover.fidgetz$popoverOrder();
        if (includeWidgets) {
            popover.fidgetz$visitWidgets(new WidgetVisitor() {
                @Override
                public <T extends class_364 & class_6379> void visitWidget(T widget) {
                    popoverWidgets.add(new OrderedEntry<>(widget, order));
                }
            });
        }
        if (includeRenderables) {
            popover.fidgetz$visitRenderables(r -> popoverRenderables.add(new OrderedEntry<>(r, order)));
        }
    }

    public <T extends class_364 & class_6379 & class_4068> T renderableWidget(T widget) {
        if (widget instanceof FZPopover popover) {
            collectPopover(popover, true, true);
            return widget;
        }

        widgets.add(widget);
        renderables.add(widget);

        if (widget instanceof FZPopoverContainer container) {
            container.fidgetz$visitPopovers(popover -> collectPopover(popover, true, true));
        }

        return widget;
    }

    public <T extends class_364 & class_6379> T widgetOnly(T widget) {
        if (widget instanceof FZPopover popover) {
            collectPopover(popover, true, false);
            return widget;
        }

        widgets.add(widget);

        if (widget instanceof FZPopoverContainer container) {
            container.fidgetz$visitPopovers(popover -> collectPopover(popover, true, false));
        }

        return widget;
    }

    public <T extends class_4068> T renderableOnly(T renderable) {
        if (renderable instanceof FZPopover popover) {
            collectPopover(popover, false, true);
            return renderable;
        }

        renderables.add(renderable);

        if (renderable instanceof FZPopoverContainer container) {
            container.fidgetz$visitPopovers(popover -> collectPopover(popover, false, true));
        }

        return renderable;
    }

    public void flushTo(WidgetVisitor widgetSink, Consumer<class_4068> renderableSink) {
        if (!popoverWidgets.isEmpty()) {
            popoverWidgets.sort(WIDGET_COMPARATOR);
            Iterator<OrderedEntry<? extends class_364>> iterator = popoverWidgets.iterator();
            while (iterator.hasNext()) {
                OrderedEntry<? extends class_364> entry = iterator.next();
                widgetSink.visitWidget(asWidget(entry.value));
                iterator.remove();
            }
        }

        Iterator<class_364> widgetsIterator = widgets.iterator();
        while (widgetsIterator.hasNext()) {
            class_364 widget = widgetsIterator.next();
            widgetSink.visitWidget(asWidget(widget));
            widgetsIterator.remove();
        }

        Iterator<class_4068> renderablesIterator = renderables.iterator();
        while (renderablesIterator.hasNext()) {
            class_4068 renderable = renderablesIterator.next();
            renderableSink.accept(renderable);
            renderablesIterator.remove();
        }

        if (!popoverRenderables.isEmpty()) {
            popoverRenderables.sort(RENDERABLE_COMPARATOR);
            Iterator<OrderedEntry<class_4068>> iterator = popoverRenderables.iterator();
            while (iterator.hasNext()) {
                renderableSink.accept(iterator.next().value);
                iterator.remove();
            }
        }
    }
}
