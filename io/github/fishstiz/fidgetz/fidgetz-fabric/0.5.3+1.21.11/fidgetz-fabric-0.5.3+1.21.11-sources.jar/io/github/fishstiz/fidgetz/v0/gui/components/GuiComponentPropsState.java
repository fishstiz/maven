package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import org.jspecify.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_339;

public class GuiComponentPropsState {
    public @Nullable String id;
    public boolean focusOnInteraction = true;
    public @Nullable RenderableRectangle overlay = null;
    public Consumer<FZContextMenu.Collector> contextEntries = FunctionUtils.nopConsumer();

    public GuiComponentPropsState() {
    }

    private void apply(GuiComponentProps props) {
        props.id().ifPresent(id -> this.id = id);
        GuiComponentPropsBase.ifNonDefault(props.focusOnInteraction(), f -> this.focusOnInteraction = f.method_61348(true));
        props.overlay().ifDefined(overlay -> this.overlay = overlay);
        props.contextEntries().ifPresent(entries -> this.contextEntries = entries.value());
    }

    public void apply(class_339 widget, GuiComponentProps props) {
        props.width().ifPresent(widget::method_25358);
        props.height().ifPresent(widget::method_53533);
        GuiComponentPropsBase.ifNonDefault(props.active(), a -> widget.field_22763 = a.method_61348(true));
        GuiComponentPropsBase.ifNonDefault(props.visible(), a -> widget.field_22764 = a.method_61348(true));
        props.tooltip().ifDefined(widget::method_47400);
        props.message().ifPresent(widget::method_25355);
        props.tabOrderGroup().ifPresent(widget::method_48591);
        apply(props);
    }
}
