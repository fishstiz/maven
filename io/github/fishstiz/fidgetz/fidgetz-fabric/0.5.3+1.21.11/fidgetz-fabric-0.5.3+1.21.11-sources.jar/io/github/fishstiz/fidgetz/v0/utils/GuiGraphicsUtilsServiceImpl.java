package io.github.fishstiz.fidgetz.v0.utils;

import net.minecraft.class_11244;
import net.minecraft.class_332;
import net.minecraft.class_8030;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@ApiStatus.Internal
public class GuiGraphicsUtilsServiceImpl implements GuiGraphicsUtils.Service {
    @Override
    public void addGuiElement(@NonNull class_332 graphics, @NonNull class_11244 blitState) {
        graphics.field_59826.method_70919(blitState);
    }

    @Override
    public @Nullable class_8030 peekScissorStack(@NonNull class_332 graphics) {
        return graphics.field_44659.method_70863();
    }
}
