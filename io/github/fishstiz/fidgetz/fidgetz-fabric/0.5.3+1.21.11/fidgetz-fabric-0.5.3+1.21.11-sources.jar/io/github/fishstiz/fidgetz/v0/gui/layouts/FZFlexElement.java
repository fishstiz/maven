package io.github.fishstiz.fidgetz.v0.gui.layouts;

import net.minecraft.class_8021;

public interface FZFlexElement extends class_8021 {
    void fidgetz$setWidth(int width);

    void fidgetz$setHeight(int height);

    default void fidgetz$setSize(int width, int height) {
        this.fidgetz$setWidth(width);
        this.fidgetz$setHeight(height);
    }

    default boolean fidgetz$isVisible() {
        return true;
    }
}
