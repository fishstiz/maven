package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.components.events.FZHoverableElement;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import net.minecraft.class_1144;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import net.minecraft.class_8030;
import net.minecraft.client.input.*;
import org.jspecify.annotations.Nullable;

import java.time.Duration;
import java.util.Collection;
import java.util.List;

public class WrappedComponent extends class_339 implements class_4069, FZComponent, FZHoverableElement {
    private List<class_339> children;
    private class_339 widget;
    private boolean dragging;

    public WrappedComponent(class_339 widget) {
        super(widget.method_46426(), widget.method_46427(), widget.method_25368(), widget.method_25364(), widget.method_25369());
        this.widget = widget;
        this.children = List.of(widget);
    }

    public void set(class_339 widget) {
        if (this.widget != widget) {
            boolean focused = method_25370();
            class_8030 rectangle = method_48202();
            this.widget = widget;
            this.children = List.of(widget);
            method_55444(rectangle.comp_1196(), rectangle.comp_1197(), rectangle.method_49620(), rectangle.method_49618());
            method_25395(focused ? widget : null);
        }
    }

    public class_339 get() {
        return this.widget;
    }

    public static WrappedComponent bind(String key, FZRef<? extends class_339> ref) {
        WrappedComponent wrapped = new WrappedComponent(ref.value());
        ref.subscribe(key, wrapped::set);
        return wrapped;
    }

    @Override
    public List<class_339> method_25396() {
        return children;
    }

    @Override
    public boolean method_25397() {
        return dragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Override
    public @Nullable class_364 method_25399() {
        return widget.method_25370() ? widget : null;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (focused == null) {
            widget.method_25365(false);
        } else if (focused == widget) {
            widget.method_25365(true);
        }
    }

    // delegate to widget

    @Override
    public @Nullable String fidgetz$componentId() {
        return widget instanceof FZComponent component ? component.fidgetz$componentId() : null;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float a) {
        widget.method_25394(graphics, mouseX, mouseY, a);
    }

    @Override
    protected void method_47399(class_6382 output) {
        widget.method_37020(output);
    }

    @Override
    public int method_25364() {
        return widget.method_25364();
    }

    @Override
    public void method_47400(@Nullable class_7919 tooltip) {
        super.method_47400(tooltip);
        widget.method_47400(tooltip);
    }

    @Override
    public void method_47402(Duration delay) {
        super.method_47402(delay);
        widget.method_47402(delay);
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        widget.method_25348(event, doubleClick);
    }

    @Override
    public void method_25357(class_11909 event) {
        widget.method_25357(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        return widget.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        return widget.method_25406(event);
    }

    @Override
    public boolean method_25403(class_11909 event, double dx, double dy) {
        return widget.method_25403(event, dx, dy);
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return class_8016.method_48192(this, widget.method_48205(navigationEvent));
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return widget.method_25405(mouseX, mouseY);
    }

    @Override
    public void method_25354(class_1144 soundManager) {
        widget.method_25354(soundManager);
    }

    @Override
    public int method_25368() {
        return widget.method_25368();
    }

    @Override
    public void method_25358(int width) {
        super.method_25358(width);
        widget.method_25358(width);
    }

    @Override
    public void method_53533(int height) {
        super.method_53533(height);
        widget.method_53533(height);
    }

    @Override
    public void method_25350(float alpha) {
        super.method_25350(alpha);
        widget.method_25350(alpha);
    }

    @Override
    public float method_75798() {
        return widget.method_75798();
    }

    @Override
    public void method_25355(class_2561 message) {
        super.method_25355(message);
        widget.method_25355(message);
    }

    @Override
    public class_2561 method_25369() {
        return widget.method_25369();
    }

    @Override
    public boolean method_25370() {
        return widget.method_25370();
    }

    @Override
    public boolean method_49606() {
        return widget.method_49606();
    }

    @Override
    public boolean method_25367() {
        return widget.method_25367();
    }

    @Override
    public boolean method_37303() {
        return widget.method_37303();
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        widget.method_25365(focused);
    }

    @Override
    public class_6380 method_37018() {
        return widget.method_37018();
    }

    @Override
    public int method_46426() {
        return widget.method_46426();
    }

    @Override
    public void method_46421(int x) {
        super.method_46421(x);
        widget.method_46421(x);
    }

    @Override
    public int method_46427() {
        return widget.method_46427();
    }

    @Override
    public void method_46419(int y) {
        super.method_46419(y);
        widget.method_46419(y);
    }

    @Override
    public int method_55442() {
        return widget.method_55442();
    }

    @Override
    public int method_55443() {
        return widget.method_55443();
    }

    @Override
    public void method_55445(int width, int height) {
        super.method_55445(width, height);
        widget.method_55445(width, height);
    }

    @Override
    public class_8030 method_48202() {
        return widget.method_48202();
    }

    @Override
    public void method_55444(int width, int height, int x, int y) {
        super.method_55444(width, height, x, y);
        widget.method_55444(width, height, x, y);
    }

    @Override
    public boolean fidgetz$isVisible() {
        return widget.field_22764;
    }

    @Override
    public int method_48590() {
        return widget.method_48590();
    }

    @Override
    public void method_48591(int tabOrderGroup) {
        super.method_48591(tabOrderGroup);
        widget.method_48591(tabOrderGroup);
    }

    @Override
    public void method_48229(int x, int y) {
        super.method_48229(x, y);
        widget.method_48229(x, y);
    }

    @Override
    public void method_16014(double x, double y) {
        widget.method_16014(x, y);
    }

    @Override
    public boolean method_25401(double x, double y, double scrollX, double scrollY) {
        return widget.method_25401(x, y, scrollX, scrollY);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        return widget.method_25404(event);
    }

    @Override
    public boolean method_16803(class_11908 event) {
        return widget.method_16803(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        return widget.method_25400(event);
    }

    @Override
    public boolean method_72784() {
        return widget.method_72784();
    }

    @Override
    public @Nullable class_8016 method_48218() {
        return widget.method_48218();
    }

    @Override
    public class_8030 method_65515(class_8028 opposite) {
        return widget.method_65515(opposite);
    }

    @Override
    public Collection<? extends class_6379> method_65516() {
        return widget.method_65516();
    }
}
