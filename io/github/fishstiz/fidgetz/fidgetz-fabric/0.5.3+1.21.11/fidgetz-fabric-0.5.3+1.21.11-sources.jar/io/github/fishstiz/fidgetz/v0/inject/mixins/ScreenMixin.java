package io.github.fishstiz.fidgetz.v0.inject.mixins;

import io.github.fishstiz.fidgetz.v0.inject.interfaces.WidgetOperator;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
abstract class ScreenMixin implements WidgetOperator {
    @Shadow
    @Final
    @Mutable
    private List<class_4068> renderables;

    @Shadow
    @Final
    @Mutable
    private List<class_6379> narratables;

    @Shadow
    @Final
    @Mutable
    private List<class_364> children;

    @Override
    public void fidgetz$modifyWidgets(UnaryOperator<List<class_364>> modifier) {
        children = modifier.apply(children);
    }

    @Override
    public void fidgetz$modifyNarratables(UnaryOperator<List<class_6379>> modifier) {
        narratables = modifier.apply(narratables);
    }

    @Override
    public void fidgetz$modifyRenderables(UnaryOperator<List<class_4068>> modifier) {
        renderables = modifier.apply(renderables);
    }
}
