package io.github.fishstiz.fidgetz.v0.gui.layouts;

import java.util.function.Consumer;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

abstract class ComposedLayout implements FZLayout {
    protected class_8133 composed;

    ComposedLayout(class_8133 composed) {
        this.composed = composed;
    }

    @Override
    public void fidgetz$setWidth(int width) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setWidth(width);
        }
    }

    @Override
    public void fidgetz$setHeight(int height) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setHeight(height);
        }
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setSize(width, height);
        }
    }

    @Override
    public boolean fidgetz$isVisible() {
        if (composed instanceof FZFlexElement flexElement) {
            return flexElement.fidgetz$isVisible();
        }
        return true;
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        composed.method_48227(layoutElementVisitor);
    }

    @Override
    public void method_46421(int x) {
        composed.method_46421(x);
    }

    @Override
    public void method_46419(int y) {
        composed.method_46419(y);
    }

    @Override
    public int method_46426() {
        return composed.method_46426();
    }

    @Override
    public int method_46427() {
        return composed.method_46427();
    }

    @Override
    public int method_25368() {
        return composed.method_25368();
    }

    @Override
    public int method_25364() {
        return composed.method_25364();
    }

    @Override
    public class_8030 method_48202() {
        return composed.method_48202();
    }

    @Override
    public abstract void method_48222();
}
