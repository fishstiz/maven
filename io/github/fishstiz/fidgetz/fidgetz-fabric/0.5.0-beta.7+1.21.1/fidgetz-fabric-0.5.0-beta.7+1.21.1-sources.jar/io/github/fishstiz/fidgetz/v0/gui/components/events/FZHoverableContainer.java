package io.github.fishstiz.fidgetz.v0.gui.components.events;

import net.minecraft.class_364;
import org.jetbrains.annotations.Nullable;

public interface FZHoverableContainer extends FZHoverableElement {
    private UnsupportedOperationException notImplemented(String method) {
        return new UnsupportedOperationException("""
                FZHoverableContainer is only implemented for ContainerEventHandlers, \
                override %s if implementing on an unsupported class (%s).
                """.formatted(method, getClass().getName())
        );
    }

    default @Nullable class_364 fidgetz$getHovered() {
        throw notImplemented("fidgetz$getHovered");
    }

    default void fidgetz$setHovered(@Nullable class_364 hovered) {
        throw notImplemented("fidgetz$setHovered");
    }

    @Override
    default boolean fidgetz$isHovered() {
        return fidgetz$getHovered() != null;
    }

    @Override
    default void fidgetz$setHovered(boolean hovered) {
        if (!hovered) {
            fidgetz$setHovered(null);
        }
    }
}
