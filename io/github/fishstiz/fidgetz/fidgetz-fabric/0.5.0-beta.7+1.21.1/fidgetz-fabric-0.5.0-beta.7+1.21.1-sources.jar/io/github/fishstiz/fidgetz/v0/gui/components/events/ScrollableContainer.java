package io.github.fishstiz.fidgetz.v0.gui.components.events;

import io.github.fishstiz.fidgetz.v0.utils.NavigationUtils;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;

public interface ScrollableContainer extends class_4069 {
    double scrollRate();

    double scrollAmount();

    void setScrollAmount(double scrollAmount);

    default @Nullable class_8016 addScrollEffectOnFocus(class_8023 event, @Nullable class_8016 path) {
        if (!(path instanceof class_8016.class_8018(class_4069 ignored, class_8016 childPath))) {
            return path;
        }

        if (event instanceof class_8023.class_8026 ||
            event instanceof class_8023.class_8024) {
            return class_8016.method_48192(this, NavigationUtils.afterFocusEffect(childPath, this::scrollOnFocus));
        }

        return path;
    }

    default void scrollOnFocus(class_364 component) {
        if (method_25399() == component) {
            class_8030 area = method_48202();
            class_8030 componentRectangle = component.method_48202();
            int topDelta = componentRectangle.method_49618() - area.method_49618();
            int bottomDelta = componentRectangle.method_49619() - area.method_49619();
            double scrollRate = scrollRate();
            if (topDelta < 0) {
                setScrollAmount(scrollAmount() + topDelta - scrollRate);
            } else if (bottomDelta > 0) {
                setScrollAmount(scrollAmount() + bottomDelta + scrollRate);
            }
        }
    }
}
