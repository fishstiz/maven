package io.github.fishstiz.fidgetz.v0.gui.renderables;

import net.minecraft.class_332;

record Outline(int color) implements RenderableRectangle {
    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        graphics.method_49601(left, top, width, height, color);
    }
}
