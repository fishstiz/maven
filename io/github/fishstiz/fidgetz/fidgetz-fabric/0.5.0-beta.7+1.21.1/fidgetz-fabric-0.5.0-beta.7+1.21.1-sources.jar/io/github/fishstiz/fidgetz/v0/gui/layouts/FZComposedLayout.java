package io.github.fishstiz.fidgetz.v0.gui.layouts;

import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_7843;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import net.minecraft.class_8133;

public final class FZComposedLayout extends ComposedLayout {
    private class_8030 padding = class_8030.method_48248();
    private @Nullable Supplier<class_8030> maxBounds;
    private @Nullable Supplier<class_8030> alignmentBounds;
    private float alignX;
    private float alignY;

    FZComposedLayout(class_8133 base) {
        super(base);
    }

    public static FZComposedLayout compose(class_8133 base) {
        return new FZComposedLayout(base);
    }

    public static Contained contain(Supplier<class_8030> area, class_8133 base) {
        return new Contained(area, base);
    }

    public static Contained contain(class_8021 container, class_8133 base) {
        return new Contained(container::method_48202, base);
    }

    public static Contained contain(class_364 container, class_8133 base) {
        return new Contained(container::method_48202, base);
    }

    public FZComposedLayout nest() {
        return new FZComposedLayout(this);
    }

    public FZComposedLayout padding(int padding) {
        this.padding = ScreenRectangleUtils.insets(padding);
        return this;
    }

    public FZComposedLayout padding(int left, int top, int right, int bottom) {
        padding = ScreenRectangleUtils.insets(left, top, right, bottom);
        return this;
    }

    public FZComposedLayout align(Supplier<class_8030> alignmentBounds, float x, float y) {
        this.alignmentBounds = alignmentBounds;
        alignX = Math.clamp(x, 0f, 1f);
        alignY = Math.clamp(y, 0f, 1f);
        return this;
    }

    public FZComposedLayout align(class_364 container, float x, float y) {
        return align(container::method_48202, x, y);
    }

    public FZComposedLayout align(class_8021 container, float x, float y) {
        return align(container::method_48202, x, y);
    }

    public FZComposedLayout center(class_8021 container) {
        return align(container, 0.5f, 0.5f);
    }

    public FZComposedLayout center(class_364 container) {
        return align(container, 0.5f, 0.5f);
    }

    public FZComposedLayout clamp(Supplier<class_8030> maxBounds) {
        this.maxBounds = maxBounds;
        return this;
    }

    public FZComposedLayout clamp(class_364 container) {
        return clamp(container::method_48202);
    }

    public FZComposedLayout clamp(class_8021 container) {
        return clamp(container::method_48202);
    }

    public FZComposedLayout scrollable(Supplier<class_8030> maxScrollArea) {
        composed = FZScrollableLayout.from(maxScrollArea, composed);
        return this;
    }

    public FZComposedLayout scrollable(class_364 container) {
        return scrollable(container::method_48202);
    }

    public FZComposedLayout scrollable(class_8021 container) {
        return scrollable(container::method_48202);
    }

    public FZComposedLayout scrollable(int maxHeight) {
        composed = FZScrollableLayout.from(maxHeight, composed);
        return this;
    }

    public FZComposedLayout scrollable(Supplier<class_8030> maxScrollArea, Consumer<FZScrollableLayout> configurator) {
        FZScrollableLayout scrollable = FZScrollableLayout.from(maxScrollArea, composed);
        configurator.accept(scrollable);
        composed = scrollable;
        return this;
    }

    public FZComposedLayout scrollable(class_364 container, Consumer<FZScrollableLayout> configurator) {
        return scrollable(container::method_48202, configurator);
    }

    public FZComposedLayout scrollable(class_8021 container, Consumer<FZScrollableLayout> configurator) {
        return scrollable(container::method_48202, configurator);
    }

    public FZComposedLayout scrollable(int maxHeight, Consumer<FZScrollableLayout> configurator) {
        FZScrollableLayout scrollable = FZScrollableLayout.from(maxHeight, composed);
        configurator.accept(scrollable);
        composed = scrollable;
        return this;
    }

    public FZScrollableLayout toScrollable(Supplier<class_8030> maxScrollArea) {
        return FZScrollableLayout.from(maxScrollArea, this);
    }

    public FZScrollableLayout toScrollable(class_364 container) {
        return toScrollable(container::method_48202);
    }

    public FZScrollableLayout toScrollable(class_8021 container) {
        return toScrollable(container::method_48202);
    }

    public FZScrollableLayout toScrollable(int maxHeight) {
        return FZScrollableLayout.from(maxHeight, composed);
    }

    public FZScrollableLayout toScrollable() {
        return FZScrollableLayout.from(composed);
    }

    @Override
    public void fidgetz$setWidth(int width) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setWidth(width - (padding.method_49620() + padding.method_49621()));
        }
    }

    @Override
    public void fidgetz$setHeight(int height) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setHeight(height - (padding.method_49618() + padding.method_49619()));
        }
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        if (composed instanceof FZFlexElement flexElement) {
            flexElement.fidgetz$setSize(width - (padding.method_49620() + padding.method_49621()), height - (padding.method_49618() + padding.method_49619()));
        }
    }

    @Override
    public void method_46421(int x) {
        int clampedX = x + padding.method_49620();
        if (maxBounds != null) {
            class_8030 bounds = maxBounds.get();
            int minX = bounds.method_49620() + padding.method_49620();
            int maxX = Math.max(bounds.method_49620() + padding.method_49620(), bounds.method_49621() - padding.method_49621() - composed.method_25368());
            clampedX = Math.clamp(clampedX, minX, maxX);
        }
        composed.method_46421(clampedX);
    }

    @Override
    public void method_46419(int y) {
        int clampedY = y + padding.method_49618();
        if (maxBounds != null) {
            class_8030 bounds = maxBounds.get();
            int minY = bounds.method_49618() + padding.method_49618();
            int maxY = Math.max(bounds.method_49618() + padding.method_49618(), bounds.method_49619() - padding.method_49619() - composed.method_25364());
            clampedY = Math.clamp(clampedY, minY, maxY);
        }
        composed.method_46419(clampedY);
    }

    @Override
    public void method_48229(int x, int y) {
        method_46421(x);
        method_46419(y);
    }

    @Override
    public int method_46426() {
        return composed.method_46426() - padding.method_49620();
    }

    @Override
    public int method_46427() {
        return composed.method_46427() - padding.method_49618();
    }

    @Override
    public int method_25368() {
        return composed.method_25368() + padding.method_49620() + padding.method_49621();
    }

    @Override
    public int method_25364() {
        return composed.method_25364() + padding.method_49618() + padding.method_49619();
    }

    @Override
    public class_8030 method_48202() {
        return ScreenRectangleUtils.expand(composed.method_48202(), padding);
    }

    @Override
    public void method_48222() {
        composed.method_48222();

        if (alignmentBounds != null) {
            class_8030 area = alignmentBounds.get();
            class_8030 inset = new class_8030(
                    area.method_49620() + padding.method_49620(),
                    area.method_49618() + padding.method_49618(),
                    area.comp_1196() - padding.method_49620() - padding.method_49621(),
                    area.comp_1197() - padding.method_49618() - padding.method_49619()
            );
            class_7843.method_49617(composed, inset, alignX, alignY);
        } else {
            composed.method_48229(method_46426() + padding.method_49620(), method_46427() + padding.method_49618());
        }

        if (maxBounds != null) {
            class_8030 bounds = maxBounds.get();
            fidgetz$setSize(Math.clamp(method_25368(), 0, bounds.comp_1196()), Math.clamp(method_25364(), 0, bounds.comp_1197()));
            method_48229(composed.method_46426() - padding.method_49620(), composed.method_46427() - padding.method_49618());
        }
    }

    public static final class Contained {
        private final Supplier<class_8030> screenArea;
        private final FZComposedLayout composed;

        private Contained(Supplier<class_8030> screenArea, class_8133 base) {
            this.composed = new FZComposedLayout(base);
            this.screenArea = screenArea;
        }

        public Contained padding(int padding) {
            composed.padding(padding);
            return this;
        }

        public Contained padding(int left, int top, int right, int bottom) {
            composed.padding(left, top, right, bottom);
            return this;
        }

        public Contained align(float x, float y) {
            composed.align(screenArea, x, y);
            return this;
        }

        public Contained center() {
            return align(0.5f, 0.5f);
        }

        public Contained clamp() {
            composed.clamp(screenArea);
            return this;
        }

        public Contained arrange() {
            composed.method_48222();
            return this;
        }

        public Contained scrollable() {
            composed.scrollable(screenArea);
            return this;
        }

        public Contained scrollable(Consumer<FZScrollableLayout> configurator) {
            composed.scrollable(screenArea, configurator);
            return this;
        }

        public Contained visitWidgets(Consumer<class_339> widgetVisitor) {
            composed.method_48206(widgetVisitor);
            return this;
        }

        public Contained nest() {
            return new Contained(screenArea, composed.nest());
        }

        public FZComposedLayout get() {
            return composed;
        }
    }
}