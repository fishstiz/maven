@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package io.github.fishstiz.fidgetz.v0.gui.components.events;
