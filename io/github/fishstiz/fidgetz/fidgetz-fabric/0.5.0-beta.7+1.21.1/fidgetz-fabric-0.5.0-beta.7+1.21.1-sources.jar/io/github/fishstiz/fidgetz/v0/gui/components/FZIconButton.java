package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.utils.Undefinable;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_8666;

public final class FZIconButton extends FZButtonBase {
    private @Nullable WidgetRenderables background;
    private @Nullable WidgetElements icon;

    private FZIconButton() {
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float a) {
        if (background != null) {
            background.get(method_37303(), method_25367())
                    .extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, a);
        }
        if (icon != null) {
            int x = (method_46426() + method_25368() / 2 - icon.width() / 2) + icon.margin().method_49620() - icon.margin().method_49621();
            int y = (method_46427() + method_25364() / 2 - icon.height() / 2) + icon.margin().method_49618() - icon.margin().method_49619();
            icon.elements()
                    .get(method_37303(), method_25367())
                    .extractRenderState(graphics, x, y, icon.width(), icon.height(), mouseX, mouseY, a);
        }

        extractOverlay(graphics, mouseX, mouseY, a);
    }

    private void applyProps(io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props props) {
        super.applyProps(props);
        props.background().ifDefined(background -> this.background = background);
        props.icon().ifDefined(icon -> this.icon = icon);
    }

    public static FZIconButton bind(String key, FZRef<io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props> ref) {
        io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props props = ref.value();
        FZIconButton button = new FZIconButton();
        button.applyProps(props);
        ref.subscribe(key, button::applyProps);
        return button;
    }

    public static Builder builder() {
        return new Builder(DEFAULT_RENDERABLES);
    }

    public static Builder builder(WidgetRenderables renderables) {
        return new Builder(renderables);
    }

    public static Builder builder(RenderableRectangle renderable) {
        return new Builder(new WidgetRenderables(renderable));
    }

    public static Builder builder(class_8666 sprites) {
        return new Builder(WidgetRenderables.sprites(sprites));
    }

    public static Builder builder(class_2960 sprite) {
        return new Builder(new WidgetRenderables(Renderables.sprite(sprite)));
    }

    public interface Props extends FZButtonBase.Props {
        default Undefinable<@Nullable WidgetRenderables> background() {
            return Undefinable.undefined();
        }

        default Undefinable<@Nullable WidgetElements> icon() {
            return Undefinable.undefined();
        }
    }

    private static final class PropsImpl extends FZButtonBase.PropsImpl implements io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props {
        private final Undefinable<@Nullable WidgetRenderables> background;
        private final Undefinable<@Nullable WidgetElements> icon;

        PropsImpl(
                Undefinable<@Nullable WidgetRenderables> background,
                Undefinable<@Nullable WidgetElements> icon,
                @Nullable FZKeyed<Consumer<PressEvent>> pressHandler,
                GuiComponentProps props
        ) {
            super(pressHandler, props);
            this.background = background;
            this.icon = icon;
        }

        @Override
        public Undefinable<@Nullable WidgetRenderables> background() {
            return background;
        }

        @Override
        public Undefinable<@Nullable WidgetElements> icon() {
            return icon;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(other.background(), this.background) &&
                   Objects.equals(other.icon(), this.icon);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), background, icon);
        }
    }

    public static final class Builder extends AbstractBuilder<Builder, FZIconButton, io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props> {
        private Undefinable<@Nullable WidgetRenderables> background;
        private Undefinable<@Nullable WidgetElements> icon = Undefinable.undefined();

        Builder(WidgetRenderables background) {
            this.background = Undefinable.of(background);
        }

        public Builder defaultBackground() {
            this.background = Undefinable.of(DEFAULT_RENDERABLES);
            return this;
        }

        public Builder background(@Nullable WidgetRenderables background) {
            this.background = Undefinable.of(background);
            return this;
        }

        public Builder icon(@Nullable WidgetElements icon) {
            this.icon = Undefinable.of(icon);
            return this;
        }

        @Override
        public io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.Props toProps() {
            return new io.github.fishstiz.fidgetz.v0.gui.components.FZIconButton.PropsImpl(background, icon, pressHandler, props);
        }

        @Override
        public FZIconButton build() {
            FZIconButton button = new FZIconButton();
            button.applyProps(toProps());
            return button;
        }
    }
}
