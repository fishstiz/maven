package io.github.fishstiz.fidgetz.v0.gui.layouts;

import io.github.fishstiz.fidgetz.v0.utils.IntIntBiConsumer;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import io.github.fishstiz.fidgetz.v0.utils.TriState;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_7838;
import net.minecraft.class_7847;
import net.minecraft.class_8021;
import net.minecraft.class_8027;
import net.minecraft.class_8029;
import net.minecraft.class_8030;

public final class FZFlexLayout extends class_7838 implements FZLayout {
    private final Supplier<class_8030> screenArea;
    private final Settings defaultChildSettings = Settings.method_46481();
    private final List<ChildContainer> children = new ArrayList<>();
    private final class_8027 axis;
    private int maxWidth;
    private int maxHeight;
    private int mainSpacing;
    private int lineSpacing;
    private Justification mainJustification = Justification.START;
    private Justification crossJustification = Justification.START;
    private boolean wrap;
    private boolean visible = true;

    FZFlexLayout(Supplier<class_8030> screenArea, class_8027 axis) {
        super(0, 0, screenArea.get().comp_1196(), screenArea.get().comp_1197());
        this.screenArea = screenArea;
        this.axis = axis;
    }

    static FZFlexLayout auto(class_8027 axis) {
        return new FZFlexLayout(class_8030::method_48248, axis);
    }

    public static FZFlexLayout horizontal(class_437 screen) {
        return new FZFlexLayout(screen::method_48202, class_8027.field_41822);
    }

    public static FZFlexLayout horizontal(class_8021 container) {
        return new FZFlexLayout(container::method_48202, class_8027.field_41822);
    }

    public static FZFlexLayout horizontal() {
        return auto(class_8027.field_41822);
    }

    public static FZFlexLayout vertical(class_437 screen) {
        return new FZFlexLayout(screen::method_48202, class_8027.field_41823);
    }

    public static FZFlexLayout vertical(class_8021 container) {
        return new FZFlexLayout(container::method_48202, class_8027.field_41823);
    }

    public static FZFlexLayout vertical() {
        return auto(class_8027.field_41823);
    }

    private static <T> T getAxisValue(class_8027 axis, T horizontalValue, T verticalValue) {
        return switch (axis) {
            case field_41822 -> horizontalValue;
            case field_41823 -> verticalValue;
        };
    }

    public FZFlexLayout maxWidth(int maxWidth) {
        this.maxWidth = MathUtils.optionalMin(maxWidth, screenArea.get().comp_1196());
        return this;
    }

    public FZFlexLayout maxHeight(int maxHeight) {
        this.maxHeight = MathUtils.optionalMin(maxHeight, screenArea.get().comp_1197());
        return this;
    }

    public FZFlexLayout maxSize(int maxWidth, int maxHeight) {
        return maxWidth(maxWidth).maxHeight(maxHeight);
    }

    public FZFlexLayout alignContents(Justification justification) {
        this.crossJustification = justification;
        return this;
    }

    public FZFlexLayout justifyContents(Justification justification) {
        this.mainJustification = justification;
        return this;
    }

    public FZFlexLayout spacing(int spacing) {
        this.mainSpacing = spacing;
        this.lineSpacing = spacing;
        return this;
    }

    public FZFlexLayout verticalSpacing(int spacing) {
        switch (axis) {
            case field_41822 -> this.lineSpacing = spacing;
            case field_41823 -> this.mainSpacing = spacing;
        }
        return this;
    }

    public FZFlexLayout horizontalSpacing(int spacing) {
        switch (axis) {
            case field_41822 -> this.mainSpacing = spacing;
            case field_41823 -> this.lineSpacing = spacing;
        }
        return this;
    }

    public FZFlexLayout wrap(boolean wrap) {
        this.wrap = wrap;
        return this;
    }

    public FZFlexLayout wrap() {
        return this.wrap(true);
    }

    public FZFlexLayout visible(boolean visible) {
        this.visible = visible;
        return this;
    }

    public FZFlexLayout visible() {
        return visible(true);
    }

    public FZFlexLayout invisible() {
        return visible(false);
    }

    @Override
    public boolean fidgetz$isVisible() {
        return visible;
    }

    @Override
    public void fidgetz$setWidth(int width) {
        int previousMaxWidth = this.maxWidth;
        maxWidth(width);
        if (previousMaxWidth != maxWidth) {
            method_48222();
        }
    }

    @Override
    public void fidgetz$setHeight(int height) {
        int previousMaxHeight = this.maxHeight;
        maxHeight(height);
        if (previousMaxHeight != maxHeight) {
            method_48222();
        }
    }

    @Override
    public void fidgetz$setSize(int width, int height) {
        int previousMaxWidth = this.maxWidth;
        int previousMaxHeight = this.maxHeight;
        maxSize(width, height);
        if (previousMaxWidth != maxWidth || previousMaxHeight != maxHeight) {
            method_48222();
        }
    }

    public class_8027 mainAxis() {
        return axis;
    }

    private boolean canWrap() {
        return wrap && getMaxLength(axis) > 0;
    }

    private int getPosition(class_8027 axis) {
        return switch (axis) {
            case field_41822 -> method_46426();
            case field_41823 -> method_46427();
        };
    }

    private int getMaxLength(class_8027 axis) {
        return switch (axis) {
            case field_41822 -> MathUtils.eitherOptionalMin(maxWidth, screenArea.get().comp_1196());
            case field_41823 -> MathUtils.eitherOptionalMin(maxHeight, screenArea.get().comp_1197());
        };
    }

    public FZFlexLayout also(Consumer<FZFlexLayout> configurator) {
        configurator.accept(this);
        return this;
    }

    public <T extends class_8021> T child(T child, class_7847 layoutSettings) {
        children.add(new ChildContainer(child, layoutSettings));
        return child;
    }

    public <T extends class_8021> T child(T child) {
        return child(child, defaultChildSettings.layoutSettings);
    }

    public <T extends class_339> T child(T child, Settings settings) {
        children.add(new FlexChildContainer(child, settings));
        return child;
    }

    public <T extends class_339> T child(T child, class_7847 layoutSettings) {
        return child(child, defaultChildSettings.copyWithLayoutSettings(layoutSettings));
    }

    public <T extends class_339> T child(T child) {
        return child(child, defaultChildSettings);
    }

    public <T extends FZFlexElement> T child(T child, Settings settings) {
        children.add(new FlexChildContainer(child, settings));
        return child;
    }

    public <T extends FZFlexElement> T child(T child, class_7847 layoutSettings) {
        return child(child, defaultChildSettings.copyWithLayoutSettings(layoutSettings));
    }

    public <T extends FZFlexElement> T child(T child) {
        return child(child, defaultChildSettings);
    }

    public FZFlexSpacerElement spacer(Settings settings) {
        FZFlexSpacerElement spacer = new FZFlexSpacerElement();
        children.add(new FlexChildContainer(spacer, settings));
        return spacer;
    }

    public FZFlexSpacerElement spacer() {
        return spacer(defaultChildSettings);
    }

    public void clear() {
        children.clear();
    }

    public Settings newChildSettings() {
        return defaultChildSettings.method_46478();
    }

    public Settings defaultChildSettings() {
        return defaultChildSettings;
    }

    public Settings flexChildMainSettings() {
        return newChildSettings().flexMain();
    }

    public Settings flexChildCrossSettings() {
        return newChildSettings().flexCross();
    }

    public Settings flexChildSettings() {
        return newChildSettings().flexBoth();
    }

    public Settings flexChildVerticalSettings() {
        return switch (axis) {
            case field_41822 -> flexChildCrossSettings();
            case field_41823 -> flexChildMainSettings();
        };
    }

    public Settings flexChildHorizontalSettings() {
        return switch (axis) {
            case field_41822 -> flexChildMainSettings();
            case field_41823 -> flexChildCrossSettings();
        };
    }

    private int[] distributeMainAxisFlexLengths(List<ChildContainer> flexChildren, int availableSpace) {
        List<ChildContainer> remaining = new ArrayList<>(flexChildren);
        int[] lengths = new int[flexChildren.size()];

        while (!remaining.isEmpty()) {
            int flexLength = Math.max(0, availableSpace / remaining.size());
            int remainder = availableSpace % remaining.size();
            List<ChildContainer> nextRemaining = new ArrayList<>();
            boolean anyFrozen = false;

            for (int i = 0; i < remaining.size(); i++) {
                ChildContainer container = remaining.get(i);
                int idx = flexChildren.indexOf(container);
                int minFlexMain = container.getMinLength(axis);
                int maxFlexMain = container.getMaxLength(axis);
                int clampedLength = MathUtils.clampOptionalMax(flexLength + (i < remainder ? 1 : 0), minFlexMain, maxFlexMain);
                if (clampedLength != flexLength && clampedLength == minFlexMain) {
                    lengths[idx] = clampedLength;
                    availableSpace -= clampedLength;
                    anyFrozen = true;
                } else if (maxFlexMain > 0 && clampedLength == maxFlexMain) {
                    lengths[idx] = clampedLength;
                    availableSpace -= clampedLength;
                    anyFrozen = true;
                } else {
                    nextRemaining.add(container);
                }
            }

            if (!anyFrozen) {
                for (int i = 0; i < remaining.size(); i++) {
                    ChildContainer container = remaining.get(i);
                    int idx = flexChildren.indexOf(container);
                    int minFlexMain = container.getMinLength(axis);
                    int maxFlexMain = container.getMaxLength(axis);
                    lengths[idx] = MathUtils.clampOptionalMax(flexLength + (i < remainder ? 1 : 0), minFlexMain, maxFlexMain);
                }
                break;
            }
            remaining = nextRemaining;
        }

        return lengths;
    }

    private int applyFlexLengths(List<ChildContainer> flexMainChildren, int[] lengths, int crossLength) {
        class_8027 crossAxis = axis.method_48232();
        int occupied = 0;

        for (int i = 0; i < flexMainChildren.size(); i++) {
            ChildContainer container = flexMainChildren.get(i);
            if (container.flexCross()) {
                int minFlexCross = container.getMinLength(crossAxis);
                int maxFlexCross = container.getMaxLength(crossAxis);
                container.setSize(axis, lengths[i], MathUtils.clampOptionalMax(crossLength, minFlexCross, maxFlexCross));
            } else {
                container.setLength(axis, lengths[i]);
            }
            occupied += container.getLength(axis);
        }

        return occupied;
    }

    @Override
    public int method_25368() {
        return MathUtils.optionalMin(super.method_25368(), this.maxWidth);
    }

    @Override
    public int method_25364() {
        return MathUtils.optionalMin(super.method_25364(), this.maxHeight);
    }

    private void arrangeLinear() {
        super.method_48222();

        final class_8027 crossAxis = axis.method_48232();
        final int maxMain = getMaxLength(axis);
        final int maxCross = getMaxLength(crossAxis);

        List<ChildContainer> flexMain = new ArrayList<>();
        List<ChildContainer> flexCrossOnly = new ArrayList<>();
        int occupiedMain = 0;
        int occupiedCross = maxCross;
        int visibleCount = 0;

        for (ChildContainer container : children) {
            if (!container.visible()) continue;

            if (container.flexMain()) {
                flexMain.add(container);
            } else {
                occupiedMain += container.getLength(axis);
                if (container.flexCross()) {
                    flexCrossOnly.add(container);
                }
            }

            visibleCount++;
            int crossLength = container.getLength(crossAxis);
            if (container.flexCross()) {
                int minFlexCross = container.getMinLength(crossAxis);
                int maxFlexCross = container.getMaxLength(crossAxis);
                crossLength = MathUtils.clampOptionalMax(crossLength, minFlexCross, maxFlexCross);
            }
            occupiedCross = MathUtils.clampOptionalMax(crossLength, occupiedCross, maxCross);
        }

        int totalSpacing = mainSpacing * Math.max(0, visibleCount - 1);

        if (!flexMain.isEmpty()) {
            int availableSpace = maxMain - occupiedMain - totalSpacing;
            int[] lengths = distributeMainAxisFlexLengths(flexMain, availableSpace);
            occupiedMain += applyFlexLengths(flexMain, lengths, occupiedCross);
        }

        occupiedMain += totalSpacing;

        for (ChildContainer container : flexCrossOnly) {
            int minFlexCross = container.getMinLength(crossAxis);
            int maxFlexCross = container.getMaxLength(crossAxis);
            container.setLength(crossAxis, MathUtils.clampOptionalMax(occupiedCross, minFlexCross, maxFlexCross));
        }

        int mainResult = maxMain == 0 ? Math.max(0, occupiedMain) : maxMain;
        int crossResult = maxCross == 0 ? Math.max(0, occupiedCross) : maxCross;

        Justification.Results justified = mainJustification.compute(
                getPosition(axis),
                mainSpacing,
                visibleCount,
                Math.max(0, maxMain - occupiedMain)
        );

        int mainPos = justified.pos();
        int crossPos = getPosition(crossAxis);

        for (int i = 0; i < children.size(); i++) {
            ChildContainer container = children.get(i);
            if (container.visible()) {
                container.setPosition(axis, mainPos, mainResult);
                container.setPosition(crossAxis, crossPos, crossResult);
                mainPos = container.getPosition(axis) + container.getLength(axis) + justified.adjustSpacing(i);
            }
        }

        class_8029 resultSize = class_8029.method_48246(axis, mainResult, crossResult);
        this.field_41813 = resultSize.comp_1193();
        this.field_41814 = resultSize.comp_1194();
    }

    private void arrangeWrapped() {
        super.method_48222();

        final class_8027 crossAxis = axis.method_48232();
        final int maxMain = getMaxLength(axis);
        final int maxCross = getMaxLength(crossAxis);

        if (maxMain <= 0) {
            throw new RuntimeException("cannot arrange wrap if max main is <= 0");
        }

        List<List<ChildContainer>> lines = new ArrayList<>();
        List<ChildContainer> currentLine = new ArrayList<>();
        IntArrayList lineCrossSizes = new IntArrayList();
        int currentLineMain = 0;
        int currentLineCount = 0;
        int currentLineCross = 0;
        int totalCross = 0;

        for (ChildContainer container : children) {
            if (!container.visible()) continue;

            int basisSize = container.flexMain() ? container.getMinLength(axis) : container.getLength(axis);
            if (currentLineCount > 0 && (currentLineMain + mainSpacing + basisSize > maxMain)) {
                lines.add(currentLine);
                lineCrossSizes.add(currentLineCross);
                totalCross += currentLineCross;
                currentLine = new ArrayList<>();
                currentLineMain = 0;
                currentLineCross = 0;
                currentLineCount = 0;
            }

            currentLine.add(container);
            currentLineMain += (currentLineCount > 0 ? mainSpacing : 0) + basisSize;
            currentLineCross = Math.max(currentLineCross, container.getLength(crossAxis));
            currentLineCount++;
        }

        if (!currentLine.isEmpty()) {
            lines.add(currentLine);
            lineCrossSizes.add(currentLineCross);
            totalCross += currentLineCross;
        }

        int totalLineSpacing = lineSpacing * Math.max(0, lines.size() - 1);
        totalCross += totalLineSpacing;

        Justification.Results crossJustified = crossJustification.compute(
                getPosition(crossAxis),
                lineSpacing,
                lines.size(),
                Math.max(0, maxCross - totalCross)
        );

        int crossPos = crossJustified.pos();
        int maxOccupiedMain = 0;

        int equalLineCross = 0;
        if (crossJustification == Justification.STRETCH && totalCross < maxCross) {
            equalLineCross = (maxCross - totalLineSpacing) / lines.size();
        }

        for (int li = 0; li < lines.size(); li++) {
            List<ChildContainer> line = lines.get(li);
            int lineCross = equalLineCross > 0 ? equalLineCross : lineCrossSizes.getInt(li);

            List<ChildContainer> lineFlexMain = new ArrayList<>();
            List<ChildContainer> lineFlexCrossOnly = new ArrayList<>();
            int occupiedMain = 0;
            int visibleCount = line.size();

            for (ChildContainer container : line) {
                if (container.flexMain()) {
                    lineFlexMain.add(container);
                } else {
                    occupiedMain += container.getLength(axis);
                    if (container.flexCross()) lineFlexCrossOnly.add(container);
                }
            }

            int totalSpacing = mainSpacing * Math.max(0, visibleCount - 1);
            if (!lineFlexMain.isEmpty()) {
                int availableSpace = maxMain - occupiedMain - totalSpacing;
                int[] lengths = distributeMainAxisFlexLengths(lineFlexMain, availableSpace);
                occupiedMain += applyFlexLengths(lineFlexMain, lengths, lineCross);
            }

            for (ChildContainer container : lineFlexCrossOnly) {
                container.setLength(crossAxis, lineCross);
            }

            occupiedMain += totalSpacing;
            maxOccupiedMain = Math.max(maxOccupiedMain, occupiedMain);

            Justification.Results mainJustified = mainJustification.compute(
                    getPosition(axis),
                    mainSpacing,
                    visibleCount,
                    Math.max(0, maxMain - occupiedMain)
            );

            int mainPos = mainJustified.pos();

            for (int i = 0; i < line.size(); i++) {
                ChildContainer container = line.get(i);
                if (container.visible()) {
                    container.setPosition(axis, mainPos, container.getLength(axis));
                    container.setPosition(crossAxis, crossPos, lineCross);
                    mainPos += container.getLength(axis) + mainJustified.adjustSpacing(i);
                }
            }

            crossPos += lineCross + crossJustified.adjustSpacing(li);
        }

        int crossResult = Math.max(0, Math.max(totalCross, maxCross));
        class_8029 resultSize = class_8029.method_48246(axis, maxMain, crossResult);
        this.field_41813 = resultSize.comp_1193();
        this.field_41814 = resultSize.comp_1194();
    }

    @Override
    public void method_48222() {
        if (canWrap()) {
            arrangeWrapped();
        } else {
            arrangeLinear();
        }
    }

    @Override
    public void method_48227(Consumer<class_8021> layoutElementVisitor) {
        children.forEach(container -> layoutElementVisitor.accept(container.field_40752));
    }

    public static class Settings implements class_7847 {
        private final class_7847 layoutSettings;
        private boolean flexMain;
        private boolean flexCross;
        private int minWidth;
        private int minHeight;
        private int maxWidth;
        private int maxHeight;
        private TriState visible = TriState.DEFAULT;

        Settings(class_7847 layoutSettings) {
            this.layoutSettings = layoutSettings;
        }

        public static Settings method_46481() {
            return new Settings(class_7847.method_46481());
        }

        public Settings flexMain(boolean flexMain) {
            this.flexMain = flexMain;
            return this;
        }

        public Settings flexCross(boolean flexCross) {
            this.flexCross = flexCross;
            return this;
        }

        public Settings flexMain() {
            return flexMain(true);
        }

        public Settings flexCross() {
            return flexCross(true);
        }

        public Settings flexBoth() {
            return flexMain().flexCross();
        }

        public Settings flexMainOnly() {
            return flexMain().flexCross(false);
        }

        public Settings flexCrossOnly() {
            return flexCross().flexMain(false);
        }

        public Settings unflex() {
            return flexMain(false).flexCross(false);
        }

        public Settings minFlexWidth(int minWidth) {
            this.minWidth = minWidth;
            return this;
        }

        public Settings minFlexHeight(int minHeight) {
            this.minHeight = minHeight;
            return this;
        }

        public Settings maxFlexWidth(int maxWidth) {
            this.maxWidth = maxWidth;
            return this;
        }

        public Settings maxFlexHeight(int maxHeight) {
            this.maxHeight = maxHeight;
            return this;
        }

        public Settings visible(boolean visible) {
            this.visible = TriState.from(visible);
            return this;
        }

        public Settings visible() {
            return visible(true);
        }

        public Settings invisible() {
            return visible(false);
        }

        public Settings defaultVisibility() {
            this.visible = TriState.DEFAULT;
            return this;
        }

        @Override
        public Settings method_46464(int padding) {
            layoutSettings.method_46464(padding);
            return this;
        }

        @Override
        public Settings method_46465(int horizontal, int vertical) {
            layoutSettings.method_46465(horizontal, vertical);
            return this;
        }

        @Override
        public Settings method_46466(int left, int top, int right, int bottom) {
            layoutSettings.method_46466(left, top, right, bottom);
            return this;
        }

        @Override
        public Settings method_46469(int padding) {
            layoutSettings.method_46469(padding);
            return this;
        }

        @Override
        public Settings method_46471(int padding) {
            layoutSettings.method_46471(padding);
            return this;
        }

        @Override
        public Settings method_46473(int padding) {
            layoutSettings.method_46473(padding);
            return this;
        }

        @Override
        public Settings method_46475(int padding) {
            layoutSettings.method_46475(padding);
            return this;
        }

        @Override
        public Settings method_46477(int padding) {
            layoutSettings.method_46477(padding);
            return this;
        }

        @Override
        public Settings method_46479(int padding) {
            layoutSettings.method_46479(padding);
            return this;
        }

        @Override
        public Settings method_46463(float xAlignment, float yAlignment) {
            layoutSettings.method_46463(xAlignment, yAlignment);
            return this;
        }

        @Override
        public Settings method_46462(float xAlignment) {
            layoutSettings.method_46462(xAlignment);
            return this;
        }

        @Override
        public Settings method_46468(float yAlignment) {
            layoutSettings.method_46468(yAlignment);
            return this;
        }

        @Override
        public Settings method_46461() {
            class_7847.super.method_46461();
            return this;
        }

        @Override
        public Settings method_46467() {
            class_7847.super.method_46467();
            return this;
        }

        @Override
        public Settings method_46470() {
            class_7847.super.method_46470();
            return this;
        }

        @Override
        public Settings method_46472() {
            class_7847.super.method_46472();
            return this;
        }

        @Override
        public Settings method_46474() {
            class_7847.super.method_46474();
            return this;
        }

        @Override
        public Settings method_46476() {
            class_7847.super.method_46476();
            return this;
        }

        @Override
        public Settings method_46478() {
            Settings copy = new Settings(layoutSettings.method_46478());
            copy.flexMain = flexMain;
            copy.flexCross = flexCross;
            return copy;
        }

        private Settings copyWithLayoutSettings(class_7847 layoutSettings) {
            Settings copy = new Settings(layoutSettings.method_46478());
            copy.flexMain = flexMain;
            copy.flexCross = flexCross;
            return copy;
        }

        @Override
        public class_7848 method_46480() {
            return layoutSettings.method_46480();
        }
    }

    private static class ChildContainer extends class_7839 {
        protected ChildContainer(class_8021 child, class_7847 layoutSettings) {
            super(child, layoutSettings);
        }

        boolean flexMain() {
            return false;
        }

        boolean flexCross() {
            return false;
        }

        boolean visible() {
            return true;
        }

        void setSize(class_8027 axis, int length, int otherLength) {
        }

        void setLength(class_8027 axis, int length) {
        }

        int getLength(class_8027 axis) {
            return switch (axis) {
                case field_41822 -> method_46424();
                case field_41823 -> method_46422();
            };
        }

        int getMaxLength(class_8027 axis) {
            return getLength(axis);
        }

        int getMinLength(class_8027 axis) {
            return getLength(axis);
        }

        void setPosition(class_8027 axis, int position, int availableSpace) {
            switch (axis) {
                case field_41822 -> method_46423(position, availableSpace);
                case field_41823 -> method_46425(position, availableSpace);
            }
        }

        int getPosition(class_8027 axis) {
            return switch (axis) {
                case field_41822 -> field_40752.method_46426();
                case field_41823 -> field_40752.method_46427();
            };
        }
    }

    private static final class FlexChildContainer extends ChildContainer {
        private final Settings flexSettings;
        private final BooleanSupplier visibilityGetter;
        private final IntIntBiConsumer sizeSetter;

        FlexChildContainer(class_8021 child, Settings flexSettings, BooleanSupplier visibilityGetter, IntIntBiConsumer sizeSetter) {
            super(child, flexSettings.layoutSettings);
            this.visibilityGetter = visibilityGetter;
            this.sizeSetter = sizeSetter;
            this.flexSettings = flexSettings;
        }

        FlexChildContainer(FZFlexElement child, Settings flexSettings) {
            this(child, flexSettings, child::fidgetz$isVisible, child::fidgetz$setSize);
        }

        FlexChildContainer(class_339 child, Settings flexSettings) {
            this(child, flexSettings, () -> child.field_22764, child::method_55445);
        }

        @Override
        boolean flexMain() {
            return flexSettings.flexMain;
        }

        @Override
        boolean flexCross() {
            return flexSettings.flexCross;
        }

        @Override
        boolean visible() {
            return flexSettings.visible.toBoolean(visibilityGetter.getAsBoolean());
        }

        @Override
        void setLength(class_8027 axis, int length) {
            switch (axis) {
                case field_41822 -> sizeSetter.accept(length, field_40752.method_25364());
                case field_41823 -> sizeSetter.accept(field_40752.method_25368(), length);
            }
        }

        @Override
        void setSize(class_8027 axis, int length, int otherLength) {
            class_8029 position = class_8029.method_48246(axis, length, otherLength);
            sizeSetter.accept(position.comp_1193(), position.comp_1194());
        }

        @Override
        int getMaxLength(class_8027 axis) {
            return getAxisValue(axis, flexSettings.maxWidth, flexSettings.maxHeight);
        }

        @Override
        int getMinLength(class_8027 axis) {
            return getAxisValue(axis, flexSettings.minWidth, flexSettings.minHeight);
        }
    }
}
