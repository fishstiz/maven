package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZKeyed;
import io.github.fishstiz.fidgetz.v0.utils.FunctionUtils;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_8030;
import net.minecraft.class_8666;

public class FZButtonBase extends class_4185 implements FZComponent, FZContextMenu.Source {
    protected static final WidgetRenderables DEFAULT_RENDERABLES = WidgetRenderables.sprites(new class_8666(
            class_2960.method_60656("widget/button"),
            class_2960.method_60656("widget/button_disabled"),
            class_2960.method_60656("widget/button_highlighted")
    ));
    protected static final class_4241 NOP = ignored -> {
    };
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private Consumer<PressEvent> pressHandler = FunctionUtils.nopConsumer();
    private class_8030 bounds;

    protected FZButtonBase(int width, int height, class_2561 message) {
        super(0, 0, width, height, message, NOP, field_40754);
        bounds = new class_8030(0, 0, width, height);
    }

    protected FZButtonBase(int width, int height) {
        this(width, height, class_5244.field_39003);
    }

    protected FZButtonBase() {
        this(field_39500, field_39501, class_5244.field_39003);
    }

    @Override
    public void method_25306() {
        super.method_25306();
        pressHandler.accept(new PressEvent(this));
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(graphics, mouseX, mouseY, partialTick);
        extractOverlay(graphics, mouseX, mouseY, partialTick);
    }

    protected void extractOverlay(class_332 graphics, int mouseX, int mouseY, float a) {
        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, a);
        }
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            bounds = super.method_48202();
        }
        return bounds;
    }

    protected void applyProps(Props props) {
        propsState.apply(this, props);
        props.pressHandler().ifPresent(handler -> this.pressHandler = handler.value());
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    @Override
    public boolean fidgetz$shouldTakeFocusAfterInteraction() {
        return propsState.focusOnInteraction;
    }

    public record PressEvent(FZButtonBase target) {
    }

    public interface Props extends GuiComponentProps {
        default Optional<FZKeyed<Consumer<PressEvent>>> pressHandler() {
            return Optional.empty();
        }
    }

    abstract static class PropsImpl extends GuiComponentPropsBase implements Props {
        private final @Nullable FZKeyed<Consumer<PressEvent>> pressHandler;

        PropsImpl(@Nullable FZKeyed<Consumer<PressEvent>> pressHandler, GuiComponentProps props) {
            super(props);
            this.pressHandler = pressHandler;
        }

        @Override
        public Optional<FZKeyed<Consumer<PressEvent>>> pressHandler() {
            return Optional.ofNullable(pressHandler);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Props other)) return false;
            return super.equals(o) &&
                   Objects.equals(pressHandler(), other.pressHandler());
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), pressHandler);
        }
    }

    public static abstract class AbstractBuilder<T, B extends FZButtonBase, P extends Props> extends GuiComponentPropsBuilder<T> {
        protected @Nullable FZKeyed<Consumer<PressEvent>> pressHandler;

        protected AbstractBuilder() {
        }

        public T bigWidth() {
            return width(field_49479);
        }

        public T smallWidth() {
            return width(field_39499);
        }

        public T square() {
            int size = field_39501;
            return size(size, size);
        }

        public T onPress(Consumer<PressEvent> pressHandler) {
            this.pressHandler = FZKeyed.selfKey(Objects.requireNonNull(pressHandler, "pressHandler cannot be null"));
            return self();
        }

        public T onPress(Runnable clickAction) {
            Objects.requireNonNull(clickAction, "clickAction cannot be null");
            this.pressHandler = FZKeyed.selfKey(ignored -> clickAction.run());
            return self();
        }

        public T onPress(Object key, Consumer<PressEvent> pressHandler) {
            this.pressHandler = new FZKeyed<>(key, Objects.requireNonNull(pressHandler, "pressHandler cannot be null"));
            return self();
        }

        public T onPress(Object key, Runnable clickAction) {
            Objects.requireNonNull(clickAction, "clickAction cannot be null");
            this.pressHandler = new FZKeyed<>(key, ignored -> clickAction.run());
            return self();
        }

        public abstract P toProps();

        public abstract B build();
    }
}
