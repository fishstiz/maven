package io.github.fishstiz.fidgetz.v0.gui.renderables;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4587;
import net.minecraft.class_8030;

@FunctionalInterface
public interface RenderableRectangle {
    void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick);

    default RenderableRectangle withBlend() {
        return ((graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            RenderSystem.enableBlend();
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            RenderSystem.disableBlend();
        });
    }

    default RenderableRectangle pose(Consumer<class_4587> transformer) {
        return ((graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            graphics.method_51448().method_22903();
            transformer.accept(graphics.method_51448());
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            graphics.method_51448().method_22909();
        });
    }

    default RenderableRectangle then(RenderableRectangle after) {
        return (graphics, left, top, width, height, mouseX, mouseY, partialTick) -> {
            extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
            after.extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
        };
    }

    default class_4068 toRenderable(class_8030 bounds) {
        int left = bounds.method_49620();
        int top = bounds.method_49618();
        int width = bounds.comp_1196();
        int height = bounds.comp_1197();
        return (graphics, mouseX, mouseY, partialTick) ->
                extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
    }

    default class_4068 toRenderable(Supplier<class_8030> boundsSupplier) {
        return (graphics, mouseX, mouseY, partialTick) -> {
            class_8030 bounds = boundsSupplier.get();
            extractRenderState(graphics, bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197(), mouseX, mouseY, partialTick);
        };
    }

    default class_4068 toPopover(class_8030 bounds) {
        return new Popover(toRenderable(bounds));
    }

    default class_4068 toPopover(class_8030 bounds, int order) {
        return new Popover(toRenderable(bounds), order);
    }

    default class_4068 toPopover(Supplier<class_8030> boundsSupplier) {
        return new Popover(toRenderable(boundsSupplier));
    }

    default class_4068 toPopover(Supplier<class_8030> boundsSupplier, int order) {
        return new Popover(toRenderable(boundsSupplier), order);
    }
}
