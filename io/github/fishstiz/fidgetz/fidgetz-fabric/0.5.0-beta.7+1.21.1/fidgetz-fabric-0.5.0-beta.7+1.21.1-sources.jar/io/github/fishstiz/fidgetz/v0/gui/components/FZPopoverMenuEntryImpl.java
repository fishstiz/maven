package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.Fidgetz;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_3675;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import net.minecraft.class_8012;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;
import net.minecraft.class_9110;

final class FZPopoverMenuEntryImpl implements FZPopoverMenuItem.Entry {
    private static final class_2561 CHEVRON_RIGHT = class_2561.method_43470(">");
    private static final int CHEVRON_RIGHT_WIDTH = class_310.method_1551().field_1772.method_27525(CHEVRON_RIGHT);
    private static final int DEFAULT_TEXT_COLOR = class_8012.field_42973;
    private static final int DEFAULT_INACTIVE_TEXT_COLOR = class_8012.field_45073;
    private static final int SPACING = 8;
    private final FZPopoverMenuItem.Context context;
    private final List<FZPopoverMenuItem> children;
    private final Supplier<@Nullable WidgetRenderables> backgroundSupplier;
    private final Supplier<@Nullable WidgetElements> iconSupplier;
    private final Supplier<@Nullable class_2561> messageSupplier;
    private final class_9110 tooltipHolder;
    private final BooleanSupplier activeSupplier;
    private final Function<FZPopoverMenuItem.Builder.PressEvent, @Nullable Boolean> pressHandler;
    private final boolean playClickSoundOnInteraction;
    private final int height;
    private final int minWidth;
    private int width;

    FZPopoverMenuEntryImpl(
            FZPopoverMenuItem.Context context,
            List<FZPopoverMenuItem> children,
            Supplier<@Nullable WidgetRenderables> backgroundSupplier,
            Supplier<@Nullable WidgetElements> iconSupplier,
            Supplier<@Nullable class_2561> messageSupplier,
            class_9110 tooltipHolder,
            BooleanSupplier activeSupplier,
            Function<FZPopoverMenuItem.Builder.PressEvent, Boolean> pressHandler,
            boolean playClickSoundOnInteraction,
            int height,
            int minWidth
    ) {
        this.context = context;
        this.children = children;
        this.backgroundSupplier = backgroundSupplier;
        this.iconSupplier = iconSupplier;
        this.messageSupplier = messageSupplier;
        this.tooltipHolder = tooltipHolder;
        this.activeSupplier = activeSupplier;
        this.pressHandler = pressHandler;
        this.playClickSoundOnInteraction = playClickSoundOnInteraction;
        this.height = height;
        this.minWidth = minWidth;
    }

    @Override
    public FZPopoverMenuItem.Context context() {
        return context;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_8030 bounds = context.getRectangle();
        final int left = bounds.method_49620();
        final int top = bounds.method_49618();
        final int width = bounds.comp_1196();
        final int height = bounds.comp_1197();

        WidgetRenderables background = backgroundSupplier.get();
        if (background != null) {
            background.get(context.isActive(), context.isFocusedOrHovered())
                    .extractRenderState(graphics, left, top, width, height, mouseX, mouseY, partialTick);
        }

        int x = left;

        WidgetElements icon = iconSupplier.get();
        if (icon != null) {
            x += SPACING + icon.margin().method_49620();
            int iconWidth = icon.width();
            int iconHeight = icon.height();
            int iconY = (top + SPACING + ((height - SPACING * 2) - iconHeight) / 2) + icon.margin().method_49618() - icon.margin().method_49619();

            icon.elements()
                    .get(context.isActive(), context.isFocusedOrHovered())
                    .extractRenderState(graphics, x, iconY, iconWidth, iconHeight, mouseX, mouseY, partialTick);
            x += iconWidth + icon.margin().method_49621();
        }

        int innerRight = left + width - SPACING;

        if (!children.isEmpty()) {
            int chevronX = (left + width) - CHEVRON_RIGHT_WIDTH - SPACING;
            innerRight = chevronX - SPACING;
            class_327 font = class_310.method_1551().field_1772;
            int chevronHeight = font.field_2000;
            int chevronColor = activeSupplier.getAsBoolean() ? DEFAULT_TEXT_COLOR : DEFAULT_INACTIVE_TEXT_COLOR;
            int chevronY = top + (height - chevronHeight) / 2;
            graphics.method_27535(font, CHEVRON_RIGHT, chevronX, chevronY + 1, chevronColor);
        }

        class_2561 text = messageSupplier.get();
        if (text != null) {
            x += SPACING;
            int textWidth = Math.max(0, innerRight - x);
            GuiGraphicsUtils.scrollingText(graphics, text, x, top + 1, x + textWidth, top + height + 1, activeSupplier.getAsBoolean()
                    ? DEFAULT_TEXT_COLOR
                    : DEFAULT_INACTIVE_TEXT_COLOR
            );
        }

        if (context.isHovered()) {
            tooltipHolder.method_56142(true, method_25370(), bounds);
        }
    }

    private void playClickSound() {
        if (playClickSoundOnInteraction) {
            class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (context.isActive() &&
            button == class_3675.field_32000 &&
            Boolean.TRUE.equals(pressHandler.apply(new FZPopoverMenuItem.Builder.PressEvent(context, this)))) {
            playClickSound();
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (context.isActive() &&
            (keyCode == class_3675.field_31957 || keyCode == class_3675.field_31980) &&
            Boolean.TRUE.equals(pressHandler.apply(new FZPopoverMenuItem.Builder.PressEvent(context, this)))) {
            playClickSound();
            return true;
        }
        return false;
    }

    @Override
    public List<FZPopoverMenuItem> childItems() {
        return children;
    }

    @Override
    public boolean method_37303() {
        return activeSupplier.getAsBoolean();
    }

    @Override
    public void method_37020(class_6382 output) {
        class_2561 message = messageSupplier.get();
        if (message != null) {
            output.method_37034(class_6381.field_33788, class_339.method_32602(message));
            if (method_37303()) {
                if (method_25370()) {
                    output.method_37034(class_6381.field_33791, class_2561.method_43471("narration.button.usage.focused"));
                } else if (context.isHovered()) {
                    output.method_37034(class_6381.field_33791, class_2561.method_43471("narration.button.usage.hovered"));
                }
            }
        }
        tooltipHolder.method_56139(output);
    }

    @Override
    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public int method_25368() {
        return Math.max(width, minWidth);
    }

    @Override
    public int method_25364() {
        return height;
    }

    record Divider(
            FZPopoverMenuItem.Context context,
            RenderableRectangle rectangle,
            int height
    ) implements FZPopoverMenuItem.Entry {
        static final int DEFAULT_HEIGHT = 4;
        static final FZPopoverMenuItem.Divider DEFAULT_SECTION = new FZPopoverMenuItem.Divider(
                ctx -> new Divider(ctx, Renderables.sprite(Fidgetz.id("widget/popovermenu_section_divider")).withBlend())
        );
        static final FZPopoverMenuItem.Divider DEFAULT_ENTRY = new FZPopoverMenuItem.Divider(
                ctx -> new Divider(ctx, Renderables.sprite(Fidgetz.id("widget/popovermenu_entry_divider")).withBlend())
        );

        Divider(FZPopoverMenuItem.Context context, RenderableRectangle rectangle) {
            this(context, rectangle, DEFAULT_HEIGHT);
        }

        @Override
        public int method_25368() {
            return context().getRectangle().comp_1196();
        }

        @Override
        public int method_25364() {
            return height;
        }

        @Override
        public boolean method_25370() {
            return false;
        }

        @Override
        public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
            return null;
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            class_8030 bounds = context.getRectangle();
            rectangle.extractRenderState(graphics, bounds.method_49620(), bounds.method_49618(), bounds.comp_1196(), bounds.comp_1197(), mouseX, mouseY, partialTick);
        }

        @Override
        public class_6380 method_37018() {
            return class_6380.field_33784;
        }
    }

    static final class TooltipHolder extends class_9110 {
        private final class_9110 delegate;
        private final @Nullable Supplier<@Nullable class_7919> tooltipSupplier;

        private TooltipHolder(class_9110 delegate, @Nullable Supplier<@Nullable class_7919> tooltipSupplier) {
            this.delegate = delegate;
            this.tooltipSupplier = tooltipSupplier;
        }

        TooltipHolder(class_9110 delegate) {
            this(delegate, null);
        }

        TooltipHolder(Supplier<@Nullable class_7919> tooltipSupplier) {
            this(new class_9110(), tooltipSupplier);
        }

        @Override
        public void method_56141(Duration delay) {
            delegate.method_56141(delay);
        }

        @Override
        public void method_56138(@Nullable class_7919 tooltip) {
            delegate.method_56138(tooltip);
        }

        @Override
        public @Nullable class_7919 method_56137() {
            return delegate.method_56137();
        }

        @Override
        public void method_56142(boolean hovering, boolean focused, class_8030 screenRectangle) {
            if (tooltipSupplier != null) delegate.method_56138(tooltipSupplier.get());
            delegate.method_56142(hovering, focused, screenRectangle);
        }

        @Override
        public void method_56139(class_6382 output) {
            delegate.method_56139(output);
        }
    }
}
