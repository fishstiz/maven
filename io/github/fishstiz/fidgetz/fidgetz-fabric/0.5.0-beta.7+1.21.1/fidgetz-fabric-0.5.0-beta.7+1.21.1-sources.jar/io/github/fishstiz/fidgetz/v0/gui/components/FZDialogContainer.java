package io.github.fishstiz.fidgetz.v0.gui.components;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_8030;

public interface FZDialogContainer extends class_4069, FZPopoverContainer {
    default List<? extends FZDialog> fidgetz$Dialogs() {
        return method_25396().stream().filter(FZDialog.class::isInstance).map(FZDialog.class::cast).toList();
    }

    default boolean fidgetz$captureEventForDialogs(int keyCode) {
        if (keyCode == class_3675.field_31958) {
            for (FZDialog dialog : fidgetz$Dialogs()) {
                if (dialog.isOpen() && dialog.shouldCloseOnEscape()) {
                    class_364 focused = this.method_25399();
                    dialog.setOpen(false);
                    if (focused == dialog) {
                        dialog.refocusLastContainerPath();
                    }
                    return true;
                }
            }
        }
        return false;
    }

    default boolean fidgetz$captureEventForDialogs(double mouseX, double mouseY, int button) {
        if (button == class_3675.field_32000) {
            for (FZDialog dialog : fidgetz$Dialogs()) {
                if (!dialog.isOpen()) continue;

                if (dialog.shouldCloseAfterClickOutOfBounds() && !dialog.areCoordinatesInBounds((int) mouseX, (int) mouseY)) {
                    dialog.setOpen(false);
                    return dialog.shouldCaptureClick();
                }

                if (dialog.method_25405(mouseX, mouseY)) {
                    return false;
                }
            }
        }
        return false;
    }

    @Override
    default void fidgetz$visitPopovers(Consumer<FZPopover> visitor) {
        fidgetz$Dialogs().forEach(visitor);
    }

    @Override
    class_8030 method_48202();
}
