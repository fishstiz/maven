package io.github.fishstiz.fidgetz.v0.gui.renderables;

import io.github.fishstiz.fidgetz.v0.utils.GuiGraphicsUtils;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_8012;

record TextRectangle(Supplier<class_2561> text) implements RenderableRectangle {
    @Override
    public void extractRenderState(class_332 graphics, int left, int top, int width, int height, int mouseX, int mouseY, float partialTick) {
        GuiGraphicsUtils.scrollingCenteredText(graphics, text.get(), left + (width / 2), left, left + width, top, top + height, class_8012.field_42973);
    }
}
