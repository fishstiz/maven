package io.github.fishstiz.fidgetz.v0.utils;

import net.minecraft.class_8021;
import net.minecraft.class_8030;

public final class ScreenRectangleUtils {
    public static boolean isAreaEmpty(int width, int height) {
        return width <= 0 || height <= 0;
    }

    public static boolean isAreaEmpty(class_8030 rectangle) {
        return isAreaEmpty(rectangle.comp_1196(), rectangle.comp_1197());
    }

    public static boolean unequal(class_8030 rectangle, int left, int top, int width, int height) {
        return left != rectangle.method_49620() ||
               top != rectangle.method_49618() ||
               width != rectangle.comp_1196() ||
               height != rectangle.comp_1197();
    }

    public static boolean unequal(class_8030 rectangle, class_8021 element) {
        return unequal(rectangle, element.method_46426(), element.method_46427(), element.method_25368(), element.method_25364());
    }

    public static boolean encompasses(class_8030 a, class_8030 b) {
        return b.method_49620() >= a.method_49620() && b.method_49618() >= a.method_49618() && b.method_49621() <= a.method_49621() && b.method_49619() <= a.method_49619();
    }

    public static boolean containsPoint(class_8030 rectangle, int x, int y) {
        return !isAreaEmpty(rectangle) && rectangle.method_58137(x, y);
    }

    public static boolean containsPoint(int left, int top, int width, int height, int x, int y) {
        return !isAreaEmpty(width, height) && x >= left && x < left + width && y >= top && y < top + height;
    }

    public static class_8030 union(class_8030 a, class_8030 b) {
        if (isAreaEmpty(a)) return b;
        if (isAreaEmpty(b)) return a;

        int left = Math.min(a.method_49620(), b.method_49620());
        int top = Math.min(a.method_49618(), b.method_49618());
        int right = Math.max(a.method_49621(), b.method_49621());
        int bottom = Math.max(a.method_49619(), b.method_49619());

        return new class_8030(left, top, right - left, bottom - top);
    }

    public static boolean isInsetsEmpty(class_8030 insets) {
        return insets.method_49620() <= 0 && insets.method_49618() <= 0 && insets.method_49621() <= 0 && insets.method_49619() <= 0;
    }

    public static class_8030 insets(int left, int top, int right, int bottom) {
        return new class_8030(left, top, right - left, bottom - top);
    }

    public static class_8030 insets(int margin) {
        return new class_8030(margin, margin, 0, 0);
    }

    public static class_8030 expand(class_8030 rectangle, class_8030 insets) {
        int left = rectangle.method_49620() - insets.method_49620();
        int top = rectangle.method_49618() - insets.method_49618();
        int right = rectangle.method_49621() + insets.method_49621();
        int bottom = rectangle.method_49619() + insets.method_49619();
        return new class_8030(left, top, right - left, bottom - top);
    }

    public static class_8030 shrink(class_8030 rectangle, class_8030 insets) {
        int left = rectangle.method_49620() + insets.method_49620();
        int top = rectangle.method_49618() + insets.method_49618();
        int width = rectangle.comp_1196() - (insets.method_49620() + insets.method_49621());
        int height = rectangle.comp_1197() - (insets.method_49618() + insets.method_49619());
        return new class_8030(left, top, width, height);
    }

    public static class_8030 withLeft(class_8030 rectangle, int left) {
        return new class_8030(left, rectangle.method_49618(), rectangle.comp_1196(), rectangle.comp_1197());
    }

    public static class_8030 withTop(class_8030 rectangle, int top) {
        return new class_8030(rectangle.method_49620(), top, rectangle.comp_1196(), rectangle.comp_1197());
    }

    public static class_8030 withWidth(class_8030 rectangle, int width) {
        return new class_8030(rectangle.method_49620(), rectangle.method_49618(), width, rectangle.comp_1197());
    }

    public static class_8030 withHeight(class_8030 rectangle, int height) {
        return new class_8030(rectangle.method_49620(), rectangle.method_49618(), rectangle.comp_1196(), height);
    }

    private ScreenRectangleUtils() {
    }
}
