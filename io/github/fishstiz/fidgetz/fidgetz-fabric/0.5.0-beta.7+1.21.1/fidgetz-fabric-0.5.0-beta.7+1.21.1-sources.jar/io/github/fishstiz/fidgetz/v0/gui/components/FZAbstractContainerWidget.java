package io.github.fishstiz.fidgetz.v0.gui.components;

import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import org.jetbrains.annotations.Nullable;

// backported from 26.1
public abstract class FZAbstractContainerWidget extends FZAbstractScrollArea implements ContainerEventHandlerPatch {
    private @Nullable class_364 focused;
    private boolean isDragging;

    public FZAbstractContainerWidget(int x, int y, int width, int height, class_2561 message, ScrollbarSettings scrollbarSettings) {
        super(x, y, width, height, message, scrollbarSettings);
    }

    public final boolean method_25397() {
        return this.isDragging;
    }

    public final void method_25398(boolean dragging) {
        this.isDragging = dragging;
    }

    public @Nullable class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (method_25399() != focused) {
            if (this.focused != null) {
                this.focused.method_25365(false);
            }

            if (focused != null) {
                focused.method_25365(true);
            }

            this.focused = focused;
        }
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return ContainerEventHandlerPatch.super.method_48205(navigationEvent);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean scrolling = this.updateScrolling(mouseX, mouseY, button);
        return ContainerEventHandlerPatch.super.method_25402(mouseX, mouseY, button) || scrolling;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        super.method_25406(mouseX, mouseY, button);
        return ContainerEventHandlerPatch.super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
        super.method_25403(mouseX, mouseY, button, dx, dy);
        return ContainerEventHandlerPatch.super.method_25403(mouseX, mouseY, button, dx, dy);
    }

    public boolean method_25370() {
        return ContainerEventHandlerPatch.super.method_25370();
    }

    public void method_25365(boolean focused) {
        ContainerEventHandlerPatch.super.method_25365(focused);
    }
}
