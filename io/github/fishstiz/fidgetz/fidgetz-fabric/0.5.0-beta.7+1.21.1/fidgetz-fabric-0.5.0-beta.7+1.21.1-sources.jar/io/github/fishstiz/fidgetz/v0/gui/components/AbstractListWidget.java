package io.github.fishstiz.fidgetz.v0.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.fishstiz.fidgetz.v0.gui.components.events.ScrollableContainer;
import io.github.fishstiz.fidgetz.v0.gui.renderables.RenderableRectangle;
import io.github.fishstiz.fidgetz.v0.gui.renderables.Renderables;
import io.github.fishstiz.fidgetz.v0.utils.MathUtils;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import org.jetbrains.annotations.Nullable;

abstract class AbstractListWidget extends FZAbstractContainerWidget implements ScrollableContainer {
    protected static final int DEFAULT_MAX_CONTENT_WIDTH = 270;
    protected static final int DEFAULT_SCROLL_RATE = 10;
    protected static final int SEPARATOR_HEIGHT = 2;
    private static final RenderableRectangle BACKGROUND = Renderables.texture(class_2960.method_60656("textures/gui/menu_list_background.png"), 32, 32);
    private static final RenderableRectangle INWORLD_BACKGROUND = Renderables.texture(class_2960.method_60656("textures/gui/inworld_menu_list_background.png"), 32, 32);
    private static final RenderableRectangle HEADER_SEPARATOR = Renderables.texture(class_437.field_49895, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_HEADER_SEPARATOR = Renderables.texture(class_437.field_49897, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle FOOTER_SEPARATOR = Renderables.texture(class_437.field_49896, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private static final RenderableRectangle INWORLD_FOOTER_SEPARATOR = Renderables.texture(class_437.field_49898, 32, SEPARATOR_HEIGHT, 32, SEPARATOR_HEIGHT);
    private final class_310 minecraft;

    protected AbstractListWidget(class_310 minecraft, int x, int y, int width, int height, class_2561 message, ScrollbarSettings scrollbarSettings) {
        super(x, y, width, height, message, scrollbarSettings);
        this.minecraft = minecraft;
    }

    protected AbstractListWidget(class_310 minecraft, int x, int y, int width, int height, class_2561 message) {
        this(minecraft, x, y, width, height, message, FZAbstractScrollArea.defaultSettings(DEFAULT_SCROLL_RATE));
    }

    protected AbstractListWidget(int x, int y, int width, int height, class_2561 message, ScrollbarSettings scrollbarSettings) {
        this(class_310.method_1551(), x, y, width, height, message, scrollbarSettings);
    }

    protected AbstractListWidget(int x, int y, int width, int height, class_2561 message) {
        this(class_310.method_1551(), x, y, width, height, message);
    }

    protected void extractBackgroundRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        RenderableRectangle background = minecraft.field_1687 == null ? BACKGROUND : INWORLD_BACKGROUND;
        RenderSystem.enableBlend();
        background.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, partialTick);
        RenderSystem.disableBlend();
    }

    protected void extractSeparatorsRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        RenderableRectangle header = minecraft.field_1687 == null ? HEADER_SEPARATOR : INWORLD_HEADER_SEPARATOR;
        RenderableRectangle footer = minecraft.field_1687 == null ? FOOTER_SEPARATOR : INWORLD_FOOTER_SEPARATOR;
        RenderSystem.enableBlend();
        header.extractRenderState(graphics, method_46426(), method_46427() - SEPARATOR_HEIGHT, method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
        footer.extractRenderState(graphics, method_46426(), method_55443(), method_25368(), SEPARATOR_HEIGHT, mouseX, mouseY, partialTick);
        RenderSystem.disableBlend();
    }

    protected abstract void extractEntriesRenderState(class_332 graphics, int mouseX, int mouseY, float partialTick);

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        extractBackgroundRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.method_44379(method_46426(), method_46427(), method_55442(), method_55443());
        extractEntriesRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.method_44380();
        extractSeparatorsRenderState(graphics, mouseX, mouseY, partialTick);
        extractScrollbar(graphics, mouseX, mouseY);
    }

    protected int contentPaddingLeft() {
        return 0;
    }

    protected int contentPaddingRight() {
        return 0;
    }

    protected int maxContentWidth() {
        return DEFAULT_MAX_CONTENT_WIDTH;
    }

    protected int contentWidth() {
        int contentWidth = method_25368() - scrollbarReserve() - contentPaddingLeft() - contentPaddingRight();
        return MathUtils.optionalMin(contentWidth, maxContentWidth());
    }

    @Override
    protected abstract int contentHeight();

    protected final int contentLeft() {
        return Math.min(
                method_46426() + (method_25368() / 2 - contentWidth() / 2) + contentPaddingLeft() - contentPaddingRight(),
                method_55442() - scrollbarReserve() - contentWidth()
        );
    }

    protected boolean scrollbarVisible() {
        return contentHeight() > method_25364();
    }

    protected boolean reserveScrollbarWidth() {
        return false;
    }

    protected int scrollbarReserve() {
        return reserveScrollbarWidth() || scrollbarVisible() ? scrollbarWidth() : 0;
    }

    @Override
    protected int scrollBarX() {
        return Math.min(contentLeft() + contentWidth() + contentPaddingRight(), method_55442() - scrollbarWidth());
    }

    @Override
    public double scrollRate() {
        return super.scrollRate();
    }

    @Override
    protected boolean isOverScrollbar(double x, double y) {
        return super.isOverScrollbar(x, y) && method_49606();
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            method_25395(null);
        }
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        if (method_25399() != focused) {
            super.method_25395(focused);
        }
    }

    @Override
    public @Nullable class_8016 method_48205(class_8023 navigationEvent) {
        return addScrollEffectOnFocus(navigationEvent, super.method_48205(navigationEvent));
    }

    @Override
    public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
        if (method_37303() && method_19355(mx, my).filter(child -> child.method_25401(mx, my, scrollX, scrollY)).isPresent()) {
            return true;
        }
        return super.method_25401(mx, my, scrollX, scrollY) && scrollable();
    }

    @Override
    protected void method_47399(class_6382 output) {
    }
}
