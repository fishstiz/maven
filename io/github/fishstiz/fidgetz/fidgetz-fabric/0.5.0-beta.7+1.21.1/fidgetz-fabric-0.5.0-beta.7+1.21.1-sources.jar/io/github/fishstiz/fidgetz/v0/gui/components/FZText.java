package io.github.fishstiz.fidgetz.v0.gui.components;

import io.github.fishstiz.fidgetz.v0.gui.state.FZRef;
import io.github.fishstiz.fidgetz.v0.utils.ScreenRectangleUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5244;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_7842;
import net.minecraft.class_8012;
import net.minecraft.class_8030;

public final class FZText extends class_7842 implements FZComponent, FZContextMenu.Source {
    private final GuiComponentPropsState propsState = new GuiComponentPropsState();
    private class_8030 bounds;

    FZText(class_2561 message) {
        super(message, class_310.method_1551().field_1772);
        method_48596();
        bounds = super.method_48202();
    }

    @Override
    public void fidgetz$updateContextEntries(double x, double y, FZContextMenu.Collector collector) {
        propsState.contextEntries.accept(collector);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float a) {
        super.method_48579(graphics, mouseX, mouseY, a);
        if (method_25370()) {
            graphics.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), class_8012.field_42973);
        }
        if (propsState.overlay != null) {
            propsState.overlay.extractRenderState(graphics, method_46426(), method_46427(), method_25368(), method_25364(), mouseX, mouseY, a);
        }
    }

    @Override
    public void method_25354(class_1144 soundManager) {
    }

    @Override
    protected void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, this.method_25369());
    }

    @Override
    public class_8030 method_48202() {
        if (ScreenRectangleUtils.unequal(bounds, this)) {
            bounds = super.method_48202();
        }
        return bounds;
    }

    @Override
    public @Nullable String fidgetz$componentId() {
        return propsState.id;
    }

    @Override
    public boolean fidgetz$shouldTakeFocusAfterInteraction() {
        return propsState.focusOnInteraction;
    }

    void applyProps(Props props) {
        propsState.apply(this, props);
    }

    public static FZText bind(String key, FZRef<Props> ref) {
        Props props = ref.value();
        FZText text = new FZText(props.message().orElse(class_5244.field_39003));
        text.applyProps(props);
        props.textAlignment().ifPresent(alignment -> alignment.apply(text));
        if (props.width().isEmpty()) {
            text.method_25358(text.method_48977().method_27525(text.method_25369()));
        }
        ref.subscribe(key, text::applyProps);
        return text;
    }

    public static Builder builder(class_2561 message) {
        return new Builder(message);
    }

    public enum Alignment {
        LEFT,
        CENTER,
        RIGHT;

        private void apply(FZText widget) {
            switch (this) {
                case LEFT -> widget.method_48596();
                case CENTER -> widget.method_48597();
                case RIGHT -> widget.method_48599();
            }
        }
    }

    public interface Props extends GuiComponentProps {
        default Optional<Alignment> textAlignment() {
            return Optional.empty();
        }
    }

    private static final class PropsImpl extends GuiComponentPropsBase implements Props {
        private final @Nullable Alignment textAlignment;

        private PropsImpl(GuiComponentProps props, @Nullable Alignment textAlignment) {
            super(props);
            this.textAlignment = textAlignment;
        }

        @Override
        public Optional<Alignment> textAlignment() {
            return Optional.ofNullable(textAlignment);
        }
    }

    public static final class Builder extends GuiComponentPropsBuilder<Builder> {
        private @Nullable Alignment textAlignment;

        private Builder(class_2561 message) {
            props.message = message;
        }

        public Builder align(Alignment alignment) {
            this.textAlignment = alignment;
            return this;
        }

        public Builder alignLeft() {
            return align(Alignment.LEFT);
        }

        public Builder alignCenter() {
            return align(Alignment.CENTER);
        }

        public Builder alignRight() {
            return align(Alignment.RIGHT);
        }

        public Props toProps() {
            return new PropsImpl(props, textAlignment);
        }

        public FZText build() {
            FZText text = new FZText(props.message().orElse(class_5244.field_39003));
            Props props = toProps();
            text.applyProps(props);
            if (props.width().isEmpty()) {
                text.method_25358(text.method_48977().method_27525(text.method_25369()));
            }
            return text;
        }
    }
}
