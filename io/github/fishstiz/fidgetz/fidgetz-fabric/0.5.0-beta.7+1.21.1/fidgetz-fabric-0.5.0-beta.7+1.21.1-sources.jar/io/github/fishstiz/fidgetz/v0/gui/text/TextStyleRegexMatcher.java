package io.github.fishstiz.fidgetz.v0.gui.text;

import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2583;

public final class TextStyleRegexMatcher implements TextStyleMatcher {
    private final @Nullable Predicate<String> styleable;
    private final Matcher matcher;
    private final class_2583 style;

    public TextStyleRegexMatcher(Matcher matcher, class_2583 style, @Nullable Predicate<String> styleable) {
        this.matcher = matcher;
        this.style = style;
        this.styleable = styleable;
    }

    public TextStyleRegexMatcher(Pattern pattern, class_2583 style, @Nullable Predicate<String> styleable) {
        this(pattern.matcher(""), style, styleable);
    }

    public TextStyleRegexMatcher(Pattern pattern, class_2583 style) {
        this(pattern, style, null);
    }

    @Override
    public boolean styleable(String input) {
        return styleable == null || styleable.test(input);
    }

    @Override
    public void reset(String input) {
        matcher.reset(input);
    }

    @Override
    public boolean find() {
        return matcher.find();
    }

    @Override
    public int start() {
        return matcher.start();
    }

    @Override
    public int end() {
        return matcher.end();
    }

    @Override
    public class_2583 style() {
        return matcher.hasMatch() ? style : class_2583.field_24360;
    }

    @Override
    public TextStyleMatcher copy() {
        return new TextStyleRegexMatcher(matcher.pattern(), style, styleable);
    }
}
