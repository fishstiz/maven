@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package io.github.fishstiz.fidgetz.v0.gui.screens;
