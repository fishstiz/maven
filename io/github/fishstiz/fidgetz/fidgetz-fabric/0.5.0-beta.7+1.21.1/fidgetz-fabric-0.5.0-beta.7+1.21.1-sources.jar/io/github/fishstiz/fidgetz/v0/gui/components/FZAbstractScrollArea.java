package io.github.fishstiz.fidgetz.v0.gui.components;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import org.jetbrains.annotations.Nullable;

// backported from 26.1
public abstract class FZAbstractScrollArea extends class_339 {
    public static final int SCROLLBAR_WIDTH = 6;
    private static final int SCROLLBAR_MIN_HEIGHT = 32;
    private static final class_2960 SCROLLER_SPRITE = class_2960.method_60656("widget/scroller");
    private static final class_2960 SCROLLER_BACKGROUND_SPRITE = class_2960.method_60656("widget/scroller_background");
    private final FZAbstractScrollArea.ScrollbarSettings scrollbarSettings;
    private double scrollAmount;
    private boolean scrolling;

    public FZAbstractScrollArea(int x, int y, int width, int height, class_2561 message, ScrollbarSettings scrollbarSettings) {
        super(x, y, width, height, message);
        this.scrollbarSettings = scrollbarSettings;
    }

    @Override
    public boolean method_25401(final double mx, final double my, final double scrollX, final double scrollY) {
        if (!this.field_22764) {
            return false;
        } else {
            this.setScrollAmount(this.scrollAmount() - scrollY * this.scrollRate());
            return true;
        }
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
        if (this.scrolling) {
            if (mouseY < this.method_46427()) {
                this.setScrollAmount(0.0);
            } else if (mouseY > this.method_55443()) {
                this.setScrollAmount(this.maxScrollAmount());
            } else {
                double max = Math.max(1, this.maxScrollAmount());
                int barHeight = this.scrollerHeight();
                double yDragScale = Math.max(1.0, max / (this.field_22759 - barHeight));
                this.setScrollAmount(this.scrollAmount() + dy * yDragScale);
            }

            return true;
        } else {
            return super.method_25403(mouseX, mouseY, button, dx, dy);
        }
    }

    public void method_25357(double mouseX, double mouseY) {
        this.scrolling = false;
    }

    public double scrollAmount() {
        return this.scrollAmount;
    }

    public void setScrollAmount(final double scrollAmount) {
        this.scrollAmount = class_3532.method_15350(scrollAmount, 0.0, this.maxScrollAmount());
    }

    public boolean updateScrolling(double mouseX, double mouseY, int button) {
        this.scrolling = this.scrollable() && this.method_25351(button) && this.isOverScrollbar(mouseX, mouseY);
        return this.scrolling;
    }

    protected boolean isOverScrollbar(final double x, final double y) {
        return x >= this.scrollBarX() && x <= this.scrollBarX() + this.scrollbarWidth() && y >= this.method_46427() && y < this.method_55443();
    }

    public void refreshScrollAmount() {
        this.setScrollAmount(this.scrollAmount);
    }

    public int maxScrollAmount() {
        return Math.max(0, this.contentHeight() - this.field_22759);
    }

    protected boolean scrollable() {
        return this.maxScrollAmount() > 0;
    }

    public int scrollbarWidth() {
        return this.scrollbarSettings.scrollbarWidth();
    }

    protected int scrollerHeight() {
        return class_3532.method_15340((int) ((float) (this.field_22759 * this.field_22759) / this.contentHeight()), 32, this.field_22759 - 8);
    }

    protected int scrollBarX() {
        return this.method_55442() - this.scrollbarWidth();
    }

    public int scrollBarY() {
        return this.maxScrollAmount() == 0
                ? this.method_46427()
                : Math.max(this.method_46427(), (int) this.scrollAmount * (this.field_22759 - this.scrollerHeight()) / this.maxScrollAmount() + this.method_46427());
    }

    protected void extractScrollbar(class_332 graphics, int mouseX, int mouseY) {
        int scrollbarX = this.scrollBarX();
        int scrollerHeight = this.scrollerHeight();
        int scrollerY = this.scrollBarY();
        if (!this.scrollable() && this.scrollbarSettings.disabledScrollerSprite() != null) {
            graphics.method_52706(this.scrollbarSettings.backgroundSprite(), scrollbarX, this.method_46427(), this.scrollbarWidth(), this.method_25364());
            graphics.method_52706(this.scrollbarSettings.disabledScrollerSprite(), scrollbarX, this.method_46427(), this.scrollbarWidth(), scrollerHeight);
        }

        if (this.scrollable()) {
            graphics.method_52706(this.scrollbarSettings.backgroundSprite(), scrollbarX, this.method_46427(), this.scrollbarWidth(), this.method_25364());
            graphics.method_52706(this.scrollbarSettings.scrollerSprite(), scrollbarX, scrollerY, this.scrollbarWidth(), scrollerHeight);
        }
    }

    protected abstract int contentHeight();

    protected double scrollRate() {
        return this.scrollbarSettings.scrollRate();
    }

    public static FZAbstractScrollArea.ScrollbarSettings defaultSettings(final int scrollRate) {
        return new FZAbstractScrollArea.ScrollbarSettings(SCROLLER_SPRITE, null, SCROLLER_BACKGROUND_SPRITE, SCROLLBAR_WIDTH, SCROLLBAR_MIN_HEIGHT, scrollRate, true);
    }

    public record ScrollbarSettings(
            class_2960 scrollerSprite,
            @Nullable class_2960 disabledScrollerSprite,
            class_2960 backgroundSprite,
            int scrollbarWidth,
            int scrollbarMinHeight,
            int scrollRate,
            boolean resizingScrollbar
    ) {
    }
}
