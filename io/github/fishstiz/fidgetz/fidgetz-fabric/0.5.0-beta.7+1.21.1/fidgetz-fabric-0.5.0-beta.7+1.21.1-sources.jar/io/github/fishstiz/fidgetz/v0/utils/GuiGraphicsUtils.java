package io.github.fishstiz.fidgetz.v0.utils;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class GuiGraphicsUtils {
    public static void sprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height) {
        graphics.method_52706(sprite, x, y, width, height);
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int uWidth,
            int vHeight,
            int textureWidth,
            int textureHeight
    ) {
        graphics.method_25293(
                texture,
                x,
                y,
                width,
                height,
                u,
                v,
                uWidth,
                vHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            float u,
            float v,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                u,
                v,
                width,
                height,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );
    }

    public static void texture(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            int width,
            int height,
            int textureWidth,
            int textureHeight
    ) {
        texture(
                graphics,
                texture,
                x,
                y,
                0,
                0,
                width, height,
                textureWidth, textureHeight
        );
    }

    public static void texture(class_332 graphics, class_2960 texture, int x, int y, int textureWidth, int textureHeight) {
        texture(graphics, texture, x, y, textureWidth, textureHeight, textureWidth, textureHeight);
    }

    public static void text(class_332 graphics, class_2561 text, int x, int y, int color) {
        graphics.method_27535(class_310.method_1551().field_1772, text, x, y, color);
    }

    public static void scrollingText(
            class_332 graphics,
            class_327 font,
            class_2561 component,
            int left,
            int top,
            int right,
            int bottom,
            int color,
            boolean shadow
    ) {
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_51439(font, component, left - (int) scrollOffset, textY, color, shadow);
            graphics.method_44380();
        } else {
            graphics.method_51439(font, component, left, textY, color, shadow);
        }
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color, boolean shadow) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color, shadow);
    }

    public static void scrollingText(class_332 graphics, class_327 font, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, font, component, left, top, right, bottom, color, true);
    }

    public static void scrollingText(class_332 graphics, class_2561 component, int left, int top, int right, int bottom, int color) {
        scrollingText(graphics, class_310.method_1551().field_1772, component, left, top, right, bottom, color);
    }

    public static void scrollingCenteredText(
            class_332 graphics,
            class_2561 component,
            int centerX,
            int left,
            int right,
            int top,
            int bottom,
            int color
    ) {
        class_327 font = class_310.method_1551().field_1772;
        int textWidth = font.method_27525(component);
        int textY = (top + bottom - font.field_2000) / 2 + 1;
        int availableWidth = right - left;

        if (textWidth > availableWidth) {
            int overflowWidth = textWidth - availableWidth;
            double timeSeconds = class_156.method_658() / 1000.0;
            double scrollDuration = Math.max(overflowWidth * 0.5, 3.0);
            double scrollFactor = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * timeSeconds / scrollDuration)) / 2.0 + 0.5;
            double scrollOffset = class_3532.method_16436(scrollFactor, 0.0, overflowWidth);

            graphics.method_44379(left, top, right, bottom);
            graphics.method_27535(font, component, left - (int) scrollOffset, textY, color);
            graphics.method_44380();
        } else {
            int i1 = class_3532.method_15340(centerX, left + textWidth / 2, right - textWidth / 2);
            graphics.method_27534(font, component, i1, textY, color);
        }
    }

    private GuiGraphicsUtils() {
    }
}
